<?php

session_start();

require_once "config/database.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: login.php");
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

if ($username === '' || $password === '') {
    header("Location: login.php?error=Please enter username and password.");
    exit;
}

/*
|--------------------------------------------------------------------------
| Find User
|--------------------------------------------------------------------------
*/

$sql = "SELECT id, username, password, full_name, role, status, expires_at
        FROM users
        WHERE username = ?
        LIMIT 1";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Database error.");
}

$stmt->bind_param("s", $username);

$stmt->execute();

$result = $stmt->get_result();

$user = $result->fetch_assoc();

$stmt->close();

/*
|--------------------------------------------------------------------------
| Check User
|--------------------------------------------------------------------------
*/

if (!$user) {
    header("Location: login.php?error=Invalid username or password.");
    exit;
}

/*
|--------------------------------------------------------------------------
| Check Account Status
|--------------------------------------------------------------------------
*/

if ($user['status'] !== 'active') {
    header("Location: login.php?error=Your account is inactive.");
    exit;
}

// Only the exact default account (ID 1 and username admin) is exempt.
$isDefaultAdmin = ((int)$user['id'] === 1 && $user['username'] === 'admin');
if (
    !$isDefaultAdmin &&
    !empty($user['expires_at']) &&
    strtotime($user['expires_at']) <= time()
) {
    header("Location: login.php?error=" . urlencode(
        "Your account has expired. Please contact the school administrator for renewal."
    ));
    exit;
}

/*
|--------------------------------------------------------------------------
| Verify Password
|--------------------------------------------------------------------------
*/

if (!password_verify($password, $user['password'])) {

    header("Location: login.php?error=Invalid username or password.");
    exit;
}

/*
|--------------------------------------------------------------------------
| Login Successful
|--------------------------------------------------------------------------
*/

session_regenerate_id(true);

$_SESSION['user_id'] = $user['id'];
$_SESSION['username'] = $user['username'];
$_SESSION['full_name'] = $user['full_name'];
$_SESSION['role'] = $user['role'];

/*
|--------------------------------------------------------------------------
| Redirect Based On Role
|--------------------------------------------------------------------------
*/

switch ($user['role']) {

    case 'administrator':

        header("Location: admin/dashboard.php");
        exit;

    case 'assistant_administrator':

        header("Location: assistant_admin/dashboard.php");
        exit;

    case 'bursar':

        header("Location: bursar/dashboard.php");
        exit;

    case 'teacher':

        header("Location: teacher/dashboard.php");
        exit;

    default:

        session_unset();
        session_destroy();

        header("Location: login.php?error=Invalid user role.");
        exit;
}

?>