<?php

$host = "localhost";
$username = "sserumedia";
$password = "med1a@2026";
$database = "sserumed_school_mgt";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
?>