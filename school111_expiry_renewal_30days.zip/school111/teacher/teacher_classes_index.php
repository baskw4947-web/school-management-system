<?php
/**
 * School Management System - Teacher: My Classes
 * Location: /teacher/teacher_classes_index.php
 *
 * Shows only the classes assigned to the signed-in teacher and students
 * belonging to those classes. In the supplied database, teacher allocation
 * is represented by class_timetables.teacher_name (there is no teacher_id
 * assignment table in the supplied SQL schema).
 */

require_once __DIR__ . '/../includes/auth.php';
requireRole(['teacher']);

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

$db = null;
$pageError = '';
$assignmentNotice = '';
$assignedClasses = [];
$studentsByClass = [];
$filteredStudentsByClass = [];
$totalAssignedStudents = 0;

try {
    require_once __DIR__ . '/../config/database.php';
    $db = $conn ?? ($mysqli ?? ($connection ?? null));
    if (!$db instanceof mysqli) {
        throw new RuntimeException('The database connection was not found. Check the existing config/database.php file.');
    }
    $db->set_charset('utf8mb4');
} catch (Throwable $e) {
    error_log('Teacher My Classes database setup: ' . $e->getMessage());
    $pageError = 'The database connection is unavailable. Please contact the system administrator.';
}

function teacherClassesE($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function teacherClassesIdent(string $name): string
{
    if (!preg_match('/^[A-Za-z0-9_]+$/', $name)) {
        throw new RuntimeException('An unexpected database column name was found.');
    }
    return '`' . $name . '`';
}

function teacherClassesColumns(mysqli $db, string $table): array
{
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) return [];
    $columns = [];
    $result = $db->query('SHOW COLUMNS FROM ' . teacherClassesIdent($table));
    while ($row = $result->fetch_assoc()) {
        $columns[strtolower((string)$row['Field'])] = (string)$row['Field'];
    }
    $result->free();
    return $columns;
}

function teacherClassesFirstColumn(array $columns, array $candidates): ?string
{
    foreach ($candidates as $candidate) {
        $key = strtolower((string)$candidate);
        if (isset($columns[$key])) return $columns[$key];
    }
    return null;
}

function teacherClassesNormalise(string $value): string
{
    $value = trim(preg_replace('/\s+/', ' ', $value) ?? $value);
    return function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
}

function teacherClassesFullName(array $row, array $columns): string
{
    foreach (['full_name', 'teacher_name', 'staff_name', 'employee_name', 'name'] as $candidate) {
        if (!empty($columns[$candidate]) && trim((string)($row[$columns[$candidate]] ?? '')) !== '') {
            return trim((string)$row[$columns[$candidate]]);
        }
    }
    $first = !empty($columns['first_name']) ? trim((string)($row[$columns['first_name']] ?? '')) : '';
    $other = !empty($columns['other_names']) ? trim((string)($row[$columns['other_names']] ?? '')) : '';
    $last = !empty($columns['last_name']) ? trim((string)($row[$columns['last_name']] ?? '')) : '';
    return trim(preg_replace('/\s+/', ' ', implode(' ', array_filter([$first, $other, $last], static fn($v) => $v !== ''))));
}

function teacherClassesAge($dateOfBirth): ?int
{
    $value = trim((string)($dateOfBirth ?? ''));
    if ($value === '' || $value === '0000-00-00') return null;
    try {
        $dob = new DateTime($value);
        return $dob->diff(new DateTime('today'))->y;
    } catch (Throwable $e) {
        return null;
    }
}

$userId = (int)($_SESSION['user_id'] ?? $_SESSION['id'] ?? 0);
$teacherId = (int)($_SESSION['teacher_id'] ?? $_SESSION['staff_id'] ?? 0);
$teacherDisplayName = trim((string)($_SESSION['teacher_name'] ?? $_SESSION['full_name'] ?? $_SESSION['name'] ?? 'Teacher'));

// Resolve the teacher profile and names used by the timetable assignments.
$teacherNameAliases = [];
$teacherProfile = null;
$teacherColumns = [];


if ($db instanceof mysqli) {
    try {
        $tablesResult = $db->query('SHOW TABLES');
        $availableTables = [];
        while ($tableRow = $tablesResult->fetch_row()) $availableTables[strtolower((string)$tableRow[0])] = (string)$tableRow[0];
        $tablesResult->free();

        if (isset($availableTables['teachers'])) {
            $teacherColumns = teacherClassesColumns($db, $availableTables['teachers']);
            $teacherPk = teacherClassesFirstColumn($teacherColumns, ['id', 'teacher_id']);
            $teacherUserCol = teacherClassesFirstColumn($teacherColumns, ['user_id', 'account_id', 'login_id', 'system_user_id']);

            if ($teacherId > 0 && $teacherPk) {
                $stmt = $db->prepare('SELECT * FROM ' . teacherClassesIdent($availableTables['teachers']) . ' WHERE ' . teacherClassesIdent($teacherPk) . ' = ? LIMIT 1');
                $stmt->bind_param('i', $teacherId);
                $stmt->execute();
                $teacherProfile = $stmt->get_result()->fetch_assoc() ?: null;
                $stmt->close();
            }

            if (!$teacherProfile && $userId > 0 && $teacherUserCol && $teacherPk) {
                $stmt = $db->prepare('SELECT * FROM ' . teacherClassesIdent($availableTables['teachers']) . ' WHERE ' . teacherClassesIdent($teacherUserCol) . ' = ? LIMIT 1');
                $stmt->bind_param('i', $userId);
                $stmt->execute();
                $teacherProfile = $stmt->get_result()->fetch_assoc() ?: null;
                $stmt->close();
            }

            // The supplied schema does not link users to teachers by ID. When
            // needed, match the logged-in full name to one unambiguous profile.
            if (!$teacherProfile && $teacherDisplayName !== '') {
                $teacherRowsResult = $db->query('SELECT * FROM ' . teacherClassesIdent($availableTables['teachers']));
                $matches = [];
                $firstNameMatches = [];
                while ($row = $teacherRowsResult->fetch_assoc()) {
                    $first = !empty($teacherColumns['first_name']) ? trim((string)($row[$teacherColumns['first_name']] ?? '')) : '';
                    if ($first !== '' && teacherClassesNormalise($first) === teacherClassesNormalise($teacherDisplayName)) {
                        $firstNameMatches[] = $row;
                    }
                    $nameParts = [];
                    $full = teacherClassesFullName($row, $teacherColumns);
                    if ($full !== '') $nameParts[] = $full;
                    $first = !empty($teacherColumns['first_name']) ? trim((string)($row[$teacherColumns['first_name']] ?? '')) : '';
                    $other = !empty($teacherColumns['other_names']) ? trim((string)($row[$teacherColumns['other_names']] ?? '')) : '';
                    $last = !empty($teacherColumns['last_name']) ? trim((string)($row[$teacherColumns['last_name']] ?? '')) : '';
                    if ($first !== '' && $last !== '') {
                        $nameParts[] = trim($first . ' ' . $last);
                        if ($other !== '') $nameParts[] = trim($first . ' ' . $other . ' ' . $last);
                    }
                    foreach ($nameParts as $namePart) {
                        if (teacherClassesNormalise($namePart) === teacherClassesNormalise($teacherDisplayName)) {
                            $matches[] = $row;
                            break;
                        }
                    }
                }
                $teacherRowsResult->free();
                if (count($matches) === 1) {
                    $teacherProfile = $matches[0];
                } elseif (count($matches) > 1) {
                    $assignmentNotice = 'More than one teacher profile has the same name as your login. Ask the administrator to link your user account to the correct teacher profile before viewing assigned classes.';
                } elseif (count($firstNameMatches) === 1) {
                    $teacherProfile = $firstNameMatches[0];
                }
            }
        }

        $addAlias = static function ($value) use (&$teacherNameAliases): void {
            $value = trim((string)($value ?? ''));
            if ($value === '') return;
            $normal = teacherClassesNormalise($value);
            foreach ($teacherNameAliases as $existing) {
                if (teacherClassesNormalise($existing) === $normal) return;
            }
            $teacherNameAliases[] = $value;
        };

        if ($teacherDisplayName !== '' && strcasecmp($teacherDisplayName, 'Teacher') !== 0) $addAlias($teacherDisplayName);
        if ($teacherProfile && $teacherColumns) {
            $addAlias(teacherClassesFullName($teacherProfile, $teacherColumns));
            foreach (['full_name', 'teacher_name', 'staff_name', 'employee_name', 'name'] as $candidate) {
                if (isset($teacherColumns[$candidate])) $addAlias($teacherProfile[$teacherColumns[$candidate]] ?? '');
            }
            $first = isset($teacherColumns['first_name']) ? trim((string)($teacherProfile[$teacherColumns['first_name']] ?? '')) : '';
            $other = isset($teacherColumns['other_names']) ? trim((string)($teacherProfile[$teacherColumns['other_names']] ?? '')) : '';
            $last = isset($teacherColumns['last_name']) ? trim((string)($teacherProfile[$teacherColumns['last_name']] ?? '')) : '';
            if ($first !== '' && $last !== '') {
                $addAlias($first . ' ' . $last);
                if ($other !== '') $addAlias($first . ' ' . $other . ' ' . $last);
            }
            // Some existing timetable forms populate the teacher dropdown
            // from teachers.first_name only. Use that alias only if it is unique.
            if ($first !== '' && isset($availableTables['teachers'])) {
                $countSql = 'SELECT COUNT(*) AS total FROM ' . teacherClassesIdent($availableTables['teachers']) . ' WHERE LOWER(TRIM(' . teacherClassesIdent($teacherColumns['first_name']) . ')) = LOWER(TRIM(?))';
                $countStmt = $db->prepare($countSql);
                $countStmt->bind_param('s', $first);
                $countStmt->execute();
                $firstCount = (int)($countStmt->get_result()->fetch_assoc()['total'] ?? 0);
                $countStmt->close();
                if ($firstCount === 1) $addAlias($first);
            }
        }

        if (isset($availableTables['class_timetables']) && $teacherNameAliases && $assignmentNotice === '') {
            $ttColumns = teacherClassesColumns($db, $availableTables['class_timetables']);
            $ttTeacherCol = teacherClassesFirstColumn($ttColumns, ['teacher_name', 'teacher', 'staff_name']);
            $ttClassCol = teacherClassesFirstColumn($ttColumns, ['class_name', 'class']);
            $ttStreamCol = teacherClassesFirstColumn($ttColumns, ['stream', 'section']);
            $ttYearCol = teacherClassesFirstColumn($ttColumns, ['academic_year', 'year']);
            $ttStatusCol = teacherClassesFirstColumn($ttColumns, ['status']);

            if ($ttTeacherCol && $ttClassCol && isset($availableTables['classes'])) {
                $namePlaceholders = implode(',', array_fill(0, count($teacherNameAliases), '?'));
                $sql = 'SELECT DISTINCT ' . teacherClassesIdent($ttClassCol) . ' AS assigned_class'
                     . ($ttStreamCol ? ', ' . teacherClassesIdent($ttStreamCol) . ' AS assigned_stream' : ", '' AS assigned_stream")
                     . ($ttYearCol ? ', ' . teacherClassesIdent($ttYearCol) . ' AS assigned_year' : ", '' AS assigned_year")
                     . ' FROM ' . teacherClassesIdent($availableTables['class_timetables'])
                     . ' WHERE LOWER(TRIM(' . teacherClassesIdent($ttTeacherCol) . ')) IN (' . $namePlaceholders . ')';
                if ($ttStatusCol) $sql .= " AND LOWER(TRIM(" . teacherClassesIdent($ttStatusCol) . ")) = 'active'";
                $stmt = $db->prepare($sql);
                $normalAliases = array_map('teacherClassesNormalise', $teacherNameAliases);
                $types = str_repeat('s', count($normalAliases));
                $bind = [$types];
                foreach ($normalAliases as $key => &$alias) $bind[] = &$alias;
                unset($alias);
                call_user_func_array([$stmt, 'bind_param'], $bind);
                $stmt->execute();
                $assignmentResult = $stmt->get_result();

                $classesTable = $availableTables['classes'];
                $classColumns = teacherClassesColumns($db, $classesTable);
                $classIdCol = teacherClassesFirstColumn($classColumns, ['id', 'class_id']);
                $classNameCol = teacherClassesFirstColumn($classColumns, ['class_name', 'name']);
                $classSectionCol = teacherClassesFirstColumn($classColumns, ['section', 'stream']);
                $classYearCol = teacherClassesFirstColumn($classColumns, ['academic_year', 'year']);
                $classStatusCol = teacherClassesFirstColumn($classColumns, ['status']);

                if ($classIdCol && $classNameCol) {
                    $classRowsResult = $db->query('SELECT * FROM ' . teacherClassesIdent($classesTable) . ($classStatusCol ? ' WHERE LOWER(TRIM(' . teacherClassesIdent($classStatusCol) . ")) = 'active'" : ''));
                    $allClassRows = [];
                    while ($classRow = $classRowsResult->fetch_assoc()) $allClassRows[] = $classRow;
                    $classRowsResult->free();

                    while ($assignment = $assignmentResult->fetch_assoc()) {
                        $assignedClassName = trim((string)$assignment['assigned_class']);
                        $assignedStream = trim((string)($assignment['assigned_stream'] ?? ''));
                        $assignedYear = trim((string)($assignment['assigned_year'] ?? ''));
                        if ($assignedClassName === '') continue;
                        foreach ($allClassRows as $classRow) {
                            if (teacherClassesNormalise((string)($classRow[$classNameCol] ?? '')) !== teacherClassesNormalise($assignedClassName)) continue;
                            $dbStream = $classSectionCol ? trim((string)($classRow[$classSectionCol] ?? '')) : '';
                            $dbYear = $classYearCol ? trim((string)($classRow[$classYearCol] ?? '')) : '';
                            // A timetable stream/year narrows the allocation when
                            // the matching class record stores those values.
                            if ($assignedStream !== '' && $dbStream !== '' && teacherClassesNormalise($dbStream) !== teacherClassesNormalise($assignedStream)) continue;
                            if ($assignedYear !== '' && $dbYear !== '' && teacherClassesNormalise($dbYear) !== teacherClassesNormalise($assignedYear)) continue;
                            $classId = (int)$classRow[$classIdCol];
                            $key = (string)$classId;
                            if (!isset($assignedClasses[$key])) {
                                $classRow['_class_id'] = $classId;
                                $classRow['_class_name'] = (string)($classRow[$classNameCol] ?? '');
                                $classRow['_class_section'] = $dbStream !== '' ? $dbStream : $assignedStream;
                                $classRow['_academic_year'] = $dbYear !== '' ? $dbYear : $assignedYear;
                                $assignedClasses[$key] = $classRow;
                            }
                        }
                    }
                    $classRowsResult = null;
                }
                $assignmentResult->free();
                $stmt->close();
            } else {
                $assignmentNotice = 'The class timetable or classes table is missing required class/teacher columns. Ask the administrator to review the timetable setup.';
            }
        } elseif (!isset($availableTables['class_timetables'])) {
            $assignmentNotice = 'No class timetable allocation table was found. Ask the administrator to assign you to classes in the school timetable.';
        } elseif (!$teacherNameAliases) {
            $assignmentNotice = 'Your login name could not be matched to a teacher name. Ask the administrator to check your teacher profile and timetable teacher name.';
        }

        if (!$assignedClasses && $assignmentNotice === '') {
            $assignmentNotice = 'No active classes are currently assigned to your teacher account. Ask the administrator to add your name to the class timetable.';
        }

        // Load students only for the class IDs assigned to this teacher.
        if ($assignedClasses && isset($availableTables['students'])) {
            $studentTable = $availableTables['students'];
            $studentColumns = teacherClassesColumns($db, $studentTable);
            $studentClassCol = teacherClassesFirstColumn($studentColumns, ['class_id']);
            $studentIdCol = teacherClassesFirstColumn($studentColumns, ['id', 'student_id']);
            $firstNameCol = teacherClassesFirstColumn($studentColumns, ['first_name']);
            $lastNameCol = teacherClassesFirstColumn($studentColumns, ['last_name']);
            if ($studentClassCol && $studentIdCol) {
                $classIds = array_map(static fn($row) => (int)$row['_class_id'], array_values($assignedClasses));
                $classIdPlaceholders = implode(',', array_fill(0, count($classIds), '?'));
                $sql = 'SELECT s.*';
                $guardianTable = $availableTables['guardians'] ?? null;
                $guardianColumns = $guardianTable ? teacherClassesColumns($db, $guardianTable) : [];
                $studentGuardianCol = teacherClassesFirstColumn($studentColumns, ['guardian_id']);
                $guardianIdCol = teacherClassesFirstColumn($guardianColumns, ['id', 'guardian_id']);
                $guardianNameCol = teacherClassesFirstColumn($guardianColumns, ['full_name', 'guardian_name', 'name']);
                $guardianPhoneCol = teacherClassesFirstColumn($guardianColumns, ['phone', 'phone_number', 'mobile']);
                if ($guardianTable && $studentGuardianCol && $guardianIdCol) {
                    if ($guardianNameCol) $sql .= ', g.' . teacherClassesIdent($guardianNameCol) . ' AS _guardian_name';
                    if ($guardianPhoneCol) $sql .= ', g.' . teacherClassesIdent($guardianPhoneCol) . ' AS _guardian_phone';
                    $sql .= ' FROM ' . teacherClassesIdent($studentTable) . ' s LEFT JOIN ' . teacherClassesIdent($guardianTable) . ' g ON s.' . teacherClassesIdent($studentGuardianCol) . ' = g.' . teacherClassesIdent($guardianIdCol);
                } else {
                    $sql .= ' FROM ' . teacherClassesIdent($studentTable) . ' s';
                }
                $sql .= ' WHERE s.' . teacherClassesIdent($studentClassCol) . ' IN (' . $classIdPlaceholders . ')';
                $order = [];
                if ($lastNameCol) $order[] = 's.' . teacherClassesIdent($lastNameCol) . ' ASC';
                if ($firstNameCol) $order[] = 's.' . teacherClassesIdent($firstNameCol) . ' ASC';
                if ($order) $sql .= ' ORDER BY ' . implode(', ', $order);
                $studentStmt = $db->prepare($sql);
                $bind = [str_repeat('i', count($classIds))];
                foreach ($classIds as $key => &$classIdValue) $bind[] = &$classIdValue;
                unset($classIdValue);
                call_user_func_array([$studentStmt, 'bind_param'], $bind);
                $studentStmt->execute();
                $studentResult = $studentStmt->get_result();
                while ($student = $studentResult->fetch_assoc()) {
                    $classId = (int)($student[$studentClassCol] ?? 0);
                    $studentsByClass[(string)$classId][] = $student;
                }
                $studentResult->free();
                $studentStmt->close();
            }
        }
    } catch (Throwable $e) {
        error_log('Teacher My Classes page error: ' . $e->getMessage());
        $pageError = 'The My Classes page could not load the class or student records. Check the PHP error log for details.';
    }
}

// Filters are applied only after the teacher's own class allocation has been
// resolved. They can never broaden the result to classes owned by other staff.
$filterClassId = max(0, (int)($_GET['class_id'] ?? 0));
$filterSearch = trim((string)($_GET['q'] ?? ''));
$filterGender = trim((string)($_GET['gender'] ?? ''));
$filterStudentSection = trim((string)($_GET['student_section'] ?? ''));
$filterStudentStatus = trim((string)($_GET['student_status'] ?? ''));
$minAge = (isset($_GET['min_age']) && $_GET['min_age'] !== '') ? max(0, min(120, (int)$_GET['min_age'])) : null;
$maxAge = (isset($_GET['max_age']) && $_GET['max_age'] !== '') ? max(0, min(120, (int)$_GET['max_age'])) : null;

foreach ($assignedClasses as $key => $classRow) {
    $classId = (int)$classRow['_class_id'];
    if ($filterClassId > 0 && $classId !== $filterClassId) continue;
    $classStudents = $studentsByClass[(string)$classId] ?? [];
    $filtered = [];
    foreach ($classStudents as $student) {
        $gender = (string)($student['gender'] ?? '');
        if ($filterGender !== '' && strcasecmp($gender, $filterGender) !== 0) continue;
        $studentSection = (string)($student['student_section'] ?? $student['residence_type'] ?? $student['boarding_status'] ?? '');
        if ($filterStudentSection !== '' && strcasecmp($studentSection, $filterStudentSection) !== 0) continue;
        $status = (string)($student['status'] ?? '');
        if ($filterStudentStatus !== '' && strcasecmp($status, $filterStudentStatus) !== 0) continue;
        $age = teacherClassesAge($student['date_of_birth'] ?? null);
        if ($minAge !== null && ($age === null || $age < $minAge)) continue;
        if ($maxAge !== null && ($age === null || $age > $maxAge)) continue;
        $searchHaystack = implode(' ', [
            $student['first_name'] ?? '', $student['last_name'] ?? '', $student['other_names'] ?? '',
            $student['admission_no'] ?? '', $student['lin_no'] ?? '', $student['student_payment_code'] ?? '',
            $student['_guardian_name'] ?? '', $student['_guardian_phone'] ?? ''
        ]);
        if ($filterSearch !== '' && stripos($searchHaystack, $filterSearch) === false) continue;
        $student['_display_age'] = $age;
        $student['_display_section'] = $studentSection;
        $filtered[] = $student;
    }
    $filteredStudentsByClass[$key] = $filtered;
    $totalAssignedStudents += count($filtered);
}

$totalAssignedClasses = count($assignedClasses);
$totalFilteredStudents = array_sum(array_map('count', $filteredStudentsByClass));

$genderOptions = ['Male', 'Female', 'Other'];
$studentSectionOptions = ['Day', 'Boarding'];
$statusOptions = ['active' => 'Active', 'inactive' => 'Inactive'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Classes | School Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root { --teacher-navy: #172b4d; --teacher-navy-dark: #10213d; --teacher-blue: #007bff; --page-bg: #f4f6f9; }
        body { background: var(--page-bg); font-family: Arial, sans-serif; color: #243247; }
        .sidebar { position: fixed; left: 0; top: 0; bottom: 0; width: 250px; background: var(--teacher-navy); color: #fff; overflow-y: auto; z-index: 1050; transition: left .22s ease; }
        .sidebar-brand { padding: 25px 18px; background: var(--teacher-navy-dark); text-align: center; font-size: 20px; font-weight: 700; }
        .sidebar-subtitle { display: block; color: #aebbd0; font-size: 12px; font-weight: 400; margin-top: 5px; }
        .sidebar-menu { padding: 15px 10px; }
        .menu-title { color: #8998ad; font-size: 11px; letter-spacing: .7px; text-transform: uppercase; padding: 14px 15px 8px; }
        .sidebar-menu a { display: block; color: #d8e0eb; padding: 12px 15px; margin-bottom: 5px; border-radius: 6px; text-decoration: none; transition: .18s; }
        .sidebar-menu a:hover, .sidebar-menu a.active { background: var(--teacher-blue); color: #fff; }
        .sidebar-menu i { width: 25px; }
        .main-content { margin-left: 250px; min-height: 100vh; }
        .topbar { background: #fff; padding: 15px 25px; box-shadow: 0 2px 8px rgba(0,0,0,.07); display: flex; justify-content: space-between; align-items: center; gap: 15px; }
        .topbar h4 { margin: 0; font-weight: 600; }
        .topbar-user { color: #495057; white-space: nowrap; }
        .content { padding: 24px; }
        .page-heading, .filter-panel, .class-panel { background: #fff; border-radius: 10px; box-shadow: 0 3px 12px rgba(0,0,0,.055); }
        .page-heading { padding: 22px 24px; margin-bottom: 20px; }
        .page-heading h2 { font-size: 23px; margin: 0 0 6px; font-weight: 700; }
        .page-heading p { margin: 0; color: #6c757d; }
        .summary-card { border: 0; border-radius: 10px; box-shadow: 0 3px 12px rgba(0,0,0,.07); height: 100%; }
        .summary-icon { width: 48px; height: 48px; border-radius: 10px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 20px; margin-right: 13px; flex-shrink: 0; }
        .summary-value { font-size: 24px; line-height: 1.1; font-weight: 700; margin: 0; }
        .summary-label { color: #6c757d; font-size: 13px; }
        .filter-panel { padding: 19px; margin-bottom: 22px; }
        .filter-panel label { font-size: 13px; font-weight: 600; }
        .form-control, .custom-select, .btn { border-radius: 6px; }
        .class-panel { margin-bottom: 22px; overflow: hidden; }
        .class-panel-header { padding: 17px 20px; border-bottom: 1px solid #e9edf3; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
        .class-title { font-size: 18px; font-weight: 700; margin: 0; }
        .class-meta { color: #6c757d; font-size: 13px; margin-top: 4px; }
        .class-count { background: #eaf2ff; color: #1558a6; border-radius: 20px; padding: 6px 11px; font-size: 12px; font-weight: 700; }
        .class-body { padding: 0 18px 15px; }
        .table { margin-bottom: 0; }
        .table thead th { background: #f8f9fb; color: #596579; border-top: 0; font-size: 12px; text-transform: uppercase; white-space: nowrap; }
        .table td { vertical-align: middle; font-size: 13px; }
        .student-name { font-weight: 700; color: #26364a; }
        .student-sub { color: #7b8796; font-size: 11px; }
        .pill { display: inline-block; padding: 4px 8px; border-radius: 20px; font-size: 11px; font-weight: 700; background: #eef2f7; color: #526174; }
        .pill-day { background: #e8f4ff; color: #1764a3; }
        .pill-boarding { background: #e8f7ef; color: #167346; }
        .empty-state { padding: 35px 15px; text-align: center; color: #6c757d; }
        .empty-state i { font-size: 34px; color: #b7c1ce; margin-bottom: 10px; }
        .sidebar-overlay { display: none; }
        .mobile-menu-button { display: none; border: 0; background: transparent; font-size: 20px; color: #fff; padding: 0 10px 0 0; }
        @media (max-width: 991px) {
            .sidebar { left: -260px; }
            .sidebar.show { left: 0; }
            .sidebar-overlay.show { display: block; position: fixed; inset: 0; background: rgba(0,0,0,.45); z-index: 1040; }
            .main-content { margin-left: 0; }
            .mobile-menu-button { display: inline-block; }
            .topbar { padding: 13px 16px; }
            .content { padding: 16px; }
        }
        @media (max-width: 575px) {
            .topbar h4 { font-size: 17px; }
            .topbar-user { font-size: 12px; }
            .page-heading { padding: 18px; }
            .page-heading h2 { font-size: 20px; }
            .class-body { padding: 0 10px 12px; }
        }
    </style>
<link rel="stylesheet" href="/assets/css/admin-theme.css?v=20261114">
</head>
<body>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<aside class="sidebar" id="sidebar">
    <div class="sidebar-brand"><i class="fas fa-school mr-2"></i>School Management<span class="sidebar-subtitle">Teacher Workspace</span></div>
    <nav class="sidebar-menu">
        <div class="menu-title">Main</div>
        <a href="/teacher/dashboard.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
        <a href="/teacher/teacher_classes_index.php" class="active"><i class="fas fa-chalkboard"></i>My Classes</a>
        <div class="menu-title">Account</div>
        <a href="/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
    </nav>
</aside>

<div class="main-content">
    <header class="topbar">
        <div class="d-flex align-items-center">
            <button type="button" class="mobile-menu-button" id="mobileMenuButton" aria-label="Open menu"><i class="fas fa-bars"></i></button>
            <h4><i class="fas fa-chalkboard text-primary mr-2"></i>My Classes</h4>
        </div>
        <div class="topbar-user"><i class="fas fa-user-circle mr-1"></i><?= teacherClassesE($teacherDisplayName) ?> <a href="/logout.php" class="btn btn-sm btn-outline-danger ml-2">Logout</a></div>
    </header>

    <main class="content">
        <?php if ($pageError !== ''): ?>
            <div class="alert alert-danger"><?= teacherClassesE($pageError) ?></div>
        <?php endif; ?>
        <?php if ($assignmentNotice !== ''): ?>
            <div class="alert alert-info"><i class="fas fa-info-circle mr-1"></i><?= teacherClassesE($assignmentNotice) ?></div>
        <?php endif; ?>

        <section class="page-heading">
            <h2><i class="fas fa-chalkboard-teacher text-primary mr-2"></i>My Class Assignments</h2>
            <p>View only the classes allocated to your teacher account and the students registered in each class.</p>
        </section>

        <div class="row mb-4">
            <div class="col-md-6 mb-3">
                <div class="card summary-card"><div class="card-body d-flex align-items-center">
                    <div class="summary-icon" style="background:#007bff"><i class="fas fa-chalkboard"></i></div>
                    <div><div class="summary-label">My assigned classes</div><div class="summary-value"><?= number_format($totalAssignedClasses) ?></div></div>
                </div></div>
            </div>
            <div class="col-md-6 mb-3">
                <div class="card summary-card"><div class="card-body d-flex align-items-center">
                    <div class="summary-icon" style="background:#28a745"><i class="fas fa-user-graduate"></i></div>
                    <div><div class="summary-label">Students in my classes (current filters)</div><div class="summary-value"><?= number_format($totalFilteredStudents) ?></div></div>
                </div></div>
            </div>
        </div>

        <section class="filter-panel">
            <form method="get" action="teacher_classes_index.php">
                <div class="d-flex justify-content-between align-items-center flex-wrap mb-3">
                    <h5 class="mb-0"><i class="fas fa-filter text-primary mr-2"></i>Filter my classes and students</h5>
                    <small class="text-muted">Filters apply only to your own assignments</small>
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-4 col-md-6">
                        <label for="q">Search student</label>
                        <input type="search" class="form-control" id="q" name="q" value="<?= teacherClassesE($filterSearch) ?>" placeholder="Name, admission, LIN, payment code or guardian phone">
                    </div>
                    <div class="form-group col-lg-2 col-md-6">
                        <label for="class_id">Assigned class</label>
                        <select class="custom-select" id="class_id" name="class_id">
                            <option value="0">All my classes</option>
                            <?php foreach ($assignedClasses as $class): ?>
                                <option value="<?= (int)$class['_class_id'] ?>" <?= $filterClassId === (int)$class['_class_id'] ? 'selected' : '' ?>><?= teacherClassesE($class['_class_name'] . ($class['_class_section'] !== '' ? ' - ' . $class['_class_section'] : '') . ($class['_academic_year'] !== '' ? ' (' . $class['_academic_year'] . ')' : '')) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-lg-2 col-md-4">
                        <label for="gender">Sex</label>
                        <select class="custom-select" id="gender" name="gender"><option value="">All</option><?php foreach ($genderOptions as $gender): ?><option value="<?= teacherClassesE($gender) ?>" <?= $filterGender === $gender ? 'selected' : '' ?>><?= teacherClassesE($gender) ?></option><?php endforeach; ?></select>
                    </div>
                    <div class="form-group col-lg-2 col-md-4">
                        <label for="student_section">Day / Boarding</label>
                        <select class="custom-select" id="student_section" name="student_section"><option value="">All</option><?php foreach ($studentSectionOptions as $section): ?><option value="<?= teacherClassesE($section) ?>" <?= strcasecmp($filterStudentSection, $section) === 0 ? 'selected' : '' ?>><?= teacherClassesE($section) ?></option><?php endforeach; ?></select>
                    </div>
                    <div class="form-group col-lg-2 col-md-4">
                        <label for="student_status">Student status</label>
                        <select class="custom-select" id="student_status" name="student_status"><option value="">All</option><?php foreach ($statusOptions as $value => $label): ?><option value="<?= teacherClassesE($value) ?>" <?= $filterStudentStatus === $value ? 'selected' : '' ?>><?= teacherClassesE($label) ?></option><?php endforeach; ?></select>
                    </div>
                    <div class="form-group col-md-2">
                        <label for="min_age">Minimum age</label>
                        <input type="number" min="0" max="120" class="form-control" id="min_age" name="min_age" value="<?= $minAge === null ? '' : (int)$minAge ?>" placeholder="From">
                    </div>
                    <div class="form-group col-md-2">
                        <label for="max_age">Maximum age</label>
                        <input type="number" min="0" max="120" class="form-control" id="max_age" name="max_age" value="<?= $maxAge === null ? '' : (int)$maxAge ?>" placeholder="To">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-search mr-1"></i>Apply Filters</button>
                <a href="teacher_classes_index.php" class="btn btn-outline-secondary ml-1">Clear Filters</a>
            </form>
        </section>

        <?php if ($assignedClasses && $filteredStudentsByClass): ?>
            <?php foreach ($assignedClasses as $key => $class): if ($filterClassId > 0 && $filterClassId !== (int)$class['_class_id']) continue; $classStudents = $filteredStudentsByClass[$key] ?? []; ?>
                <section class="class-panel" id="class-<?= (int)$class['_class_id'] ?>">
                    <div class="class-panel-header">
                        <div>
                            <h5 class="class-title"><i class="fas fa-chalkboard text-primary mr-2"></i><?= teacherClassesE($class['_class_name']) ?><?= $class['_class_section'] !== '' ? ' <span class="text-muted">/ ' . teacherClassesE($class['_class_section']) . '</span>' : '' ?></h5>
                            <div class="class-meta">Academic year: <?= teacherClassesE($class['_academic_year'] !== '' ? $class['_academic_year'] : 'Not specified') ?></div>
                        </div>
                        <span class="class-count"><?= number_format(count($classStudents)) ?> student(s)</span>
                    </div>
                    <div class="class-body">
                        <?php if (!$classStudents): ?>
                            <div class="empty-state"><i class="fas fa-user-graduate d-block"></i>No students match the selected filters in this class.</div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead><tr><th>#</th><th>Student</th><th>Admission No.</th><th>LIN No.</th><th>Student Payment Code</th><th>Sex</th><th>Age</th><th>Day / Boarding</th><th>Guardian Phone</th></tr></thead>
                                    <tbody>
                                    <?php foreach ($classStudents as $index => $student):
                                        $studentName = trim(implode(' ', array_filter([
                                            $student['first_name'] ?? '',
                                            $student['other_names'] ?? '',
                                            $student['last_name'] ?? ''
                                        ], static fn($v) => trim((string)$v) !== '')));
                                        $residence = trim((string)($student['_display_section'] ?? ''));
                                    ?>
                                        <tr>
                                            <td><?= $index + 1 ?></td>
                                            <td><span class="student-name"><?= teacherClassesE($studentName !== '' ? $studentName : 'Student') ?></span></td>
                                            <td><?= teacherClassesE($student['admission_no'] ?? '—') ?></td>
                                            <td><?= teacherClassesE($student['lin_no'] ?? '—') ?></td>
                                            <td><?= teacherClassesE($student['student_payment_code'] ?? '—') ?></td>
                                            <td><?= teacherClassesE($student['gender'] ?? '—') ?></td>
                                            <td><?= $student['_display_age'] === null ? '—' : (int)$student['_display_age'] ?></td>
                                            <td><?php if ($residence !== ''): ?><span class="pill <?= strcasecmp($residence, 'Boarding') === 0 ? 'pill-boarding' : 'pill-day' ?>"><?= teacherClassesE($residence) ?></span><?php else: ?>—<?php endif; ?></td>
                                            <td><?= teacherClassesE($student['_guardian_phone'] ?? '—') ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </section>
            <?php endforeach; ?>
        <?php elseif (!$pageError && !$assignmentNotice): ?>
            <div class="class-panel"><div class="empty-state"><i class="fas fa-chalkboard d-block"></i><strong>No assigned classes found</strong><div class="mt-1">There are no active class assignments linked to this teacher account.</div></div></div>
        <?php elseif ($assignedClasses && !$filteredStudentsByClass): ?>
            <div class="class-panel"><div class="empty-state"><i class="fas fa-filter d-block"></i>No classes match the selected filters.</div></div>
        <?php endif; ?>

        <div class="text-center text-muted mt-4"><small>School Management System &copy; <?= date('Y') ?></small></div>
    </main>
</div>

<script>
(function () {
    var sidebar = document.getElementById('sidebar');
    var overlay = document.getElementById('sidebarOverlay');
    var button = document.getElementById('mobileMenuButton');
    function closeMenu() {
        if (sidebar) sidebar.classList.remove('show');
        if (overlay) overlay.classList.remove('show');
    }
    if (button && sidebar) {
        button.addEventListener('click', function () {
            sidebar.classList.toggle('show');
            if (overlay) overlay.classList.toggle('show', sidebar.classList.contains('show'));
        });
    }
    if (overlay) overlay.addEventListener('click', closeMenu);
    document.addEventListener('keydown', function (event) { if (event.key === 'Escape') closeMenu(); });
    window.addEventListener('resize', function () { if (window.innerWidth > 991) closeMenu(); });
})();
</script>
</body>
</html>
