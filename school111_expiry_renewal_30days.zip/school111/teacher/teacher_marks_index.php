<?php
/**
 * Teacher Marks & Assessments
 * Location: /public_html/teacher/teacher_marks_index.php
 *
 * Uses the same authentication and MySQLi connection files as teacher/dashboard.php.
 * Assessment records are stored in teacher_assessment_marks (created automatically).
 */
require_once __DIR__ . '/../includes/auth.php';
requireRole(['teacher']);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$db = null;
try {
    require_once __DIR__ . '/../config/database.php';
    $db = $conn ?? ($mysqli ?? ($connection ?? null));
    if ($db instanceof mysqli) {
        $db->set_charset('utf8mb4');
    }
} catch (Throwable $e) {
    error_log('Teacher marks database connection: ' . $e->getMessage());
}

function tm_e($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}
function tm_table_exists(mysqli $db, string $table): bool {
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $table)) return false;
    $stmt = $db->prepare('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1');
    if (!$stmt) return false;
    $stmt->bind_param('s', $table);
    $stmt->execute();
    $exists = $stmt->get_result()->num_rows > 0;
    $stmt->close();
    return $exists;
}
function tm_columns(mysqli $db, string $table): array {
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $table) || !tm_table_exists($db, $table)) return [];
    $result = $db->query('SHOW COLUMNS FROM `' . $table . '`');
    $out = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) $out[strtolower($row['Field'])] = $row['Field'];
        $result->free();
    }
    return $out;
}
function tm_pick(array $columns, array $names): ?string {
    foreach ($names as $name) if (isset($columns[$name])) return $columns[$name];
    return null;
}
function tm_lookup_name(mysqli $db, array $tables, int $id, array $idNames, array $labelNames, string $fallback): string {
    foreach ($tables as $table) {
        $cols = tm_columns($db, $table);
        $pk = tm_pick($cols, $idNames);
        $label = tm_pick($cols, $labelNames);
        if (!$pk || !$label) continue;
        $sql = 'SELECT `' . $label . '` AS label FROM `' . $table . '` WHERE `' . $pk . '` = ? LIMIT 1';
        $stmt = $db->prepare($sql);
        if (!$stmt) continue;
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($row && trim((string)$row['label']) !== '') return (string)$row['label'];
    }
    return $fallback . ' #' . $id;
}

$userId = (int)($_SESSION['user_id'] ?? $_SESSION['id'] ?? 0);
$teacherId = (int)($_SESSION['teacher_id'] ?? $_SESSION['staff_id'] ?? 0);
$teacherName = (string)($_SESSION['full_name'] ?? $_SESSION['name'] ?? 'Teacher');
if ($teacherId <= 0 && $userId > 0 && $db instanceof mysqli && tm_table_exists($db, 'teachers')) {
    $tc = tm_columns($db, 'teachers');
    $pk = tm_pick($tc, ['id', 'teacher_id']);
    $uc = tm_pick($tc, ['user_id', 'account_id', 'login_id']);
    if ($pk && $uc) {
        $stmt = $db->prepare("SELECT `$pk` AS teacher_id FROM teachers WHERE `$uc` = ? LIMIT 1");
        if ($stmt) {
            $stmt->bind_param('i', $userId);
            $stmt->execute();
            $teacherId = (int)($stmt->get_result()->fetch_assoc()['teacher_id'] ?? 0);
            $stmt->close();
        }
    }
}

$notice = '';
$error = '';
$success = '';
$assignmentPairs = [];
$assignmentTable = null;
$assignmentTeacherColumn = null;
$assignmentTeacherValue = 0;
$assignmentClassColumn = null;
$assignmentSubjectColumn = null;
$studentColumns = [];
$studentPk = null;
$studentClassColumn = null;
$studentNameExpression = null;

if (!($db instanceof mysqli)) {
    $error = 'The database connection is unavailable. Check config/database.php.';
} elseif ($teacherId <= 0 && $userId <= 0) {
    $error = 'Your teacher account could not be identified. Please sign in again or contact the administrator.';
} else {
    // Keep the assignment table discovery consistent with teacher/dashboard.php.
    foreach (['teacher_classes', 'class_teachers', 'teacher_assignments', 'teacher_class_subjects', 'teacher_subjects', 'class_teacher_assignments'] as $candidate) {
        $cols = tm_columns($db, $candidate);
        if (!$cols) continue;
        $tcol = tm_pick($cols, ['teacher_id', 'staff_id', 'employee_id']);
        $tval = $teacherId;
        if (!$tcol || $tval <= 0) {
            $tcol = $cols['user_id'] ?? null;
            $tval = $userId;
        }
        $ccol = tm_pick($cols, ['class_id']);
        $scol = tm_pick($cols, ['subject_id']);
        if ($tcol && $tval > 0 && $ccol && $scol) {
            $assignmentTable = $candidate;
            $assignmentTeacherColumn = $tcol;
            $assignmentTeacherValue = $tval;
            $assignmentClassColumn = $ccol;
            $assignmentSubjectColumn = $scol;
            break;
        }
    }

    if (!$assignmentTable) {
        $error = 'A teacher assignment table containing teacher_id, class_id and subject_id could not be identified. Marks entry is disabled until class and subject allocations are configured.';
    } else {
        $sql = 'SELECT DISTINCT `' . $assignmentClassColumn . '` AS class_id, `' . $assignmentSubjectColumn . '` AS subject_id '
             . 'FROM `' . $assignmentTable . '` WHERE `' . $assignmentTeacherColumn . '` = ?';
        $stmt = $db->prepare($sql);
        if ($stmt) {
            $stmt->bind_param('i', $assignmentTeacherValue);
            $stmt->execute();
            $res = $stmt->get_result();
            while ($r = $res->fetch_assoc()) {
                $cid = (int)$r['class_id']; $sid = (int)$r['subject_id'];
                if ($cid > 0 && $sid > 0) $assignmentPairs[$cid . ':' . $sid] = ['class_id' => $cid, 'subject_id' => $sid];
            }
            $stmt->close();
        }
        if (!$assignmentPairs) $error = 'No class and subject allocations were found for your teacher account. Contact the administrator.';
    }

    $studentColumns = tm_columns($db, 'students');
    $studentPk = tm_pick($studentColumns, ['id', 'student_id']);
    $studentClassColumn = tm_pick($studentColumns, ['class_id']);
    $firstName = tm_pick($studentColumns, ['first_name', 'firstname', 'given_name']);
    $lastName = tm_pick($studentColumns, ['last_name', 'lastname', 'surname', 'family_name']);
    $fullName = tm_pick($studentColumns, ['full_name', 'student_name', 'name']);
    if ($fullName) $studentNameExpression = 's.`' . $fullName . '`';
    elseif ($firstName && $lastName) $studentNameExpression = "CONCAT(s.`$firstName`, ' ', s.`$lastName`)";
    elseif ($firstName) $studentNameExpression = 's.`' . $firstName . '`';

    if (!$studentPk || !$studentClassColumn || !$studentNameExpression) {
        $error = 'The students table must contain a student ID, class_id and a student name field before marks can be recorded.';
    }

    // Create a separate, auditable assessment table. Existing school tables are not altered.
    if (!$error) {
        $db->query("CREATE TABLE IF NOT EXISTS teacher_assessment_marks (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            teacher_id INT NOT NULL,
            student_id INT NOT NULL,
            class_id INT NOT NULL,
            subject_id INT NOT NULL,
            assessment_name VARCHAR(150) NOT NULL,
            assessment_type VARCHAR(60) NOT NULL DEFAULT 'Test',
            term VARCHAR(30) NOT NULL,
            academic_year VARCHAR(20) NOT NULL,
            max_marks DECIMAL(8,2) NOT NULL,
            marks_obtained DECIMAL(8,2) NOT NULL,
            remarks VARCHAR(500) NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_teacher_student (teacher_id, student_id),
            KEY idx_class_subject_term (class_id, subject_id, term, academic_year)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        if ($db->error) {
            error_log('Could not create teacher_assessment_marks: ' . $db->error);
            $error = 'The assessment marks table could not be prepared. Check database CREATE TABLE permissions.';
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$error && $db instanceof mysqli) {
    $postedToken = (string)($_POST['csrf_token'] ?? '');
    if (!hash_equals((string)($_SESSION['teacher_marks_csrf'] ?? ''), $postedToken)) {
        $error = 'Your session security token has expired. Refresh the page and try again.';
    } else {
        $action = (string)($_POST['action'] ?? 'save');
        $recordId = (int)($_POST['record_id'] ?? 0);
        $classId = (int)($_POST['class_id'] ?? 0);
        $subjectId = (int)($_POST['subject_id'] ?? 0);
        $studentId = (int)($_POST['student_id'] ?? 0);
        $pairKey = $classId . ':' . $subjectId;
        $assessmentName = trim((string)($_POST['assessment_name'] ?? ''));
        $assessmentType = trim((string)($_POST['assessment_type'] ?? 'Test'));
        $term = trim((string)($_POST['term'] ?? ''));
        $academicYear = trim((string)($_POST['academic_year'] ?? ''));
        $maxMarks = (float)($_POST['max_marks'] ?? 0);
        $obtained = (float)($_POST['marks_obtained'] ?? 0);
        $remarks = trim((string)($_POST['remarks'] ?? ''));

        if (!isset($assignmentPairs[$pairKey])) {
            $error = 'You are not assigned to the selected class and subject.';
        } elseif ($action === 'save' || $action === 'update') {
            if ($assessmentName === '' || $studentId <= 0 || $term === '' || $academicYear === '' || $maxMarks <= 0 || $obtained < 0 || $obtained > $maxMarks) {
                $error = 'Complete all required fields. Marks obtained must be between zero and the maximum marks.';
            } else {
                $checkSql = 'SELECT `' . $studentPk . '` AS id FROM students WHERE `' . $studentPk . '` = ? AND `' . $studentClassColumn . '` = ? LIMIT 1';
                $check = $db->prepare($checkSql);
                $check->bind_param('ii', $studentId, $classId);
                $check->execute();
                $validStudent = (bool)$check->get_result()->fetch_assoc();
                $check->close();
                if (!$validStudent) {
                    $error = 'The selected student is not in the selected class.';
                } elseif ($action === 'update' && $recordId > 0) {
                    $sql = "UPDATE teacher_assessment_marks SET student_id=?, class_id=?, subject_id=?, assessment_name=?, assessment_type=?, term=?, academic_year=?, max_marks=?, marks_obtained=?, remarks=? WHERE id=? AND teacher_id=?";
                    $stmt = $db->prepare($sql);
                    $stmt->bind_param('iiissssddsii', $studentId, $classId, $subjectId, $assessmentName, $assessmentType, $term, $academicYear, $maxMarks, $obtained, $remarks, $recordId, $assignmentTeacherValue);
                    if ($stmt->execute() && $stmt->affected_rows >= 0) $success = 'Assessment mark updated successfully.';
                    else $error = 'Unable to update the assessment mark.';
                    $stmt->close();
                } else {
                    $sql = "INSERT INTO teacher_assessment_marks (teacher_id, student_id, class_id, subject_id, assessment_name, assessment_type, term, academic_year, max_marks, marks_obtained, remarks) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
                    $stmt = $db->prepare($sql);
                    $stmt->bind_param('iiiissssdds', $assignmentTeacherValue, $studentId, $classId, $subjectId, $assessmentName, $assessmentType, $term, $academicYear, $maxMarks, $obtained, $remarks);
                    if ($stmt->execute()) $success = 'Assessment mark recorded successfully.';
                    else $error = 'Unable to record the assessment mark. It may already exist or the database rejected the entry.';
                    $stmt->close();
                }
            }
        }
    }
}

if (!isset($_SESSION['teacher_marks_csrf'])) $_SESSION['teacher_marks_csrf'] = bin2hex(random_bytes(32));
$csrf = (string)$_SESSION['teacher_marks_csrf'];

$filterClass = (int)($_GET['class_id'] ?? 0);
$filterSubject = (int)($_GET['subject_id'] ?? 0);
$filterTerm = trim((string)($_GET['term'] ?? ''));
$filterYear = trim((string)($_GET['academic_year'] ?? ''));
$edit = null;
$students = [];
$records = [];
$classOptions = [];
$subjectOptions = [];

if ($db instanceof mysqli && $assignmentPairs) {
    $classIds = []; $subjectIds = [];
    foreach ($assignmentPairs as $pair) {
        $classIds[$pair['class_id']] = true;
        $subjectIds[$pair['subject_id']] = true;
    }
    foreach (array_keys($classIds) as $id) $classOptions[$id] = tm_lookup_name($db, ['classes', 'school_classes', 'class'], (int)$id, ['id', 'class_id'], ['class_name', 'name', 'title'], 'Class');
    foreach (array_keys($subjectIds) as $id) $subjectOptions[$id] = tm_lookup_name($db, ['subjects', 'school_subjects'], (int)$id, ['id', 'subject_id'], ['subject_name', 'name', 'title'], 'Subject');

    if (!$filterClass || !isset($classOptions[$filterClass])) $filterClass = (int)array_key_first($classOptions);
    $allowedSubjects = [];
    foreach ($assignmentPairs as $pair) if ($pair['class_id'] === $filterClass) $allowedSubjects[$pair['subject_id']] = true;
    if (!$filterSubject || !isset($allowedSubjects[$filterSubject])) $filterSubject = (int)(array_key_first($allowedSubjects) ?: 0);

    if ($filterClass > 0 && $filterSubject > 0 && isset($assignmentPairs[$filterClass . ':' . $filterSubject])) {
        $sql = 'SELECT `' . $studentPk . '` AS id, ' . $studentNameExpression . ' AS student_name FROM students s WHERE s.`' . $studentClassColumn . '` = ? ORDER BY student_name';
        $stmt = $db->prepare($sql);
        $stmt->bind_param('i', $filterClass);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($r = $res->fetch_assoc()) $students[] = $r;
        $stmt->close();
    }

    if (isset($_GET['edit']) && ctype_digit((string)$_GET['edit'])) {
        $id = (int)$_GET['edit'];
        $stmt = $db->prepare('SELECT * FROM teacher_assessment_marks WHERE id=? AND teacher_id=? LIMIT 1');
        $stmt->bind_param('ii', $id, $assignmentTeacherValue);
        $stmt->execute();
        $candidate = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($candidate && isset($assignmentPairs[(int)$candidate['class_id'] . ':' . (int)$candidate['subject_id']])) {
            $edit = $candidate;
            $filterClass = (int)$candidate['class_id'];
            $filterSubject = (int)$candidate['subject_id'];
            $students = [];
            $sql = 'SELECT `' . $studentPk . '` AS id, ' . $studentNameExpression . ' AS student_name FROM students s WHERE s.`' . $studentClassColumn . '` = ? ORDER BY student_name';
            $stmt = $db->prepare($sql);
            $stmt->bind_param('i', $filterClass);
            $stmt->execute();
            $res = $stmt->get_result();
            while ($r = $res->fetch_assoc()) $students[] = $r;
            $stmt->close();
        }
    }

    $where = ['teacher_id = ?'];
    $types = 'i';
    $params = [$assignmentTeacherValue];
    if ($filterClass > 0) { $where[] = 'class_id = ?'; $types .= 'i'; $params[] = $filterClass; }
    if ($filterSubject > 0) { $where[] = 'subject_id = ?'; $types .= 'i'; $params[] = $filterSubject; }
    if ($filterTerm !== '') { $where[] = 'term = ?'; $types .= 's'; $params[] = $filterTerm; }
    if ($filterYear !== '') { $where[] = 'academic_year = ?'; $types .= 's'; $params[] = $filterYear; }
    $sql = 'SELECT * FROM teacher_assessment_marks WHERE ' . implode(' AND ', $where) . ' ORDER BY created_at DESC, id DESC LIMIT 300';
    $stmt = $db->prepare($sql);
    if ($stmt) {
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($r = $res->fetch_assoc()) {
            if (isset($assignmentPairs[(int)$r['class_id'] . ':' . (int)$r['subject_id']])) {
                $r['student_name'] = tm_lookup_name($db, ['students'], (int)$r['student_id'], ['id', 'student_id'], ['full_name', 'student_name', 'name'], 'Student');
                if (str_starts_with($r['student_name'], 'Student #')) {
                    $sc = tm_columns($db, 'students');
                    $fn = tm_pick($sc, ['first_name', 'firstname', 'given_name']);
                    $ln = tm_pick($sc, ['last_name', 'lastname', 'surname', 'family_name']);
                    if ($fn) {
                        $selectName = $ln ? "CONCAT(`$fn`, ' ', `$ln`)" : "`$fn`";
                        $ns = $db->prepare("SELECT $selectName AS n FROM students WHERE `" . tm_pick($sc, ['id', 'student_id']) . "`=?");
                        $ns->bind_param('i', $r['student_id']); $ns->execute();
                        $r['student_name'] = (string)($ns->get_result()->fetch_assoc()['n'] ?? $r['student_name']); $ns->close();
                    }
                }
                $r['class_name'] = $classOptions[(int)$r['class_id']] ?? ('Class #' . $r['class_id']);
                $r['subject_name'] = $subjectOptions[(int)$r['subject_id']] ?? ('Subject #' . $r['subject_id']);
                $records[] = $r;
            }
        }
        $stmt->close();
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Marks &amp; Assessments | Teacher</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.6.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
body{background:#f4f6f9;font-family:Arial,sans-serif;color:#263238}.sidebar{position:fixed;top:0;bottom:0;left:0;width:245px;background:#172b4d;color:#fff;overflow-y:auto}.brand{padding:24px 16px;background:#10213d;text-align:center;font-weight:700;font-size:19px}.nav-area{padding:16px 10px}.nav-area a{display:block;padding:12px 14px;margin-bottom:5px;color:#d8e0eb;border-radius:6px;text-decoration:none}.nav-area a:hover,.nav-area a.active{background:#007bff;color:#fff}.main{margin-left:245px;min-height:100vh}.topbar{background:#fff;padding:17px 25px;box-shadow:0 2px 8px #0000000d}.content{padding:25px}.panel{background:#fff;border:0;border-radius:10px;box-shadow:0 3px 12px #0000000c}.panel-head{padding:18px 20px;border-bottom:1px solid #edf0f3;font-weight:700}.panel-body{padding:20px}.form-control,.custom-select{min-height:40px}.table td,.table th{vertical-align:middle}.small-muted{color:#718096;font-size:13px}@media(max-width:768px){.sidebar{position:relative;width:100%;}.main{margin-left:0}.content{padding:15px}}
</style>
<link rel="stylesheet" href="/assets/css/admin-theme.css?v=20261114">
</head>
<body>
<aside class="sidebar">
 <div class="brand"><i class="fas fa-school mr-2"></i>School Management</div>
 <nav class="nav-area">
  <a href="/teacher/dashboard.php"><i class="fas fa-tachometer-alt mr-2"></i>Dashboard</a>
  <a href="/teacher/teacher_classes_index.php"><i class="fas fa-chalkboard mr-2"></i>My Classes</a>
  <a href="/teacher/teacher_subject_index.php"><i class="fas fa-book-open mr-2"></i>My Subjects</a>
  <a href="/teacher/teacher_attendance_index.php"><i class="fas fa-calendar-check mr-2"></i>Attendance</a>
  <a class="active" href="/teacher/teacher_marks_index.php"><i class="fas fa-clipboard-list mr-2"></i>Marks &amp; Assessments</a>
  <a href="/teacher/timetable.php"><i class="fas fa-calendar-alt mr-2"></i>Timetable</a>
  <a href="/logout.php"><i class="fas fa-sign-out-alt mr-2"></i>Logout</a>
 </nav>
</aside>
<main class="main">
 <header class="topbar d-flex justify-content-between align-items-center flex-wrap">
  <h4 class="mb-1"><i class="fas fa-clipboard-list text-primary mr-2"></i>Marks &amp; Assessments</h4>
  <span class="text-muted"><i class="fas fa-user-circle mr-1"></i><?=tm_e($teacherName)?></span>
 </header>
 <div class="content">
  <?php if ($error): ?><div class="alert alert-danger"><?=tm_e($error)?></div><?php endif; ?>
  <?php if ($success): ?><div class="alert alert-success"><?=tm_e($success)?></div><?php endif; ?>
  <div class="mb-4">
   <h5 class="font-weight-bold">Assessment workspace</h5>
   <p class="small-muted mb-0">Record, update and review marks for students in your assigned classes and subjects only.</p>
  </div>
  <?php if (!$error && $assignmentPairs): ?>
  <section class="panel mb-4">
   <div class="panel-head"><i class="fas fa-edit text-primary mr-2"></i><?= $edit ? 'Update assessment mark' : 'Record assessment mark' ?></div>
   <div class="panel-body">
    <form method="post" action="teacher_marks_index.php">
     <input type="hidden" name="csrf_token" value="<?=tm_e($csrf)?>">
     <input type="hidden" name="action" value="<?=$edit?'update':'save'?>">
     <?php if ($edit): ?><input type="hidden" name="record_id" value="<?=(int)$edit['id']?>"><?php endif; ?>
     <div class="form-row">
      <div class="form-group col-md-6"><label>Class *</label><select name="class_id" id="class_id" class="custom-select" required>
       <?php foreach($classOptions as $id=>$name): ?><option value="<?=(int)$id?>" <?=((int)($edit['class_id']??$filterClass)===(int)$id)?'selected':''?>><?=tm_e($name)?></option><?php endforeach; ?>
      </select></div>
      <div class="form-group col-md-6"><label>Subject *</label><select name="subject_id" id="subject_id" class="custom-select" required>
       <?php foreach($subjectOptions as $id=>$name): if(!isset($assignmentPairs[$filterClass.':'.$id]) && !$edit) continue; ?><option value="<?=(int)$id?>" <?=((int)($edit['subject_id']??$filterSubject)===(int)$id)?'selected':''?>><?=tm_e($name)?></option><?php endforeach; ?>
      </select></div>
      <div class="form-group col-md-6"><label>Student *</label><select name="student_id" class="custom-select" required><option value="">Select student</option>
       <?php foreach($students as $student): ?><option value="<?=(int)$student['id']?>" <?=((int)($edit['student_id']??0)===(int)$student['id'])?'selected':''?>><?=tm_e($student['student_name'])?></option><?php endforeach; ?>
      </select></div>
      <div class="form-group col-md-6"><label>Assessment name *</label><input class="form-control" name="assessment_name" maxlength="150" required placeholder="e.g. Mid-term test" value="<?=tm_e($edit['assessment_name']??'')?>"></div>
      <div class="form-group col-md-3"><label>Assessment type</label><select name="assessment_type" class="custom-select"><?php foreach(['Test','Quiz','Assignment','Coursework','Practical','Examination','Oral'] as $type): ?><option <?=((string)($edit['assessment_type']??'Test')===$type)?'selected':''?>><?=tm_e($type)?></option><?php endforeach; ?></select></div>
      <div class="form-group col-md-3"><label>Term *</label><select name="term" class="custom-select" required><?php foreach(['Term 1','Term 2','Term 3'] as $term): ?><option <?=((string)($edit['term']??'Term 1')===$term)?'selected':''?>><?=tm_e($term)?></option><?php endforeach; ?></select></div>
      <div class="form-group col-md-3"><label>Academic year *</label><input class="form-control" name="academic_year" maxlength="20" required placeholder="e.g. 2026" value="<?=tm_e($edit['academic_year']??date('Y'))?>"></div>
      <div class="form-group col-md-3"><label>Maximum marks *</label><input type="number" min="0.01" step="0.01" class="form-control" name="max_marks" required value="<?=tm_e($edit['max_marks']??100)?>"></div>
      <div class="form-group col-md-4"><label>Marks obtained *</label><input type="number" min="0" step="0.01" class="form-control" name="marks_obtained" required value="<?=tm_e($edit['marks_obtained']??'')?>"></div>
      <div class="form-group col-md-8"><label>Remarks (optional)</label><input class="form-control" name="remarks" maxlength="500" value="<?=tm_e($edit['remarks']??'')?>" placeholder="Teacher's comments"></div>
     </div>
     <button class="btn btn-primary" type="submit"><i class="fas fa-save mr-1"></i><?=$edit?'Update Mark':'Record Mark'?></button>
     <?php if($edit): ?><a href="teacher_marks_index.php" class="btn btn-light ml-2">Cancel</a><?php endif; ?>
    </form>
    <div class="small-muted mt-3">The student list is limited to the selected class. Class and subject combinations are checked against your teacher allocations before saving.</div>
   </div>
  </section>
  <section class="panel">
   <div class="panel-head"><i class="fas fa-history text-primary mr-2"></i>Previous assessments</div>
   <div class="panel-body">
    <form method="get" class="form-row align-items-end mb-3">
     <div class="form-group col-md-3"><label>Class</label><select name="class_id" class="custom-select"><?php foreach($classOptions as $id=>$name): ?><option value="<?=(int)$id?>" <?=($filterClass===(int)$id)?'selected':''?>><?=tm_e($name)?></option><?php endforeach; ?></select></div>
     <div class="form-group col-md-3"><label>Subject</label><select name="subject_id" class="custom-select"><option value="">All assigned subjects</option><?php foreach($subjectOptions as $id=>$name): ?><option value="<?=(int)$id?>" <?=($filterSubject===(int)$id)?'selected':''?>><?=tm_e($name)?></option><?php endforeach; ?></select></div>
     <div class="form-group col-md-2"><label>Term</label><select name="term" class="custom-select"><option value="">All terms</option><?php foreach(['Term 1','Term 2','Term 3'] as $t): ?><option <?=($filterTerm===$t)?'selected':''?>><?=tm_e($t)?></option><?php endforeach; ?></select></div>
     <div class="form-group col-md-2"><label>Academic year</label><input name="academic_year" class="form-control" value="<?=tm_e($filterYear)?>" placeholder="e.g. 2026"></div>
     <div class="form-group col-md-2"><button class="btn btn-outline-primary btn-block"><i class="fas fa-filter mr-1"></i>Filter</button></div>
    </form>
    <div class="table-responsive"><table class="table table-hover table-bordered">
     <thead class="thead-light"><tr><th>Student</th><th>Class</th><th>Subject</th><th>Assessment</th><th>Term / Year</th><th>Marks</th><th>Date</th><th>Action</th></tr></thead>
     <tbody>
     <?php if(!$records): ?><tr><td colspan="8" class="text-center text-muted py-4">No assessment records match these filters.</td></tr><?php else: foreach($records as $r): ?>
      <tr><td><?=tm_e($r['student_name'])?></td><td><?=tm_e($r['class_name'])?></td><td><?=tm_e($r['subject_name'])?></td><td><?=tm_e($r['assessment_name'])?><br><small class="text-muted"><?=tm_e($r['assessment_type'])?></small></td><td><?=tm_e($r['term'])?><br><small class="text-muted"><?=tm_e($r['academic_year'])?></small></td><td><strong><?=tm_e($r['marks_obtained'])?></strong> / <?=tm_e($r['max_marks'])?></td><td><?=tm_e(date('d M Y', strtotime($r['created_at'])))?></td><td><a class="btn btn-sm btn-outline-primary" href="?edit=<?=(int)$r['id']?>"><i class="fas fa-edit"></i> Edit</a></td></tr>
     <?php endforeach; endif; ?>
     </tbody>
    </table></div>
    <small class="text-muted">Showing up to 300 records belonging to your teacher account and current assignment scope.</small>
   </div>
  </section>
  <?php endif; ?>
  <div class="text-center text-muted mt-4"><small>School Management System &copy; <?=date('Y')?></small></div>
 </div>
</main>
<script>
(function(){
 const pairs = <?=json_encode(array_values($assignmentPairs), JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT)?>;
 const classSelect=document.getElementById('class_id'), subjectSelect=document.getElementById('subject_id');
 if(!classSelect||!subjectSelect)return;
 const subjectLabels={};
 <?php foreach($subjectOptions as $sid=>$sname): ?>subjectLabels[<?=json_encode((string)$sid)?>]=<?=json_encode($sname, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT)?>;<?php endforeach; ?>
 function refreshSubjects(){
   const cls=parseInt(classSelect.value,10), current=subjectSelect.value;
   const allowed=pairs.filter(p=>parseInt(p.class_id,10)===cls).map(p=>String(p.subject_id));
   subjectSelect.innerHTML='';
   allowed.forEach(id=>{if(!subjectLabels[id])return;const o=document.createElement('option');o.value=id;o.textContent=subjectLabels[id];subjectSelect.appendChild(o);});
   if(allowed.includes(current))subjectSelect.value=current;
 }
 classSelect.addEventListener('change',refreshSubjects);
})();
</script>
</body>
</html>
