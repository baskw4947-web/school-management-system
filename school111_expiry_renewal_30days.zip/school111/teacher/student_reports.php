<?php
/**
 * Teacher Attendance
 * Install as: public_html/teacher/teacher_attendance_index.php
 * Uses the existing classes, students and class_timetables tables.
 * Creates teacher_student_attendance on first use if it does not exist.
 */

error_reporting(E_ALL);
ini_set('display_errors', '0'); // Change to 1 temporarily only when debugging.

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';

requireLogin();
requireRole(['teacher']);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$conn = $conn ?? ($mysqli ?? ($connection ?? null));
if (!$conn instanceof mysqli) {
    http_response_code(500);
    exit('Database connection was not found. Check config/database.php.');
}
$conn->set_charset('utf8mb4');

if (empty($_SESSION['csrf_attendance'])) {
    $_SESSION['csrf_attendance'] = bin2hex(random_bytes(32));
}

function h($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function tableExists(mysqli $db, string $table): bool {
    $safe = $db->real_escape_string($table);
    $result = $db->query("SHOW TABLES LIKE '{$safe}'");
    return $result && $result->num_rows > 0;
}

function columnExists(mysqli $db, string $table, string $column): bool {
    $table = str_replace('`', '', $table);
    $column = $db->real_escape_string($column);
    $result = $db->query("SHOW COLUMNS FROM `{$table}` LIKE '{$column}'");
    return $result && $result->num_rows > 0;
}

$conn->set_charset('utf8mb4');

$teacherName = $_SESSION['full_name']
    ?? $_SESSION['name']
    ?? 'Teacher';

$userId = (int)(
    $_SESSION['user_id']
    ?? $_SESSION['id']
    ?? 0
);

$teacherId = (int)(
    $_SESSION['teacher_id']
    ?? $_SESSION['staff_id']
    ?? $_SESSION['employee_id']
    ?? 0
);

$pageError = '';
$reports = [];
$assignedClasses = [];
$classOptions = [];
$reportSubjects = [];
$selectedReport = null;

$search = trim($_GET['q'] ?? '');
$filterClass = trim($_GET['class'] ?? '');
$filterTerm = trim($_GET['term'] ?? '');
$filterYear = trim($_GET['year'] ?? '');
$viewId = (int)($_GET['view'] ?? 0);

/* -----------------------------------------------------
   HELPER FUNCTIONS
----------------------------------------------------- */

function trp_e($value)
{
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

function trp_columns($db, $table)
{
    $columns = [];

    $result = $db->query("SHOW COLUMNS FROM `$table`");

    while ($row = $result->fetch_assoc()) {
        $columns[strtolower($row['Field'])] = $row['Field'];
    }

    $result->free();

    return $columns;
}

function trp_pick($columns, $names)
{
    foreach ($names as $name) {
        if (isset($columns[strtolower($name)])) {
            return $columns[strtolower($name)];
        }
    }

    return null;
}

function trp_table_exists($db, $table)
{
    $stmt = $db->prepare(
        "SELECT 1
         FROM information_schema.TABLES
         WHERE TABLE_SCHEMA = DATABASE()
         AND TABLE_NAME = ?
         LIMIT 1"
    );

    $stmt->bind_param('s', $table);
    $stmt->execute();
    $stmt->store_result();

    $exists = $stmt->num_rows > 0;

    $stmt->close();

    return $exists;
}

/**
 * Fetch rows without requiring mysqlnd/get_result().
 */
function trp_rows($stmt)
{
    $metadata = $stmt->result_metadata();

    if (!$metadata) {
        return [];
    }

    $fields = $metadata->fetch_fields();

    $row = [];
    $bindings = [];

    foreach ($fields as $field) {
        $row[$field->name] = null;
        $bindings[] = &$row[$field->name];
    }

    call_user_func_array(
        [$stmt, 'bind_result'],
        $bindings
    );

    $rows = [];

    while ($stmt->fetch()) {
        $copy = [];

        foreach ($row as $key => $value) {
            $copy[$key] = $value;
        }

        $rows[] = $copy;
    }

    $metadata->free();

    return $rows;
}

function trp_normalize($value)
{
    $value = strtolower(trim((string)$value));

    $value = preg_replace('/\s+/', ' ', $value);

    return $value;
}

function trp_lookup(
    $db,
    $tables,
    $id,
    $idNames,
    $nameNames
) {
    $id = (int)$id;

    if ($id <= 0) {
        return '';
    }

    foreach ($tables as $table) {

        if (!trp_table_exists($db, $table)) {
            continue;
        }

        $columns = trp_columns($db, $table);

        $idColumn = trp_pick($columns, $idNames);
        $nameColumn = trp_pick($columns, $nameNames);

        if (!$idColumn || !$nameColumn) {
            continue;
        }

        $stmt = $db->prepare(
            "SELECT `$nameColumn` AS item_name
             FROM `$table`
             WHERE `$idColumn` = ?
             LIMIT 1"
        );

        $stmt->bind_param('i', $id);
        $stmt->execute();

        $rows = trp_rows($stmt);

        $stmt->close();

        if (!empty($rows[0]['item_name'])) {
            return $rows[0]['item_name'];
        }
    }

    return '';
}

/* -----------------------------------------------------
   LOAD TEACHER'S ASSIGNED CLASSES
----------------------------------------------------- */

try {

    if (!trp_table_exists($conn, 'class_timetables')) {
        throw new Exception(
            'The class_timetables table was not found.'
        );
    }

    /*
     * Resolve teacher profile from the teachers table.
     */
    if ($teacherId <= 0 && $userId > 0
        && trp_table_exists($conn, 'teachers')) {

        $teacherColumns = trp_columns($conn, 'teachers');

        $teacherPk = trp_pick(
            $teacherColumns,
            ['id', 'teacher_id']
        );

        $userColumn = trp_pick(
            $teacherColumns,
            ['user_id', 'account_id', 'login_id']
        );

        if ($teacherPk && $userColumn) {

            $stmt = $conn->prepare(
                "SELECT `$teacherPk` AS teacher_id
                 FROM teachers
                 WHERE `$userColumn` = ?
                 LIMIT 1"
            );

            $stmt->bind_param('i', $userId);
            $stmt->execute();

            $rows = trp_rows($stmt);

            $teacherId = (int)(
                $rows[0]['teacher_id'] ?? 0
            );

            $stmt->close();
        }
    }

    if ($teacherId <= 0) {
        throw new Exception(
            'Your teacher profile could not be identified.'
        );
    }

    $ttColumns = trp_columns(
        $conn,
        'class_timetables'
    );

    $teacherColumn = trp_pick(
        $ttColumns,
        ['teacher_id', 'staff_id', 'employee_id']
    );

    $classIdColumn = trp_pick(
        $ttColumns,
        ['class_id']
    );

    $streamIdColumn = trp_pick(
        $ttColumns,
        ['stream_id']
    );

    $classNameColumn = trp_pick(
        $ttColumns,
        ['class_name', 'class']
    );

    $streamNameColumn = trp_pick(
        $ttColumns,
        ['stream_name', 'stream']
    );

    if (!$teacherColumn) {
        throw new Exception(
            'The teacher allocation column was not found in class_timetables.'
        );
    }

    if (!$classIdColumn && !$classNameColumn) {
        throw new Exception(
            'No class information was found in class_timetables.'
        );
    }

    $stmt = $conn->prepare(
        "SELECT *
         FROM class_timetables
         WHERE `$teacherColumn` = ?"
    );

    $stmt->bind_param('i', $teacherId);
    $stmt->execute();

    $allocations = trp_rows($stmt);

    $stmt->close();

    /*
     * Build allowed class names.
     */
    foreach ($allocations as $allocation) {

        $className = '';

        if ($classNameColumn) {
            $className = trim(
                (string)($allocation[$classNameColumn] ?? '')
            );
        }

        $classId = $classIdColumn
            ? (int)($allocation[$classIdColumn] ?? 0)
            : 0;

        if ($className === '' && $classId > 0) {

            $className = trp_lookup(
                $conn,
                ['classes', 'school_classes'],
                $classId,
                ['id', 'class_id'],
                ['class_name', 'name', 'title']
            );
        }

        if ($className === '') {
            continue;
        }

        $assignedClasses[] = $className;

        $streamName = '';

        if ($streamNameColumn) {
            $streamName = trim(
                (string)($allocation[$streamNameColumn] ?? '')
            );
        }

        $streamId = $streamIdColumn
            ? (int)($allocation[$streamIdColumn] ?? 0)
            : 0;

        if ($streamName === '' && $streamId > 0) {

            $streamName = trp_lookup(
                $conn,
                ['streams', 'class_streams'],
                $streamId,
                ['id', 'stream_id'],
                ['stream_name', 'name', 'title']
            );
        }

        /*
         * Include common class/stream labels because saved
         * reports store class_name as text.
         */
        if ($streamName !== '') {

            $assignedClasses[] =
                $className . ' ' . $streamName;

            $assignedClasses[] =
                $className . ' - ' . $streamName;

            $assignedClasses[] =
                $className . '/' . $streamName;
        }
    }

    /*
     * Remove duplicate class names.
     */
    $uniqueClasses = [];

    foreach ($assignedClasses as $name) {

        $name = trim($name);

        if ($name === '') {
            continue;
        }

        $key = trp_normalize($name);

        $uniqueClasses[$key] = $name;
    }

    $assignedClasses = array_values($uniqueClasses);

    $classOptions = $assignedClasses;

    if (!$assignedClasses) {
        throw new Exception(
            'No assigned classes were found for your teacher account. Ask the administrator to allocate your classes.'
        );
    }

    /* -------------------------------------------------
       CHECK REPORT TABLES
    ------------------------------------------------- */

    if (!trp_table_exists($conn, 'student_term_reports')) {
        throw new Exception(
            'The student_term_reports table does not exist. Ask the administrator to configure student reports.'
        );
    }

    if (!trp_table_exists($conn, 'student_term_report_subjects')) {
        throw new Exception(
            'The student_term_report_subjects table does not exist.'
        );
    }

    /*
     * Load recent reports.
     *
     * We check the report class against the teacher's
     * assigned class names before displaying anything.
     */
    $stmt = $conn->prepare(
        "SELECT *
         FROM student_term_reports
         ORDER BY created_at DESC, id DESC
         LIMIT 1000"
    );

    $stmt->execute();

    $allReports = trp_rows($stmt);

    $stmt->close();

    foreach ($allReports as $report) {

        $reportClass = trp_normalize(
            $report['class_name'] ?? ''
        );

        if ($reportClass === '') {
            continue;
        }

        $allowed = false;

        foreach ($assignedClasses as $assignedClass) {

            if (
                $reportClass === trp_normalize($assignedClass)
            ) {
                $allowed = true;
                break;
            }
        }

        if (!$allowed) {
            continue;
        }

        /*
         * Apply filters.
         */
        if (
            $filterClass !== ''
            && $reportClass !== trp_normalize($filterClass)
        ) {
            continue;
        }

        if (
            $filterTerm !== ''
            && (string)($report['term'] ?? '') !== $filterTerm
        ) {
            continue;
        }

        if (
            $filterYear !== ''
            && (string)($report['academic_year'] ?? '') !== $filterYear
        ) {
            continue;
        }

        if ($search !== '') {

            $searchText = strtolower(
                ($report['student_name'] ?? '') . ' ' .
                ($report['admission_no'] ?? '') . ' ' .
                ($report['student_number'] ?? '')
            );

            if (strpos($searchText, strtolower($search)) === false) {
                continue;
            }
        }

        $reports[] = $report;
    }

    /*
     * Load individual report only after checking class access.
     */
    if ($viewId > 0) {

        foreach ($reports as $report) {

            if ((int)$report['id'] === $viewId) {
                $selectedReport = $report;
                break;
            }
        }

        if (!$selectedReport) {
            throw new Exception(
                'This report was not found in your assigned classes.'
            );
        }

        $stmt = $conn->prepare(
            "SELECT *
             FROM student_term_report_subjects
             WHERE report_id = ?
             ORDER BY sort_order ASC, id ASC"
        );

        $stmt->bind_param('i', $viewId);
        $stmt->execute();

        $reportSubjects = trp_rows($stmt);

        $stmt->close();
    }

} catch (Throwable $e) {

    error_log(
        'Teacher student reports error: ' . $e->getMessage()
    );

    $pageError = $e->getMessage();
}

/* -----------------------------------------------------
   FILTER OPTIONS
----------------------------------------------------- */

$terms = [];
$years = [];

foreach ($reports as $report) {

    $term = trim((string)($report['term'] ?? ''));
    $year = trim((string)($report['academic_year'] ?? ''));

    if ($term !== '') {
        $terms[$term] = $term;
    }

    if ($year !== '') {
        $years[$year] = $year;
    }
}

$totalReports = count($reports);
$totalStudents = count(
    array_unique(
        array_filter(
            array_map(
                function ($r) {
                    return (string)(
                        $r['student_id']
                        ?? $r['admission_no']
                        ?? $r['student_name']
                        ?? ''
                    );
                },
                $reports
            )
        )
    )
);

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Student Reports | Teacher Portal</title>

<link rel="stylesheet"
href="https://stackpath.bootstrapcdn.com/bootstrap/4.6.2/css/bootstrap.min.css">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<style>

body {
    background: #f4f6f9;
    font-family: Arial, sans-serif;
    color: #263238;
}

.sidebar {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    width: 245px;
    background: #172b4d;
    color: white;
    overflow-y: auto;
    z-index: 1000;
}

.brand {
    padding: 24px 16px;
    background: #10213d;
    text-align: center;
    font-weight: bold;
    font-size: 19px;
}

.nav-area {
    padding: 16px 10px;
}

.nav-area a {
    display: block;
    padding: 12px 14px;
    margin-bottom: 5px;
    color: #d8e0eb;
    border-radius: 6px;
    text-decoration: none;
}

.nav-area a:hover,
.nav-area a.active {
    background: #007bff;
    color: white;
}

.main {
    margin-left: 245px;
    min-height: 100vh;
}

.topbar {
    background: white;
    padding: 17px 25px;
    box-shadow: 0 2px 8px rgba(0,0,0,.06);
}

.content {
    padding: 25px;
}

.panel,
.stat-card {
    background: white;
    border: none;
    border-radius: 10px;
    box-shadow: 0 3px 12px rgba(0,0,0,.06);
}

.stat-card {
    padding: 20px;
    height: 100%;
}

.stat-icon {
    font-size: 27px;
    color: #007bff;
    margin-right: 15px;
}

.stat-number {
    font-size: 25px;
    font-weight: bold;
}

.panel-heading {
    padding: 18px 20px;
    border-bottom: 1px solid #edf0f3;
    font-weight: bold;
}

.panel-body {
    padding: 20px;
}

.table th {
    background: #f8fafc;
    white-space: nowrap;
}

.table td {
    vertical-align: middle;
}

.report-header {
    text-align: center;
    border-bottom: 2px solid #172b4d;
    padding-bottom: 20px;
    margin-bottom: 20px;
}

.report-section {
    margin-bottom: 25px;
}

.report-section h6 {
    font-weight: bold;
    color: #172b4d;
    border-bottom: 1px solid #ddd;
    padding-bottom: 8px;
}

.comment-box {
    background: #f8fafc;
    border: 1px solid #e5eaf0;
    border-radius: 6px;
    padding: 15px;
    min-height: 65px;
}

.grade-badge {
    display: inline-block;
    background: #e8f1ff;
    color: #0056b3;
    padding: 5px 10px;
    border-radius: 5px;
    font-weight: bold;
}

@media(max-width: 768px) {

    .sidebar {
        position: relative;
        width: 100%;
    }

    .main {
        margin-left: 0;
    }

    .content {
        padding: 15px;
    }
}

@media print {

    .sidebar,
    .topbar,
    .no-print {
        display: none !important;
    }

    .main {
        margin: 0;
    }

    .content {
        padding: 0;
    }

    .panel {
        box-shadow: none;
    }

    body {
        background: white;
    }

}

</style>

<link rel="stylesheet" href="/assets/css/admin-theme.css?v=20261114">
</head>

<body>

<aside class="sidebar no-print">

    <div class="brand">
        <i class="fas fa-school mr-2"></i>
        School Management
    </div>

    <nav class="nav-area">

        <a href="/teacher/dashboard.php">
            <i class="fas fa-tachometer-alt mr-2"></i>
            Dashboard
        </a>

        <a href="/teacher/teacher_classes_index.php">
            <i class="fas fa-chalkboard mr-2"></i>
            My Classes
        </a>

        <a href="/teacher/teacher_subject_index.php">
            <i class="fas fa-book-open mr-2"></i>
            My Subjects
        </a>

        <a href="/teacher/teacher_attendance_index.php">
            <i class="fas fa-calendar-check mr-2"></i>
            Attendance
        </a>

        <a href="/teacher/teacher_marks_index.php">
            <i class="fas fa-clipboard-list mr-2"></i>
            Marks &amp; Assessments
        </a>

        <a href="/teacher/timetable.php">
            <i class="fas fa-calendar-alt mr-2"></i>
            Timetable
        </a>

        <a class="active" href="/teacher/student_reports.php">
            <i class="fas fa-file-alt mr-2"></i>
            Student Reports
        </a>

        <a href="/logout.php">
            <i class="fas fa-sign-out-alt mr-2"></i>
            Logout
        </a>

    </nav>

</aside>

<main class="main">

    <header class="topbar d-flex justify-content-between align-items-center flex-wrap">

        <h4 class="mb-1">
            <i class="fas fa-file-alt text-primary mr-2"></i>
            Student Reports
        </h4>

        <span class="text-muted">
            <i class="fas fa-user-circle mr-1"></i>
            <?= trp_e($teacherName) ?>
        </span>

    </header>

    <div class="content">

        <?php if ($pageError !== ''): ?>

            <div class="alert alert-danger">

                <h5>
                    <i class="fas fa-exclamation-triangle mr-2"></i>
                    Unable to load student reports
                </h5>

                <?= trp_e($pageError) ?>

            </div>

        <?php elseif ($selectedReport): ?>

            <!-- INDIVIDUAL STUDENT REPORT -->

            <div class="d-flex justify-content-between align-items-center flex-wrap mb-3 no-print">

                <a href="student_reports.php"
                   class="btn btn-outline-secondary">

                    <i class="fas fa-arrow-left mr-1"></i>
                    Back to Student Reports

                </a>

                <button type="button"
                        onclick="window.print()"
                        class="btn btn-primary">

                    <i class="fas fa-print mr-1"></i>
                    Print Student Report

                </button>

            </div>

            <section class="panel">

                <div class="panel-body">

                    <div class="report-header">

                        <h3 class="font-weight-bold">
                            STUDENT ACADEMIC REPORT
                        </h3>

                        <h5>
                            <?= trp_e($selectedReport['report_title']) ?>
                        </h5>

                        <p class="mb-0">
                            <?= trp_e($selectedReport['term']) ?>
                            -
                            <?= trp_e($selectedReport['academic_year']) ?>
                        </p>

                    </div>

                    <div class="report-section">

                        <h6>
                            <i class="fas fa-user-graduate mr-2"></i>
                            STUDENT INFORMATION
                        </h6>

                        <div class="row">

                            <div class="col-md-6 mb-2">
                                <strong>Student Name:</strong>
                                <?= trp_e($selectedReport['student_name']) ?>
                            </div>

                            <div class="col-md-6 mb-2">
                                <strong>Admission Number:</strong>
                                <?= trp_e($selectedReport['admission_no'] ?: '—') ?>
                            </div>

                            <div class="col-md-6 mb-2">
                                <strong>Student Number:</strong>
                                <?= trp_e($selectedReport['student_number'] ?: '—') ?>
                            </div>

                            <div class="col-md-6 mb-2">
                                <strong>Class:</strong>
                                <?= trp_e($selectedReport['class_name']) ?>
                            </div>

                            <div class="col-md-6 mb-2">
                                <strong>Academic Year:</strong>
                                <?= trp_e($selectedReport['academic_year']) ?>
                            </div>

                            <div class="col-md-6 mb-2">
                                <strong>Term:</strong>
                                <?= trp_e($selectedReport['term']) ?>
                            </div>

                        </div>

                    </div>

                    <div class="report-section">

                        <h6>
                            <i class="fas fa-book mr-2"></i>
                            SUBJECT PERFORMANCE
                        </h6>

                        <div class="table-responsive">

                            <table class="table table-bordered table-sm">

                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Code</th>
                                        <th>Subject</th>
                                        <th>AOI 2</th>
                                        <th>AOI 1</th>
                                        <th>Out of 20</th>
                                        <th>Out of 80</th>
                                        <th>Final Mark</th>
                                        <th>Grade</th>
                                        <th>Comment</th>
                                    </tr>
                                </thead>

                                <tbody>

                                    <?php if (!$reportSubjects): ?>

                                        <tr>
                                            <td colspan="10"
                                                class="text-center text-muted">

                                                No subject results were recorded.

                                            </td>
                                        </tr>

                                    <?php else: ?>

                                        <?php
                                        $totalMarks = 0;
                                        $markedSubjects = 0;
                                        ?>

                                        <?php foreach ($reportSubjects as $index => $subject): ?>

                                            <?php
                                            $mark = $subject['final_mark'] ?? null;

                                            if ($mark === null || $mark === '') {
                                                $mark = (
                                                    ($subject['out20'] ?? 0)
                                                    + ($subject['out80'] ?? 0)
                                                );

                                                if (
                                                    ($subject['out20'] ?? null) === null
                                                    && ($subject['out80'] ?? null) === null
                                                ) {
                                                    $mark = null;
                                                }
                                            }

                                            if ($mark !== null) {
                                                $totalMarks += (float)$mark;
                                                $markedSubjects++;
                                            }
                                            ?>

                                            <tr>

                                                <td><?= $index + 1 ?></td>

                                                <td>
                                                    <?= trp_e($subject['subject_code'] ?? '') ?>
                                                </td>

                                                <td>
                                                    <strong>
                                                        <?= trp_e($subject['subject_name']) ?>
                                                    </strong>
                                                </td>

                                                <td>
                                                    <?= trp_e($subject['aoi2'] ?? '—') ?>
                                                </td>

                                                <td>
                                                    <?= trp_e($subject['aoi1'] ?? '—') ?>
                                                </td>

                                                <td>
                                                    <?= trp_e($subject['out20'] ?? '—') ?>
                                                </td>

                                                <td>
                                                    <?= trp_e($subject['out80'] ?? '—') ?>
                                                </td>

                                                <td>
                                                    <strong>
                                                        <?= $mark === null
                                                            ? '—'
                                                            : trp_e(number_format((float)$mark, 1)) ?>
                                                    </strong>
                                                </td>

                                                <td>
                                                    <span class="grade-badge">
                                                        <?= trp_e($subject['grade'] ?? '—') ?>
                                                    </span>
                                                </td>

                                                <td>
                                                    <?= trp_e($subject['comment'] ?? '') ?>
                                                </td>

                                            </tr>

                                        <?php endforeach; ?>

                                    <?php endif; ?>

                                </tbody>

                                <?php if ($markedSubjects > 0): ?>

                                    <tfoot>

                                        <tr>
                                            <th colspan="7" class="text-right">
                                                Total Marks
                                            </th>

                                            <th>
                                                <?= number_format($totalMarks, 1) ?>
                                            </th>

                                            <th colspan="2"></th>
                                        </tr>

                                        <tr>
                                            <th colspan="7" class="text-right">
                                                Average
                                            </th>

                                            <th>
                                                <?= number_format(
                                                    $totalMarks / $markedSubjects,
                                                    1
                                                ) ?>
                                            </th>

                                            <th colspan="2"></th>
                                        </tr>

                                    </tfoot>

                                <?php endif; ?>

                            </table>

                        </div>

                    </div>

                    <div class="report-section">

                        <h6>
                            <i class="fas fa-comment-alt mr-2"></i>
                            CLASS TEACHER'S COMMENT
                        </h6>

                        <div class="comment-box">

                            <?= nl2br(
                                trp_e(
                                    $selectedReport['class_teacher_comment']
                                    ?? 'No class teacher comment recorded.'
                                )
                            ) ?>

                        </div>

                    </div>

                    <div class="report-section">

                        <h6>
                            <i class="fas fa-user-tie mr-2"></i>
                            HEADTEACHER'S COMMENT
                        </h6>

                        <div class="comment-box">

                            <?= nl2br(
                                trp_e(
                                    $selectedReport['headteacher_comment']
                                    ?? 'No headteacher comment recorded.'
                                )
                            ) ?>

                        </div>

                    </div>

                    <div class="report-section">

                        <h6>
                            <i class="fas fa-calendar-alt mr-2"></i>
                            SCHOOL INFORMATION
                        </h6>

                        <div class="row">

                            <div class="col-md-6 mb-2">

                                <strong>Term Closes:</strong>

                                <?= !empty($selectedReport['term_closes'])
                                    ? trp_e(date(
                                        'd M Y',
                                        strtotime($selectedReport['term_closes'])
                                    ))
                                    : '—' ?>

                            </div>

                            <div class="col-md-6 mb-2">

                                <strong>Next Term Begins:</strong>

                                <?= !empty($selectedReport['next_term_begins'])
                                    ? trp_e(date(
                                        'd M Y',
                                        strtotime($selectedReport['next_term_begins'])
                                    ))
                                    : '—' ?>

                            </div>

                            <div class="col-md-6 mb-2">

                                <strong>Fees Balance:</strong>

                                <?= $selectedReport['fees_balance'] !== null
                                    ? 'UGX ' . number_format(
                                        (float)$selectedReport['fees_balance']
                                    )
                                    : '—' ?>

                            </div>

                        </div>

                    </div>

                    <div class="row mt-5">

                        <div class="col-md-6 text-center">

                            <hr>

                            <strong>Class Teacher's Signature</strong>

                        </div>

                        <div class="col-md-6 text-center">

                            <hr>

                            <strong>Headteacher's Signature</strong>

                        </div>

                    </div>

                    <div class="text-center text-muted mt-4">

                        <small>
                            Generated by the School Management System
                        </small>

                    </div>

                </div>

            </section>

        <?php else: ?>

            <!-- REPORT DASHBOARD -->

            <div class="mb-4">

                <h5 class="font-weight-bold">
                    Academic Reports
                </h5>

                <p class="text-muted">
                    View academic reports for students in your assigned classes.
                    Open individual reports to review subject marks, grades and comments.
                </p>

            </div>

            <div class="row mb-4">

                <div class="col-md-6 mb-3">

                    <div class="stat-card d-flex align-items-center">

                        <i class="fas fa-file-alt stat-icon"></i>

                        <div>

                            <small class="text-muted">
                                Available Reports
                            </small>

                            <div class="stat-number">
                                <?= number_format($totalReports) ?>
                            </div>

                        </div>

                    </div>

                </div>

                <div class="col-md-6 mb-3">

                    <div class="stat-card d-flex align-items-center">

                        <i class="fas fa-user-graduate stat-icon"></i>

                        <div>

                            <small class="text-muted">
                                Students Reported
                            </small>

                            <div class="stat-number">
                                <?= number_format($totalStudents) ?>
                            </div>

                        </div>

                    </div>

                </div>

            </div>

            <!-- FILTERS -->

            <section class="panel mb-4">

                <div class="panel-heading">

                    <i class="fas fa-filter text-primary mr-2"></i>
                    Search and Filter Reports

                </div>

                <div class="panel-body">

                    <form method="get" class="form-row align-items-end">

                        <div class="form-group col-lg-3">

                            <label>Search Student</label>

                            <input type="search"
                                   name="q"
                                   class="form-control"
                                   value="<?= trp_e($search) ?>"
                                   placeholder="Name or admission number">

                        </div>

                        <div class="form-group col-lg-3">

                            <label>Assigned Class</label>

                            <select name="class" class="custom-select">

                                <option value="">All Assigned Classes</option>

                                <?php foreach ($classOptions as $class): ?>

                                    <option value="<?= trp_e($class) ?>"
                                        <?= trp_normalize($filterClass) === trp_normalize($class)
                                            ? 'selected'
                                            : '' ?>>

                                        <?= trp_e($class) ?>

                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                        <div class="form-group col-lg-2">

                            <label>Term</label>

                            <select name="term" class="custom-select">

                                <option value="">All Terms</option>

                                <?php foreach ($terms as $term): ?>

                                    <option value="<?= trp_e($term) ?>"
                                        <?= $filterTerm === $term ? 'selected' : '' ?>>

                                        <?= trp_e($term) ?>

                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                        <div class="form-group col-lg-2">

                            <label>Academic Year</label>

                            <select name="year" class="custom-select">

                                <option value="">All Years</option>

                                <?php foreach ($years as $year): ?>

                                    <option value="<?= trp_e($year) ?>"
                                        <?= $filterYear === $year ? 'selected' : '' ?>>

                                        <?= trp_e($year) ?>

                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                        <div class="form-group col-lg-2">

                            <button type="submit"
                                    class="btn btn-primary btn-block">

                                <i class="fas fa-search mr-1"></i>
                                Search

                            </button>

                        </div>

                    </form>

                    <a href="/teacher/student_reports.php"
                       class="btn btn-sm btn-outline-secondary">

                        <i class="fas fa-redo mr-1"></i>
                        Clear Filters

                    </a>

                </div>

            </section>

            <!-- REPORT LIST -->

            <section class="panel">

                <div class="panel-heading">

                    <i class="fas fa-folder-open text-primary mr-2"></i>
                    Student Academic Reports

                    <span class="badge badge-primary float-right">
                        <?= count($reports) ?> Reports
                    </span>

                </div>

                <div class="panel-body">

                    <div class="table-responsive">

                        <table class="table table-bordered table-hover">

                            <thead>

                                <tr>

                                    <th>#</th>
                                    <th>Student Name</th>
                                    <th>Admission Number</th>
                                    <th>Class</th>
                                    <th>Term</th>
                                    <th>Academic Year</th>
                                    <th>Date Created</th>
                                    <th>Action</th>

                                </tr>

                            </thead>

                            <tbody>

                                <?php if (!$reports): ?>

                                    <tr>

                                        <td colspan="8"
                                            class="text-center py-5">

                                            <i class="fas fa-folder-open fa-3x text-muted mb-3"></i>

                                            <h5>No Student Reports Found</h5>

                                            <p class="text-muted mb-0">

                                                No saved academic reports match your assigned classes
                                                and selected filters.

                                            </p>

                                        </td>

                                    </tr>

                                <?php else: ?>

                                    <?php foreach ($reports as $index => $report): ?>

                                        <tr>

                                            <td>
                                                <?= $index + 1 ?>
                                            </td>

                                            <td>

                                                <strong>
                                                    <?= trp_e($report['student_name']) ?>
                                                </strong>

                                            </td>

                                            <td>
                                                <?= trp_e(
                                                    $report['admission_no'] ?: '—'
                                                ) ?>
                                            </td>

                                            <td>
                                                <?= trp_e($report['class_name']) ?>
                                            </td>

                                            <td>

                                                <span class="badge badge-info">
                                                    <?= trp_e($report['term']) ?>
                                                </span>

                                            </td>

                                            <td>
                                                <?= trp_e($report['academic_year']) ?>
                                            </td>

                                            <td>

                                                <?= !empty($report['created_at'])
                                                    ? trp_e(date(
                                                        'd M Y',
                                                        strtotime($report['created_at'])
                                                    ))
                                                    : '—' ?>

                                            </td>

                                            <td class="text-nowrap">

                                                <a href="student_reports.php?view=<?= (int)$report['id'] ?>"
                                                   class="btn btn-sm btn-primary">

                                                    <i class="fas fa-eye mr-1"></i>
                                                    View Report

                                                </a>

                                            </td>

                                        </tr>

                                    <?php endforeach; ?>

                                <?php endif; ?>

                            </tbody>

                        </table>

                    </div>

                </div>

            </section>

        <?php endif; ?>

        <div class="text-center text-muted mt-4 mb-3">

            <small>
                School Management System &copy; <?= date('Y') ?>
            </small>

        </div>

    </div>

</main>

</body>
</html>
