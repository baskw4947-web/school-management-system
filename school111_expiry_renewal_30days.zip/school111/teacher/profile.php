<?php
/**
 * Teacher My Profile
 * Install as: public_html/teacher/teacher_profile.php
 * Uses the existing database connection and teacher authentication.
 */

error_reporting(E_ALL);
ini_set('display_errors', '0');

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';

requireLogin();
requireRole(['teacher']);

$conn = $conn ?? ($mysqli ?? ($connection ?? null));

if (!$conn instanceof mysqli) {
    http_response_code(500);
    exit('Database connection was not found. Check config/database.php.');
}

$conn->set_charset('utf8mb4');

function tp_escape($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function tp_columns(mysqli $db, string $table): array
{
    $columns = [];
    $result = $db->query("SHOW COLUMNS FROM `$table`");
    while ($row = $result->fetch_assoc()) {
        $columns[strtolower($row['Field'])] = $row['Field'];
    }
    $result->free();
    return $columns;
}

function tp_pick(array $columns, array $candidates): ?string
{
    foreach ($candidates as $candidate) {
        if (isset($columns[strtolower($candidate)])) {
            return $columns[strtolower($candidate)];
        }
    }
    return null;
}

function tp_normalize_name(string $name): string
{
    $name = preg_replace('/\s+/', ' ', trim($name));
    return strtolower($name);
}

$teacher = null;
$pageError = '';
$teacherColumns = [];

try {
    $tableCheck = $conn->query("SHOW TABLES LIKE 'teachers'");
    if (!$tableCheck || $tableCheck->num_rows === 0) {
        throw new Exception('The teachers table was not found in the database.');
    }
    $tableCheck->free();

    $teacherColumns = tp_columns($conn, 'teachers');

    $idColumn = tp_pick($teacherColumns, ['id', 'teacher_id']);
    if (!$idColumn) {
        throw new Exception('The teachers table does not have a recognised teacher ID column.');
    }

    // Prefer an explicitly stored teacher profile ID when the login session has one.
    $sessionTeacherId = (int)($_SESSION['teacher_id']
        ?? $_SESSION['staff_id']
        ?? $_SESSION['employee_id']
        ?? 0);

    if ($sessionTeacherId > 0) {
        $stmt = $conn->prepare("SELECT * FROM teachers WHERE `$idColumn` = ? LIMIT 1");
        $stmt->bind_param('i', $sessionTeacherId);
        $stmt->execute();
        $result = $stmt->get_result();
        $teacher = $result ? $result->fetch_assoc() : null;
        $stmt->close();
    }

    // Existing login setup may only store full_name, so match the teacher's name.
    if (!$teacher) {
        $sessionName = trim((string)($_SESSION['full_name'] ?? $_SESSION['name'] ?? ''));

        $firstColumn = tp_pick($teacherColumns, ['first_name', 'firstname', 'given_name']);
        $lastColumn = tp_pick($teacherColumns, ['last_name', 'lastname', 'surname', 'family_name']);
        $otherColumn = tp_pick($teacherColumns, ['other_names', 'middle_name', 'other_name']);

        if ($sessionName !== '' && $firstColumn && $lastColumn) {
            $result = $conn->query("SELECT * FROM teachers");
            $matches = [];

            while ($row = $result->fetch_assoc()) {
                $parts = [];
                if (!empty($row[$firstColumn])) $parts[] = trim((string)$row[$firstColumn]);
                if ($otherColumn && !empty($row[$otherColumn])) $parts[] = trim((string)$row[$otherColumn]);
                if (!empty($row[$lastColumn])) $parts[] = trim((string)$row[$lastColumn]);

                if (tp_normalize_name(implode(' ', $parts)) === tp_normalize_name($sessionName)) {
                    $matches[] = $row;
                }
            }
            $result->free();

            if (count($matches) === 1) {
                $teacher = $matches[0];
            } elseif (count($matches) > 1) {
                throw new Exception('More than one teacher has the same name. Ask the administrator to link your login to your teacher profile.');
            }
        }
    }

    if (!$teacher) {
        throw new Exception('Your teacher profile could not be matched to your login. Check that your login full name matches the name in the teachers table, or link your account using teacher_id.');
    }

} catch (Throwable $e) {
    error_log('Teacher profile page: ' . $e->getMessage());
    $pageError = $e->getMessage();
}

$firstColumn = tp_pick($teacherColumns, ['first_name', 'firstname', 'given_name']);
$lastColumn = tp_pick($teacherColumns, ['last_name', 'lastname', 'surname', 'family_name']);
$otherColumn = tp_pick($teacherColumns, ['other_names', 'middle_name', 'other_name']);

$displayName = 'Teacher';
if ($teacher) {
    $nameParts = [];
    foreach ([$firstColumn, $otherColumn, $lastColumn] as $column) {
        if ($column && !empty($teacher[$column])) $nameParts[] = trim((string)$teacher[$column]);
    }
    $displayName = $nameParts ? implode(' ', $nameParts) : (string)($_SESSION['full_name'] ?? 'Teacher');
}

$teacherNoColumn = tp_pick($teacherColumns, ['teacher_no', 'staff_no', 'employee_no', 'registration_no']);
$photoColumn = tp_pick($teacherColumns, ['photo', 'profile_photo', 'photo_path', 'image']);
$photo = ($teacher && $photoColumn) ? trim((string)($teacher[$photoColumn] ?? '')) : '';

$profileFields = [
    'Teacher Number' => ['teacher_no', 'staff_no', 'employee_no', 'registration_no'],
    'Gender' => ['gender', 'sex'],
    'Date of Birth' => ['date_of_birth', 'dob', 'birth_date'],
    'Phone Number' => ['phone', 'phone_number', 'contact', 'contact_number', 'mobile'],
    'Email Address' => ['email', 'email_address'],
    'Address' => ['address', 'residential_address', 'home_address'],
    'Department' => ['department', 'department_name'],
    'Subject / Specialisation' => ['subject', 'specialisation', 'specialization', 'subject_specialisation'],
    'Qualification' => ['qualification', 'highest_qualification', 'academic_qualification'],
    'Employment Date' => ['employment_date', 'date_employed', 'joining_date', 'hire_date'],
    'Employment Type' => ['employment_type', 'staff_type'],
    'Status' => ['status', 'employment_status']
];

$profileValues = [];
if ($teacher) {
    foreach ($profileFields as $label => $candidates) {
        $column = tp_pick($teacherColumns, $candidates);
        if ($column && isset($teacher[$column]) && trim((string)$teacher[$column]) !== '') {
            $value = $teacher[$column];
            if (in_array($column, ['date_of_birth', 'dob', 'birth_date', 'employment_date', 'date_employed', 'joining_date', 'hire_date'], true)) {
                $timestamp = strtotime((string)$value);
                if ($timestamp) $value = date('d M Y', $timestamp);
            }
            $profileValues[$label] = $value;
        }
    }
}

$initials = '';
foreach (preg_split('/\s+/', trim($displayName)) as $part) {
    if ($part !== '') $initials .= strtoupper(substr($part, 0, 1));
    if (strlen($initials) >= 2) break;
}
if ($initials === '') $initials = 'T';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile | Teacher Portal</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.6.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body { background:#f4f6f9; font-family:Arial,sans-serif; color:#263238; }
        .sidebar { position:fixed; top:0; bottom:0; left:0; width:245px; background:#172b4d; color:white; overflow-y:auto; z-index:1000; }
        .brand { padding:24px 16px; background:#10213d; text-align:center; font-weight:bold; font-size:19px; }
        .nav-area { padding:16px 10px; }
        .nav-area a { display:block; padding:12px 14px; margin-bottom:5px; color:#d8e0eb; border-radius:6px; text-decoration:none; }
        .nav-area a:hover, .nav-area a.active { background:#007bff; color:white; }
        .main { margin-left:245px; min-height:100vh; }
        .topbar { background:white; padding:17px 25px; box-shadow:0 2px 8px rgba(0,0,0,.06); }
        .content { padding:25px; }
        .panel, .stat-card { background:white; border:none; border-radius:10px; box-shadow:0 3px 12px rgba(0,0,0,.06); }
        .panel-heading { padding:18px 20px; border-bottom:1px solid #edf0f3; font-weight:bold; }
        .panel-body { padding:20px; }
        .profile-banner { background:linear-gradient(120deg,#172b4d,#244d7d); color:#fff; padding:28px; border-radius:10px 10px 0 0; }
        .profile-avatar { width:112px; height:112px; border-radius:50%; background:#e8f1ff; color:#172b4d; display:flex; align-items:center; justify-content:center; font-size:34px; font-weight:bold; border:4px solid rgba(255,255,255,.85); overflow:hidden; }
        .profile-avatar img { width:100%; height:100%; object-fit:cover; }
        .profile-name { font-size:25px; font-weight:bold; margin:0; }
        .profile-number { color:#e1eaf5; margin-top:5px; }
        .detail-item { padding:15px 10px; border-bottom:1px solid #edf0f3; height:100%; }
        .detail-label { color:#718096; font-size:12px; text-transform:uppercase; letter-spacing:.5px; margin-bottom:6px; }
        .detail-value { color:#263238; font-weight:600; overflow-wrap:anywhere; }
        .section-title { color:#172b4d; font-weight:bold; border-bottom:1px solid #edf0f3; padding-bottom:10px; margin-bottom:10px; }
        .stat-icon { font-size:27px; color:#007bff; margin-right:15px; }
        @media(max-width:768px) {
            .sidebar { position:relative; width:100%; }
            .main { margin-left:0; }
            .content { padding:15px; }
            .profile-banner { text-align:center; }
            .profile-avatar { margin:0 auto 15px; }
        }
    </style>
<link rel="stylesheet" href="/assets/css/admin-theme.css?v=20261114">
</head>
<body>
<aside class="sidebar">
    <div class="brand"><i class="fas fa-school mr-2"></i>School Management</div>
    <nav class="nav-area">
        <a href="/teacher/dashboard.php"><i class="fas fa-tachometer-alt mr-2"></i>Dashboard</a>
        <a href="/teacher/teacher_classes_index.php"><i class="fas fa-chalkboard mr-2"></i>My Classes</a>
        <a href="/teacher/teacher_subject_index.php"><i class="fas fa-book-open mr-2"></i>My Subjects</a>
        <a href="/teacher/teacher_attendance_index.php"><i class="fas fa-calendar-check mr-2"></i>Attendance</a>
        <a href="/teacher/teacher_marks_index.php"><i class="fas fa-clipboard-list mr-2"></i>Marks &amp; Assessments</a>
        <a href="/teacher/timetable.php"><i class="fas fa-calendar-alt mr-2"></i>Timetable</a>
        <a href="/teacher/student_reports.php"><i class="fas fa-file-alt mr-2"></i>Student Reports</a>
        <a class="active" href="/teacher/profile.php"><i class="fas fa-user-circle mr-2"></i>My Profile</a>
        <a href="/logout.php"><i class="fas fa-sign-out-alt mr-2"></i>Logout</a>
    </nav>
</aside>

<main class="main">
    <header class="topbar d-flex justify-content-between align-items-center flex-wrap">
        <h4 class="mb-1"><i class="fas fa-user-circle text-primary mr-2"></i>My Profile</h4>
        <span class="text-muted"><i class="fas fa-user mr-1"></i><?= tp_escape($displayName) ?></span>
    </header>

    <div class="content">
        <?php if ($pageError !== ''): ?>
            <div class="alert alert-danger">
                <h5><i class="fas fa-exclamation-triangle mr-2"></i>Unable to load teacher profile</h5>
                <?= tp_escape($pageError) ?>
            </div>
        <?php else: ?>
            <div class="mb-4">
                <h5 class="font-weight-bold">My Profile</h5>
                <p class="text-muted mb-0">View your teacher account and profile information.</p>
            </div>

            <section class="panel mb-4">
                <div class="profile-banner">
                    <div class="row align-items-center">
                        <div class="col-md-auto">
                            <div class="profile-avatar">
                                <?php if ($photo !== ''): ?>
                                    <img src="<?= tp_escape($photo) ?>" alt="Teacher profile photo">
                                <?php else: ?>
                                    <?= tp_escape($initials) ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col">
                            <h3 class="profile-name"><?= tp_escape($displayName) ?></h3>
                            <div class="profile-number">
                                <?php if ($teacherNoColumn && !empty($teacher[$teacherNoColumn])): ?>
                                    Teacher No: <?= tp_escape($teacher[$teacherNoColumn]) ?>
                                <?php else: ?>
                                    Teacher Account
                                <?php endif; ?>
                            </div>
                            <div class="mt-2"><i class="fas fa-check-circle mr-1"></i>Logged in as a teacher</div>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    <h6 class="section-title"><i class="fas fa-id-card mr-2"></i>Personal and Employment Information</h6>
                    <?php if (!$profileValues): ?>
                        <div class="alert alert-info mb-0">Your teacher record was found, but no additional profile fields were available to display. Please ask the administrator to complete your teacher record.</div>
                    <?php else: ?>
                        <div class="row">
                            <?php foreach ($profileValues as $label => $value): ?>
                                <div class="col-md-6 col-lg-4">
                                    <div class="detail-item">
                                        <div class="detail-label"><?= tp_escape($label) ?></div>
                                        <div class="detail-value"><?= tp_escape($value) ?></div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </section>

            <div class="text-muted small text-center mt-4">
                School Management System &copy; <?= date('Y') ?>
            </div>
        <?php endif; ?>
    </div>
</main>
</body>
</html>
