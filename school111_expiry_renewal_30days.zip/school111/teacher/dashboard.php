<?php

/**

 * School Management System - Teacher Dashboard

 * Design adapted from the supplied Administrator Dashboard.

 * Location: /teacher/dashboard.php

 *

 * Access is restricted to authenticated teacher accounts.

 * Dashboard totals are shown only when a recognised teacher assignment

 * relationship can be found in the existing database.

 */

require_once __DIR__ . '/../includes/auth.php';

requireRole(['teacher']);

$dashboardDb = null;

$dashboardDbWarning = false;

try {

    require_once __DIR__ . '/../config/database.php';

    $dashboardDb = $conn ?? ($mysqli ?? ($connection ?? null));

    if ($dashboardDb instanceof mysqli) {

        $dashboardDb->set_charset('utf8mb4');

    } else {

        $dashboardDbWarning = true;

        error_log('Teacher dashboard: database configuration did not provide a MySQLi connection.');

    }

} catch (Throwable $exception) {

    $dashboardDbWarning = true;

    error_log('Teacher dashboard database error: ' . $exception->getMessage());

}

function tdTableExists(mysqli $db, string $table): bool

{

    if (!preg_match('/^[a-zA-Z0-9_]+$/', $table)) {

        return false;

    }

    try {

        $stmt = $db->prepare('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1');

        $stmt->bind_param('s', $table);

        $stmt->execute();

        $exists = $stmt->get_result()->num_rows > 0;

        $stmt->close();

        return $exists;

    } catch (Throwable $exception) {

        error_log('Teacher dashboard table check failed: ' . $exception->getMessage());

        return false;

    }

}

function tdColumns(mysqli $db, string $table): array

{

    if (!preg_match('/^[a-zA-Z0-9_]+$/', $table) || !tdTableExists($db, $table)) {

        return [];

    }

    try {

        $result = $db->query('SHOW COLUMNS FROM `' . $table . '`');

        $columns = [];

        while ($row = $result->fetch_assoc()) {

            $columns[strtolower($row['Field'])] = $row['Field'];

        }

        $result->free();

        return $columns;

    } catch (Throwable $exception) {

        error_log('Teacher dashboard column check failed for ' . $table . ': ' . $exception->getMessage());

        return [];

    }

}

function tdFirstColumn(array $columns, array $candidates): ?string

{

    foreach ($candidates as $candidate) {

        if (isset($columns[$candidate])) {

            return $columns[$candidate];

        }

    }

    return null;

}

function tdCountDistinct(mysqli $db, string $table, string $column, string $whereColumn, int $whereValue): ?int

{

    foreach ([$table, $column, $whereColumn] as $identifier) {

        if (!preg_match('/^[a-zA-Z0-9_]+$/', $identifier)) {

            return null;

        }

    }

    try {

        $sql = 'SELECT COUNT(DISTINCT `' . $column . '`) AS total FROM `' . $table . '` WHERE `' . $whereColumn . '` = ?';

        $stmt = $db->prepare($sql);

        $stmt->bind_param('i', $whereValue);

        $stmt->execute();

        $row = $stmt->get_result()->fetch_assoc();

        $stmt->close();

        return (int)($row['total'] ?? 0);

    } catch (Throwable $exception) {

        error_log('Teacher dashboard count failed: ' . $exception->getMessage());

        return null;

    }

}

function tdE($value): string

{

    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');

}

$userId = (int)($_SESSION['user_id'] ?? $_SESSION['id'] ?? 0);

$teacherId = (int)($_SESSION['teacher_id'] ?? $_SESSION['staff_id'] ?? 0);

$teacherName = (string)($_SESSION['full_name'] ?? $_SESSION['name'] ?? 'Teacher');

$teacherStats = [

    'classes' => null,

    'students' => null,

    'subjects' => null,

    'assignments' => null,

];

$assignmentNotice = '';

$assignmentSource = null;

if ($dashboardDb instanceof mysqli) {

    // Resolve the teacher's staff-record ID from the logged-in user when it is

    // not already stored in the session.

    if ($teacherId <= 0 && $userId > 0 && tdTableExists($dashboardDb, 'teachers')) {

        $teacherColumns = tdColumns($dashboardDb, 'teachers');

        $teacherPrimaryKey = tdFirstColumn($teacherColumns, ['id', 'teacher_id']);

        $teacherUserColumn = tdFirstColumn($teacherColumns, ['user_id', 'account_id', 'login_id']);

        if ($teacherPrimaryKey && $teacherUserColumn) {

            try {

                $sql = 'SELECT `' . $teacherPrimaryKey . '` AS teacher_id FROM `teachers` WHERE `' . $teacherUserColumn . '` = ? LIMIT 1';

                $stmt = $dashboardDb->prepare($sql);

                $stmt->bind_param('i', $userId);

                $stmt->execute();

                $teacherRow = $stmt->get_result()->fetch_assoc();

                $stmt->close();

                $teacherId = (int)($teacherRow['teacher_id'] ?? 0);

            } catch (Throwable $exception) {

                error_log('Teacher dashboard could not resolve teacher profile: ' . $exception->getMessage());

            }

        }

    }

    // Detect common teacher-to-class/subject assignment table names. Table and

    // column identifiers come only from the database schema, never from input.

    $candidateTables = [

        'teacher_classes',

        'class_teachers',

        'teacher_assignments',

        'teacher_class_subjects',

        'teacher_subjects',

        'class_teacher_assignments'

    ];

    foreach ($candidateTables as $candidateTable) {

        $columns = tdColumns($dashboardDb, $candidateTable);

        if (!$columns) {

            continue;

        }

        $teacherColumn = tdFirstColumn($columns, ['teacher_id', 'staff_id', 'employee_id']);

        $teacherValue = $teacherId;

        if (!$teacherColumn || $teacherValue <= 0) {

            $teacherColumn = isset($columns['user_id']) ? $columns['user_id'] : null;

            $teacherValue = $userId;

        }

        if (!$teacherColumn || $teacherValue <= 0) {

            continue;

        }

        $assignmentSource = [

            'table' => $candidateTable,

            'columns' => $columns,

            'teacher_column' => $teacherColumn,

            'teacher_value' => $teacherValue

        ];

        break;

    }

    if ($assignmentSource !== null) {

        $table = $assignmentSource['table'];

        $columns = $assignmentSource['columns'];

        $teacherColumn = $assignmentSource['teacher_column'];

        $teacherValue = $assignmentSource['teacher_value'];

        $classColumn = tdFirstColumn($columns, ['class_id']);

        $subjectColumn = tdFirstColumn($columns, ['subject_id']);

        $assignmentIdColumn = tdFirstColumn($columns, ['id', 'assignment_id']);

        if ($classColumn) {

            $teacherStats['classes'] = tdCountDistinct($dashboardDb, $table, $classColumn, $teacherColumn, $teacherValue);

            // Count students only within classes assigned to this teacher.

            $studentColumns = tdColumns($dashboardDb, 'students');

            $studentIdColumn = tdFirstColumn($studentColumns, ['id', 'student_id']);

            $studentClassColumn = tdFirstColumn($studentColumns, ['class_id']);

            if ($studentIdColumn && $studentClassColumn) {

                try {

                    $sql = 'SELECT COUNT(DISTINCT s.`' . $studentIdColumn . '`) AS total '

                         . 'FROM `students` s INNER JOIN `' . $table . '` a '

                         . 'ON s.`' . $studentClassColumn . '` = a.`' . $classColumn . '` '

                         . 'WHERE a.`' . $teacherColumn . '` = ?';

                    $stmt = $dashboardDb->prepare($sql);

                    $stmt->bind_param('i', $teacherValue);

                    $stmt->execute();

                    $row = $stmt->get_result()->fetch_assoc();

                    $stmt->close();

                    $teacherStats['students'] = (int)($row['total'] ?? 0);

                } catch (Throwable $exception) {

                    error_log('Teacher dashboard student count failed: ' . $exception->getMessage());

                }

            }

        }

        if ($subjectColumn) {

            $teacherStats['subjects'] = tdCountDistinct($dashboardDb, $table, $subjectColumn, $teacherColumn, $teacherValue);

        }

        if ($assignmentIdColumn) {

            $teacherStats['assignments'] = tdCountDistinct($dashboardDb, $table, $assignmentIdColumn, $teacherColumn, $teacherValue);

        } else {

            // A row count is an assignment count when the relation table has no ID column.

            try {

                $stmt = $dashboardDb->prepare('SELECT COUNT(*) AS total FROM `' . $table . '` WHERE `' . $teacherColumn . '` = ?');

                $stmt->bind_param('i', $teacherValue);

                $stmt->execute();

                $row = $stmt->get_result()->fetch_assoc();

                $stmt->close();

                $teacherStats['assignments'] = (int)($row['total'] ?? 0);

            } catch (Throwable $exception) {

                error_log('Teacher dashboard assignment count failed: ' . $exception->getMessage());

            }

        }

    } else {

        $assignmentNotice = 'Your teacher account is logged in, but a teacher-to-class assignment table could not be identified. Dashboard totals will appear after the assignment table or its column names are configured.';

    }

    if (in_array(null, $teacherStats, true)) {

        $dashboardDbWarning = true;

    }

} else {

    $assignmentNotice = 'The database connection is not available. Please contact the system administrator.';

}

// A module link is enabled only when its PHP page exists in the teacher folder.

$teacherModules = [

    ['title' => 'My Classes', 'description' => 'View the classes assigned to you and the students in each class.', 'icon' => 'fa-chalkboard', 'color' => 'blue', 'path' => 'teacher_classes_index.php', 'button' => 'View My Classes'],

    ['title' => 'My Subjects', 'description' => 'View the subjects you teach and their class allocations.', 'icon' => 'fa-book-open', 'color' => 'green', 'path' => 'teacher_subject_index.php', 'button' => 'View My Subjects'],

    ['title' => 'Attendance', 'description' => 'Record and review attendance for your assigned classes.', 'icon' => 'fa-calendar-check', 'color' => 'orange', 'path' => 'teacher_attendance_index.php', 'button' => 'Manage Attendance'],

    ['title' => 'Marks & Assessments', 'description' => 'Enter, update and review students’ assessment marks.', 'icon' => 'fa-clipboard-list', 'color' => 'purple', 'path' => 'teacher_marks_index.php', 'button' => 'Manage Marks'],

    ['title' => 'Timetable', 'description' => 'Check your teaching timetable and lesson schedule.', 'icon' => 'fa-calendar-alt', 'color' => 'blue', 'path' => 'timetable.php', 'button' => 'View Timetable'],

    ['title' => 'Student Reports', 'description' => 'View academic reports for students in your assigned classes.', 'icon' => 'fa-file-alt', 'color' => 'green', 'path' => 'student_reports.php', 'button' => 'View Reports'],

    ['title' => 'My Profile', 'description' => 'View your teacher account and profile information.', 'icon' => 'fa-user-circle', 'color' => 'orange', 'path' => 'profile.php', 'button' => 'View Profile'],

];

$navItems = [

    ['label' => 'Dashboard', 'path' => 'dashboard.php', 'icon' => 'fa-tachometer-alt', 'active' => true],

    ['label' => 'My Classes', 'path' => 'teacher_classes_index.php', 'icon' => 'fa-chalkboard'],

    ['label' => 'My Subjects', 'path' => 'teacher_subject_index.php', 'icon' => 'fa-book-open'],

    ['label' => 'Attendance', 'path' => 'teacher_attendance_index.php', 'icon' => 'fa-calendar-check'],

    ['label' => 'Marks & Assessments', 'path' => 'teacher_marks_index.php', 'icon' => 'fa-clipboard-list'],

    ['label' => 'Timetable', 'path' => 'timetable.php', 'icon' => 'fa-calendar-alt'],

    ['label' => 'Student Reports', 'path' => 'student_reports.php', 'icon' => 'fa-file-alt'],

    ['label' => 'My Profile', 'path' => 'profile.php', 'icon' => 'fa-user-circle'],

];

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Teacher Dashboard | School Management System</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>

        body { background: #f4f6f9; font-family: Arial, sans-serif; }

        .sidebar { position: fixed; left: 0; top: 0; bottom: 0; width: 250px; background: #172b4d; color: white; overflow-y: auto; z-index: 1000; }

        .sidebar-brand { padding: 25px 20px; font-size: 21px; font-weight: bold; background: #10213d; text-align: center; }

        .sidebar-menu { padding: 15px 10px; }

        .sidebar-menu a, .sidebar-menu .disabled-link { display: block; color: #d8e0eb; padding: 13px 15px; margin-bottom: 5px; border-radius: 6px; text-decoration: none; transition: 0.2s; }

        .sidebar-menu a:hover, .sidebar-menu a.active { background: #007bff; color: white; }

        .sidebar-menu i { width: 25px; }

        .sidebar-menu .disabled-link { color: #8998ad; cursor: not-allowed; opacity: .7; }

        .menu-title { color: #8998ad; font-size: 12px; text-transform: uppercase; padding: 15px; margin-top: 10px; }

        .main-content { margin-left: 250px; min-height: 100vh; }

        .topbar { background: white; padding: 15px 25px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); display: flex; justify-content: space-between; align-items: center; }

        .topbar h4 { margin: 0; font-weight: 600; }

        .welcome-box { background: linear-gradient(135deg, #007bff, #0056b3); color: white; border-radius: 10px; padding: 25px; margin-bottom: 25px; }

        .welcome-box h3 { font-weight: bold; }

        .stat-card { border: none; border-radius: 10px; box-shadow: 0 3px 12px rgba(0,0,0,0.08); transition: 0.2s; }

        .stat-card:hover { transform: translateY(-3px); }

        .stat-icon { width: 55px; height: 55px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 23px; color: white; }

        .blue { background: #007bff; }

        .green { background: #28a745; }

        .orange { background: #fd7e14; }

        .purple { background: #6f42c1; }

        .stat-number { font-size: 24px; font-weight: 700; margin: 0; }

        .module-card { background: white; border-radius: 10px; padding: 25px; height: 100%; border: none; box-shadow: 0 3px 12px rgba(0,0,0,0.07); transition: 0.2s; }

        .module-card:hover { transform: translateY(-4px); box-shadow: 0 7px 20px rgba(0,0,0,0.12); }

        .module-icon { width: 60px; height: 60px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 26px; color: white; margin-bottom: 15px; }

        .module-card h5 { font-weight: bold; margin-bottom: 8px; }

        .module-card p { color: #777; font-size: 14px; min-height: 40px; }

        .module-card .btn { border-radius: 5px; }

        .dashboard-note { border-radius: 8px; }

        @media (max-width: 768px) {

            .sidebar { position: relative; width: 100%; min-height: auto; }

            .main-content { margin-left: 0; }

            .sidebar-menu { padding-bottom: 10px; }

            .topbar { padding: 14px 16px; flex-wrap: wrap; row-gap: 10px; }

            .container-fluid.p-4 { padding: 1rem !important; }

        }

    </style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">

<link rel="stylesheet" href="/assets/css/admin-theme.css?v=20261114">
</head>

<body>

<button type="button" id="unifiedSidebarToggle" class="unified-sidebar-toggle" aria-label="Open navigation" aria-controls="sidebar" aria-expanded="false"><i class="fas fa-bars"></i></button>

<div id="unifiedSidebarOverlay" class="sidebar-overlay"></div>

    <div class="sidebar">

        <div class="sidebar-brand"><i class="fas fa-school mr-2"></i>School Management</div>

        <div class="sidebar-menu">

            <div class="menu-title">Main</div>

            <a href="/teacher/dashboard.php" class="active"><i class="fas fa-tachometer-alt"></i>Dashboard</a>

            <div class="menu-title">Teaching</div>

            <?php foreach ($navItems as $item): if ($item['active'] ?? false) continue; $exists = is_file(__DIR__ . '/' . $item['path']); ?>

                <?php if ($exists): ?>

                    <a href="<?= tdE($item['path']) ?>"><i class="fas <?= tdE($item['icon']) ?>"></i><?= tdE($item['label']) ?></a>

                <?php else: ?>

                    <span class="disabled-link" title="This module page has not been installed yet"><i class="fas <?= tdE($item['icon']) ?>"></i><?= tdE($item['label']) ?></span>

                <?php endif; ?>

            <?php endforeach; ?>

            <div class="menu-title">Account</div>

            <a href="/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>

        </div>

    </div>

    <div class="main-content">

        <div class="topbar">

            <h4><i class="fas fa-chalkboard-teacher text-primary mr-2"></i>Teacher Dashboard</h4>

            <div>

                <span class="mr-3"><i class="fas fa-user-circle"></i> <?= tdE($teacherName) ?></span>

                <a href="../logout.php" class="btn btn-outline-danger btn-sm"><i class="fas fa-sign-out-alt"></i> Logout</a>

            </div>

        </div>

        <div class="container-fluid p-4">

            <?php if ($dashboardDbWarning): ?>

                <div class="alert alert-warning dashboard-note" role="status">

                    <strong>Some teacher dashboard totals are unavailable.</strong>

                    The dashboard will still load. Check the PHP error log and confirm that your teacher assignment tables and columns match the existing database.

                </div>

            <?php endif; ?>

            <?php if ($assignmentNotice !== ''): ?>

                <div class="alert alert-info dashboard-note" role="status"><?= tdE($assignmentNotice) ?></div>

            <?php endif; ?>

            <div class="welcome-box">

                <h3>Welcome, <?= tdE($teacherName) ?></h3>

                <p class="mb-0">Manage your teaching work, assigned classes, subjects, attendance, student assessments and academic reports from one place.</p>

            </div>

            <div class="row">

                <div class="col-md-3 mb-4">

                    <div class="card stat-card"><div class="card-body d-flex align-items-center">

                        <div class="stat-icon blue mr-3"><i class="fas fa-chalkboard"></i></div>

                        <div><small class="text-muted">My Classes</small><h4 class="stat-number"><?= $teacherStats['classes'] === null ? '—' : number_format($teacherStats['classes']) ?></h4></div>

                    </div></div>

                </div>

                <div class="col-md-3 mb-4">

                    <div class="card stat-card"><div class="card-body d-flex align-items-center">

                        <div class="stat-icon green mr-3"><i class="fas fa-user-graduate"></i></div>

                        <div><small class="text-muted">My Students</small><h4 class="stat-number"><?= $teacherStats['students'] === null ? '—' : number_format($teacherStats['students']) ?></h4></div>

                    </div></div>

                </div>

                <div class="col-md-3 mb-4">

                    <div class="card stat-card"><div class="card-body d-flex align-items-center">

                        <div class="stat-icon orange mr-3"><i class="fas fa-book"></i></div>

                        <div><small class="text-muted">My Subjects</small><h4 class="stat-number"><?= $teacherStats['subjects'] === null ? '—' : number_format($teacherStats['subjects']) ?></h4></div>

                    </div></div>

                </div>

                <div class="col-md-3 mb-4">

                    <div class="card stat-card"><div class="card-body d-flex align-items-center">

                        <div class="stat-icon purple mr-3"><i class="fas fa-tasks"></i></div>

                        <div><small class="text-muted">My Assignments</small><h4 class="stat-number"><?= $teacherStats['assignments'] === null ? '—' : number_format($teacherStats['assignments']) ?></h4></div>

                    </div></div>

                </div>

            </div>

            <div class="d-flex justify-content-between align-items-center mb-3">

                <h4 class="mb-0">Teaching Activities</h4>

                <small class="text-muted">Your teacher workspace</small>

            </div>

            <div class="row">

                <?php foreach ($teacherModules as $module): $moduleExists = is_file(__DIR__ . '/' . $module['path']); ?>

                    <div class="col-lg-4 col-md-6 mb-4">

                        <div class="module-card">

                            <div class="module-icon <?= tdE($module['color']) ?>"><i class="fas <?= tdE($module['icon']) ?>"></i></div>

                            <h5><?= tdE($module['title']) ?></h5>

                            <p><?= tdE($module['description']) ?></p>

                            <?php if ($moduleExists): ?>

                                <a href="<?= tdE($module['path']) ?>" class="btn btn-primary btn-block"><?= tdE($module['button']) ?></a>

                            <?php else: ?>

                                <button type="button" class="btn btn-secondary btn-block" disabled>Module page not installed</button>

                            <?php endif; ?>

                        </div>

                    </div>

                <?php endforeach; ?>

            </div>

            <div class="text-center text-muted mt-4 mb-3">

                <small>School Management System &copy; <?= date('Y') ?></small>

            </div>

        </div>

    </div>

<script src="/assets/js/sidebar-unified.js?v=20261106"></script>

</body>

</html>
