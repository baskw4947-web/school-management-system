<?php
/**
 * Teacher - My Subjects
 * Location: /teacher/teacher_subject_index.php
 * Subject allocations are read from class_timetables because the supplied
 * school database stores subject_name and teacher_name in that table.
 */
require_once __DIR__ . '/../includes/auth.php';
requireRole(['teacher']);

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function mySubjectsE($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function mySubjectsIdent(string $name): string
{
    if (!preg_match('/^[A-Za-z0-9_]+$/', $name)) {
        throw new RuntimeException('Invalid database identifier.');
    }
    return '`' . $name . '`';
}

function mySubjectsColumns(mysqli $db, string $table): array
{
    $columns = [];
    $result = $db->query('SHOW COLUMNS FROM ' . mySubjectsIdent($table));
    while ($row = $result->fetch_assoc()) {
        $columns[strtolower((string)$row['Field'])] = (string)$row['Field'];
    }
    $result->free();
    return $columns;
}

function mySubjectsFirstColumn(array $columns, array $names): ?string
{
    foreach ($names as $name) {
        $key = strtolower($name);
        if (isset($columns[$key])) return $columns[$key];
    }
    return null;
}

function mySubjectsNormalise(string $name): string
{
    $name = trim(preg_replace('/\\s+/', ' ', $name) ?? $name);
    return function_exists('mb_strtolower') ? mb_strtolower($name, 'UTF-8') : strtolower($name);
}

function mySubjectsTeacherName(array $row, array $columns): string
{
    foreach (['full_name', 'teacher_name', 'staff_name', 'employee_name', 'name'] as $key) {
        if (!empty($columns[$key]) && trim((string)($row[$columns[$key]] ?? '')) !== '') {
            return trim((string)$row[$columns[$key]]);
        }
    }
    $parts = [];
    foreach (['first_name', 'other_names', 'last_name'] as $key) {
        if (!empty($columns[$key]) && trim((string)($row[$columns[$key]] ?? '')) !== '') {
            $parts[] = trim((string)$row[$columns[$key]]);
        }
    }
    return trim(implode(' ', $parts));
}

$teacherDisplayName = trim((string)($_SESSION['full_name'] ?? $_SESSION['teacher_name'] ?? $_SESSION['name'] ?? 'Teacher'));
$userId = (int)($_SESSION['user_id'] ?? $_SESSION['id'] ?? 0);
$teacherId = (int)($_SESSION['teacher_id'] ?? $_SESSION['staff_id'] ?? 0);
$subjects = [];
$pageError = '';
$notice = '';

try {
    require_once __DIR__ . '/../config/database.php';
    $db = $conn ?? ($mysqli ?? ($connection ?? null));
    if (!$db instanceof mysqli) {
        throw new RuntimeException('Database connection not available.');
    }
    $db->set_charset('utf8mb4');

    $tables = [];
    $tableResult = $db->query('SHOW TABLES');
    while ($tableRow = $tableResult->fetch_row()) {
        $tables[strtolower((string)$tableRow[0])] = (string)$tableRow[0];
    }
    $tableResult->free();

    if (!isset($tables['class_timetables'])) {
        $notice = 'The class timetable table has not been created yet. Ask the administrator to configure subject and teacher allocations.';
    } else {
        $teacherAliases = [];
        $addAlias = static function ($value) use (&$teacherAliases): void {
            $value = trim((string)($value ?? ''));
            if ($value === '') return;
            foreach ($teacherAliases as $existing) {
                if (mySubjectsNormalise($existing) === mySubjectsNormalise($value)) return;
            }
            $teacherAliases[] = $value;
        };

        // Prefer an explicit teacher ID if the login/session and teachers table support it.
        if (isset($tables['teachers'])) {
            $teacherTable = $tables['teachers'];
            $teacherColumns = mySubjectsColumns($db, $teacherTable);
            $pk = mySubjectsFirstColumn($teacherColumns, ['id', 'teacher_id']);
            $userCol = mySubjectsFirstColumn($teacherColumns, ['user_id', 'account_id', 'login_id', 'system_user_id']);
            $profile = null;

            if ($teacherId > 0 && $pk) {
                $stmt = $db->prepare('SELECT * FROM ' . mySubjectsIdent($teacherTable) . ' WHERE ' . mySubjectsIdent($pk) . ' = ? LIMIT 1');
                $stmt->bind_param('i', $teacherId);
                $stmt->execute();
                $profile = $stmt->get_result()->fetch_assoc() ?: null;
                $stmt->close();
            }
            if (!$profile && $userId > 0 && $userCol && $pk) {
                $stmt = $db->prepare('SELECT * FROM ' . mySubjectsIdent($teacherTable) . ' WHERE ' . mySubjectsIdent($userCol) . ' = ? LIMIT 1');
                $stmt->bind_param('i', $userId);
                $stmt->execute();
                $profile = $stmt->get_result()->fetch_assoc() ?: null;
                $stmt->close();
            }
            if (!$profile && $teacherDisplayName !== '' && $teacherDisplayName !== 'Teacher') {
                $result = $db->query('SELECT * FROM ' . mySubjectsIdent($teacherTable));
                $matches = [];
                $firstMatches = [];
                while ($row = $result->fetch_assoc()) {
                    $full = mySubjectsTeacherName($row, $teacherColumns);
                    if ($full !== '' && mySubjectsNormalise($full) === mySubjectsNormalise($teacherDisplayName)) {
                        $matches[] = $row;
                    }
                    $firstCol = $teacherColumns['first_name'] ?? null;
                    if ($firstCol && mySubjectsNormalise((string)$row[$firstCol]) === mySubjectsNormalise($teacherDisplayName)) {
                        $firstMatches[] = $row;
                    }
                }
                $result->free();
                if (count($matches) === 1) $profile = $matches[0];
                elseif (count($matches) > 1) $notice = 'Your login name matches more than one teacher profile. Ask the administrator to link your login to the correct teacher profile.';
                elseif (count($firstMatches) === 1) $profile = $firstMatches[0];
            }

            if ($teacherDisplayName !== '' && $teacherDisplayName !== 'Teacher') $addAlias($teacherDisplayName);
            if ($profile) {
                $addAlias(mySubjectsTeacherName($profile, $teacherColumns));
                foreach (['full_name', 'teacher_name', 'staff_name', 'employee_name', 'name'] as $key) {
                    if (isset($teacherColumns[$key])) $addAlias($profile[$teacherColumns[$key]] ?? '');
                }
                $first = isset($teacherColumns['first_name']) ? trim((string)($profile[$teacherColumns['first_name']] ?? '')) : '';
                $other = isset($teacherColumns['other_names']) ? trim((string)($profile[$teacherColumns['other_names']] ?? '')) : '';
                $last = isset($teacherColumns['last_name']) ? trim((string)($profile[$teacherColumns['last_name']] ?? '')) : '';
                if ($first !== '' && $last !== '') {
                    $addAlias($first . ' ' . $last);
                    if ($other !== '') $addAlias($first . ' ' . $other . ' ' . $last);
                }
                // Allow first-name-only timetable entries only when the first name is unique.
                if ($first !== '') {
                    $countStmt = $db->prepare('SELECT COUNT(*) AS total FROM ' . mySubjectsIdent($teacherTable) . ' WHERE LOWER(TRIM(' . mySubjectsIdent($teacherColumns['first_name']) . ')) = LOWER(TRIM(?))');
                    $countStmt->bind_param('s', $first);
                    $countStmt->execute();
                    $count = (int)($countStmt->get_result()->fetch_assoc()['total'] ?? 0);
                    $countStmt->close();
                    if ($count === 1) $addAlias($first);
                }
            }
        } elseif ($teacherDisplayName !== '' && $teacherDisplayName !== 'Teacher') {
            $addAlias($teacherDisplayName);
        }

        if (!$teacherAliases) {
            $notice = $notice ?: 'Your teacher name could not be matched. Ask the administrator to check your teacher profile and timetable allocation.';
        } elseif ($notice === '') {
            $tt = mySubjectsColumns($db, $tables['class_timetables']);
            $teacherCol = mySubjectsFirstColumn($tt, ['teacher_name', 'teacher', 'staff_name']);
            $subjectCol = mySubjectsFirstColumn($tt, ['subject_name', 'subject']);
            $classCol = mySubjectsFirstColumn($tt, ['class_name', 'class']);

            if (!$teacherCol || !$subjectCol || !$classCol) {
                $notice = 'The class timetable is missing the subject, class or teacher column required to show your allocations.';
            } else {
                $selectMap = [
                    'subject' => $subjectCol,
                    'class_name' => $classCol,
                    'stream' => mySubjectsFirstColumn($tt, ['stream', 'section']),
                    'academic_year' => mySubjectsFirstColumn($tt, ['academic_year', 'year']),
                    'term' => mySubjectsFirstColumn($tt, ['term']),
                    'day' => mySubjectsFirstColumn($tt, ['day_of_week', 'day']),
                    'start_time' => mySubjectsFirstColumn($tt, ['start_time']),
                    'end_time' => mySubjectsFirstColumn($tt, ['end_time']),
                    'room' => mySubjectsFirstColumn($tt, ['room', 'venue']),
                    'lesson_type' => mySubjectsFirstColumn($tt, ['lesson_type']),
                    'status' => mySubjectsFirstColumn($tt, ['status'])
                ];
                $selectParts = [];
                foreach ($selectMap as $alias => $column) {
                    $selectParts[] = $column ? mySubjectsIdent($column) . ' AS ' . mySubjectsIdent($alias) : "'' AS " . mySubjectsIdent($alias);
                }
                $placeholders = implode(',', array_fill(0, count($teacherAliases), '?'));
                $sql = 'SELECT DISTINCT ' . implode(', ', $selectParts)
                     . ' FROM ' . mySubjectsIdent($tables['class_timetables'])
                     . ' WHERE LOWER(TRIM(' . mySubjectsIdent($teacherCol) . ')) IN (' . $placeholders . ')';
                if ($selectMap['status']) $sql .= " AND LOWER(TRIM(" . mySubjectsIdent($selectMap['status']) . ")) NOT IN ('cancelled','inactive')";
                $sql .= ' ORDER BY ' . mySubjectsIdent($subjectCol) . ', ' . mySubjectsIdent($classCol);
                $stmt = $db->prepare($sql);
                $normalAliases = array_map('mySubjectsNormalise', $teacherAliases);
                $bind = [str_repeat('s', count($normalAliases))];
                foreach ($normalAliases as $key => &$alias) $bind[] = &$alias;
                unset($alias);
                call_user_func_array([$stmt, 'bind_param'], $bind);
                $stmt->execute();
                $result = $stmt->get_result();
                while ($row = $result->fetch_assoc()) $subjects[] = $row;
                $result->free();
                $stmt->close();
                if (!$subjects && $notice === '') {
                    $notice = 'No subject allocations were found for your teacher account. Ask the administrator to add your name to the class timetable.';
                }
            }
        }
    }
} catch (Throwable $e) {
    error_log('Teacher My Subjects page: ' . $e->getMessage());
    $pageError = 'The My Subjects page could not load. Please contact the system administrator and ask them to check the PHP error log.';
}

$subjectCount = count(array_unique(array_map(static fn($row) => mySubjectsNormalise((string)$row['subject']), $subjects)));
$classCount = count(array_unique(array_map(static fn($row) => mySubjectsNormalise((string)$row['class_name'] . '|' . $row['stream'] . '|' . $row['academic_year']), $subjects)));
$search = trim((string)($_GET['q'] ?? ''));
$filteredSubjects = array_values(array_filter($subjects, static function ($row) use ($search) {
    if ($search === '') return true;
    $haystack = implode(' ', [$row['subject'], $row['class_name'], $row['stream'], $row['academic_year'], $row['term']]);
    return stripos($haystack, $search) !== false;
}));
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>My Subjects | School Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.6.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root{--navy:#172b4d;--navy-dark:#10213d;--blue:#007bff;--bg:#f4f6f9}
        body{background:var(--bg);font-family:Arial,sans-serif;color:#243247}
        .sidebar{position:fixed;left:0;top:0;bottom:0;width:250px;background:var(--navy);color:#fff;overflow-y:auto;z-index:1050}
        .brand{padding:25px 18px;background:var(--navy-dark);text-align:center;font-size:19px;font-weight:700}
        .brand small{display:block;color:#aebbd0;font-size:12px;font-weight:400;margin-top:5px}
        .menu{padding:15px 10px}.menu-title{color:#8998ad;font-size:11px;letter-spacing:.7px;text-transform:uppercase;padding:14px 15px 8px}
        .menu a{display:block;color:#d8e0eb;padding:12px 15px;margin-bottom:5px;border-radius:6px;text-decoration:none}.menu a:hover,.menu a.active{background:var(--blue);color:#fff}.menu i{width:25px}
        .main{margin-left:250px;min-height:100vh}.topbar{background:#fff;padding:15px 25px;box-shadow:0 2px 8px rgba(0,0,0,.07);display:flex;justify-content:space-between;align-items:center;gap:15px}
        .topbar h4{margin:0;font-weight:600}.content{padding:24px}.heading,.panel,.stat{background:#fff;border-radius:10px;box-shadow:0 3px 12px rgba(0,0,0,.055)}
        .heading{padding:22px 24px;margin-bottom:20px}.heading h2{font-size:23px;margin:0 0 6px;font-weight:700}.heading p{margin:0;color:#6c757d}
        .stat{padding:19px;height:100%;display:flex;align-items:center}.stat-icon{width:48px;height:48px;border-radius:10px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:20px;margin-right:13px;flex-shrink:0}
        .stat-label{color:#6c757d;font-size:13px}.stat-value{font-size:24px;font-weight:700;line-height:1.1}
        .panel{padding:19px;margin-bottom:20px}.table thead th{background:#f8f9fb;color:#596579;border-top:0;font-size:12px;text-transform:uppercase;white-space:nowrap}.table td{vertical-align:middle;font-size:13px}
        .subject-name{font-weight:700;color:#26364a}.tag{display:inline-block;background:#eaf2ff;color:#1558a6;border-radius:20px;padding:5px 9px;font-size:11px;font-weight:700}
        .muted{color:#778397;font-size:12px}.empty{padding:35px 15px;text-align:center;color:#6c757d}.empty i{font-size:34px;color:#b7c1ce;margin-bottom:10px}
        .mobile-btn{display:none;border:0;background:transparent;color:#fff;font-size:20px;margin-right:10px}
        @media(max-width:991px){.sidebar{left:-260px;transition:left .2s}.sidebar.show{left:0}.main{margin-left:0}.mobile-btn{display:inline-block}.topbar{padding:13px 16px}.content{padding:16px}}
        @media(max-width:575px){.heading{padding:18px}.heading h2{font-size:20px}.top-user{font-size:12px}}
    </style>
<link rel="stylesheet" href="/assets/css/admin-theme.css?v=20261114">
</head>
<body>
<aside class="sidebar" id="sidebar">
    <div class="brand"><i class="fas fa-school mr-2"></i>School Management<small>Teacher Workspace</small></div>
    <nav class="menu">
        <div class="menu-title">Main</div>
        <a href="/teacher/dashboard.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
        <a href="/teacher/teacher_classes_index.php"><i class="fas fa-chalkboard"></i>My Classes</a>
        <a href="/teacher/teacher_subject_index.php" class="active"><i class="fas fa-book-open"></i>My Subjects</a>
        <div class="menu-title">Account</div>
        <a href="/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
    </nav>
</aside>
<div class="main">
    <header class="topbar">
        <div class="d-flex align-items-center"><button class="mobile-btn" id="menuBtn" type="button" aria-label="Open menu"><i class="fas fa-bars"></i></button><h4><i class="fas fa-book-open text-primary mr-2"></i>My Subjects</h4></div>
        <div class="top-user"><i class="fas fa-user-circle mr-1"></i><?= mySubjectsE($teacherDisplayName) ?> <a href="/logout.php" class="btn btn-sm btn-outline-danger ml-2">Logout</a></div>
    </header>
    <main class="content">
        <?php if ($pageError !== ''): ?><div class="alert alert-danger"><?= mySubjectsE($pageError) ?></div><?php endif; ?>
        <?php if ($notice !== ''): ?><div class="alert alert-info"><i class="fas fa-info-circle mr-1"></i><?= mySubjectsE($notice) ?></div><?php endif; ?>
        <section class="heading"><h2><i class="fas fa-book-reader text-primary mr-2"></i>My Teaching Subjects</h2><p>View the subjects allocated to you, the classes you teach, and their timetable details.</p></section>
        <div class="row mb-4">
            <div class="col-md-6 mb-3"><div class="stat"><div class="stat-icon" style="background:#007bff"><i class="fas fa-book"></i></div><div><div class="stat-label">Assigned subjects</div><div class="stat-value"><?= number_format($subjectCount) ?></div></div></div></div>
            <div class="col-md-6 mb-3"><div class="stat"><div class="stat-icon" style="background:#28a745"><i class="fas fa-chalkboard"></i></div><div><div class="stat-label">Class allocations</div><div class="stat-value"><?= number_format($classCount) ?></div></div></div></div>
        </div>
        <section class="panel">
            <form method="get" action="index.php" class="form-row align-items-end">
                <div class="form-group col-md-8 mb-2"><label for="q" class="font-weight-bold small">Search my allocations</label><input type="search" class="form-control" id="q" name="q" value="<?= mySubjectsE($search) ?>" placeholder="Search subject, class, stream, academic year or term"></div>
                <div class="form-group col-md-4 mb-2"><button class="btn btn-primary" type="submit"><i class="fas fa-search mr-1"></i>Search</button> <a class="btn btn-outline-secondary" href="index.php">Clear</a></div>
            </form>
        </section>
        <section class="panel p-0">
            <div class="d-flex justify-content-between align-items-center flex-wrap p-3 border-bottom"><h5 class="mb-0">My Subject Allocations</h5><span class="tag"><?= number_format(count($filteredSubjects)) ?> allocation(s)</span></div>
            <?php if (!$filteredSubjects): ?>
                <div class="empty"><i class="fas fa-book-open d-block"></i><strong>No subject allocations to display</strong><div class="mt-1">Your assigned subjects will appear here after the administrator adds them to the class timetable.</div></div>
            <?php else: ?>
                <div class="table-responsive"><table class="table table-hover mb-0">
                    <thead><tr><th>#</th><th>Subject</th><th>Class</th><th>Stream</th><th>Academic Year</th><th>Term</th><th>Day</th><th>Time</th><th>Room</th><th>Lesson Type</th></tr></thead>
                    <tbody><?php foreach ($filteredSubjects as $i => $row): ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td><span class="subject-name"><?= mySubjectsE($row['subject']) ?></span></td>
                            <td><?= mySubjectsE($row['class_name']) ?></td>
                            <td><?= mySubjectsE($row['stream'] !== '' ? $row['stream'] : '—') ?></td>
                            <td><?= mySubjectsE($row['academic_year'] !== '' ? $row['academic_year'] : '—') ?></td>
                            <td><?= mySubjectsE($row['term'] !== '' ? $row['term'] : '—') ?></td>
                            <td><?= mySubjectsE($row['day'] !== '' ? $row['day'] : '—') ?></td>
                            <td><?= mySubjectsE(($row['start_time'] !== '' ? date('g:i A', strtotime($row['start_time'])) : '—') . ' - ' . ($row['end_time'] !== '' ? date('g:i A', strtotime($row['end_time'])) : '—')) ?></td>
                            <td><?= mySubjectsE($row['room'] !== '' ? $row['room'] : '—') ?></td>
                            <td><?= mySubjectsE($row['lesson_type'] !== '' ? $row['lesson_type'] : 'Lesson') ?></td>
                        </tr>
                    <?php endforeach; ?></tbody>
                </table></div>
            <?php endif; ?>
        </section>
        <div class="text-center text-muted mt-4"><small>School Management System &copy; <?= date('Y') ?></small></div>
    </main>
</div>
<script>
(function(){var sidebar=document.getElementById('sidebar');var btn=document.getElementById('menuBtn');if(btn&&sidebar){btn.addEventListener('click',function(){sidebar.classList.toggle('show');});}window.addEventListener('resize',function(){if(window.innerWidth>991&&sidebar)sidebar.classList.remove('show');});})();
</script>
</body>
</html>
