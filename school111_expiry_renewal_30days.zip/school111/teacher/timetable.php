<?php
/**
 * TEACHER MY TIMETABLE
 * File: /public_html/teacher/timetable.php
 *
 * Reads lessons created by:
 * /public_html/admin/classes/timetable.php
 *
 * Teachers can only view their own timetable.
 */

ob_start();


error_reporting(E_ALL);
ini_set('display_errors', '0');

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';

requireLogin();
requireRole(['teacher']);

$db = $conn ?? ($mysqli ?? ($connection ?? null));

if (!$db instanceof mysqli) {
    http_response_code(500);
    exit('Database connection is not available. Check config/database.php.');
}

$db->set_charset('utf8mb4');

// Get the teacher's logged-in name.
$teacherName = trim((string)(
    $_SESSION['full_name']
    ?? $_SESSION['teacher_name']
    ?? $_SESSION['name']
    ?? ''
));

/* -------------------------------------------------------
   HELPER FUNCTIONS
------------------------------------------------------- */

function teacherTtEscape($value): string
{
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

function teacherTtTime($time): string
{
    if (empty($time)) {
        return '-';
    }

    $timestamp = strtotime((string)$time);

    return $timestamp === false
        ? '-'
        : date('h:i A', $timestamp);
}

/* -------------------------------------------------------
   FILTERS
------------------------------------------------------- */

$days = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday'
];

$filterYear = trim((string)($_GET['academic_year'] ?? ''));
$filterTerm = trim((string)($_GET['term'] ?? ''));
$filterDay = trim((string)($_GET['day'] ?? ''));

if (!in_array($filterDay, $days, true)) {
    $filterDay = '';
}

$allLessons = [];
$lessons = [];

$years = [];
$terms = [];

$weeklyTimetable = array_fill_keys($days, []);

$totalLessons = 0;
$totalClasses = 0;
$totalSubjects = 0;

$pageError = '';
$notice = '';

/* -------------------------------------------------------
   LOAD TEACHER'S TIMETABLE
------------------------------------------------------- */

try {

    if ($teacherName === '') {
        throw new RuntimeException(
            'Your teacher name was not found in your login session. Please log out and log in again.'
        );
    }

    $sql = "
        SELECT
            id,
            timetable_code,
            class_name,
            stream,
            subject_name,
            teacher_name,
            room,
            day_of_week,
            start_time,
            end_time,
            academic_year,
            term,
            lesson_type,
            notes,
            status
        FROM class_timetables
        WHERE LOWER(TRIM(teacher_name)) = LOWER(TRIM(?))
          AND LOWER(TRIM(status)) NOT IN ('cancelled', 'inactive')
        ORDER BY
            FIELD(
                day_of_week,
                'Monday',
                'Tuesday',
                'Wednesday',
                'Thursday',
                'Friday',
                'Saturday',
                'Sunday'
            ),
            start_time ASC
    ";

    $stmt = $db->prepare($sql);

    if (!$stmt) {
        throw new RuntimeException(
            'Could not prepare timetable query: ' . $db->error
        );
    }

    $stmt->bind_param('s', $teacherName);
    $stmt->execute();

    // bind_result avoids depending on mysqli get_result().
    $stmt->bind_result(
        $id,
        $timetableCode,
        $className,
        $stream,
        $subjectName,
        $savedTeacherName,
        $room,
        $dayOfWeek,
        $startTime,
        $endTime,
        $academicYear,
        $term,
        $lessonType,
        $notes,
        $status
    );

    while ($stmt->fetch()) {

        $allLessons[] = [
            'id' => $id,
            'timetable_code' => $timetableCode,
            'class_name' => $className,
            'stream' => $stream,
            'subject_name' => $subjectName,
            'teacher_name' => $savedTeacherName,
            'room' => $room,
            'day_of_week' => $dayOfWeek,
            'start_time' => $startTime,
            'end_time' => $endTime,
            'academic_year' => $academicYear,
            'term' => $term,
            'lesson_type' => $lessonType,
            'notes' => $notes,
            'status' => $status
        ];
    }

    $stmt->close();

} catch (Throwable $e) {

    $pageError = $e->getMessage();

    error_log(
        'Teacher timetable error: ' .
        $e->getMessage()
    );
}

/* -------------------------------------------------------
   BUILD FILTER OPTIONS AND FILTER RECORDS
------------------------------------------------------- */

if ($pageError === '') {

    foreach ($allLessons as $lesson) {

        $yearValue = trim((string)$lesson['academic_year']);
        $termValue = trim((string)$lesson['term']);

        if ($yearValue !== '' && !in_array($yearValue, $years, true)) {
            $years[] = $yearValue;
        }

        if ($termValue !== '' && !in_array($termValue, $terms, true)) {
            $terms[] = $termValue;
        }

        // Apply selected filters.
        if (
            $filterYear !== '' &&
            $lesson['academic_year'] !== $filterYear
        ) {
            continue;
        }

        if (
            $filterTerm !== '' &&
            $lesson['term'] !== $filterTerm
        ) {
            continue;
        }

        if (
            $filterDay !== '' &&
            $lesson['day_of_week'] !== $filterDay
        ) {
            continue;
        }

        $lessons[] = $lesson;
    }

    sort($years);
    sort($terms);

    // Group lessons by day.
    foreach ($days as $weekday) {
        $weeklyTimetable[$weekday] = [];
    }

    foreach ($lessons as $lesson) {

        $weekday = trim((string)$lesson['day_of_week']);

        if (isset($weeklyTimetable[$weekday])) {
            $weeklyTimetable[$weekday][] = $lesson;
        }
    }

    $totalLessons = count($lessons);

    $totalClasses = count(array_unique(
        array_column($lessons, 'class_name')
    ));

    $totalSubjects = count(array_unique(
        array_column($lessons, 'subject_name')
    ));

    if (count($allLessons) === 0) {
        $notice = 'No active timetable lessons have been assigned to your teacher name yet. Please contact the administrator.';
    } elseif ($totalLessons === 0) {
        $notice = 'No lessons match the filters you selected.';
    }
}

$displayName = $teacherName !== '' ? $teacherName : 'Teacher';
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1">

    <title>My Timetable | Teacher Portal</title>

    <link rel="stylesheet"
          href="https://stackpath.bootstrapcdn.com/bootstrap/4.6.2/css/bootstrap.min.css">

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            background: #f4f6f9;
            font-family: Arial, sans-serif;
            margin: 0;
            color: #333;
        }

        /* SIDEBAR */

        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: #172b4d;
            color: #fff;
            overflow-y: auto;
            z-index: 1000;
            transition: all .3s ease;
        }

        .sidebar-header {
            padding: 24px 18px;
            background: #10213d;
            text-align: center;
        }

        .sidebar-header h4 {
            font-size: 19px;
            margin: 0;
            font-weight: bold;
        }

        .sidebar-header small {
            color: #cbd5e1;
        }

        .sidebar-menu {
            padding: 15px 0;
        }

        .sidebar-menu a {
            display: block;
            padding: 13px 20px;
            color: #dce4f2;
            text-decoration: none;
            font-size: 14px;
        }

        .sidebar-menu a i {
            width: 25px;
        }

        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: #007bff;
            color: #fff;
        }

        .sidebar-menu .logout {
            color: #ffb3b3;
        }

        /* MAIN CONTENT */

        .main-content {
            margin-left: 250px;
            padding: 25px;
        }

        .topbar {
            background: #fff;
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .topbar h5 {
            margin: 0;
            color: #172b4d;
            font-weight: bold;
        }

        .mobile-btn {
            display: none;
            border: none;
            background: #172b4d;
            color: #fff;
            padding: 8px 12px;
            border-radius: 5px;
        }

        .page-heading {
            margin-bottom: 22px;
        }

        .page-heading h3 {
            color: #172b4d;
            font-weight: bold;
        }

        .page-heading p {
            color: #777;
            margin-bottom: 0;
        }

        /* STATISTICS */

        .stat-card {
            background: #fff;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,.05);
            display: flex;
            align-items: center;
            min-height: 105px;
        }

        .stat-icon {
            width: 52px;
            height: 52px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            margin-right: 15px;
        }

        .icon-blue {
            background: #e5f0ff;
            color: #007bff;
        }

        .icon-green {
            background: #e2f7eb;
            color: #28a745;
        }

        .icon-orange {
            background: #fff0dc;
            color: #fd7e14;
        }

        .stat-card h4 {
            margin: 0;
            font-weight: bold;
            color: #172b4d;
        }

        .stat-card p {
            margin: 3px 0 0;
            color: #777;
            font-size: 13px;
        }

        /* PANELS */

        .panel {
            background: #fff;
            padding: 22px;
            border-radius: 8px;
            margin-bottom: 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,.05);
        }

        .panel-title {
            color: #172b4d;
            font-weight: bold;
            margin-bottom: 18px;
            font-size: 17px;
        }

        .form-control {
            height: 42px;
            border-radius: 5px;
        }

        /* LESSON CARDS */

        .day-heading {
            color: #172b4d;
            font-weight: bold;
            font-size: 16px;
            border-bottom: 2px solid #007bff;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }

        .lesson-card {
            border-left: 4px solid #007bff;
            background: #f8faff;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 13px;
            height: calc(100% - 13px);
        }

        .lesson-card h6 {
            color: #172b4d;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .lesson-card p {
            font-size: 13px;
            margin-bottom: 7px;
            color: #555;
        }

        .lesson-time {
            display: inline-block;
            background: #e5f0ff;
            color: #0056b3;
            padding: 5px 9px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .empty-state {
            text-align: center;
            padding: 45px 15px;
            color: #777;
        }

        .empty-state i {
            font-size: 45px;
            color: #cbd5e1;
            margin-bottom: 15px;
        }

        .table th {
            background: #f1f4f8;
            color: #172b4d;
            font-size: 13px;
            white-space: nowrap;
        }

        .table td {
            font-size: 13px;
            vertical-align: middle;
        }

        /* MOBILE */

        @media (max-width: 768px) {

            .sidebar {
                left: -250px;
            }

            .sidebar.show {
                left: 0;
            }

            .main-content {
                margin-left: 0;
                padding: 15px;
            }

            .mobile-btn {
                display: inline-block;
            }

            .topbar {
                padding: 12px;
            }

            .topbar h5 {
                font-size: 15px;
            }

            .panel {
                padding: 15px;
            }
        }

        /* PRINT */

        @media print {

            .sidebar,
            .topbar,
            .filters-panel,
            .no-print,
            .mobile-btn {
                display: none !important;
            }

            .main-content {
                margin: 0;
                padding: 0;
            }

            body {
                background: #fff;
            }

            .panel,
            .lesson-card {
                box-shadow: none;
                break-inside: avoid;
            }
        }

    </style>

<link rel="stylesheet" href="/assets/css/admin-theme.css?v=20261114">
</head>

<body>

<!-- SIDEBAR -->

<aside class="sidebar" id="sidebar">

    <div class="sidebar-header">

        <h4>
            <i class="fas fa-graduation-cap"></i>
            Teacher Portal
        </h4>

        <small>School Management System</small>

    </div>

    <nav class="sidebar-menu">

        <a href="dashboard.php">
            <i class="fas fa-home"></i>
            Dashboard
        </a>

        <a href="teacher_classes_index.php">
            <i class="fas fa-chalkboard"></i>
            My Classes
        </a>

        <a href="teacher_subject_index.php">
            <i class="fas fa-book"></i>
            My Subjects
        </a>

        <a href="timetable.php" class="active">
            <i class="fas fa-calendar-alt"></i>
            My Timetable
        </a>

        <a href="student_reports.php">
            <i class="fas fa-file-alt"></i>
            Student Reports
        </a>

        <a href="profile.php">
            <i class="fas fa-user"></i>
            My Profile
        </a>

        <a href="../logout.php"
           class="logout"
           onclick="return confirm('Are you sure you want to log out?');">

            <i class="fas fa-sign-out-alt"></i>
            Logout

        </a>

    </nav>

</aside>

<!-- MAIN CONTENT -->

<main class="main-content">

    <!-- TOPBAR -->

    <div class="topbar">

        <div>

            <button class="mobile-btn"
                    type="button"
                    onclick="toggleSidebar()">

                <i class="fas fa-bars"></i>

            </button>

            <h5 class="d-inline ml-2">
                My Timetable
            </h5>

        </div>

        <div class="text-muted">

            <i class="fas fa-user-circle"></i>

            <?php echo teacherTtEscape($displayName); ?>

        </div>

    </div>

    <!-- PAGE HEADING -->

    <div class="page-heading">

        <h3>
            <i class="fas fa-calendar-alt"></i>
            My Teaching Timetable
        </h3>

        <p>
            View your assigned classes, subjects, rooms and lesson times.
        </p>

    </div>

    <?php if ($pageError !== ''): ?>

        <div class="alert alert-danger">

            <strong>Timetable could not load.</strong>

            <?php echo teacherTtEscape($pageError); ?>

        </div>

    <?php endif; ?>

    <?php if ($notice !== ''): ?>

        <div class="alert alert-info">

            <i class="fas fa-info-circle"></i>

            <?php echo teacherTtEscape($notice); ?>

        </div>

    <?php endif; ?>

    <!-- STATISTICS -->

    <div class="row">

        <div class="col-md-4">

            <div class="stat-card">

                <div class="stat-icon icon-blue">
                    <i class="fas fa-calendar-check"></i>
                </div>

                <div>
                    <h4><?php echo $totalLessons; ?></h4>
                    <p>Total Lessons</p>
                </div>

            </div>

        </div>

        <div class="col-md-4">

            <div class="stat-card">

                <div class="stat-icon icon-green">
                    <i class="fas fa-chalkboard"></i>
                </div>

                <div>
                    <h4><?php echo $totalClasses; ?></h4>
                    <p>Assigned Classes</p>
                </div>

            </div>

        </div>

        <div class="col-md-4">

            <div class="stat-card">

                <div class="stat-icon icon-orange">
                    <i class="fas fa-book"></i>
                </div>

                <div>
                    <h4><?php echo $totalSubjects; ?></h4>
                    <p>Subjects</p>
                </div>

            </div>

        </div>

    </div>

    <!-- FILTERS -->

    <div class="panel filters-panel">

        <div class="panel-title">

            <i class="fas fa-filter"></i>
            Filter My Timetable

        </div>

        <form method="GET" action="timetable.php">

            <div class="form-row">

                <div class="col-md-3 mb-3">

                    <label>Academic Year</label>

                    <select name="academic_year" class="form-control">

                        <option value="">All Academic Years</option>

                        <?php foreach ($years as $year): ?>

                            <option value="<?php echo teacherTtEscape($year); ?>"
                                <?php echo ($filterYear === $year) ? 'selected' : ''; ?>>

                                <?php echo teacherTtEscape($year); ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

                <div class="col-md-3 mb-3">

                    <label>Term</label>

                    <select name="term" class="form-control">

                        <option value="">All Terms</option>

                        <?php foreach ($terms as $item): ?>

                            <option value="<?php echo teacherTtEscape($item); ?>"
                                <?php echo ($filterTerm === $item) ? 'selected' : ''; ?>>

                                <?php echo teacherTtEscape($item); ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

                <div class="col-md-3 mb-3">

                    <label>Day</label>

                    <select name="day" class="form-control">

                        <option value="">All Days</option>

                        <?php foreach ($days as $weekday): ?>

                            <option value="<?php echo teacherTtEscape($weekday); ?>"
                                <?php echo ($filterDay === $weekday) ? 'selected' : ''; ?>>

                                <?php echo teacherTtEscape($weekday); ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

                <div class="col-md-3 mb-3 d-flex align-items-end">

                    <button type="submit" class="btn btn-primary mr-2">

                        <i class="fas fa-search"></i>
                        Filter

                    </button>

                    <a href="timetable.php" class="btn btn-secondary">
                        Reset
                    </a>

                </div>

            </div>

        </form>

    </div>

    <!-- WEEKLY TIMETABLE -->

    <div class="panel">

        <div class="d-flex justify-content-between align-items-center mb-3">

            <div class="panel-title mb-0">

                <i class="fas fa-calendar-week"></i>
                Weekly Timetable

            </div>

            <button onclick="window.print()"
                    class="btn btn-outline-primary btn-sm no-print">

                <i class="fas fa-print"></i>
                Print

            </button>

        </div>

        <?php if ($totalLessons === 0): ?>

            <div class="empty-state">

                <i class="fas fa-calendar-times"></i>

                <h5>No Timetable Found</h5>

                <p>
                    No lessons are available for the selected filters.
                </p>

                <p class="small">
                    Contact the administrator if you believe lessons
                    have been assigned to you.
                </p>

            </div>

        <?php else: ?>

            <?php foreach ($days as $weekday): ?>

                <?php if (!empty($weeklyTimetable[$weekday])): ?>

                    <div class="mb-4">

                        <h5 class="day-heading">

                            <i class="fas fa-calendar-day"></i>

                            <?php echo teacherTtEscape($weekday); ?>

                            <span class="badge badge-primary">

                                <?php echo count($weeklyTimetable[$weekday]); ?>

                                Lessons

                            </span>

                        </h5>

                        <div class="row">

                            <?php foreach ($weeklyTimetable[$weekday] as $lesson): ?>

                                <div class="col-md-6 col-lg-4">

                                    <div class="lesson-card">

                                        <span class="lesson-time">

                                            <i class="far fa-clock"></i>

                                            <?php echo teacherTtTime($lesson['start_time']); ?>

                                            -

                                            <?php echo teacherTtTime($lesson['end_time']); ?>

                                        </span>

                                        <h6>
                                            <?php echo teacherTtEscape($lesson['subject_name']); ?>
                                        </h6>

                                        <p>

                                            <i class="fas fa-chalkboard"></i>

                                            <strong>Class:</strong>

                                            <?php echo teacherTtEscape($lesson['class_name']); ?>

                                            <?php if (!empty($lesson['stream'])): ?>

                                                - <?php echo teacherTtEscape($lesson['stream']); ?>

                                            <?php endif; ?>

                                        </p>

                                        <p>

                                            <i class="fas fa-door-open"></i>

                                            <strong>Room:</strong>

                                            <?php echo teacherTtEscape($lesson['room'] ?: 'Not specified'); ?>

                                        </p>

                                        <p>

                                            <i class="fas fa-calendar"></i>

                                            <strong>Term:</strong>

                                            <?php echo teacherTtEscape($lesson['term']); ?>

                                        </p>

                                        <p>

                                            <i class="fas fa-graduation-cap"></i>

                                            <strong>Academic Year:</strong>

                                            <?php echo teacherTtEscape($lesson['academic_year']); ?>

                                        </p>

                                        <p>

                                            <i class="fas fa-book-open"></i>

                                            <strong>Lesson Type:</strong>

                                            <?php echo teacherTtEscape($lesson['lesson_type'] ?: 'Lesson'); ?>

                                        </p>

                                        <?php if (!empty($lesson['notes'])): ?>

                                            <p class="mt-2">

                                                <i class="fas fa-sticky-note"></i>

                                                <strong>Notes:</strong>

                                                <?php echo teacherTtEscape($lesson['notes']); ?>

                                            </p>

                                        <?php endif; ?>

                                    </div>

                                </div>

                            <?php endforeach; ?>

                        </div>

                    </div>

                <?php endif; ?>

            <?php endforeach; ?>

        <?php endif; ?>

    </div>

    <!-- DETAILED TABLE -->

    <?php if ($totalLessons > 0): ?>

        <div class="panel">

            <div class="panel-title">

                <i class="fas fa-list"></i>
                Timetable Details

            </div>

            <div class="table-responsive">

                <table class="table table-bordered table-hover">

                    <thead>

                        <tr>
                            <th>#</th>
                            <th>Day</th>
                            <th>Time</th>
                            <th>Class</th>
                            <th>Stream</th>
                            <th>Subject</th>
                            <th>Room</th>
                            <th>Term</th>
                            <th>Academic Year</th>
                        </tr>

                    </thead>

                    <tbody>

                        <?php $number = 1; ?>

                        <?php foreach ($lessons as $lesson): ?>

                            <tr>

                                <td><?php echo $number++; ?></td>

                                <td>
                                    <?php echo teacherTtEscape($lesson['day_of_week']); ?>
                                </td>

                                <td>

                                    <?php echo teacherTtTime($lesson['start_time']); ?>

                                    -

                                    <?php echo teacherTtTime($lesson['end_time']); ?>

                                </td>

                                <td>
                                    <?php echo teacherTtEscape($lesson['class_name']); ?>
                                </td>

                                <td>
                                    <?php echo teacherTtEscape($lesson['stream'] ?: '-'); ?>
                                </td>

                                <td>
                                    <?php echo teacherTtEscape($lesson['subject_name']); ?>
                                </td>

                                <td>
                                    <?php echo teacherTtEscape($lesson['room'] ?: '-'); ?>
                                </td>

                                <td>
                                    <?php echo teacherTtEscape($lesson['term']); ?>
                                </td>

                                <td>
                                    <?php echo teacherTtEscape($lesson['academic_year']); ?>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

        </div>

    <?php endif; ?>

    <div class="text-center text-muted small mb-4">

        School Management System &copy; <?php echo date('Y'); ?>

    </div>

</main>

<script>

function toggleSidebar() {

    document.getElementById('sidebar').classList.toggle('show');

}

</script>

</body>
</html>
