<?php
/**
 * Teacher Attendance
 * Install as: public_html/teacher/teacher_attendance_index.php
 * Uses the existing classes, students and class_timetables tables.
 * Creates teacher_student_attendance on first use if it does not exist.
 */

error_reporting(E_ALL);
ini_set('display_errors', '0'); // Change to 1 temporarily only when debugging.

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';

requireLogin();
requireRole(['teacher']);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$conn = $conn ?? ($mysqli ?? ($connection ?? null));
if (!$conn instanceof mysqli) {
    http_response_code(500);
    exit('Database connection was not found. Check config/database.php.');
}
$conn->set_charset('utf8mb4');

if (empty($_SESSION['csrf_attendance'])) {
    $_SESSION['csrf_attendance'] = bin2hex(random_bytes(32));
}

function h($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function tableExists(mysqli $db, string $table): bool {
    $safe = $db->real_escape_string($table);
    $result = $db->query("SHOW TABLES LIKE '{$safe}'");
    return $result && $result->num_rows > 0;
}

function columnExists(mysqli $db, string $table, string $column): bool {
    $table = str_replace('`', '', $table);
    $column = $db->real_escape_string($column);
    $result = $db->query("SHOW COLUMNS FROM `{$table}` LIKE '{$column}'");
    return $result && $result->num_rows > 0;
}

// Attendance storage. This is a separate table and does not alter existing tables.
$conn->query("CREATE TABLE IF NOT EXISTS teacher_student_attendance (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    class_id INT NOT NULL,
    attendance_date DATE NOT NULL,
    attendance_status VARCHAR(20) NOT NULL DEFAULT 'Present',
    remarks VARCHAR(255) NULL,
    marked_by INT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_student_attendance (student_id, attendance_date),
    KEY idx_class_date (class_id, attendance_date),
    KEY idx_attendance_date (attendance_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
if (!tableExists($conn, 'teacher_student_attendance')) {
    http_response_code(500);
    exit('Could not create teacher_student_attendance. Check database CREATE TABLE permission. Database message: ' . htmlspecialchars($conn->error, ENT_QUOTES, 'UTF-8'));
}

$errors = [];
$success = '';
$teacherName = trim((string)($_SESSION['full_name'] ?? ''));
$userId = (int)($_SESSION['user_id'] ?? 0);

if ($teacherName === '') {
    $errors[] = 'Your login session does not contain your full name. Please contact the administrator to update your teacher account.';
}

// Find classes assigned to this teacher through class_timetables.
$assignedClasses = [];
if (!$errors && tableExists($conn, 'class_timetables') && tableExists($conn, 'classes')) {
    $requiredTimetableColumns = ['teacher_name', 'class_name'];
    foreach ($requiredTimetableColumns as $col) {
        if (!columnExists($conn, 'class_timetables', $col)) {
            $errors[] = "The class_timetables table is missing the '{$col}' column.";
        }
    }

    if (!$errors) {
        $hasStream = columnExists($conn, 'class_timetables', 'stream');
        $hasYear = columnExists($conn, 'class_timetables', 'academic_year');
        $hasTimetableStatus = columnExists($conn, 'class_timetables', 'status');
        $hasClassSection = columnExists($conn, 'classes', 'section');
        $hasClassYear = columnExists($conn, 'classes', 'academic_year');
        $hasClassStatus = columnExists($conn, 'classes', 'status');

        $sql = "SELECT DISTINCT c.id, c.class_name";
        $sql .= $hasClassSection ? ", c.section" : ", '' AS section";
        $sql .= $hasClassYear ? ", c.academic_year" : ", '' AS academic_year";
        $sql .= " FROM classes c INNER JOIN class_timetables t ON c.class_name = t.class_name";
        $conditions = ["t.teacher_name = ?"];
        if ($hasStream && $hasClassSection) {
            $sql .= " AND (c.section = t.stream OR t.stream IS NULL OR t.stream = '')";
        }
        if ($hasYear && $hasClassYear) {
            $sql .= " AND (c.academic_year = t.academic_year OR t.academic_year IS NULL OR t.academic_year = '')";
        }
        if ($hasTimetableStatus) {
            $conditions[] = "(t.status = 'Active' OR t.status = 'active' OR t.status IS NULL OR t.status = '')";
        }
        if ($hasClassStatus) {
            $conditions[] = "(c.status = 'Active' OR c.status = 'active' OR c.status IS NULL OR c.status = '')";
        }
        $sql .= " WHERE " . implode(' AND ', $conditions);
        $sql .= " ORDER BY c.class_name ASC" . ($hasClassSection ? ", c.section ASC" : '');

        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            $errors[] = 'Could not prepare the class assignment query: ' . $conn->error;
        } else {
            $stmt->bind_param('s', $teacherName);
            $stmt->execute();
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()) {
                $assignedClasses[(int)$row['id']] = $row;
            }
            $stmt->close();
        }
    }
} else if (!$errors) {
    $errors[] = 'The classes or class_timetables table was not found in the database.';
}

$selectedClassId = (int)($_POST['class_id'] ?? $_GET['class_id'] ?? 0);
$attendanceDate = (string)($_POST['attendance_date'] ?? $_GET['attendance_date'] ?? date('Y-m-d'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $attendanceDate)) {
    $attendanceDate = date('Y-m-d');
}

// Save submitted attendance only for a class assigned to this logged-in teacher.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_attendance']) && !$errors) {
    if (!hash_equals($_SESSION['csrf_attendance'], (string)($_POST['csrf_token'] ?? ''))) {
        $errors[] = 'Your form session expired. Refresh the page and try again.';
    } elseif (!isset($assignedClasses[$selectedClassId])) {
        $errors[] = 'You are not assigned to the selected class.';
    } elseif (!tableExists($conn, 'students') || !columnExists($conn, 'students', 'class_id')) {
        $errors[] = 'The students table or its class_id column could not be found.';
    } else {
        $rosterStmt = $conn->prepare('SELECT id FROM students WHERE class_id = ?');
        $rosterStmt->bind_param('i', $selectedClassId);
        $rosterStmt->execute();
        $rosterResult = $rosterStmt->get_result();
        $rosterIds = [];
        while ($r = $rosterResult->fetch_assoc()) $rosterIds[] = (int)$r['id'];
        $rosterStmt->close();

        $statuses = $_POST['status'] ?? [];
        $remarks = $_POST['remarks'] ?? [];
        $allowedStatuses = ['Present', 'Absent', 'Late', 'Excused'];
        $conn->begin_transaction();
        try {
            $saveStmt = $conn->prepare("INSERT INTO teacher_student_attendance
                (student_id, class_id, attendance_date, attendance_status, remarks, marked_by)
                VALUES (?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE class_id = VALUES(class_id), attendance_status = VALUES(attendance_status), remarks = VALUES(remarks), marked_by = VALUES(marked_by)");
            if (!$saveStmt) throw new Exception($conn->error);

            $saved = 0;
            foreach ($rosterIds as $studentId) {
                $status = (string)($statuses[$studentId] ?? 'Present');
                if (!in_array($status, $allowedStatuses, true)) $status = 'Present';
                $remark = trim((string)($remarks[$studentId] ?? ''));
                if (strlen($remark) > 255) $remark = substr($remark, 0, 255);
                $saveStmt->bind_param('iisssi', $studentId, $selectedClassId, $attendanceDate, $status, $remark, $userId);
                if (!$saveStmt->execute()) throw new Exception($saveStmt->error);
                $saved++;
            }
            $saveStmt->close();
            $conn->commit();
            $success = "Attendance saved successfully for {$saved} student(s).";
        } catch (Throwable $e) {
            $conn->rollback();
            $errors[] = 'Attendance could not be saved: ' . $e->getMessage();
        }
    }
}

if ($selectedClassId && !isset($assignedClasses[$selectedClassId])) {
    $selectedClassId = 0;
}

$students = [];
$history = [];
if ($selectedClassId && !$errors) {
    $studentColumns = ['id', 'admission_no', 'first_name', 'last_name'];
    foreach ($studentColumns as $col) {
        if (!columnExists($conn, 'students', $col)) {
            $errors[] = "The students table is missing the '{$col}' column.";
            break;
        }
    }
    if (!$errors) {
        $otherNames = columnExists($conn, 'students', 'other_names');
        $gender = columnExists($conn, 'students', 'gender');
        $sql = 'SELECT id, admission_no, first_name, last_name';
        $sql .= $otherNames ? ', other_names' : ", '' AS other_names";
        $sql .= $gender ? ', gender' : ", '' AS gender";
        $sql .= ' FROM students WHERE class_id = ? ORDER BY last_name ASC, first_name ASC';
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $selectedClassId);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) $students[] = $row;
        $stmt->close();

        $historyStmt = $conn->prepare("SELECT attendance_date,
            SUM(attendance_status = 'Present') AS present_count,
            SUM(attendance_status = 'Absent') AS absent_count,
            SUM(attendance_status = 'Late') AS late_count,
            SUM(attendance_status = 'Excused') AS excused_count,
            COUNT(*) AS total_count
            FROM teacher_student_attendance WHERE class_id = ?
            GROUP BY attendance_date ORDER BY attendance_date DESC LIMIT 30");
        $historyStmt->bind_param('i', $selectedClassId);
        $historyStmt->execute();
        $historyResult = $historyStmt->get_result();
        while ($row = $historyResult->fetch_assoc()) $history[] = $row;
        $historyStmt->close();

        // Load any attendance already entered for the selected date.
        $existing = [];
        $existingStmt = $conn->prepare('SELECT student_id, attendance_status, remarks FROM teacher_student_attendance WHERE class_id = ? AND attendance_date = ?');
        $existingStmt->bind_param('is', $selectedClassId, $attendanceDate);
        $existingStmt->execute();
        $existingResult = $existingStmt->get_result();
        while ($row = $existingResult->fetch_assoc()) $existing[(int)$row['student_id']] = $row;
        $existingStmt->close();
    }
}

$selectedClass = $assignedClasses[$selectedClassId] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Attendance | Teacher Portal</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.6.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
:root{--navy:#172554;--blue:#2563eb;--bg:#f4f7fb;--muted:#64748b}
body{background:var(--bg);font-family:Arial,sans-serif;color:#1e293b}.sidebar{position:fixed;top:0;left:0;bottom:0;width:245px;background:var(--navy);padding:22px 14px;color:#fff;overflow-y:auto;z-index:1000}.brand{font-size:18px;font-weight:700;padding:8px 12px 25px}.sidebar a{display:block;color:#dbeafe;padding:11px 13px;border-radius:8px;margin:4px 0;text-decoration:none}.sidebar a:hover,.sidebar a.active{background:#29427b;color:#fff}.main{margin-left:245px;padding:28px}.topline{display:flex;align-items:center;justify-content:space-between;margin-bottom:22px}.panel{background:#fff;border-radius:13px;padding:20px;box-shadow:0 4px 18px rgba(15,23,42,.05);margin-bottom:20px}.stat{font-size:24px;font-weight:700}.muted{color:var(--muted)}.table th{background:#f8fafc;white-space:nowrap}.student-name{font-weight:600}.status-select{min-width:125px}.mobile-toggle{display:none}.empty{padding:35px;text-align:center;color:var(--muted)}
@media(max-width:767.98px){.sidebar{transform:translateX(-100%);transition:transform .2s}.sidebar.show{transform:translateX(0)}.main{margin-left:0;padding:16px}.mobile-toggle{display:inline-block}.topline{align-items:flex-start;gap:12px}.table-responsive{font-size:13px}}
</style>
<link rel="stylesheet" href="/assets/css/admin-theme.css?v=20261114">
</head>
<body>
<nav class="sidebar" id="sidebar">
 <div class="brand"><i class="fas fa-school mr-2"></i>Teacher Portal</div>
 <a href="/teacher/dashboard.php"><i class="fas fa-home mr-2"></i> Dashboard</a>
 <a href="/teacher/classes/index.php"><i class="fas fa-chalkboard mr-2"></i> My Classes</a>
 <a href="/teacher/teacher_subject_index.php"><i class="fas fa-book mr-2"></i> My Subjects</a>
 <a class="active" href="/teacher/teacher_attendance_index.php"><i class="fas fa-clipboard-check mr-2"></i> Attendance</a>
 <a href="/logout.php"><i class="fas fa-sign-out-alt mr-2"></i> Logout</a>
</nav>
<main class="main">
 <div class="topline">
  <div><button class="btn btn-primary mobile-toggle mb-2" type="button" onclick="document.getElementById('sidebar').classList.toggle('show')"><i class="fas fa-bars"></i></button><h3 class="mb-1">Attendance</h3><div class="muted">Record and review attendance for your assigned classes.</div></div>
  <div class="text-right muted"><i class="fas fa-user-circle mr-1"></i><?= h($teacherName) ?></div>
 </div>
 <?php foreach ($errors as $error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endforeach; ?>
 <?php if ($success): ?><div class="alert alert-success"><i class="fas fa-check-circle mr-1"></i><?= h($success) ?></div><?php endif; ?>
 <?php if (!$errors && count($assignedClasses) === 0): ?>
  <div class="panel empty"><i class="fas fa-chalkboard-teacher fa-2x mb-3"></i><h5>No class assignments found</h5><p class="mb-0">Your assigned classes are read from the class timetable. Ask the administrator to check that your teacher name matches your login name in the timetable.</p></div>
 <?php elseif (!$errors): ?>
  <div class="panel">
   <form method="get" class="form-row align-items-end">
    <div class="form-group col-md-6"><label for="class_id">Select assigned class</label><select class="form-control" id="class_id" name="class_id" required><option value="">Choose class</option><?php foreach ($assignedClasses as $id=>$class): ?><option value="<?= $id ?>" <?= $selectedClassId===$id?'selected':'' ?>><?= h($class['class_name']) ?><?= $class['section']!==''?' - '.h($class['section']):'' ?><?= $class['academic_year']!==''?' ('.h($class['academic_year']).')':'' ?></option><?php endforeach; ?></select></div>
    <div class="form-group col-md-4"><label for="attendance_date">Attendance date</label><input type="date" class="form-control" id="attendance_date" name="attendance_date" value="<?= h($attendanceDate) ?>" required></div>
    <div class="form-group col-md-2"><button class="btn btn-primary btn-block" type="submit"><i class="fas fa-search mr-1"></i>Load</button></div>
   </form>
  </div>
  <?php if ($selectedClass): ?>
   <div class="panel">
    <div class="d-flex justify-content-between align-items-center flex-wrap mb-3"><div><h5 class="mb-1"><?= h($selectedClass['class_name']) ?><?= $selectedClass['section']!==''?' - '.h($selectedClass['section']):'' ?></h5><span class="muted">Date: <?= h(date('d M Y', strtotime($attendanceDate))) ?> · <?= count($students) ?> student(s)</span></div><span class="badge badge-primary p-2">Assigned class</span></div>
    <?php if (!$students): ?><div class="empty">No students are registered in this class.</div><?php else: ?>
    <form method="post">
     <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_attendance']) ?>">
     <input type="hidden" name="class_id" value="<?= $selectedClassId ?>">
     <input type="hidden" name="attendance_date" value="<?= h($attendanceDate) ?>">
     <div class="d-flex justify-content-between flex-wrap mb-3"><div class="btn-group btn-group-sm mb-2"><button type="button" class="btn btn-outline-success" onclick="setAll('Present')">All Present</button><button type="button" class="btn btn-outline-danger" onclick="setAll('Absent')">All Absent</button></div><button type="submit" name="save_attendance" value="1" class="btn btn-success mb-2"><i class="fas fa-save mr-1"></i>Save Attendance</button></div>
     <div class="table-responsive"><table class="table table-bordered table-hover"><thead><tr><th>#</th><th>Admission No.</th><th>Student Name</th><th>Gender</th><th>Attendance</th><th>Remarks</th></tr></thead><tbody>
     <?php foreach ($students as $i=>$student): $sid=(int)$student['id']; $old=$existing[$sid]??[]; $fullName=trim($student['first_name'].' '.$student['other_names'].' '.$student['last_name']); ?>
      <tr><td><?= $i+1 ?></td><td><?= h($student['admission_no']) ?></td><td class="student-name"><?= h($fullName) ?></td><td><?= h($student['gender']) ?></td><td><select class="form-control form-control-sm status-select attendance-status" name="status[<?= $sid ?>]"><?php foreach (['Present','Absent','Late','Excused'] as $status): ?><option value="<?= $status ?>" <?= ($old['attendance_status']??'Present')===$status?'selected':'' ?>><?= $status ?></option><?php endforeach; ?></select></td><td><input type="text" maxlength="255" class="form-control form-control-sm" name="remarks[<?= $sid ?>]" value="<?= h($old['remarks']??'') ?>" placeholder="Optional remark"></td></tr>
     <?php endforeach; ?>
     </tbody></table></div>
     <div class="text-right"><button type="submit" name="save_attendance" value="1" class="btn btn-success"><i class="fas fa-save mr-1"></i>Save Attendance</button></div>
    </form>
    <?php endif; ?>
   </div>
   <div class="panel"><h5 class="mb-3">Attendance history</h5><?php if (!$history): ?><p class="muted mb-0">No attendance records have been saved for this class yet.</p><?php else: ?><div class="table-responsive"><table class="table table-sm table-striped"><thead><tr><th>Date</th><th>Present</th><th>Absent</th><th>Late</th><th>Excused</th><th>Total marked</th></tr></thead><tbody><?php foreach ($history as $record): ?><tr><td><?= h(date('d M Y',strtotime($record['attendance_date']))) ?></td><td><span class="text-success font-weight-bold"><?= (int)$record['present_count'] ?></span></td><td><span class="text-danger font-weight-bold"><?= (int)$record['absent_count'] ?></span></td><td><?= (int)$record['late_count'] ?></td><td><?= (int)$record['excused_count'] ?></td><td><?= (int)$record['total_count'] ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></div>
  <?php else: ?><div class="panel empty">Select one of your assigned classes and a date to record or review attendance.</div><?php endif; ?>
 <?php endif; ?>
 <div class="small muted mt-3">Attendance records are saved separately from student profiles. A teacher can only mark attendance for classes assigned to their timetable name.</div>
</main>
<script>
function setAll(value){document.querySelectorAll('.attendance-status').forEach(function(el){el.value=value;});}
</script>
</body>
</html>

