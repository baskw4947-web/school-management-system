-- Add LIN No. and Day/Boarding while retaining Student Payment Code.
-- Target database: sserumed_school_mgt (MySQL 5.7).
-- BACK UP THE DATABASE BEFORE RUNNING. Run this migration once only.
-- Existing student_payment_code values remain in place; they are NOT renamed
-- or overwritten. LIN numbers are a separate student identifier.

ALTER TABLE `students`
  ADD COLUMN `lin_no` VARCHAR(50) COLLATE utf8_unicode_ci DEFAULT NULL AFTER `admission_no`,
  ADD COLUMN `student_section` ENUM('Day','Boarding') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Day' AFTER `class_id`,
  ADD KEY `idx_students_lin_no` (`lin_no`),
  ADD KEY `idx_students_payment_code` (`student_payment_code`);

-- Refresh the fee-balance view to expose all student identifiers and section.
CREATE OR REPLACE ALGORITHM=UNDEFINED SQL SECURITY INVOKER VIEW `student_fee_balances` AS
SELECT
    s.`id` AS `student_id`,
    s.`admission_no` AS `admission_no`,
    s.`lin_no` AS `lin_no`,
    s.`student_payment_code` AS `student_payment_code`,
    s.`student_section` AS `student_section`,
    s.`first_name` AS `first_name`,
    s.`last_name` AS `last_name`,
    c.`class_name` AS `class_name`,
    c.`section` AS `section`,
    a.`academic_year` AS `academic_year`,
    a.`term` AS `term`,
    a.`total_amount` AS `total_amount`,
    a.`discount_amount` AS `discount_amount`,
    a.`amount_paid` AS `amount_paid`,
    a.`balance` AS `balance`,
    a.`status` AS `status`
FROM `student_fee_accounts` a
INNER JOIN `students` s ON s.`id` = a.`student_id`
INNER JOIN `classes` c ON c.`id` = s.`class_id`;
