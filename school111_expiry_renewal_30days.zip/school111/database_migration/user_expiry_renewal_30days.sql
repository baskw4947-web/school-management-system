-- Run once in the sserumed_school_mgt database after taking a backup.
-- Existing accounts are backfilled to created_at + 30 days.
-- Only id=1 AND username='admin' is exempt.

ALTER TABLE users
    ADD COLUMN expires_at DATETIME NULL DEFAULT NULL AFTER created_at;

UPDATE users
SET expires_at = DATE_ADD(created_at, INTERVAL 30 DAY)
WHERE NOT (id = 1 AND username = 'admin')
  AND expires_at IS NULL;
