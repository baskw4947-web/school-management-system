<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Validate account status and expiry on every protected request.
 * Only the exact default account (ID 1 AND username admin) is exempt.
 */
function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: /login.php");
        exit;
    }

    if (!isset($GLOBALS['conn']) || !($GLOBALS['conn'] instanceof mysqli)) {
        require_once __DIR__ . '/../config/database.php';
    }
    $db = $conn ?? ($GLOBALS['conn'] ?? null);
    if (!($db instanceof mysqli)) {
        http_response_code(503);
        exit("The system database is temporarily unavailable. Please contact the administrator.");
    }

    $userId = (int)$_SESSION['user_id'];
    $stmt = $db->prepare("SELECT username, status, expires_at FROM users WHERE id = ? LIMIT 1");
    if (!$stmt) {
        error_log("Account expiry check failed: " . $db->error);
        http_response_code(503);
        exit("Unable to verify your account. Please contact the administrator.");
    }

    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->bind_result($dbUsername, $dbStatus, $dbExpiresAt);
    $found = $stmt->fetch();
    $stmt->close();

    if (!$found || $dbStatus !== 'active') {
        $_SESSION = [];
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
        $message = !$found
            ? "Your account could not be found. Please contact the administrator."
            : "Your account is inactive. Please contact the administrator.";
        header("Location: /login.php?error=" . urlencode($message));
        exit;
    }

    $isDefaultAdmin = ($userId === 1 && $dbUsername === 'admin');
    if (!$isDefaultAdmin && $dbExpiresAt !== null) {
        $expiry = strtotime($dbExpiresAt);
        if ($expiry === false || $expiry <= time()) {
            $_SESSION = [];
            if (session_status() === PHP_SESSION_ACTIVE) {
                session_destroy();
            }
            header("Location: /login.php?error=" . urlencode(
                "Your account has expired. Please contact the school administrator for renewal."
            ));
            exit;
        }
    }
}

function requireRole(array $allowedRoles) {

    requireLogin();

    if (!in_array(
        $_SESSION['role'] ?? '',
        $allowedRoles,
        true
    )) {
        http_response_code(403);
        exit("403 - Access denied");
    }
}
