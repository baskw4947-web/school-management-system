<?php
session_start();

if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$error = $_GET['error'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>School Management System - Login</title>

    <!-- Bootstrap 4 -->
    <link rel="stylesheet"
          href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <style>
        body {
            background: #f4f6f9;
        }

        .login-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-card {
            width: 100%;
            max-width: 420px;
            border: none;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .login-header {
            background: #007bff;
            color: white;
            padding: 25px;
            text-align: center;
            border-radius: 10px 10px 0 0;
        }

        .login-body {
            padding: 30px;
        }
    </style>
</head>

<body>

<div class="container login-container">

    <div class="card login-card">

        <div class="login-header">
            <h3>School Management System</h3>
            <p class="mb-0">Login to your account</p>
        </div>

        <div class="login-body">

            <?php if ($error): ?>

                <div class="alert alert-danger">
                    <?php echo htmlspecialchars($error); ?>
                </div>

            <?php endif; ?>

            <form action="authenticate.php" method="POST">

                <div class="form-group">
                    <label>Username</label>

                    <input
                        type="text"
                        name="username"
                        class="form-control"
                        required
                        autofocus
                    >
                </div>

                <div class="form-group">
                    <label>Password</label>

                    <input
                        type="password"
                        name="password"
                        class="form-control"
                        required
                    >
                </div>

                <button type="submit"
                        class="btn btn-primary btn-block">
                    Login
                </button>

            </form>

        </div>

    </div>

</div>

</body>
</html>