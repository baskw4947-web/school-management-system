<?php
/**
 * School Management System - Asset Register
 * Suggested location: public_html/admin/asset.php
 * Upload as UTF-8 without BOM; keep this opening PHP tag as the first bytes.
 */
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Support common placement locations without hard-coding one relative include depth.
$dbCandidates = [__DIR__ . '/../config/database.php', __DIR__ . '/../../config/database.php', __DIR__ . '/config/database.php'];
$authCandidates = [__DIR__ . '/../includes/auth.php', __DIR__ . '/../../includes/auth.php', __DIR__ . '/includes/auth.php'];
$dbFile = null;
$authFile = null;
foreach ($dbCandidates as $candidate) { if (is_file($candidate)) { $dbFile = $candidate; break; } }
foreach ($authCandidates as $candidate) { if (is_file($candidate)) { $authFile = $candidate; break; } }
if (!$dbFile || !$authFile) {
    http_response_code(500);
    exit('Configuration files were not found. Save this page under public_html/admin/asset.php or adjust the include paths.');
}
require_once $dbFile;
require_once $authFile; // Authentication file handles session startup.
requireRole(['administrator', 'assistant_administrator', 'bursar']);

if (!isset($conn) || !($conn instanceof mysqli)) {
    http_response_code(500);
    exit('Database connection is unavailable. Please check config/database.php.');
}
$conn->set_charset('utf8mb4');

function assetE($value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8'); }
function assetMoney($value): string { return number_format((float)$value, 2); }
function assetRedirect(): void { header('Location: asset.php'); exit; }
function assetFlash(string $type, string $message): void { $_SESSION['asset_flash'] = ['type' => $type, 'message' => $message]; }
function assetBind(mysqli_stmt $stmt, string $types, array &$values): void {
    $args = [$types];
    foreach ($values as &$value) $args[] = &$value;
    call_user_func_array([$stmt, 'bind_param'], $args);
}
function assetValidDate(string $value): bool {
    if ($value === '') return true;
    $date = DateTime::createFromFormat('!Y-m-d', $value);
    $errors = DateTime::getLastErrors();
    return $date !== false && $date->format('Y-m-d') === $value && ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0));
}
function assetGenerateCode(mysqli $conn): string {
    for ($i = 0; $i < 20; $i++) {
        $code = 'AST-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(2)));
        $stmt = $conn->prepare('SELECT id FROM school_assets WHERE asset_code = ? LIMIT 1');
        $stmt->bind_param('s', $code);
        $stmt->execute();
        $exists = (bool)$stmt->get_result()->fetch_row();
        $stmt->close();
        if (!$exists) return $code;
    }
    throw new RuntimeException('A unique asset code could not be generated. Please try again.');
}

$userId = 0;
if (isset($_SESSION['user_id']) && is_numeric($_SESSION['user_id'])) $userId = (int)$_SESSION['user_id'];
elseif (isset($_SESSION['id']) && is_numeric($_SESSION['id'])) $userId = (int)$_SESSION['id'];
elseif (isset($_SESSION['user']['id']) && is_numeric($_SESSION['user']['id'])) $userId = (int)$_SESSION['user']['id'];

if (empty($_SESSION['asset_csrf'])) $_SESSION['asset_csrf'] = bin2hex(random_bytes(32));
$csrfToken = (string)$_SESSION['asset_csrf'];
$flash = $_SESSION['asset_flash'] ?? null;
unset($_SESSION['asset_flash']);
$pageError = '';
$tableCreated = false;
$assets = [];
$editAsset = null;

try {
    $existsResult = $conn->query("SHOW TABLES LIKE 'school_assets'");
    $tableExists = $existsResult && $existsResult->num_rows > 0;
    if ($existsResult) $existsResult->free();
    if (!$tableExists) {
        $conn->query("CREATE TABLE school_assets (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            asset_code VARCHAR(40) NOT NULL,
            asset_name VARCHAR(180) NOT NULL,
            category VARCHAR(100) NOT NULL,
            description TEXT NULL,
            serial_number VARCHAR(120) NULL,
            quantity INT UNSIGNED NOT NULL DEFAULT 1,
            purchase_date DATE NULL,
            purchase_cost DECIMAL(14,2) NOT NULL DEFAULT 0.00,
            supplier_name VARCHAR(180) NULL,
            location VARCHAR(150) NULL,
            custodian VARCHAR(150) NULL,
            condition_status ENUM('new','good','fair','poor','damaged') NOT NULL DEFAULT 'good',
            asset_status ENUM('active','in_repair','disposed','lost','retired') NOT NULL DEFAULT 'active',
            warranty_expiry DATE NULL,
            notes TEXT NULL,
            created_by INT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_school_assets_code (asset_code),
            KEY idx_school_assets_category (category),
            KEY idx_school_assets_status (asset_status),
            KEY idx_school_assets_location (location)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $tableCreated = true;
    }
} catch (Throwable $e) {
    error_log('asset.php table setup error: ' . $e->getMessage());
    $pageError = 'The asset register table could not be prepared. Check your database privileges and hosting PHP error log.';
}

// Handle create/update, status changes and deletion using POST + CSRF protection.
if ($pageError === '' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $postedToken = (string)($_POST['csrf_token'] ?? '');
    if (!hash_equals($csrfToken, $postedToken)) {
        assetFlash('danger', 'Your form session expired. Refresh the page and try again.');
        assetRedirect();
    }
    $action = (string)($_POST['action'] ?? '');
    try {
        if ($action === 'save_asset') {
            $id = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT) ?: 0;
            $assetCode = trim((string)($_POST['asset_code'] ?? ''));
            $name = trim((string)($_POST['asset_name'] ?? ''));
            $category = trim((string)($_POST['category'] ?? ''));
            $description = trim((string)($_POST['description'] ?? ''));
            $serial = trim((string)($_POST['serial_number'] ?? ''));
            $quantity = filter_var($_POST['quantity'] ?? 1, FILTER_VALIDATE_INT);
            $purchaseDate = trim((string)($_POST['purchase_date'] ?? ''));
            $costRaw = trim((string)($_POST['purchase_cost'] ?? '0'));
            $supplier = trim((string)($_POST['supplier_name'] ?? ''));
            $location = trim((string)($_POST['location'] ?? ''));
            $custodian = trim((string)($_POST['custodian'] ?? ''));
            $condition = trim((string)($_POST['condition_status'] ?? 'good'));
            $status = trim((string)($_POST['asset_status'] ?? 'active'));
            $warranty = trim((string)($_POST['warranty_expiry'] ?? ''));
            $notes = trim((string)($_POST['notes'] ?? ''));

            if ($name === '') throw new RuntimeException('Enter the asset or property name.');
            if (mb_strlen($name) > 180) throw new RuntimeException('Asset name must not exceed 180 characters.');
            if ($category === '') throw new RuntimeException('Select or enter an asset category.');
            if (mb_strlen($category) > 100) throw new RuntimeException('Category must not exceed 100 characters.');
            if ($quantity === false || $quantity < 1) throw new RuntimeException('Quantity must be a whole number of at least 1.');
            if ($costRaw === '' || !is_numeric($costRaw) || !is_finite((float)$costRaw) || (float)$costRaw < 0) throw new RuntimeException('Enter a valid purchase cost of zero or more.');
            if (!assetValidDate($purchaseDate) || !assetValidDate($warranty)) throw new RuntimeException('Enter a valid purchase date and warranty expiry date.');
            if (!in_array($condition, ['new','good','fair','poor','damaged'], true)) throw new RuntimeException('Select a valid asset condition.');
            if (!in_array($status, ['active','in_repair','disposed','lost','retired'], true)) throw new RuntimeException('Select a valid asset status.');
            if ($assetCode !== '' && mb_strlen($assetCode) > 40) throw new RuntimeException('Asset code must not exceed 40 characters.');
            if ($assetCode === '') $assetCode = assetGenerateCode($conn);

            $check = $conn->prepare('SELECT id FROM school_assets WHERE asset_code = ? AND id <> ? LIMIT 1');
            $check->bind_param('si', $assetCode, $id);
            $check->execute();
            $duplicate = (bool)$check->get_result()->fetch_row();
            $check->close();
            if ($duplicate) throw new RuntimeException('That asset code is already in use. Enter a different code.');

            $purchaseDateValue = $purchaseDate !== '' ? $purchaseDate : null;
            $warrantyValue = $warranty !== '' ? $warranty : null;
            $descriptionValue = $description !== '' ? $description : null;
            $serialValue = $serial !== '' ? $serial : null;
            $supplierValue = $supplier !== '' ? $supplier : null;
            $locationValue = $location !== '' ? $location : null;
            $custodianValue = $custodian !== '' ? $custodian : null;
            $notesValue = $notes !== '' ? $notes : null;
            $cost = round((float)$costRaw, 2);

            if ($id > 0) {
                $check = $conn->prepare('SELECT id FROM school_assets WHERE id = ? LIMIT 1');
                $check->bind_param('i', $id);
                $check->execute();
                $found = (bool)$check->get_result()->fetch_row();
                $check->close();
                if (!$found) throw new RuntimeException('Asset record not found. Refresh the page and try again.');
                $sql = 'UPDATE school_assets SET asset_code=?, asset_name=?, category=?, description=?, serial_number=?, quantity=?, purchase_date=?, purchase_cost=?, supplier_name=?, location=?, custodian=?, condition_status=?, asset_status=?, warranty_expiry=?, notes=? WHERE id=?';
                $stmt = $conn->prepare($sql);
                $values = [$assetCode,$name,$category,$descriptionValue,$serialValue,(int)$quantity,$purchaseDateValue,$cost,$supplierValue,$locationValue,$custodianValue,$condition,$status,$warrantyValue,$notesValue,$id];
                assetBind($stmt, 'sssssisdsssssssi', $values);
                $stmt->execute();
                $stmt->close();
                assetFlash('success', 'Asset updated successfully.');
            } else {
                $sql = 'INSERT INTO school_assets (asset_code,asset_name,category,description,serial_number,quantity,purchase_date,purchase_cost,supplier_name,location,custodian,condition_status,asset_status,warranty_expiry,notes,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
                $stmt = $conn->prepare($sql);
                $values = [$assetCode,$name,$category,$descriptionValue,$serialValue,(int)$quantity,$purchaseDateValue,$cost,$supplierValue,$locationValue,$custodianValue,$condition,$status,$warrantyValue,$notesValue,($userId > 0 ? $userId : null)];
                assetBind($stmt, 'sssssisdsssssssi', $values);
                $stmt->execute();
                $stmt->close();
                assetFlash('success', 'Asset registered successfully. Asset code: ' . $assetCode);
            }
            assetRedirect();
        }

        if ($action === 'change_status') {
            $id = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT) ?: 0;
            $newStatus = trim((string)($_POST['new_status'] ?? ''));
            if ($id < 1 || !in_array($newStatus, ['active','in_repair','disposed','lost','retired'], true)) throw new RuntimeException('Select a valid asset and status.');
            $stmt = $conn->prepare('UPDATE school_assets SET asset_status = ? WHERE id = ?');
            $stmt->bind_param('si', $newStatus, $id);
            $stmt->execute();
            $stmt->close();
            assetFlash('success', 'Asset status updated to ' . ucwords(str_replace('_', ' ', $newStatus)) . '.');
            assetRedirect();
        }

        if ($action === 'delete_asset') {
            $id = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT) ?: 0;
            if ($id < 1) throw new RuntimeException('Choose an asset record to delete.');
            $stmt = $conn->prepare('DELETE FROM school_assets WHERE id = ?');
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $deleted = $stmt->affected_rows;
            $stmt->close();
            assetFlash($deleted ? 'success' : 'warning', $deleted ? 'Asset record deleted.' : 'No asset record was deleted.');
            assetRedirect();
        }
        throw new RuntimeException('Unknown action. Refresh the page and try again.');
    } catch (Throwable $e) {
        error_log('asset.php action error: ' . $e->getMessage());
        assetFlash('danger', $e instanceof RuntimeException ? $e->getMessage() : 'The asset could not be saved. Check the PHP error log if the problem continues.');
        assetRedirect();
    }
}

$search = trim((string)($_GET['q'] ?? ''));
$categoryFilter = trim((string)($_GET['category'] ?? ''));
$statusFilter = trim((string)($_GET['status'] ?? ''));
$conditionFilter = trim((string)($_GET['condition'] ?? ''));
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 15;
$totalPages = 1;
$totalRows = 0;
$totalQuantity = 0;
$totalValue = 0.0;
$activeValue = 0.0;
$activeCount = 0;
$repairCount = 0;
$assets = [];
$categories = [];

if ($pageError === '') {
    try {
        $where = [];
        $params = [];
        $types = '';
        if ($search !== '') {
            $where[] = '(asset_code LIKE ? OR asset_name LIKE ? OR category LIKE ? OR serial_number LIKE ? OR location LIKE ? OR custodian LIKE ? OR supplier_name LIKE ?)';
            $like = '%' . $search . '%';
            for ($i=0; $i<7; $i++) { $params[] = $like; $types .= 's'; }
        }
        if ($categoryFilter !== '') { $where[] = 'category = ?'; $params[] = $categoryFilter; $types .= 's'; }
        if ($statusFilter !== '') { $where[] = 'asset_status = ?'; $params[] = $statusFilter; $types .= 's'; }
        if ($conditionFilter !== '') { $where[] = 'condition_status = ?'; $params[] = $conditionFilter; $types .= 's'; }
        $whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';

        $countStmt = $conn->prepare('SELECT COUNT(*) AS total, COALESCE(SUM(quantity),0) AS qty, COALESCE(SUM(quantity * purchase_cost),0) AS total_value, COALESCE(SUM(CASE WHEN asset_status="active" THEN quantity * purchase_cost ELSE 0 END),0) AS active_value, COALESCE(SUM(CASE WHEN asset_status="active" THEN 1 ELSE 0 END),0) AS active_count, COALESCE(SUM(CASE WHEN asset_status="in_repair" THEN 1 ELSE 0 END),0) AS repair_count FROM school_assets' . $whereSql);
        if ($types !== '') assetBind($countStmt, $types, $params);
        $countStmt->execute();
        $totals = $countStmt->get_result()->fetch_assoc() ?: [];
        $countStmt->close();
        $totalRows = (int)($totals['total'] ?? 0);
        $totalQuantity = (int)($totals['qty'] ?? 0);
        $totalValue = (float)($totals['total_value'] ?? 0);
        $activeValue = (float)($totals['active_value'] ?? 0);
        $activeCount = (int)($totals['active_count'] ?? 0);
        $repairCount = (int)($totals['repair_count'] ?? 0);

        $catResult = $conn->query('SELECT DISTINCT category FROM school_assets WHERE category IS NOT NULL AND category <> "" ORDER BY category');
        while ($catRow = $catResult->fetch_assoc()) $categories[] = (string)$catRow['category'];
        $catResult->free();

        $totalPages = max(1, (int)ceil($totalRows / $perPage));
        if ($page > $totalPages) $page = $totalPages;
        $offset = ($page - 1) * $perPage;
        $sql = 'SELECT * FROM school_assets' . $whereSql . ' ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?';
        $listStmt = $conn->prepare($sql);
        $listParams = $params;
        $listTypes = $types . 'ii';
        $listParams[] = $perPage;
        $listParams[] = $offset;
        assetBind($listStmt, $listTypes, $listParams);
        $listStmt->execute();
        $result = $listStmt->get_result();
        while ($row = $result->fetch_assoc()) $assets[] = $row;
        $listStmt->close();
    } catch (Throwable $e) {
        error_log('asset.php load error: ' . $e->getMessage());
        $pageError = 'Assets could not be loaded. Please check the database table and hosting PHP error log.';
    }
}

$editId = max(0, (int)($_GET['edit'] ?? 0));
if ($editId > 0 && $pageError === '') {
    try {
        $stmt = $conn->prepare('SELECT * FROM school_assets WHERE id = ? LIMIT 1');
        $stmt->bind_param('i', $editId);
        $stmt->execute();
        $editAsset = $stmt->get_result()->fetch_assoc() ?: null;
        $stmt->close();
    } catch (Throwable $e) { error_log('asset.php edit load error: ' . $e->getMessage()); }
}

if (isset($_GET['export']) && $_GET['export'] === 'csv' && $pageError === '') {
    try {
        $exportSql = 'SELECT asset_code,asset_name,category,serial_number,quantity,purchase_date,purchase_cost,supplier_name,location,custodian,condition_status,asset_status,warranty_expiry FROM school_assets' . $whereSql . ' ORDER BY asset_name';
        $exportStmt = $conn->prepare($exportSql);
        if ($types !== '') assetBind($exportStmt, $types, $params);
        $exportStmt->execute();
        $exportResult = $exportStmt->get_result();
        if (function_exists('ob_get_length') && ob_get_length()) ob_clean();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="school_assets_' . date('Ymd') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Asset Code','Asset Name','Category','Serial Number','Quantity','Purchase Date','Unit Purchase Cost (UGX)','Supplier','Location','Custodian','Condition','Status','Warranty Expiry']);
        while ($r = $exportResult->fetch_assoc()) fputcsv($out, array_values($r));
        fclose($out);
        $exportStmt->close();
        exit;
    } catch (Throwable $e) { error_log('asset.php CSV export error: ' . $e->getMessage()); }
}

$flash = $_SESSION['asset_flash'] ?? $flash;
unset($_SESSION['asset_flash']);
$assetStatusLabels = ['active'=>'Active','in_repair'=>'In repair','disposed'=>'Disposed','lost'=>'Lost','retired'=>'Retired'];
$conditionLabels = ['new'=>'New','good'=>'Good','fair'=>'Fair','poor'=>'Poor','damaged'=>'Damaged'];
$exportQuery = $_GET; $exportQuery['export'] = 'csv'; unset($exportQuery['page'], $exportQuery['edit']);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Assets | School Management System</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f6f9;font-family:Arial,Helvetica,sans-serif;color:#343a40}.sidebar{position:fixed;top:0;bottom:0;left:0;width:250px;background:#212529;overflow-y:auto;z-index:1050}.sidebar-header{padding:22px 18px;background:#171a1d;color:#fff;font-weight:700;font-size:18px;border-bottom:1px solid rgba(255,255,255,.08)}.sidebar-section{padding:15px 16px 6px;color:#868e96;font-size:11px;text-transform:uppercase;font-weight:bold;letter-spacing:.5px}.sidebar a{display:block;color:#ced4da;padding:11px 16px;text-decoration:none;border-left:4px solid transparent;font-size:14px}.sidebar a:hover,.sidebar a.active{background:#343a40;color:#fff;border-left-color:#28a745}.sidebar a i{width:24px;text-align:center;margin-right:5px}.main{margin-left:250px;min-height:100vh}.topbar{padding:17px 25px;background:#fff;border-bottom:1px solid #e5e5e5;display:flex;align-items:center;justify-content:space-between}.content{padding:24px}.page-head,.panel,.stat-card{background:#fff;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,.05)}.page-head{padding:21px;margin-bottom:20px}.panel{padding:21px;margin-bottom:22px}.stat-card{padding:18px;margin-bottom:18px;height:calc(100% - 18px)}.stat-title{color:#6c757d;font-size:13px}.stat-number{font-size:22px;font-weight:700;overflow-wrap:anywhere}.form-control,.custom-select,.btn{border-radius:6px}.form-control,.custom-select{min-height:40px}label{font-size:13px;font-weight:600}.table th{background:#f8f9fa;white-space:nowrap;font-size:12px}.table td{vertical-align:middle;font-size:13px}.badge{padding:7px 9px}.btn{font-size:13px}.mobile-menu{display:none}.muted-small{font-size:11px;color:#89929c}.amount{white-space:nowrap;font-weight:700}.asset-code{font-size:11px;color:#6c757d}.form-section-title{font-size:14px;font-weight:700;color:#344055;border-bottom:1px solid #edf0f4;padding-bottom:8px;margin:14px 0}.alert{font-size:13px}.action-form{display:inline-block}@media(max-width:991px){.sidebar{left:-250px;transition:left .25s}.sidebar.show{left:0}.main{margin-left:0}.mobile-menu{display:inline-block}.content{padding:15px}.topbar{padding:12px 15px}.stat-number{font-size:20px}}@media print{.sidebar,.topbar,.no-print,.mobile-menu{display:none!important}.main{margin:0}.content{padding:0}.panel,.stat-card,.page-head{box-shadow:none;border:0}}
</style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<aside class="sidebar no-print" id="sidebar">
 <div class="sidebar-header"><i class="fas fa-school mr-2"></i>School Management<br><small class="text-muted">Bursar &amp; Administration</small></div>
 <div class="sidebar-section">Main</div>
 <a href="/admin/dashboard.php"><i class="fas fa-tachometer-alt"></i>Admin Dashboard</a>
 <a href="/admin/bursar/index.php"><i class="fas fa-chart-line"></i>Bursar Dashboard</a>
 <div class="sidebar-section">Students &amp; Fees</div>
 <a href="/admin/bursar/students_fee_accounts.php"><i class="fas fa-user-graduate"></i>Student Fee Accounts</a>
 <a href="/admin/bursar/fee_structure.php"><i class="fas fa-list-alt"></i>Fee Structure</a>
 <a href="/admin/bursar/payments.php"><i class="fas fa-money-bill-wave"></i>Student Payments</a>
 <div class="sidebar-section">Finance</div>
 <a href="/admin/bursar/income.php"><i class="fas fa-arrow-circle-down"></i>Income</a>
 <a href="/admin/bursar/expenses.php"><i class="fas fa-arrow-circle-up"></i>Expenses</a>
 <a href="/admin/bursar/suppliers.php"><i class="fas fa-truck"></i>Suppliers</a>
 <a href="/admin/bursar/supplier_payments.php"><i class="fas fa-file-invoice-dollar"></i>Supplier Payments</a>
 <a href="/admin/bursar/budgets.php"><i class="fas fa-wallet"></i>Budgets</a>
 <a href="/admin/bursar/cashbook.php"><i class="fas fa-book"></i>Cashbook</a>
 <div class="sidebar-section">School Property</div>
 <a href="/admin/assets/asset.php" class="active"><i class="fas fa-boxes"></i>Asset Register</a>
 <a href="/admin/classes/notes.php"><i class="fas fa-book-open"></i>Subject Notes</a>
 <a href="/admin/classes/projects.php"><i class="fas fa-folder-open"></i>Student Projects</a>
 <div class="sidebar-section">System</div>
 <a href="/admin/dashboard.php"><i class="fas fa-user-shield"></i>Admin Dashboard</a>
 <a href="/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
</aside>
<div class="main">
 <div class="topbar"><div><button class="btn btn-dark mobile-menu mr-2" id="mobileMenuBtn" type="button" aria-label="Open menu"><i class="fas fa-bars"></i></button><strong>School Property &amp; Assets</strong></div><div class="text-muted"><i class="fas fa-user-circle mr-1"></i><?= assetE($_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Administrator') ?></div></div>
 <div class="content">
  <div class="page-head d-flex justify-content-between align-items-center flex-wrap">
   <div><h3 class="mb-1"><i class="fas fa-boxes text-success mr-2"></i>Asset Register</h3><div class="text-muted">Manage school property, equipment, locations, custodians and asset condition.</div></div>
   <div class="mt-2 no-print"><button type="button" class="btn btn-success" onclick="document.getElementById('assetForm').scrollIntoView({behavior:'smooth'});"><i class="fas fa-plus-circle mr-1"></i>Register Asset</button> <button type="button" onclick="window.print()" class="btn btn-outline-secondary"><i class="fas fa-print mr-1"></i>Print</button></div>
  </div>
  <?php if ($tableCreated): ?><div class="alert alert-info"><i class="fas fa-info-circle mr-1"></i>The <code>school_assets</code> table was created because it did not previously exist.</div><?php endif; ?>
  <?php if ($pageError !== ''): ?><div class="alert alert-danger"><i class="fas fa-exclamation-triangle mr-1"></i><?= assetE($pageError) ?></div><?php endif; ?>
  <?php if (is_array($flash) && !empty($flash['message'])): ?><div class="alert alert-<?= assetE($flash['type'] ?? 'info') ?> alert-dismissible fade show" role="alert"><?= assetE($flash['message']) ?><button type="button" class="close" data-dismiss="alert"><span>&times;</span></button></div><?php endif; ?>
  <div class="row">
   <div class="col-md-6 col-xl-3"><div class="stat-card"><div class="stat-title">Asset Records</div><div class="stat-number text-primary"><?= number_format($totalRows) ?></div><div class="muted-small">Matching current filters</div></div></div>
   <div class="col-md-6 col-xl-3"><div class="stat-card"><div class="stat-title">Total Quantity</div><div class="stat-number"><?= number_format($totalQuantity) ?></div><div class="muted-small">Units or items registered</div></div></div>
   <div class="col-md-6 col-xl-3"><div class="stat-card"><div class="stat-title">Total Recorded Value</div><div class="stat-number">UGX <?= assetMoney($totalValue) ?></div><div class="muted-small">Quantity × unit purchase cost</div></div></div>
   <div class="col-md-6 col-xl-3"><div class="stat-card"><div class="stat-title">Active Assets / In Repair</div><div class="stat-number"><span class="text-success"><?= number_format($activeCount) ?></span> / <span class="text-warning"><?= number_format($repairCount) ?></span></div><div class="muted-small">Active asset records and repairs</div></div></div>
  </div>

  <?php if ($pageError === ''): ?>
  <section class="panel no-print" id="assetForm">
   <h5 class="mb-3"><i class="fas fa-edit text-success mr-2"></i><?= $editAsset ? 'Edit Asset' : 'Register New Asset' ?></h5>
   <form method="post" action="asset.php<?= $editAsset ? '?edit=' . (int)$editAsset['id'] . '#assetForm' : '#assetForm' ?>" id="assetEntryForm">
    <input type="hidden" name="csrf_token" value="<?= assetE($csrfToken) ?>"><input type="hidden" name="action" value="save_asset"><input type="hidden" name="id" value="<?= (int)($editAsset['id'] ?? 0) ?>">
    <div class="form-section-title">Asset identification</div>
    <div class="form-row">
     <div class="form-group col-lg-3 col-md-6"><label for="asset_code">Asset Code</label><input class="form-control" id="asset_code" name="asset_code" maxlength="40" value="<?= assetE($editAsset['asset_code'] ?? '') ?>" placeholder="Auto-generated if blank"><small class="form-text text-muted">Leave blank for automatic code.</small></div>
     <div class="form-group col-lg-5 col-md-6"><label for="asset_name">Asset / Property Name <span class="text-danger">*</span></label><input class="form-control" id="asset_name" name="asset_name" maxlength="180" required value="<?= assetE($editAsset['asset_name'] ?? '') ?>" placeholder="e.g. Desktop computer, school bus"></div>
     <div class="form-group col-lg-4 col-md-6"><label for="category">Category <span class="text-danger">*</span></label><input class="form-control" id="category" name="category" list="assetCategories" maxlength="100" required value="<?= assetE($editAsset['category'] ?? '') ?>" placeholder="Choose or type a category"><datalist id="assetCategories"><option value="Furniture"><option value="Computer & IT"><option value="Laboratory Equipment"><option value="Teaching Equipment"><option value="Vehicle"><option value="Building"><option value="Sports Equipment"><option value="Library Books"><option value="Electrical Equipment"><option value="Other"></datalist></div>
    </div>
    <div class="form-row">
     <div class="form-group col-md-4"><label for="serial_number">Serial / Registration Number</label><input class="form-control" id="serial_number" name="serial_number" maxlength="120" value="<?= assetE($editAsset['serial_number'] ?? '') ?>"></div>
     <div class="form-group col-md-2"><label for="quantity">Quantity <span class="text-danger">*</span></label><input class="form-control" type="number" id="quantity" name="quantity" min="1" step="1" required value="<?= assetE($editAsset['quantity'] ?? 1) ?>"></div>
     <div class="form-group col-md-3"><label for="condition_status">Condition</label><select class="custom-select" id="condition_status" name="condition_status"><?php foreach ($conditionLabels as $val=>$label): ?><option value="<?= assetE($val) ?>" <?= ($editAsset['condition_status'] ?? 'good') === $val ? 'selected' : '' ?>><?= assetE($label) ?></option><?php endforeach; ?></select></div>
     <div class="form-group col-md-3"><label for="asset_status">Status</label><select class="custom-select" id="asset_status" name="asset_status"><?php foreach ($assetStatusLabels as $val=>$label): ?><option value="<?= assetE($val) ?>" <?= ($editAsset['asset_status'] ?? 'active') === $val ? 'selected' : '' ?>><?= assetE($label) ?></option><?php endforeach; ?></select></div>
    </div>
    <div class="form-section-title">Purchase and assignment details</div>
    <div class="form-row">
     <div class="form-group col-md-3"><label for="purchase_date">Purchase Date</label><input class="form-control" type="date" id="purchase_date" name="purchase_date" value="<?= assetE($editAsset['purchase_date'] ?? '') ?>"></div>
     <div class="form-group col-md-3"><label for="purchase_cost">Unit Purchase Cost (UGX)</label><input class="form-control" type="number" id="purchase_cost" name="purchase_cost" min="0" step="0.01" value="<?= assetE(number_format((float)($editAsset['purchase_cost'] ?? 0), 2, '.', '')) ?>"></div>
     <div class="form-group col-md-3"><label for="supplier_name">Supplier / Source</label><input class="form-control" id="supplier_name" name="supplier_name" maxlength="180" value="<?= assetE($editAsset['supplier_name'] ?? '') ?>"></div>
     <div class="form-group col-md-3"><label for="warranty_expiry">Warranty Expiry</label><input class="form-control" type="date" id="warranty_expiry" name="warranty_expiry" value="<?= assetE($editAsset['warranty_expiry'] ?? '') ?>"></div>
    </div>
    <div class="form-row">
     <div class="form-group col-md-6"><label for="location">Location / Department</label><input class="form-control" id="location" name="location" maxlength="150" value="<?= assetE($editAsset['location'] ?? '') ?>" placeholder="e.g. Science laboratory, Block A"></div>
     <div class="form-group col-md-6"><label for="custodian">Responsible Person / Custodian</label><input class="form-control" id="custodian" name="custodian" maxlength="150" value="<?= assetE($editAsset['custodian'] ?? '') ?>" placeholder="Name of staff member responsible"></div>
    </div>
    <div class="form-group"><label for="description">Description</label><textarea class="form-control" id="description" name="description" rows="2" placeholder="Brand, model, specifications or other identifying details"><?= assetE($editAsset['description'] ?? '') ?></textarea></div>
    <div class="form-group"><label for="notes">Notes / Remarks</label><textarea class="form-control" id="notes" name="notes" rows="2" placeholder="Maintenance notes, condition details or other remarks"><?= assetE($editAsset['notes'] ?? '') ?></textarea></div>
    <button type="submit" class="btn btn-success"><i class="fas fa-save mr-1"></i><?= $editAsset ? 'Update Asset' : 'Save Asset' ?></button>
    <?php if ($editAsset): ?> <a href="asset.php" class="btn btn-outline-secondary">Cancel Edit</a><?php else: ?> <button type="reset" class="btn btn-outline-secondary">Clear Form</button><?php endif; ?>
   </form>
  </section>
  <?php endif; ?>

  <section class="panel">
   <div class="d-flex justify-content-between align-items-center flex-wrap mb-3"><h5 class="mb-2"><i class="fas fa-clipboard-list text-primary mr-2"></i>Registered Assets</h5><div class="mb-2 no-print"><a class="btn btn-outline-success" href="?<?= assetE(http_build_query($exportQuery)) ?>"><i class="fas fa-file-csv mr-1"></i>Export CSV</a></div></div>
   <form method="get" action="asset.php" class="form-row align-items-end mb-3 no-print">
    <div class="form-group col-xl-4 col-md-6"><label for="q">Search assets</label><input type="search" class="form-control" id="q" name="q" value="<?= assetE($search) ?>" placeholder="Asset, code, serial number, location, custodian"></div>
    <div class="form-group col-xl-2 col-md-6"><label for="category_filter">Category</label><select class="custom-select" id="category_filter" name="category"><option value="">All categories</option><?php foreach ($categories as $cat): ?><option value="<?= assetE($cat) ?>" <?= $categoryFilter === $cat ? 'selected' : '' ?>><?= assetE($cat) ?></option><?php endforeach; ?></select></div>
    <div class="form-group col-xl-2 col-md-6"><label for="status_filter">Status</label><select class="custom-select" id="status_filter" name="status"><option value="">All statuses</option><?php foreach ($assetStatusLabels as $val=>$label): ?><option value="<?= assetE($val) ?>" <?= $statusFilter === $val ? 'selected' : '' ?>><?= assetE($label) ?></option><?php endforeach; ?></select></div>
    <div class="form-group col-xl-2 col-md-6"><label for="condition_filter">Condition</label><select class="custom-select" id="condition_filter" name="condition"><option value="">All conditions</option><?php foreach ($conditionLabels as $val=>$label): ?><option value="<?= assetE($val) ?>" <?= $conditionFilter === $val ? 'selected' : '' ?>><?= assetE($label) ?></option><?php endforeach; ?></select></div>
    <div class="form-group col-xl-2 col-md-12"><button class="btn btn-primary" type="submit"><i class="fas fa-search mr-1"></i>Filter</button> <a class="btn btn-outline-secondary" href="asset.php">Reset</a></div>
   </form>
   <div class="table-responsive"><table class="table table-bordered table-hover mb-0"><thead><tr><th>Asset</th><th>Category</th><th>Qty</th><th>Location / Custodian</th><th>Purchase Date</th><th class="text-right">Unit Cost (UGX)</th><th>Condition</th><th>Status</th><th class="no-print">Actions</th></tr></thead><tbody>
   <?php if (!$assets): ?><tr><td colspan="9" class="text-center text-muted py-4"><i class="fas fa-box-open fa-2x mb-2"></i><br>No assets found. Register the first school asset using the form above.</td></tr><?php else: foreach ($assets as $asset): $st = (string)$asset['asset_status']; $statusClass = $st === 'active' ? 'success' : (in_array($st, ['in_repair','lost'], true) ? 'warning' : 'secondary'); $cond = (string)$asset['condition_status']; $condClass = in_array($cond, ['new','good'], true) ? 'success' : (in_array($cond, ['poor','damaged'], true) ? 'danger' : 'warning'); ?>
    <tr>
     <td><strong><?= assetE($asset['asset_name']) ?></strong><div class="asset-code"><?= assetE($asset['asset_code']) ?></div><?php if (!empty($asset['serial_number'])): ?><div class="muted-small">S/N: <?= assetE($asset['serial_number']) ?></div><?php endif; ?></td>
     <td><?= assetE($asset['category']) ?></td><td><?= number_format((int)$asset['quantity']) ?></td>
     <td><?= assetE($asset['location'] ?: '—') ?><?php if (!empty($asset['custodian'])): ?><div class="muted-small">Responsible: <?= assetE($asset['custodian']) ?></div><?php endif; ?></td>
     <td><?= !empty($asset['purchase_date']) ? assetE(date('d M Y', strtotime($asset['purchase_date']))) : '—' ?><?php if (!empty($asset['warranty_expiry'])): ?><div class="muted-small">Warranty: <?= assetE(date('d M Y', strtotime($asset['warranty_expiry']))) ?></div><?php endif; ?></td>
     <td class="text-right amount"><?= assetMoney($asset['purchase_cost']) ?></td><td><span class="badge badge-<?= $condClass ?>"><?= assetE($conditionLabels[$cond] ?? $cond) ?></span></td><td><span class="badge badge-<?= $statusClass ?>"><?= assetE($assetStatusLabels[$st] ?? $st) ?></span></td>
     <td class="text-nowrap no-print"><a class="btn btn-sm btn-outline-primary mb-1" href="asset.php?edit=<?= (int)$asset['id'] ?>#assetForm" title="Edit"><i class="fas fa-edit"></i></a>
      <div class="dropdown d-inline"><button class="btn btn-sm btn-outline-secondary dropdown-toggle mb-1" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="Change status"><i class="fas fa-exchange-alt"></i></button><div class="dropdown-menu dropdown-menu-right"><?php foreach ($assetStatusLabels as $statusValue=>$statusLabel): if ($statusValue === $st) continue; ?><form method="post" action="asset.php" class="m-0"><input type="hidden" name="csrf_token" value="<?= assetE($csrfToken) ?>"><input type="hidden" name="action" value="change_status"><input type="hidden" name="id" value="<?= (int)$asset['id'] ?>"><input type="hidden" name="new_status" value="<?= assetE($statusValue) ?>"><button class="dropdown-item" type="submit"><?= assetE($statusLabel) ?></button></form><?php endforeach; ?></div></div>
      <form method="post" action="asset.php" class="action-form" onsubmit="return confirm('Permanently delete this asset record? This cannot be undone.');"><input type="hidden" name="csrf_token" value="<?= assetE($csrfToken) ?>"><input type="hidden" name="action" value="delete_asset"><input type="hidden" name="id" value="<?= (int)$asset['id'] ?>"><button type="submit" class="btn btn-sm btn-outline-danger mb-1" title="Delete"><i class="fas fa-trash"></i></button></form>
     </td>
    </tr>
   <?php endforeach; endif; ?>
   </tbody></table></div>
   <?php if ($totalPages > 1): $pageQuery = $_GET; unset($pageQuery['export'], $pageQuery['edit']); ?><nav class="no-print mt-3" aria-label="Asset pages"><ul class="pagination flex-wrap mb-0"><?php $pageQuery['page'] = max(1, $page - 1); ?><li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="?<?= assetE(http_build_query($pageQuery)) ?>">Previous</a></li><?php for ($p = max(1, $page - 2); $p <= min($totalPages, $page + 2); $p++): $pageQuery['page'] = $p; ?><li class="page-item <?= $p === $page ? 'active' : '' ?>"><a class="page-link" href="?<?= assetE(http_build_query($pageQuery)) ?>"><?= $p ?></a></li><?php endfor; ?><?php $pageQuery['page'] = min($totalPages, $page + 1); ?><li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>"><a class="page-link" href="?<?= assetE(http_build_query($pageQuery)) ?>">Next</a></li></ul></nav><?php endif; ?>
  </section>
  <div class="text-center text-muted small mb-3">School Management System &mdash; Asset Register</div>
 </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>(function(){var sidebar=document.getElementById('sidebar'),menu=document.getElementById('mobileMenuBtn');if(menu&&sidebar)menu.addEventListener('click',function(){sidebar.classList.toggle('show');});document.addEventListener('click',function(e){if(window.innerWidth<=991&&sidebar&&sidebar.classList.contains('show')&&!sidebar.contains(e.target)&&menu&&!menu.contains(e.target))sidebar.classList.remove('show');});var form=document.getElementById('assetEntryForm');if(form)form.addEventListener('submit',function(){var btn=form.querySelector('button[type="submit"]');if(btn){btn.disabled=true;btn.innerHTML='<i class="fas fa-spinner fa-spin mr-1"></i>Saving asset...';}});})();</script>
</body>
</html>
