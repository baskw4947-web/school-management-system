<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator', 'bursar']);

if (!isset($conn) || !($conn instanceof mysqli)) {
    http_response_code(500);
    exit('Database connection was not established.');
}
$conn->set_charset('utf8mb4');

function outstandingE($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function outstandingMoney($value): string
{
    return number_format((float)$value, 2);
}

$requiredTables = ['students', 'student_fee_accounts'];
$missingTables = [];
try {
    foreach ($requiredTables as $table) {
        $stmt = $conn->prepare('SELECT COUNT(*) AS total FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?');
        $stmt->bind_param('s', $table);
        $stmt->execute();
        $exists = (int)($stmt->get_result()->fetch_assoc()['total'] ?? 0) > 0;
        $stmt->close();
        if (!$exists) $missingTables[] = $table;
    }
} catch (Throwable $ex) {
    error_log('Outstanding fees table check failed: ' . $ex->getMessage());
    $missingTables = $requiredTables;
}
$databaseReady = empty($missingTables);

$search = trim((string)($_GET['search'] ?? ''));
$academicYear = trim((string)($_GET['academic_year'] ?? ''));
$term = trim((string)($_GET['term'] ?? ''));
$status = trim((string)($_GET['status'] ?? ''));
$accounts = [];
$academicYears = [];
$terms = ['Term 1', 'Term 2', 'Term 3'];
$totalOutstanding = 0.0;
$totalStudents = 0;
$pageError = '';

if ($databaseReady) {
    try {
        $studentColumns = [];
        $sc = $conn->query('SHOW COLUMNS FROM `students`');
        while ($col = $sc->fetch_assoc()) $studentColumns[$col['Field']] = true;
        $sc->free();
        $accountColumns = [];
        $ac = $conn->query('SHOW COLUMNS FROM `student_fee_accounts`');
        while ($col = $ac->fetch_assoc()) $accountColumns[$col['Field']] = true;
        $ac->free();

        foreach (['id', 'student_id', 'academic_year', 'term', 'total_amount', 'amount_paid'] as $required) {
            if (!isset($accountColumns[$required])) throw new RuntimeException("The student_fee_accounts table is missing the '{$required}' column.");
        }
        foreach (['id', 'first_name', 'last_name'] as $required) {
            if (!isset($studentColumns[$required])) throw new RuntimeException("The students table is missing the '{$required}' column.");
        }
        if (!isset($accountColumns['discount_amount'])) {
            $discountExpr = '0';
        } else {
            $discountExpr = 'COALESCE(sfa.discount_amount, 0)';
        }
        $paidExpr = 'COALESCE(sfa.amount_paid, 0)';
        $totalExpr = 'COALESCE(sfa.total_amount, 0)';
        $balanceExpr = "GREATEST({$totalExpr} - {$discountExpr} - {$paidExpr}, 0)";
        $admissionSelect = isset($studentColumns['admission_no']) ? "COALESCE(s.admission_no, '')" : "''";
        $linSelect = isset($studentColumns['lin_no']) ? "COALESCE(s.lin_no, '')" : "''";
        $paymentCodeSelect = isset($studentColumns['student_payment_code']) ? "COALESCE(s.student_payment_code, '')" : "''";
        $studentSectionSelect = isset($studentColumns['student_section']) ? "COALESCE(s.student_section, 'Day')" : "'Day'";
        $searchClauses = [];
        $types = '';
        $params = [];
        $sql = "SELECT sfa.id, sfa.student_id, sfa.academic_year, sfa.term, {$totalExpr} AS total_amount, {$discountExpr} AS discount_amount, " .
            (isset($accountColumns['total_paid']) ? 'COALESCE(sfa.total_paid, 0)' : $paidExpr) . " AS total_paid, {$paidExpr} AS amount_paid, " .
            $balanceExpr . " AS balance, " .
            (isset($accountColumns['status']) ? "COALESCE(sfa.status, '')" : "''") . " AS status, " .
            "{$admissionSelect} AS admission_no, {$linSelect} AS lin_no, {$paymentCodeSelect} AS student_payment_code, {$studentSectionSelect} AS student_section, COALESCE(s.first_name, '') AS first_name, COALESCE(s.last_name, '') AS last_name, {$balanceExpr} AS calculated_balance " .
            "FROM student_fee_accounts sfa INNER JOIN students s ON sfa.student_id = s.id WHERE {$balanceExpr} > 0";

        if ($search !== '') {
            $sql .= " AND (" . $admissionSelect . " LIKE ? OR " . $linSelect . " LIKE ? OR " . $paymentCodeSelect . " LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ? OR CONCAT(s.first_name, ' ', s.last_name) LIKE ?)";
            $like = '%' . $search . '%';
            array_push($params, $like, $like, $like, $like, $like, $like);
            $types .= 'ssssss';
        }
        if ($academicYear !== '') {
            $sql .= ' AND sfa.academic_year = ?';
            $params[] = $academicYear; $types .= 's';
        }
        if ($term !== '') {
            $sql .= ' AND sfa.term = ?';
            $params[] = $term; $types .= 's';
        }
        if ($status === 'partial') {
            $sql .= " AND {$paidExpr} > 0 AND {$balanceExpr} > 0";
        } elseif ($status === 'pending') {
            $sql .= " AND {$paidExpr} <= 0 AND {$balanceExpr} > 0";
        }
        $sql .= " ORDER BY calculated_balance DESC, s.first_name ASC, s.last_name ASC";
        $stmt = $conn->prepare($sql);
        if ($types !== '') {
            $bind = [$types];
            foreach ($params as $k => &$v) $bind[] = &$v;
            call_user_func_array([$stmt, 'bind_param'], $bind);
        }
        $stmt->execute();
        $rs = $stmt->get_result();
        $studentIds = [];
        while ($row = $rs->fetch_assoc()) {
            $row['calculated_balance'] = max(0, (float)$row['calculated_balance']);
            $accounts[] = $row;
            $totalOutstanding += $row['calculated_balance'];
            $studentIds[(int)$row['student_id']] = true;
        }
        $stmt->close();
        $totalStudents = count($studentIds);

        $yearResult = $conn->query("SELECT DISTINCT academic_year FROM student_fee_accounts WHERE academic_year IS NOT NULL AND academic_year <> '' ORDER BY academic_year DESC");
        while ($yearRow = $yearResult->fetch_assoc()) $academicYears[] = (string)$yearRow['academic_year'];
        $yearResult->free();
    } catch (Throwable $ex) {
        $pageError = $ex->getMessage();
        error_log('Outstanding fees page error: ' . $ex->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Outstanding Fees | Bursar</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        *{box-sizing:border-box}
        body{margin:0;background:#f5f6fa;font-family:Arial,sans-serif;color:#343a40}
        .sidebar{position:fixed;top:0;left:0;bottom:0;width:250px;background:#212529;color:#fff;z-index:1030;overflow-y:auto}
        .sidebar-header{padding:20px 15px;color:#fff;font-weight:700;border-bottom:1px solid rgba(255,255,255,.1);font-size:18px}
        .sidebar-menu{padding:15px 10px}
        .sidebar-section{color:#6c757d;font-size:11px;text-transform:uppercase;padding:12px 10px 6px;letter-spacing:1px}
        .sidebar a{display:block;color:#ced4da;padding:12px 15px;margin-bottom:3px;text-decoration:none;border-radius:6px;font-size:14px}
        .sidebar a:hover{background:#343a40;color:#fff}
        .sidebar a.active{background:#dc3545;color:#fff}
        .sidebar i{width:25px;text-align:center;margin-right:5px}
        .main-content{margin-left:250px;min-height:100vh}
        .topbar{background:#fff;border-bottom:1px solid #e5e5e5;padding:15px 25px;display:flex;align-items:center;justify-content:space-between;gap:15px}
        .topbar h4{margin:0;font-weight:600;color:#343a40}
        .content{padding:25px}
        .page-title{font-weight:700;margin-bottom:5px;color:#343a40}
        .page-subtitle{color:#6c757d;margin-bottom:25px}
        .card{border:0;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,.06);margin-bottom:20px}
        .card-header{background:#fff;border-bottom:1px solid #eee;font-weight:600}
        .summary-card{border-left:4px solid #dc3545}
        .summary-card.students{border-left-color:#007bff}
        .summary-number{font-size:25px;font-weight:700;overflow-wrap:anywhere}
        .table th{background:#f8f9fa;white-space:nowrap;border-top:0;font-size:13px}
        .table td{vertical-align:middle;font-size:13px}
        .amount{font-weight:700;white-space:nowrap}
        .outstanding{color:#dc3545}
        .student-name{font-weight:600}
        .filter-card{background:#fff}
        .badge-partial{background:#ffc107;color:#212529;padding:7px 10px}
        .badge-pending{background:#dc3545;color:#fff;padding:7px 10px}
        .btn{border-radius:6px}
        .mobile-menu{display:none}
        @media(max-width:991px){.sidebar{width:220px}.main-content{margin-left:220px}.content{padding:18px}}
        @media(max-width:767px){.sidebar{position:relative;width:100%;height:auto;max-height:390px}.main-content{margin-left:0}.content{padding:15px}.topbar{padding:14px 15px;flex-wrap:wrap}.table{font-size:12px}}
        @media print{.sidebar,.topbar,.filter-card,.no-print{display:none!important}.main-content{margin:0}.content{padding:0}.card{box-shadow:none}body{background:#fff}}
    </style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<button type="button" id="unifiedSidebarToggle" class="unified-sidebar-toggle" aria-label="Open navigation" aria-controls="sidebar" aria-expanded="false"><i class="fas fa-bars"></i></button>
<div id="unifiedSidebarOverlay" class="sidebar-overlay"></div>

<aside class="sidebar">
    <div class="sidebar-header"><i class="fas fa-university"></i> <span>Bursar</span></div>
    <nav class="sidebar-menu">
        <a href="/admin/bursar/index.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
        <div class="sidebar-section">Students &amp; Fees</div>
        <a href="/admin/bursar/students_fees.php"><i class="fas fa-file-invoice-dollar"></i>Student Fees</a>
        <a href="/admin/bursar/students_fee_accounts.php"><i class="fas fa-file-invoice-dollar"></i>Student Fee Accounts</a>
        <a href="/admin/bursar/fee_structure.php"><i class="fas fa-list-alt"></i>Fee Structure</a>
        <a href="/admin/bursar/payments.php"><i class="fas fa-money-bill-wave"></i>Receive Payment</a>
        <a href="/admin/bursar/outstanding_fees.php" class="active"><i class="fas fa-exclamation-circle"></i>Outstanding Fees</a>
        <div class="sidebar-section">Finance</div>
        <a href="/admin/bursar/income.php"><i class="fas fa-arrow-circle-down"></i>Income</a>
        <a href="/admin/bursar/expenses.php"><i class="fas fa-arrow-circle-up"></i>Expenses</a>
        <a href="/admin/bursar/suppliers.php"><i class="fas fa-truck"></i>Suppliers</a>
        <a href="/admin/bursar/supplier_payments.php"><i class="fas fa-hand-holding-usd"></i>Supplier Payments</a>
        <div class="sidebar-section">Payroll &amp; Budget</div>
        <a href="/admin/bursar/salaries.php"><i class="fas fa-users"></i>Salaries</a>
        <a href="/admin/bursar/salary_payments.php"><i class="fas fa-money-check-alt"></i>Salary Payments</a>
        <a href="/admin/bursar/budgets.php"><i class="fas fa-chart-pie"></i>Budgets</a>
        <div class="sidebar-section">Reports</div>
        <a href="/admin/bursar/cashbook.php"><i class="fas fa-book"></i>Cashbook</a>
        <a href="/admin/bursar/financial_reports.php"><i class="fas fa-chart-line"></i>Financial Reports</a>
        <a href="/admin/bursar/income_report.php"><i class="fas fa-file-invoice"></i>Income Report</a>
        <a href="/admin/bursar/expense_report.php"><i class="fas fa-receipt"></i>Expense Report</a>
        <a href="/admin/bursar/fees_report.php"><i class="fas fa-file-alt"></i>Fees Report</a>
        <a href="/admin/bursar/profit_loss.php"><i class="fas fa-balance-scale"></i>Profit &amp; Loss</a>
        <div class="sidebar-section">System</div>
        <a href="/admin/dashboard.php"><i class="fas fa-user-shield"></i>Admin Dashboard</a>
        <a href="/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
    </nav>
</aside>
<div class="main-content">
    <div class="topbar">
        <h4><i class="fas fa-money-check-alt mr-2"></i>Bursar Management</h4>
        <div class="d-flex align-items-center">
            <button type="button" onclick="window.print()" class="btn btn-outline-secondary btn-sm mr-2 no-print"><i class="fas fa-print mr-1"></i>Print</button>
            <a href="index.php" class="btn btn-outline-secondary btn-sm"><i class="fas fa-tachometer-alt mr-1"></i>Dashboard</a>
        </div>
    </div>
    <main class="content">
        <div class="d-flex justify-content-between align-items-center flex-wrap mb-4">
            <div>
                <h3 class="page-title"><i class="fas fa-exclamation-circle text-danger mr-2"></i>Outstanding Fees</h3>
                <div class="page-subtitle mb-0">Students with unpaid or partially paid school fees.</div>
            </div>
            <a href="payments.php" class="btn btn-primary no-print mt-2"><i class="fas fa-money-bill-wave mr-1"></i>Receive Payment</a>
        </div>

        <?php if (!$databaseReady): ?>
            <div class="alert alert-danger"><h5><i class="fas fa-database mr-2"></i>Database Error</h5><p class="mb-2">The following required tables are missing:</p><ul class="mb-0"><?php foreach ($missingTables as $missing): ?><li><code><?= outstandingE($missing) ?></code></li><?php endforeach; ?></ul></div>
        <?php endif; ?>
        <?php if ($pageError !== ''): ?><div class="alert alert-danger"><strong>Unable to load outstanding fees.</strong><div><?= outstandingE($pageError) ?></div></div><?php endif; ?>

        <div class="row">
            <div class="col-md-6"><div class="card summary-card"><div class="card-body"><div class="text-muted">Total Outstanding Fees (UGX)</div><div class="summary-number text-danger"><?= outstandingMoney($totalOutstanding) ?></div></div></div></div>
            <div class="col-md-6"><div class="card summary-card students"><div class="card-body"><div class="text-muted">Students With Outstanding Fees</div><div class="summary-number text-primary"><?= number_format($totalStudents) ?></div></div></div></div>
        </div>

        <div class="card filter-card no-print">
            <div class="card-header"><i class="fas fa-filter mr-2"></i>Filter Outstanding Fees</div>
            <div class="card-body">
                <form method="GET" action="outstanding_fees.php">
                    <div class="form-row">
                        <div class="col-md-4"><div class="form-group"><label for="search">Search Student</label><input id="search" type="text" name="search" class="form-control" value="<?= outstandingE($search) ?>" placeholder="Admission No., LIN No., Payment Code or student name"></div></div>
                        <div class="col-md-2"><div class="form-group"><label for="academic_year">Academic Year</label><select id="academic_year" name="academic_year" class="custom-select"><option value="">All Years</option><?php foreach ($academicYears as $year): ?><option value="<?= outstandingE($year) ?>" <?= $academicYear === $year ? 'selected' : '' ?>><?= outstandingE($year) ?></option><?php endforeach; ?></select></div></div>
                        <div class="col-md-2"><div class="form-group"><label for="term">Term</label><select id="term" name="term" class="custom-select"><option value="">All Terms</option><?php foreach ($terms as $termOption): ?><option value="<?= outstandingE($termOption) ?>" <?= $term === $termOption ? 'selected' : '' ?>><?= outstandingE($termOption) ?></option><?php endforeach; ?></select></div></div>
                        <div class="col-md-2"><div class="form-group"><label for="status">Status</label><select id="status" name="status" class="custom-select"><option value="">All</option><option value="pending" <?= $status === 'pending' ? 'selected' : '' ?>>Pending</option><option value="partial" <?= $status === 'partial' ? 'selected' : '' ?>>Partial</option></select></div></div>
                        <div class="col-md-2"><div class="form-group"><label>&nbsp;</label><button type="submit" class="btn btn-primary btn-block"><i class="fas fa-search mr-1"></i>Search</button></div></div>
                    </div>
                    <div class="text-right"><a href="outstanding_fees.php" class="btn btn-sm btn-outline-secondary"><i class="fas fa-redo mr-1"></i>Clear Filters</a></div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center"><span><i class="fas fa-list mr-2"></i>Outstanding Student Accounts</span><span class="badge badge-danger"><?= number_format(count($accounts)) ?> Accounts</span></div>
            <div class="card-body p-0"><div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead><tr><th>#</th><th>Admission No.</th><th>Student</th><th>Academic Year</th><th>Term</th><th class="text-right">Total Fee</th><th class="text-right">Discount</th><th class="text-right">Paid</th><th class="text-right">Outstanding</th><th class="text-center no-print">Action</th></tr></thead>
                    <tbody>
                    <?php if (!$accounts): ?>
                        <tr><td colspan="10" class="text-center py-5"><i class="fas fa-check-circle fa-3x text-success mb-3"></i><h5>No Outstanding Fees</h5><p class="text-muted mb-0">No student accounts match the selected filters with an outstanding balance.</p></td></tr>
                    <?php else: $counter = 1; foreach ($accounts as $account): $paidAmount = (float)$account['amount_paid']; $accountStatus = $paidAmount > 0 ? 'partial' : 'pending'; ?>
                        <tr>
                            <td><?= $counter++ ?></td>
                            <td><strong><?= outstandingE($account['admission_no']) ?></strong></td>
                            <td>
                                <div class="student-name"><?= outstandingE(trim($account['first_name'] . ' ' . $account['last_name'])) ?></div>
                                <small class="text-muted">LIN: <?= outstandingE($account['lin_no'] ?: '—') ?> | Payment Code: <?= outstandingE($account['student_payment_code'] ?: '—') ?> | <?= outstandingE($account['student_section'] ?: 'Day') ?></small>
                            </td>
                            <td><?= outstandingE($account['academic_year']) ?></td>
                            <td><?= outstandingE($account['term']) ?></td>
                            <td class="text-right amount"><?= outstandingMoney($account['total_amount']) ?></td>
                            <td class="text-right"><?= outstandingMoney($account['discount_amount']) ?></td>
                            <td class="text-right"><?= outstandingMoney($account['amount_paid']) ?></td>
                            <td class="text-right amount outstanding"><?= outstandingMoney($account['calculated_balance']) ?></td>
                            <td class="text-center no-print"><a href="payments.php?account_id=<?= (int)$account['id'] ?>" class="btn btn-sm btn-success" title="Receive Payment"><i class="fas fa-money-bill-wave"></i></a> <a href="students_fees.php?student_id=<?= (int)$account['student_id'] ?>" class="btn btn-sm btn-info" title="View Student Fees"><i class="fas fa-eye"></i></a></td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div></div>
            <div class="card-footer small text-muted">Outstanding balances are calculated from total fees minus discounts and amount paid.</div>
        </div>
        <p class="small text-muted text-center">School Management System &mdash; Bursar Outstanding Fees</p>
    </main>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

<script src="/assets/js/sidebar-unified.js?v=20261106"></script>
</body>
</html>
