<?php
/* Supplier Payments — School Management System */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator', 'bursar']);

if (!isset($conn) || !($conn instanceof mysqli)) {
    http_response_code(500);
    exit('Database connection is unavailable. Please check config/database.php.');
}
$conn->set_charset('utf8mb4');

if (!function_exists('spE')) {
    function spE($value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8'); }
}
function spFirstColumn(array $columns, array $candidates): ?string {
    foreach ($candidates as $candidate) if (isset($columns[$candidate])) return $candidate;
    return null;
}
function spFlash(string $type, string $message): void {
    $_SESSION['supplier_payments_flash'] = ['type' => $type, 'message' => $message];
}
function spRedirect(): void {
    $query = $_SERVER['QUERY_STRING'] ?? '';
    header('Location: supplier_payments.php' . ($query !== '' ? '?' . $query : ''));
    exit;
}
function spUserId(): int {
    if (isset($_SESSION['user_id']) && is_numeric($_SESSION['user_id'])) return (int)$_SESSION['user_id'];
    if (isset($_SESSION['id']) && is_numeric($_SESSION['id'])) return (int)$_SESSION['id'];
    if (isset($_SESSION['user']) && is_array($_SESSION['user']) && isset($_SESSION['user']['id'])) return (int)$_SESSION['user']['id'];
    return 0;
}
function spEnumValues(string $type): array {
    if (stripos($type, 'enum(') !== 0) return [];
    preg_match_all("/'((?:[^'\\\\]|\\\\.)*)'/", $type, $matches);
    return array_map(static fn($v) => stripcslashes($v), $matches[1] ?? []);
}
function spStatusValue(string $type): string {
    $values = spEnumValues($type);
    foreach (['completed', 'paid', 'successful', 'approved', 'active', 'recorded'] as $preferred) {
        if (in_array($preferred, $values, true)) return $preferred;
    }
    return $values[0] ?? 'completed';
}
function spGeneratePaymentNo(mysqli $conn): string {
    for ($attempt = 0; $attempt < 10; $attempt++) {
        $candidate = 'SPAY-' . date('Ymd-His') . '-' . strtoupper(bin2hex(random_bytes(2)));
        $stmt = $conn->prepare('SELECT id FROM supplier_payments WHERE payment_no = ? LIMIT 1');
        $stmt->bind_param('s', $candidate);
        $stmt->execute();
        $exists = (bool)$stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$exists) return $candidate;
    }
    throw new RuntimeException('A unique payment number could not be generated. Please try again.');
}

if (empty($_SESSION['supplier_payments_csrf'])) {
    $_SESSION['supplier_payments_csrf'] = bin2hex(random_bytes(32));
}
$csrfToken = (string)$_SESSION['supplier_payments_csrf'];
$flash = $_SESSION['supplier_payments_flash'] ?? null;
unset($_SESSION['supplier_payments_flash']);
$schemaError = '';
$pageError = '';
$tableExists = false;
$paymentColumns = [];
$supplierColumns = [];
$suppliers = [];
$methodOptions = [];
$payments = [];
$totalRows = 0;
$totalPages = 1;
$filteredTotal = 0.0;
$perPage = 15;
$search = trim((string)($_GET['q'] ?? ''));
$dateFrom = trim((string)($_GET['from'] ?? ''));
$dateTo = trim((string)($_GET['to'] ?? ''));
$page = max(1, (int)($_GET['page'] ?? 1));

try {
    $tableResult = $conn->query("SHOW TABLES LIKE 'supplier_payments'");
    $tableExists = $tableResult && $tableResult->num_rows > 0;
    if ($tableResult) $tableResult->free();

    $supplierColResult = $conn->query('SHOW COLUMNS FROM `suppliers`');
    while ($col = $supplierColResult->fetch_assoc()) $supplierColumns[$col['Field']] = $col;
    $supplierColResult->free();

    if ($tableExists) {
        $colResult = $conn->query('SHOW COLUMNS FROM `supplier_payments`');
        while ($col = $colResult->fetch_assoc()) $paymentColumns[$col['Field']] = $col;
        $colResult->free();
    }

    $supplierIdCol = spFirstColumn($supplierColumns, ['id', 'supplier_id']);
    $supplierNameCol = spFirstColumn($supplierColumns, ['supplier_name', 'name', 'company_name']);
    $supplierNoCol = spFirstColumn($supplierColumns, ['supplier_no', 'supplier_code', 'code']);
    $supplierStatusCol = spFirstColumn($supplierColumns, ['status']);
    if (!$supplierIdCol || !$supplierNameCol) throw new RuntimeException('The suppliers table must include an ID and supplier name column.');
    $supplierSql = 'SELECT `' . $supplierIdCol . '` AS id, `' . $supplierNameCol . '` AS supplier_name, ' .
        ($supplierNoCol ? '`' . $supplierNoCol . '`' : "''") . ' AS supplier_no, ' .
        ($supplierStatusCol ? '`' . $supplierStatusCol . '`' : "'active'") . ' AS status FROM `suppliers` ORDER BY `' . $supplierNameCol . '`';
    $sr = $conn->query($supplierSql);
    while ($row = $sr->fetch_assoc()) $suppliers[] = $row;
    $sr->free();

    if ($tableExists && isset($paymentColumns['payment_method_id'])) {
        $methodTableResult = $conn->query("SHOW TABLES LIKE 'payment_methods'");
        $hasMethodTable = $methodTableResult && $methodTableResult->num_rows > 0;
        if ($methodTableResult) $methodTableResult->free();
        if ($hasMethodTable) {
            $methodCols = [];
            $mr = $conn->query('SHOW COLUMNS FROM `payment_methods`');
            while ($col = $mr->fetch_assoc()) $methodCols[$col['Field']] = $col;
            $mr->free();
            $methodIdCol = spFirstColumn($methodCols, ['id', 'payment_method_id']);
            $methodNameCol = spFirstColumn($methodCols, ['method_name', 'name', 'payment_method', 'title']);
            $methodStatusCol = spFirstColumn($methodCols, ['status', 'is_active']);
            if ($methodIdCol && $methodNameCol) {
                $methodSql = 'SELECT `' . $methodIdCol . '` AS method_id, `' . $methodNameCol . '` AS method_name FROM `payment_methods`';
                if ($methodStatusCol === 'is_active') $methodSql .= ' WHERE `is_active` = 1';
                elseif ($methodStatusCol === 'status') $methodSql .= " WHERE `status` = 'active'";
                $methodSql .= ' ORDER BY `' . $methodNameCol . '`';
                $methodResult = $conn->query($methodSql);
                while ($row = $methodResult->fetch_assoc()) $methodOptions[] = $row;
                $methodResult->free();
            }
        }
    }
} catch (Throwable $e) {
    error_log('supplier_payments.php schema load error: ' . $e->getMessage());
    $schemaError = $e instanceof RuntimeException ? $e->getMessage() : 'The page could not read the supplier/payment database structure. Check that the suppliers and supplier_payments tables exist and are accessible.';
}

$map = [
    'id' => spFirstColumn($paymentColumns, ['id', 'payment_id']),
    'payment_no' => spFirstColumn($paymentColumns, ['payment_no']),
    'supplier_id' => spFirstColumn($paymentColumns, ['supplier_id']),
    'amount' => spFirstColumn($paymentColumns, ['amount', 'payment_amount', 'paid_amount', 'total_amount']),
    'date' => spFirstColumn($paymentColumns, ['payment_date', 'paid_date', 'transaction_date', 'date_paid', 'date']),
    'method_text' => spFirstColumn($paymentColumns, ['payment_method', 'method', 'payment_type']),
    'method_id' => spFirstColumn($paymentColumns, ['payment_method_id']),
    'reference' => spFirstColumn($paymentColumns, ['reference_no', 'reference_number', 'transaction_reference', 'transaction_id', 'receipt_no', 'payment_reference']),
    'notes' => spFirstColumn($paymentColumns, ['description', 'notes', 'remarks', 'purpose', 'narration']),
    'status' => spFirstColumn($paymentColumns, ['status', 'payment_status']),
    'created_by' => spFirstColumn($paymentColumns, ['created_by', 'paid_by', 'recorded_by', 'user_id']),
    'created_at' => spFirstColumn($paymentColumns, ['created_at', 'recorded_at']),
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $tableExists && $schemaError === '') {
    $postedToken = (string)($_POST['csrf_token'] ?? '');
    if (!hash_equals($csrfToken, $postedToken)) {
        spFlash('danger', 'Your form session expired. Refresh the page and try again.');
        header('Location: supplier_payments.php');
        exit;
    }
    if ((string)($_POST['action'] ?? '') === 'record_payment') {
        try {
            if (!$map['supplier_id'] || !$map['amount']) throw new RuntimeException('The supplier_payments table must include supplier_id and an amount column.');
            $supplierId = (int)($_POST['supplier_id'] ?? 0);
            $amount = filter_var($_POST['amount'] ?? null, FILTER_VALIDATE_FLOAT);
            $paymentDateInput = trim((string)($_POST['payment_date'] ?? date('Y-m-d')));
            $paymentDate = DateTime::createFromFormat('!Y-m-d', $paymentDateInput);
            $paymentMethodText = trim((string)($_POST['payment_method'] ?? 'Cash'));
            $paymentMethodId = (int)($_POST['payment_method_id'] ?? 0);
            $reference = trim((string)($_POST['reference'] ?? ''));
            $notes = trim((string)($_POST['notes'] ?? ''));
            if ($supplierId < 1) throw new RuntimeException('Please select a supplier.');
            if ($amount === false || !is_finite((float)$amount) || (float)$amount <= 0) throw new RuntimeException('Enter a valid payment amount greater than zero.');
            if (!$paymentDate || $paymentDate->format('Y-m-d') !== $paymentDateInput) throw new RuntimeException('Please select a valid payment date.');
            if (!$map['method_id'] && $map['method_text'] && $paymentMethodText === '') throw new RuntimeException('Please select a payment method.');

            $check = $conn->prepare('SELECT `' . ($supplierIdCol ?? 'id') . '` FROM `suppliers` WHERE `' . ($supplierIdCol ?? 'id') . '` = ? LIMIT 1');
            $check->bind_param('i', $supplierId);
            $check->execute();
            $supplierExists = (bool)$check->get_result()->fetch_assoc();
            $check->close();
            if (!$supplierExists) throw new RuntimeException('The selected supplier could not be found.');

            $values = [];
            $types = '';
            $addValue = static function (?string $column, $value, string $type) use (&$values, &$types, $paymentColumns): void {
                if (!$column || !isset($paymentColumns[$column])) return;
                $values[$column] = $value;
                $types .= $type;
            };
            $generatedPaymentNo = '';
            if ($map['payment_no']) {
                $generatedPaymentNo = spGeneratePaymentNo($conn);
                $addValue($map['payment_no'], $generatedPaymentNo, 's');
            }
            $addValue($map['supplier_id'], $supplierId, 'i');
            $addValue($map['amount'], (float)$amount, 'd');
            if ($map['date']) {
                $dateType = strtolower((string)($paymentColumns[$map['date']]['Type'] ?? ''));
                $dateToStore = $paymentDateInput;
                if (strpos($dateType, 'datetime') !== false || strpos($dateType, 'timestamp') !== false) $dateToStore .= ' ' . date('H:i:s');
                $addValue($map['date'], $dateToStore, 's');
            }
            if ($map['method_text']) $addValue($map['method_text'], $paymentMethodText, 's');
            if ($map['method_id']) $addValue($map['method_id'], $paymentMethodId > 0 ? $paymentMethodId : null, 'i');
            if ($map['reference']) $addValue($map['reference'], $reference !== '' ? $reference : null, 's');
            if ($map['notes']) $addValue($map['notes'], $notes !== '' ? $notes : null, 's');
            if ($map['status']) $addValue($map['status'], spStatusValue((string)$paymentColumns[$map['status']]['Type']), 's');
            if ($map['created_by']) {
                $uid = spUserId();
                if ($uid < 1 && stripos((string)$paymentColumns[$map['created_by']]['Type'], 'int') !== false) throw new RuntimeException('Your logged-in user ID could not be identified. Sign out and sign back in, then try again.');
                $addValue($map['created_by'], $uid, 'i');
            }
            foreach ($paymentColumns as $name => $info) {
                if (array_key_exists($name, $values)) continue;
                if (stripos((string)$info['Extra'], 'auto_increment') !== false || strtoupper((string)$info['Null']) === 'YES' || $info['Default'] !== null || in_array($name, ['created_at', 'updated_at'], true)) continue;
                throw new RuntimeException('The supplier_payments table has another required column named `' . $name . '` without a default. Please share the table structure so it can be mapped.');
            }
            if (!$values) throw new RuntimeException('No compatible supplier payment fields were found.');
            $columnSql = implode(', ', array_map(static fn($name) => '`' . str_replace('`', '``', $name) . '`', array_keys($values)));
            $placeholderSql = implode(', ', array_fill(0, count($values), '?'));
            $insert = $conn->prepare('INSERT INTO `supplier_payments` (' . $columnSql . ') VALUES (' . $placeholderSql . ')');
            $bindArgs = [$types];
            foreach ($values as $key => &$value) $bindArgs[] = &$value;
            call_user_func_array([$insert, 'bind_param'], $bindArgs);
            $insert->execute();
            $insertId = $insert->insert_id;
            $insert->close();
            $message = 'Supplier payment recorded successfully.';
            if ($generatedPaymentNo !== '') $message .= ' Payment No: ' . $generatedPaymentNo . '.';
            if ($insertId) $message .= ' Payment ID: ' . $insertId . '.';
            spFlash('success', $message);
            header('Location: supplier_payments.php');
            exit;
        } catch (Throwable $e) {
            error_log('supplier_payments.php record error: ' . $e->getMessage());
            spFlash('danger', $e instanceof RuntimeException ? $e->getMessage() : 'The payment could not be recorded. Confirm the table structure and check the PHP error log.');
            header('Location: supplier_payments.php');
            exit;
        }
    }
}

if ($tableExists && $schemaError === '') {
    try {
        if (!$map['supplier_id'] || !$map['amount']) {
            $pageError = 'The supplier_payments table does not contain the expected supplier_id and amount columns. Detected columns: ' . implode(', ', array_keys($paymentColumns));
        } else {
            $where = ' WHERE 1=1 ';
            $escapedSearch = $conn->real_escape_string('%' . $search . '%');
            if ($search !== '') {
                $parts = [];
                foreach ([$map['payment_no'], $map['reference'], $map['notes'], $map['method_text'], $map['status'], $map['id']] as $column) {
                    if ($column) $parts[] = 'CAST(p.`' . str_replace('`', '``', $column) . '` AS CHAR) LIKE \'' . $escapedSearch . '\'';
                }
                if ($supplierNameCol) $parts[] = 's.`' . $supplierNameCol . '` LIKE \'' . $escapedSearch . '\'';
                if ($supplierNoCol) $parts[] = 's.`' . $supplierNoCol . '` LIKE \'' . $escapedSearch . '\'';
                if ($parts) $where .= ' AND (' . implode(' OR ', $parts) . ')';
            }
            if ($map['date'] && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom)) $where .= " AND DATE(p.`" . $map['date'] . "`) >= '" . $conn->real_escape_string($dateFrom) . "'";
            if ($map['date'] && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo)) $where .= " AND DATE(p.`" . $map['date'] . "`) <= '" . $conn->real_escape_string($dateTo) . "'";
            $supplierJoin = ' LEFT JOIN `suppliers` s ON s.`' . $supplierIdCol . '` = p.`' . $map['supplier_id'] . '`';
            $countSql = 'SELECT COUNT(*) AS total, COALESCE(SUM(p.`' . $map['amount'] . '`),0) AS total_amount FROM `supplier_payments` p' . $supplierJoin . $where;
            $countResult = $conn->query($countSql);
            $countRow = $countResult->fetch_assoc() ?: [];
            $totalRows = (int)($countRow['total'] ?? 0);
            $filteredTotal = (float)($countRow['total_amount'] ?? 0);
            $countResult->free();
            $totalPages = max(1, (int)ceil($totalRows / $perPage));
            $page = min($page, $totalPages);
            $offset = ($page - 1) * $perPage;
            $orderColumn = $map['date'] ?: $map['id'];
            $orderSql = $orderColumn ? ' ORDER BY p.`' . $orderColumn . '` DESC' : '';
            $supplierNameSelect = $supplierNameCol ? 's.`' . $supplierNameCol . '`' : "'Supplier not found'";
            $supplierNoSelect = $supplierNoCol ? 's.`' . $supplierNoCol . '`' : "''";
            $listSql = 'SELECT p.*, ' . $supplierNameSelect . ' AS _supplier_name, ' . $supplierNoSelect . ' AS _supplier_no FROM `supplier_payments` p' . $supplierJoin . $where . $orderSql . ' LIMIT ' . (int)$perPage . ' OFFSET ' . (int)$offset;
            $listResult = $conn->query($listSql);
            while ($row = $listResult->fetch_assoc()) $payments[] = $row;
            $listResult->free();
        }
    } catch (Throwable $e) {
        error_log('supplier_payments.php list error: ' . $e->getMessage());
        $pageError = 'Unable to load supplier payments. Please check the supplier_payments table columns and PHP error log.';
    }
}

$hasPaymentMethods = !empty($methodOptions) && (bool)$map['method_id'];
$schemaSql = "CREATE TABLE supplier_payments (\n  id INT(11) NOT NULL AUTO_INCREMENT,\n  payment_no VARCHAR(50) NOT NULL,\n  supplier_id INT(11) NOT NULL,\n  amount DECIMAL(12,2) NOT NULL,\n  payment_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,\n  payment_method_id INT(11) DEFAULT NULL,\n  reference_no VARCHAR(100) DEFAULT NULL,\n  description TEXT DEFAULT NULL,\n  paid_by INT(11) NOT NULL,\n  status ENUM('completed','cancelled','reversed') NOT NULL DEFAULT 'completed',\n  PRIMARY KEY (id),\n  UNIQUE KEY uq_supplier_payment_no (payment_no),\n  KEY idx_supplier_id (supplier_id),\n  KEY idx_payment_date (payment_date)\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Supplier Payments | Bursar</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
:root{--sidebar-width:250px;--sidebar-bg:#212529;--accent:#dc3545;--page-bg:#f4f6f9}*{box-sizing:border-box}body{margin:0;background:var(--page-bg);font-family:Arial,Helvetica,sans-serif;color:#343a40}.sidebar{position:fixed;top:0;left:0;bottom:0;width:var(--sidebar-width);background:var(--sidebar-bg);color:#fff;overflow-y:auto;z-index:1050;transition:left .25s ease}.sidebar-header{padding:20px 15px;color:#fff;font-weight:700;border-bottom:1px solid rgba(255,255,255,.1);font-size:18px}.sidebar-menu{padding:15px 10px}.sidebar-section{color:#9aa0a6;font-size:11px;text-transform:uppercase;padding:12px 10px 6px;letter-spacing:1px}.sidebar-menu a{display:block;color:#c9cdd1;text-decoration:none;padding:10px;border-radius:5px;font-size:13px;margin:2px 0}.sidebar-menu a i{width:22px;text-align:center;margin-right:3px}.sidebar-menu a:hover,.sidebar-menu a.active{background:var(--accent);color:#fff}.sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:1040}.sidebar-overlay.show{display:block}.main{margin-left:var(--sidebar-width);padding:25px;min-height:100vh}.topbar{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:22px}.topbar h2{font-size:25px;margin:0;font-weight:700;color:#212529}.subheading{color:#6c757d;font-size:13px;margin-top:5px}.panel{background:#fff;border-radius:9px;box-shadow:0 3px 15px rgba(0,0,0,.045);padding:22px;margin-bottom:22px;border:1px solid #eceff2}.panel-title{font-size:17px;font-weight:700;margin-bottom:17px;color:#28313a}.stat-card{background:#fff;border:1px solid #eceff2;border-radius:9px;padding:17px 19px;box-shadow:0 3px 15px rgba(0,0,0,.035);height:100%}.stat-card .label{color:#6c757d;font-size:12px}.stat-card .value{font-size:23px;font-weight:700;margin-top:6px}.stat-card .symbol{float:right;width:38px;height:38px;line-height:38px;text-align:center;border-radius:9px;background:#fbe9eb;color:#dc3545}.form-control{font-size:13px;min-height:38px}label{font-size:12px;color:#4e5c70;font-weight:600}.table thead th{background:#f7f8fa;color:#68717d;font-size:11px;text-transform:uppercase;letter-spacing:.4px;border-top:0;white-space:nowrap}.table td{font-size:12px;vertical-align:middle}.btn{font-size:12px}.badge{font-size:10px;padding:6px 8px}.empty-state{padding:35px 10px;text-align:center;color:#8290a4}.empty-state i{font-size:30px;margin-bottom:12px;color:#bec8d7}.footer-note{text-align:center;color:#97a1b1;font-size:11px;padding:7px 0 0}.mobile-menu{display:none}.help-text{font-size:11px;color:#8490a1}@media(max-width:991px){.sidebar{left:-250px}.sidebar.show{left:0}.main{margin-left:0;padding:16px}.mobile-menu{display:inline-block}}@media print{.sidebar,.topbar,.no-print,.sidebar-overlay,#paymentForm{display:none!important}.main{margin:0;padding:0}body{background:#fff}.panel,.stat-card{box-shadow:none}}
</style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<aside class="sidebar" id="sidebar">
 <div class="sidebar-header"><i class="fas fa-university mr-1"></i> <span>Bursar</span></div>
 <nav class="sidebar-menu">
  <div class="sidebar-section">Main</div><a href="/admin/bursar/index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
  <div class="sidebar-section">Students &amp; Fees</div><a href="/admin/bursar/students_fees.php"><i class="fas fa-file-invoice-dollar"></i> Student Fees</a><a href="/admin/bursar/students_fee_accounts.php"><i class="fas fa-file-invoice-dollar"></i> Student Fee Accounts</a><a href="/admin/bursar/fee_structure.php"><i class="fas fa-list-alt"></i> Fee Structure</a><a href="/admin/bursar/payments.php"><i class="fas fa-money-bill-wave"></i> Receive Payment</a><a href="/admin/bursar/outstanding_fees.php"><i class="fas fa-exclamation-circle"></i> Outstanding Fees</a>
  <div class="sidebar-section">Finance</div><a href="/admin/bursar/income.php"><i class="fas fa-arrow-circle-down"></i> Income</a><a href="/admin/bursar/expenses.php"><i class="fas fa-arrow-circle-up"></i> Expenses</a><a href="/admin/bursar/suppliers.php"><i class="fas fa-truck"></i> Suppliers</a><a href="/admin/bursar/supplier_payments.php" class="active"><i class="fas fa-hand-holding-usd"></i> Supplier Payments</a>
  <div class="sidebar-section">Payroll &amp; Budget</div><a href="/admin/bursar/salaries.php"><i class="fas fa-users"></i> Salaries</a><a href="/admin/bursar/salary_payments.php"><i class="fas fa-money-check-alt"></i> Salary Payments</a><a href="/admin/bursar/budgets.php"><i class="fas fa-chart-pie"></i> Budgets</a>
  <div class="sidebar-section">Reports</div><a href="/admin/bursar/cashbook.php"><i class="fas fa-book"></i> Cashbook</a><a href="/admin/bursar/financial_reports.php"><i class="fas fa-chart-line"></i> Financial Reports</a><a href="/admin/bursar/income_report.php"><i class="fas fa-file-invoice"></i> Income Report</a><a href="/admin/bursar/expense_report.php"><i class="fas fa-receipt"></i> Expense Report</a><a href="/admin/bursar/fees_report.php"><i class="fas fa-file-alt"></i> Fees Report</a><a href="/admin/bursar/profit_loss.php"><i class="fas fa-balance-scale"></i> Profit &amp; Loss</a>
  <div class="sidebar-section">System</div><a href="/admin/dashboard.php"><i class="fas fa-cogs"></i> Admin Dashboard</a><a href="/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
 </nav>
</aside>
<div class="main">
 <div class="topbar"><div class="d-flex align-items-start"><button class="btn btn-dark mobile-menu mr-3" id="mobileMenuBtn" type="button" aria-label="Open navigation"><i class="fas fa-bars"></i></button><div><h2>Supplier Payments</h2><div class="subheading">Record and review payments made to suppliers.</div></div></div><button type="button" class="btn btn-outline-secondary no-print" onclick="window.print()"><i class="fas fa-print mr-1"></i> Print</button></div>
 <?php if ($flash): ?><div class="alert alert-<?= spE($flash['type'] ?? 'info') ?> alert-dismissible fade show" role="alert"><?= spE($flash['message'] ?? '') ?><button type="button" class="close" data-dismiss="alert"><span>&times;</span></button></div><?php endif; ?>
 <?php if ($schemaError): ?><div class="alert alert-danger"><?= spE($schemaError) ?></div><?php endif; ?>
 <?php if (!$tableExists && !$schemaError): ?>
  <section class="panel"><div class="panel-title text-danger"><i class="fas fa-database mr-2"></i>Supplier payments table not found</div><p>The <code>suppliers</code> table is available, but the database does not contain a table named <code>supplier_payments</code>. Create it in phpMyAdmin using the SQL below, then refresh this page.</p><textarea class="form-control mb-2" rows="13" readonly id="createTableSql"><?= spE($schemaSql) ?></textarea><button type="button" class="btn btn-danger" id="copySqlBtn"><i class="fas fa-copy mr-1"></i> Copy SQL</button><p class="help-text mt-3 mb-0">Select the school management database in phpMyAdmin, open the SQL tab, paste the SQL and execute it. Do not create a duplicate table if supplier payments already exist under a different name.</p></section>
 <?php else: ?>
  <?php if ($pageError): ?><div class="alert alert-warning"><?= spE($pageError) ?></div><?php endif; ?>
  <div class="row mb-4"><div class="col-md-6 mb-3 mb-md-0"><div class="stat-card"><span class="symbol"><i class="fas fa-receipt"></i></span><div class="label">Payments matching current filters</div><div class="value"><?= number_format($totalRows) ?></div></div></div><div class="col-md-6"><div class="stat-card"><span class="symbol"><i class="fas fa-money-bill-wave"></i></span><div class="label">Total amount in results</div><div class="value">UGX <?= number_format($filteredTotal, 2) ?></div></div></div></div>
  <section class="panel" id="paymentForm"><div class="panel-title"><i class="fas fa-plus-circle text-danger mr-2"></i>Record Supplier Payment</div>
   <?php if (!$map['supplier_id'] || !$map['amount']): ?><div class="alert alert-warning mb-0">The <code>supplier_payments</code> table needs a <code>supplier_id</code> column and an amount column such as <code>amount</code>, <code>payment_amount</code>, or <code>paid_amount</code>. Detected columns: <code><?= spE(implode(', ', array_keys($paymentColumns))) ?></code>.</div>
   <?php else: ?>
   <form method="POST" action="supplier_payments.php" id="supplierPaymentForm"><input type="hidden" name="csrf_token" value="<?= spE($csrfToken) ?>"><input type="hidden" name="action" value="record_payment">
    <div class="form-row">
     <div class="form-group col-lg-5"><label for="supplier_id">Supplier <span class="text-danger">*</span></label><select class="form-control" name="supplier_id" id="supplier_id" required><option value="">Select supplier</option><?php foreach ($suppliers as $supplier): ?><option value="<?= (int)$supplier['id'] ?>"><?= spE($supplier['supplier_name']) ?><?= ($supplier['supplier_no'] ?? '') !== '' ? ' (' . spE($supplier['supplier_no']) . ')' : '' ?><?= strtolower((string)($supplier['status'] ?? 'active')) === 'inactive' ? ' — Inactive' : '' ?></option><?php endforeach; ?></select><?php if (!$suppliers): ?><small class="text-danger">No suppliers found. Add a supplier first.</small><?php endif; ?></div>
     <div class="form-group col-lg-3"><label for="amount">Amount (UGX) <span class="text-danger">*</span></label><input class="form-control" type="number" name="amount" id="amount" min="0.01" step="0.01" required placeholder="e.g. 150000"></div>
     <div class="form-group col-lg-4"><label for="payment_date">Payment Date <span class="text-danger">*</span></label><input class="form-control" type="date" name="payment_date" id="payment_date" value="<?= spE(date('Y-m-d')) ?>" required></div>
    </div>
    <div class="form-row">
     <?php if ($map['method_id']): ?><div class="form-group col-md-4"><label for="payment_method_id">Payment Method (optional)</label><?php if ($hasPaymentMethods): ?><select class="form-control" name="payment_method_id" id="payment_method_id"><option value="">Not specified</option><?php foreach ($methodOptions as $method): ?><option value="<?= (int)$method['method_id'] ?>"><?= spE($method['method_name']) ?></option><?php endforeach; ?></select><?php else: ?><input class="form-control" type="number" min="1" name="payment_method_id" id="payment_method_id" placeholder="Payment method ID (optional)"><small class="help-text">No readable payment method list was found. Leave blank if not used.</small><?php endif; ?></div><?php elseif ($map['method_text']): ?><div class="form-group col-md-4"><label for="payment_method">Payment Method</label><select class="form-control" name="payment_method" id="payment_method"><option value="Cash">Cash</option><option value="Bank Transfer">Bank Transfer</option><option value="Mobile Money">Mobile Money</option><option value="Cheque">Cheque</option><option value="Other">Other</option></select></div><?php endif; ?>
     <?php if ($map['reference']): ?><div class="form-group col-md-4"><label for="reference">Reference / Receipt Number</label><input class="form-control" name="reference" id="reference" maxlength="100" placeholder="Bank reference or receipt number"></div><?php endif; ?>
     <?php if ($map['notes']): ?><div class="form-group col-md-<?= (($map['method_id'] || $map['method_text']) && $map['reference']) ? '4' : '8' ?>"><label for="notes">Description / Notes</label><input class="form-control" name="notes" id="notes" maxlength="500" placeholder="What was paid for?"></div><?php endif; ?>
    </div>
    <button type="submit" class="btn btn-danger" <?= !$suppliers ? 'disabled' : '' ?> id="recordPaymentButton"><i class="fas fa-save mr-1"></i> Record Payment</button> <button type="reset" class="btn btn-outline-secondary"><i class="fas fa-undo mr-1"></i> Clear</button>
   </form><?php endif; ?>
  </section>
  <section class="panel"><div class="d-flex flex-wrap align-items-center justify-content-between mb-3"><div class="panel-title mb-2"><i class="fas fa-list mr-2 text-danger"></i>Supplier Payment History</div><span class="text-muted small mb-2"><?= number_format($totalRows) ?> payment(s)</span></div>
   <form method="GET" action="supplier_payments.php" class="form-row align-items-end mb-3 no-print"><div class="form-group col-md-5 mb-2"><label for="q">Search</label><input class="form-control" type="search" name="q" id="q" value="<?= spE($search) ?>" placeholder="Supplier, reference, method, notes or ID"></div><?php if ($map['date']): ?><div class="form-group col-md-2 mb-2"><label for="from">From date</label><input type="date" class="form-control" id="from" name="from" value="<?= spE($dateFrom) ?>"></div><div class="form-group col-md-2 mb-2"><label for="to">To date</label><input type="date" class="form-control" id="to" name="to" value="<?= spE($dateTo) ?>"></div><?php endif; ?><div class="form-group col-md-3 mb-2"><button class="btn btn-danger mr-1" type="submit"><i class="fas fa-search mr-1"></i> Filter</button><a href="supplier_payments.php" class="btn btn-outline-secondary">Reset</a></div></form>
   <div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Payment No.</th><th>Supplier</th><th>Date</th><th>Method</th><th>Reference / Notes</th><th>Status</th><th class="text-right">Amount (UGX)</th></tr></thead><tbody>
    <?php if (!$payments): ?><tr><td colspan="7"><div class="empty-state"><i class="fas fa-receipt d-block"></i><strong>No supplier payments found</strong><div class="small mt-1">Record a payment above or change your filters.</div></div></td></tr><?php else: foreach ($payments as $payment):
      $pid = $map['id'] ? ($payment[$map['id']] ?? '') : '';
      $paymentNo = $map['payment_no'] ? trim((string)($payment[$map['payment_no']] ?? '')) : '';
      $paidAt = $map['date'] ? ($payment[$map['date']] ?? '') : ($map['created_at'] ? ($payment[$map['created_at']] ?? '') : '');
      $methodLabel = $map['method_text'] ? ($payment[$map['method_text']] ?? '') : ($map['method_id'] ? ('Method ID ' . ($payment[$map['method_id']] ?? '')) : '—');
      $refLabel = $map['reference'] ? ($payment[$map['reference']] ?? '') : '';
      $notesLabel = $map['notes'] ? ($payment[$map['notes']] ?? '') : '';
      $statusLabel = $map['status'] ? ($payment[$map['status']] ?? '') : 'Recorded';
      $reversed = in_array(strtolower((string)$statusLabel), ['reversed','cancelled','canceled','void','voided','deleted'], true);
    ?><tr><td><strong><?= $paymentNo !== '' ? spE($paymentNo) : ($pid !== '' ? '#' . spE($pid) : 'Payment') ?></strong><?php if ($pid !== '' && $paymentNo !== ''): ?><div class="text-muted small">ID: #<?= spE($pid) ?></div><?php endif; ?><?php if ($map['created_at'] && !empty($payment[$map['created_at']])): ?><div class="text-muted small">Recorded <?= spE(date('d M Y H:i', strtotime((string)$payment[$map['created_at']]))) ?></div><?php endif; ?></td><td><strong><?= spE($payment['_supplier_name'] ?? 'Supplier not found') ?></strong><div class="text-muted small"><?= spE($payment['_supplier_no'] ?? '') ?></div></td><td><?= $paidAt && strtotime((string)$paidAt) ? spE(date('d M Y', strtotime((string)$paidAt))) : '—' ?></td><td><?= $methodLabel !== '' ? spE($methodLabel) : '—' ?></td><td><?= $refLabel !== '' ? '<div>' . spE($refLabel) . '</div>' : '' ?><?= $notesLabel !== '' ? '<div class="text-muted small">' . spE($notesLabel) . '</div>' : '' ?><?= $refLabel === '' && $notesLabel === '' ? '—' : '' ?></td><td><span class="badge <?= $reversed ? 'badge-danger' : 'badge-success' ?>"><?= spE($statusLabel ?: 'Recorded') ?></span></td><td class="text-right font-weight-bold <?= $reversed ? 'text-muted' : 'text-success' ?>"><?= $reversed ? '— ' : '' ?><?= number_format((float)($payment[$map['amount']] ?? 0), 2) ?></td></tr><?php endforeach; endif; ?>
   </tbody></table></div>
   <?php if ($totalPages > 1): $pageQuery = $_GET; ?><nav class="no-print mt-3" aria-label="Payment pages"><ul class="pagination flex-wrap mb-0"><?php $pageQuery['page'] = max(1, $page - 1); ?><li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="?<?= spE(http_build_query($pageQuery)) ?>">Previous</a></li><?php for ($p = max(1, $page - 2); $p <= min($totalPages, $page + 2); $p++): $pageQuery['page'] = $p; ?><li class="page-item <?= $p === $page ? 'active' : '' ?>"><a class="page-link" href="?<?= spE(http_build_query($pageQuery)) ?>"><?= $p ?></a></li><?php endfor; ?><?php $pageQuery['page'] = min($totalPages, $page + 1); ?><li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>"><a class="page-link" href="?<?= spE(http_build_query($pageQuery)) ?>">Next</a></li></ul></nav><?php endif; ?>
  </section>
 <?php endif; ?>
 <div class="footer-note">School Management System &mdash; Bursar Supplier Payments</div>
</div>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function(){
 var sidebar=document.getElementById('sidebar'), overlay=document.getElementById('sidebarOverlay'), menuButton=document.getElementById('mobileMenuBtn');
 function closeSidebar(){if(sidebar)sidebar.classList.remove('show');if(overlay)overlay.classList.remove('show');}
 if(menuButton&&sidebar){menuButton.addEventListener('click',function(){sidebar.classList.toggle('show');if(overlay)overlay.classList.toggle('show',sidebar.classList.contains('show'));});}
 if(overlay)overlay.addEventListener('click',closeSidebar);
 document.addEventListener('keydown',function(e){if(e.key==='Escape')closeSidebar();});
 var form=document.getElementById('supplierPaymentForm');if(form){form.addEventListener('submit',function(){var button=document.getElementById('recordPaymentButton');if(button){button.disabled=true;button.innerHTML='<i class="fas fa-spinner fa-spin mr-1"></i> Recording payment...';}});}
 var copyBtn=document.getElementById('copySqlBtn');if(copyBtn){copyBtn.addEventListener('click',function(){var field=document.getElementById('createTableSql');field.select();field.setSelectionRange(0,99999);try{document.execCommand('copy');copyBtn.innerHTML='<i class="fas fa-check mr-1"></i> SQL copied';}catch(e){copyBtn.innerHTML='Select and copy SQL';}});}
})();
</script>
</body>
</html>
