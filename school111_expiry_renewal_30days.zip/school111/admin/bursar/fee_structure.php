<?php
session_start();

require_once '../../config/database.php';
require_once '../../includes/auth.php';

requireRole([
    'administrator',
    'assistant_administrator',
    'bursar'
]);

if (!isset($conn) || !($conn instanceof mysqli)) {
    die("Database connection was not established.");
}

$conn->set_charset("utf8mb4");

/*
|--------------------------------------------------------------------------
| CURRENT USER
|--------------------------------------------------------------------------
*/
$created_by = (int)($_SESSION['user_id'] ?? $_SESSION['id'] ?? 0);

if ($created_by <= 0) {
    die("Unable to identify the logged-in user.");
}

/*
|--------------------------------------------------------------------------
| CSRF TOKEN
|--------------------------------------------------------------------------
*/
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrf_token = $_SESSION['csrf_token'];

/*
|--------------------------------------------------------------------------
| HELPER
|--------------------------------------------------------------------------
*/
function e($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function money($value)
{
    return number_format((float)$value, 2);
}

/*
|--------------------------------------------------------------------------
| MESSAGES
|--------------------------------------------------------------------------
*/
$success = '';
$error = '';

/*
|--------------------------------------------------------------------------
| CHECK TABLE
|--------------------------------------------------------------------------
*/
$tableExists = false;

$tableCheck = $conn->query("SHOW TABLES LIKE 'fee_structures'");

if ($tableCheck && $tableCheck->num_rows > 0) {
    $tableExists = true;
}

/*
|--------------------------------------------------------------------------
| FIND THE TABLE REFERENCED BY class_id
|--------------------------------------------------------------------------
|
| This avoids assuming whether your class table is called:
| classes, school_classes, academic_classes, etc.
|
|--------------------------------------------------------------------------
*/
$classTable = null;
$classColumn = null;

if ($tableExists) {

    $stmt = $conn->prepare("
        SELECT
            REFERENCED_TABLE_NAME,
            REFERENCED_COLUMN_NAME
        FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fee_structures'
          AND COLUMN_NAME = 'class_id'
          AND REFERENCED_TABLE_NAME IS NOT NULL
        LIMIT 1
    ");

    if ($stmt) {

        $stmt->execute();

        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {

            $row = $result->fetch_assoc();

            $classTable = $row['REFERENCED_TABLE_NAME'];
            $classColumn = $row['REFERENCED_COLUMN_NAME'];
        }

        $stmt->close();
    }
}

/*
|--------------------------------------------------------------------------
| FIND A DISPLAY COLUMN FOR THE CLASS TABLE
|--------------------------------------------------------------------------
*/
$classDisplayColumn = null;

if ($classTable) {

    $possibleColumns = [
        'class_name',
        'name',
        'class',
        'class_title',
        'grade_name',
        'title'
    ];

    foreach ($possibleColumns as $possibleColumn) {

        $columnCheck = $conn->prepare("
            SELECT COLUMN_NAME
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = ?
              AND COLUMN_NAME = ?
            LIMIT 1
        ");

        if ($columnCheck) {

            $columnCheck->bind_param(
                "ss",
                $classTable,
                $possibleColumn
            );

            $columnCheck->execute();

            $columnResult = $columnCheck->get_result();

            if ($columnResult && $columnResult->num_rows > 0) {

                $classDisplayColumn = $possibleColumn;

                $columnCheck->close();

                break;
            }

            $columnCheck->close();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | FALLBACK
    |--------------------------------------------------------------------------
    */
    if (!$classDisplayColumn) {
        $classDisplayColumn = $classColumn;
    }
}

/*
|--------------------------------------------------------------------------
| LOAD CLASSES
|--------------------------------------------------------------------------
*/
$classes = [];

if ($classTable && $classColumn && $classDisplayColumn) {

    /*
    | Identifiers come directly from INFORMATION_SCHEMA,
    | not from user input.
    */
    $safeClassTable = str_replace('`', '``', $classTable);
    $safeClassColumn = str_replace('`', '``', $classColumn);
    $safeDisplayColumn = str_replace('`', '``', $classDisplayColumn);

    $classSQL = "
        SELECT
            `$safeClassColumn` AS class_id,
            `$safeDisplayColumn` AS class_name
        FROM `$safeClassTable`
        ORDER BY `$safeDisplayColumn` ASC
    ";

    $classResult = $conn->query($classSQL);

    if ($classResult) {

        while ($classRow = $classResult->fetch_assoc()) {
            $classes[] = $classRow;
        }
    }
}

/*
|--------------------------------------------------------------------------
| HANDLE POST
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $tableExists) {

    $postedToken = $_POST['csrf_token'] ?? '';

    if (!hash_equals($_SESSION['csrf_token'], $postedToken)) {

        $error = "Invalid security token. Please refresh the page and try again.";

    } else {

        $action = $_POST['action'] ?? '';

        /*
        |--------------------------------------------------------------------------
        | ADD
        |--------------------------------------------------------------------------
        */
        if ($action === 'add') {

            $class_id = (int)($_POST['class_id'] ?? 0);
            $academic_year = trim($_POST['academic_year'] ?? '');
            $term = trim($_POST['term'] ?? '');
            $fee_name = trim($_POST['fee_name'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $amount = $_POST['amount'] ?? '';
            $due_date = trim($_POST['due_date'] ?? '');
            $status = trim($_POST['status'] ?? 'active');

            if ($class_id <= 0) {

                $error = "Please select a class.";

            } elseif ($academic_year === '') {

                $error = "Please enter the academic year.";

            } elseif (!in_array($term, ['Term 1', 'Term 2', 'Term 3'], true)) {

                $error = "Please select a valid term.";

            } elseif ($fee_name === '') {

                $error = "Please enter the fee name.";

            } elseif (!is_numeric($amount) || (float)$amount < 0) {

                $error = "Please enter a valid amount.";

            } elseif (
                $due_date !== '' &&
                !preg_match('/^\d{4}-\d{2}-\d{2}$/', $due_date)
            ) {

                $error = "Please enter a valid due date.";

            } elseif (!in_array($status, ['active', 'inactive'], true)) {

                $error = "Invalid status.";

            } else {

                $amount = (float)$amount;

                if ($due_date === '') {
                    $due_date = null;
                }

                $stmt = $conn->prepare("
                    INSERT INTO fee_structures
                    (
                        class_id,
                        academic_year,
                        term,
                        fee_name,
                        description,
                        amount,
                        due_date,
                        status,
                        created_by
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");

                if ($stmt) {

                    $stmt->bind_param(
                        "issssdssi",
                        $class_id,
                        $academic_year,
                        $term,
                        $fee_name,
                        $description,
                        $amount,
                        $due_date,
                        $status,
                        $created_by
                    );

                    if ($stmt->execute()) {

                        $success = "Fee structure added successfully.";

                    } else {

                        $error = "Unable to add fee structure: " . $stmt->error;
                    }

                    $stmt->close();

                } else {

                    $error = "Database error: " . $conn->error;
                }
            }
        }

        /*
        |--------------------------------------------------------------------------
        | UPDATE
        |--------------------------------------------------------------------------
        */
        elseif ($action === 'update') {

            $id = (int)($_POST['id'] ?? 0);
            $class_id = (int)($_POST['class_id'] ?? 0);
            $academic_year = trim($_POST['academic_year'] ?? '');
            $term = trim($_POST['term'] ?? '');
            $fee_name = trim($_POST['fee_name'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $amount = $_POST['amount'] ?? '';
            $due_date = trim($_POST['due_date'] ?? '');
            $status = trim($_POST['status'] ?? 'active');

            if ($id <= 0) {

                $error = "Invalid fee structure.";

            } elseif ($class_id <= 0) {

                $error = "Please select a class.";

            } elseif ($academic_year === '') {

                $error = "Please enter the academic year.";

            } elseif (!in_array($term, ['Term 1', 'Term 2', 'Term 3'], true)) {

                $error = "Please select a valid term.";

            } elseif ($fee_name === '') {

                $error = "Please enter the fee name.";

            } elseif (!is_numeric($amount) || (float)$amount < 0) {

                $error = "Please enter a valid amount.";

            } elseif (
                $due_date !== '' &&
                !preg_match('/^\d{4}-\d{2}-\d{2}$/', $due_date)
            ) {

                $error = "Please enter a valid due date.";

            } elseif (!in_array($status, ['active', 'inactive'], true)) {

                $error = "Invalid status.";

            } else {

                $amount = (float)$amount;

                if ($due_date === '') {
                    $due_date = null;
                }

                $stmt = $conn->prepare("
                    UPDATE fee_structures
                    SET
                        class_id = ?,
                        academic_year = ?,
                        term = ?,
                        fee_name = ?,
                        description = ?,
                        amount = ?,
                        due_date = ?,
                        status = ?
                    WHERE id = ?
                ");

                if ($stmt) {

                    $stmt->bind_param(
                        "issssdssi",
                        $class_id,
                        $academic_year,
                        $term,
                        $fee_name,
                        $description,
                        $amount,
                        $due_date,
                        $status,
                        $id
                    );

                    if ($stmt->execute()) {

                        $success = "Fee structure updated successfully.";

                    } else {

                        $error = "Unable to update fee structure: " . $stmt->error;
                    }

                    $stmt->close();

                } else {

                    $error = "Database error: " . $conn->error;
                }
            }
        }

        /*
        |--------------------------------------------------------------------------
        | DELETE
        |--------------------------------------------------------------------------
        */
        elseif ($action === 'delete') {

            $id = (int)($_POST['id'] ?? 0);

            if ($id <= 0) {

                $error = "Invalid fee structure.";

            } else {

                $stmt = $conn->prepare("
                    DELETE FROM fee_structures
                    WHERE id = ?
                ");

                if ($stmt) {

                    $stmt->bind_param("i", $id);

                    if ($stmt->execute()) {

                        $success = "Fee structure deleted successfully.";

                    } else {

                        $error = "Unable to delete fee structure: " . $stmt->error;
                    }

                    $stmt->close();

                } else {

                    $error = "Database error: " . $conn->error;
                }
            }
        }
    }
}

/*
|--------------------------------------------------------------------------
| FILTERS
|--------------------------------------------------------------------------
*/
$search = trim($_GET['search'] ?? '');
$filter_year = trim($_GET['academic_year'] ?? '');
$filter_term = trim($_GET['term'] ?? '');
$filter_class = (int)($_GET['class_id'] ?? 0);
$filter_status = trim($_GET['status'] ?? '');

/*
|--------------------------------------------------------------------------
| EDIT RECORD
|--------------------------------------------------------------------------
*/
$editFee = null;

if ($tableExists && isset($_GET['edit'])) {

    $editId = (int)$_GET['edit'];

    if ($editId > 0) {

        $stmt = $conn->prepare("
            SELECT
                id,
                class_id,
                academic_year,
                term,
                fee_name,
                description,
                amount,
                due_date,
                status,
                created_by,
                created_at,
                updated_at
            FROM fee_structures
            WHERE id = ?
            LIMIT 1
        ");

        if ($stmt) {

            $stmt->bind_param("i", $editId);
            $stmt->execute();

            $result = $stmt->get_result();

            if ($result && $result->num_rows === 1) {
                $editFee = $result->fetch_assoc();
            }

            $stmt->close();
        }
    }
}

/*
|--------------------------------------------------------------------------
| GET YEARS
|--------------------------------------------------------------------------
*/
$years = [];

if ($tableExists) {

    $result = $conn->query("
        SELECT DISTINCT academic_year
        FROM fee_structures
        ORDER BY academic_year DESC
    ");

    if ($result) {

        while ($row = $result->fetch_assoc()) {
            $years[] = $row['academic_year'];
        }
    }
}

/*
|--------------------------------------------------------------------------
| GET FEE STRUCTURES
|--------------------------------------------------------------------------
*/
$fees = [];

$totalRecords = 0;
$totalAmount = 0;
$activeCount = 0;
$inactiveCount = 0;

if ($tableExists) {

    $sql = "
        SELECT
            fs.id,
            fs.class_id,
            fs.academic_year,
            fs.term,
            fs.fee_name,
            fs.description,
            fs.amount,
            fs.due_date,
            fs.status,
            fs.created_by,
            fs.created_at
    ";

    /*
    |--------------------------------------------------------------------------
    | ADD CLASS NAME IF CLASS TABLE WAS FOUND
    |--------------------------------------------------------------------------
    */
    if ($classTable && $classColumn && $classDisplayColumn) {

        $safeClassTable = str_replace('`', '``', $classTable);
        $safeClassColumn = str_replace('`', '``', $classColumn);
        $safeDisplayColumn = str_replace('`', '``', $classDisplayColumn);

        $sql .= ",
            c.`$safeDisplayColumn` AS class_name
        ";

        $sql .= "
            FROM fee_structures fs
            LEFT JOIN `$safeClassTable` c
                ON fs.class_id = c.`$safeClassColumn`
        ";

    } else {

        $sql .= ",
            fs.class_id AS class_name
        ";

        $sql .= "
            FROM fee_structures fs
        ";
    }

    $sql .= " WHERE 1=1 ";

    $types = '';
    $params = [];

    /*
    |--------------------------------------------------------------------------
    | SEARCH
    |--------------------------------------------------------------------------
    */
    if ($search !== '') {

        $sql .= "
            AND (
                fs.fee_name LIKE ?
                OR fs.description LIKE ?
            )
        ";

        $searchValue = '%' . $search . '%';

        $types .= 'ss';

        $params[] = $searchValue;
        $params[] = $searchValue;
    }

    /*
    |--------------------------------------------------------------------------
    | YEAR
    |--------------------------------------------------------------------------
    */
    if ($filter_year !== '') {

        $sql .= " AND fs.academic_year = ? ";

        $types .= 's';
        $params[] = $filter_year;
    }

    /*
    |--------------------------------------------------------------------------
    | TERM
    |--------------------------------------------------------------------------
    */
    if ($filter_term !== '') {

        $sql .= " AND fs.term = ? ";

        $types .= 's';
        $params[] = $filter_term;
    }

    /*
    |--------------------------------------------------------------------------
    | CLASS
    |--------------------------------------------------------------------------
    */
    if ($filter_class > 0) {

        $sql .= " AND fs.class_id = ? ";

        $types .= 'i';
        $params[] = $filter_class;
    }

    /*
    |--------------------------------------------------------------------------
    | STATUS
    |--------------------------------------------------------------------------
    */
    if ($filter_status !== '') {

        $sql .= " AND fs.status = ? ";

        $types .= 's';
        $params[] = $filter_status;
    }

    $sql .= "
        ORDER BY
            fs.academic_year DESC,
            FIELD(fs.term, 'Term 1', 'Term 2', 'Term 3'),
            class_name ASC,
            fs.fee_name ASC
    ";

    $stmt = $conn->prepare($sql);

    if ($stmt) {

        if (!empty($params)) {

            $bind = [];
            $bind[] = $types;

            foreach ($params as $key => $value) {
                $bind[] = &$params[$key];
            }

            call_user_func_array(
                [$stmt, 'bind_param'],
                $bind
            );
        }

        $stmt->execute();

        $result = $stmt->get_result();

        if ($result) {

            while ($row = $result->fetch_assoc()) {

                $fees[] = $row;

                $totalRecords++;

                $totalAmount += (float)$row['amount'];

                if ($row['status'] === 'active') {
                    $activeCount++;
                } else {
                    $inactiveCount++;
                }
            }
        }

        $stmt->close();
    }
}

/*
|--------------------------------------------------------------------------
| FORM DEFAULTS
|--------------------------------------------------------------------------
*/
$formClassId = $editFee['class_id'] ?? '';
$formAcademicYear = $editFee['academic_year'] ?? date('Y');
$formTerm = $editFee['term'] ?? 'Term 1';
$formFeeName = $editFee['fee_name'] ?? '';
$formDescription = $editFee['description'] ?? '';
$formAmount = $editFee['amount'] ?? '';
$formDueDate = $editFee['due_date'] ?? '';
$formStatus = $editFee['status'] ?? 'active';

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Fee Structure | Bursar</title>

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
    >

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
    >

    <style>
        body {
            background: #f5f6fa;
            font-family: Arial, sans-serif;
            color: #343a40;
        }

        /* Shared Bursar sidebar: copied from students_fee_accounts.php */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            width: 250px;
            background: #212529;
            z-index: 1030;
            overflow-y: auto;
        }
        .sidebar-header {
            padding: 20px 15px;
            color: #fff;
            font-weight: 700;
            border-bottom: 1px solid rgba(255,255,255,.1);
        }
        .sidebar-menu { padding: 15px 10px; }
        .sidebar-section {
            color: #6c757d;
            font-size: 11px;
            text-transform: uppercase;
            padding: 12px 10px 6px;
        }
        .sidebar a {
            display: block;
            color: #ced4da;
            padding: 12px 15px;
            margin-bottom: 3px;
            text-decoration: none;
            border-radius: 6px;
            transition: background .2s ease, color .2s ease;
        }
        .sidebar a:hover { background: #343a40; color: #fff; }
        .sidebar a.active { background: #dc3545; color: #fff; }
        .sidebar i { width: 25px; text-align: center; margin-right: 5px; }

        /* Keep the existing Fee Structure page content, styled beside the shared sidebar. */
        .topbar {
            margin-left: 250px;
            background: #343a40;
            color: #fff;
            padding: 15px 25px;
        }
        .topbar h4 { margin: 0; font-weight: 600; }
        .container-fluid { padding-left: 0; padding-right: 0; }
        .container-fluid > .row { display: block; margin-left: 0; margin-right: 0; }
        .content {
            margin-left: 250px;
            width: calc(100% - 250px);
            max-width: calc(100% - 250px);
            flex: 0 0 calc(100% - 250px);
            padding: 25px;
        }
        .page-title { font-weight: 700; color: #343a40; }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 12px rgba(0,0,0,.06);
            margin-bottom: 20px;
        }
        .card-header { background: #fff; border-bottom: 1px solid #eee; font-weight: 600; }
        .summary-card { border-left: 4px solid #dc3545; }
        .summary-card.success { border-left-color: #28a745; }
        .summary-card.warning { border-left-color: #ffc107; }
        .summary-card.danger { border-left-color: #dc3545; }
        .summary-number { font-size: 24px; font-weight: 700; }
        .table th { background: #f8f9fa; white-space: nowrap; }
        .amount { font-weight: 600; white-space: nowrap; }
        .empty-state { padding: 50px 20px; text-align: center; color: #6c757d; }
        .badge-active { background: #28a745; color: #fff; }
        .badge-inactive { background: #6c757d; color: #fff; }
        .btn, .form-control, .custom-select { border-radius: 6px; }
        .page-title { margin-bottom: 5px; }

        @media (max-width: 991px) {
            .sidebar { width: 220px; }
            .topbar { margin-left: 220px; }
            .content {
                margin-left: 220px;
                width: calc(100% - 220px);
                max-width: calc(100% - 220px);
                flex: 0 0 calc(100% - 220px);
            }
        }
        @media (max-width: 767px) {
            .sidebar {
                position: relative;
                top: auto;
                left: auto;
                bottom: auto;
                width: 100%;
                height: auto;
                max-height: none;
            }
            .topbar { margin-left: 0; padding: 15px; }
            .content {
                margin-left: 0;
                width: 100%;
                max-width: 100%;
                flex: 0 0 100%;
                padding: 15px;
            }
            .table-responsive { font-size: 12px; }
        }
        @media print {
            .sidebar, .topbar, .no-print { display: none !important; }
            .content { margin: 0; width: 100%; max-width: 100%; padding: 0; }
            .card { box-shadow: none; }
        }
    </style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>

<body>
<button type="button" id="unifiedSidebarToggle" class="unified-sidebar-toggle" aria-label="Open navigation" aria-controls="sidebar" aria-expanded="false"><i class="fas fa-bars"></i></button>
<div id="unifiedSidebarOverlay" class="sidebar-overlay"></div>



<!-- TOP BAR -->

<div class="topbar">

    <div class="d-flex justify-content-between align-items-center">

        <h4>
            <i class="fas fa-money-check-alt mr-2"></i>
            Bursar Management
        </h4>

        <a
            href="index.php"
            class="btn btn-outline-light btn-sm"
        >
            <i class="fas fa-tachometer-alt mr-1"></i>
            Dashboard
        </a>

    </div>

</div>


<div class="container-fluid">

    <div class="row">


        <!-- SIDEBAR copied from students_fee_accounts.php -->

<div class="sidebar">

    <div class="sidebar-header">
    <i class="fas fa-university"></i>
    <span>Bursar</span>
</div>


    <div class="sidebar-menu">

        <a href="/admin/bursar/index.php">
            <i class="fas fa-tachometer-alt"></i>
            Dashboard
        </a>

        <div class="sidebar-section">
            Students & Fees
        </div>
        <a href="/admin/bursar/students_fees.php" >
            <i class="fas fa-file-invoice-dollar"></i>
            Student Fees
        </a>

        <a href="/admin/bursar/students_fee_accounts.php">
            <i class="fas fa-file-invoice-dollar"></i>
            Student Fee Accounts
        </a>

        <a href="/admin/bursar/fee_structure.php" class="active">
            <i class="fas fa-list-alt"></i>
            Fee Structure
        </a>

        <a href="/admin/bursar/payments.php">
            <i class="fas fa-money-bill-wave"></i>
            Receive Payment
        </a>

        <a href="/admin/bursar/outstanding_fees.php">
            <i class="fas fa-exclamation-circle"></i>
            Outstanding Fees
        </a>

        <div class="sidebar-section">
            Finance
        </div>

        <a href="/admin/bursar/income.php">
            <i class="fas fa-arrow-circle-down"></i>
            Income
        </a>

        <a href="/admin/bursar/expenses.php">
            <i class="fas fa-arrow-circle-up"></i>
            Expenses
        </a>

        <a href="/admin/bursar/suppliers.php">
            <i class="fas fa-truck"></i>
            Suppliers
        </a>

        <a href="/admin/bursar/supplier_payments.php">
            <i class="fas fa-hand-holding-usd"></i>
            Supplier Payments
        </a>

        <div class="sidebar-section">
            Payroll & Budget
        </div>

        <a href="/admin/bursar/salaries.php">
            <i class="fas fa-users"></i>
            Salaries
        </a>

        <a href="/admin/bursar/salary_payments.php">
            <i class="fas fa-money-check-alt"></i>
            Salary Payments
        </a>

        <a href="/admin/bursar/budgets.php">
            <i class="fas fa-chart-pie"></i>
            Budgets
        </a>

        <div class="sidebar-section">
            Reports
        </div>

        <a href="/admin/bursar/cashbook.php">
            <i class="fas fa-book"></i>
            Cashbook
        </a>

        <a href="/admin/bursar/financial_reports.php">
            <i class="fas fa-chart-line"></i>
            Financial Reports
        </a>

        <a href="/admin/bursar/income_report.php">
            <i class="fas fa-file-invoice"></i>
            Income Report
        </a>

        <a href="/admin/bursar/expense_report.php">
            <i class="fas fa-receipt"></i>
            Expense Report
        </a>

        <a href="/admin/bursar/fees_report.php">
            <i class="fas fa-file-alt"></i>
            Fees Report
        </a>

        <a href="/admin/bursar/profit_loss.php">
            <i class="fas fa-balance-scale"></i>
            Profit & Loss
        </a>

        <div class="sidebar-section">
            System
        </div>

        <a href="/admin/dashboard.php">
            <i class="fas fa-user-shield"></i>
            Admin Dashboard
        </a>

        <a href="/logout.php">
            <i class="fas fa-sign-out-alt"></i>
            Logout
        </a>

    </div>

</div>

<div class="col-md-9 col-lg-10 content">


            <div class="d-flex justify-content-between align-items-center mb-4">

                <div>

                    <h3 class="page-title mb-1">
                        Fee Structure
                    </h3>

                    <small class="text-muted">
                        Manage school fees by class, academic year and term.
                    </small>

                </div>

                <button
                    type="button"
                    class="btn btn-primary"
                    data-toggle="modal"
                    data-target="#addFeeModal"
                >

                    <i class="fas fa-plus mr-1"></i>
                    Add Fee

                </button>

            </div>


            <!-- MESSAGES -->

            <?php if ($success): ?>

                <div class="alert alert-success alert-dismissible fade show">

                    <i class="fas fa-check-circle mr-2"></i>

                    <?= e($success) ?>

                    <button
                        type="button"
                        class="close"
                        data-dismiss="alert"
                    >
                        &times;
                    </button>

                </div>

            <?php endif; ?>


            <?php if ($error): ?>

                <div class="alert alert-danger alert-dismissible fade show">

                    <i class="fas fa-exclamation-triangle mr-2"></i>

                    <?= e($error) ?>

                    <button
                        type="button"
                        class="close"
                        data-dismiss="alert"
                    >
                        &times;
                    </button>

                </div>

            <?php endif; ?>


            <?php if (!$tableExists): ?>

                <div class="alert alert-danger">

                    <strong>
                        Fee structure table not found.
                    </strong>

                    Please verify that the
                    <code>fee_structures</code>
                    table exists.

                </div>

            <?php else: ?>


                <!-- SUMMARY -->

                <div class="row">

                    <div class="col-md-3 mb-3">

                        <div class="card summary-card">

                            <div class="card-body">

                                <div class="text-muted">
                                    Fee Items
                                </div>

                                <div class="summary-number">
                                    <?= number_format($totalRecords) ?>
                                </div>

                            </div>

                        </div>

                    </div>


                    <div class="col-md-3 mb-3">

                        <div class="card summary-card success">

                            <div class="card-body">

                                <div class="text-muted">
                                    Active
                                </div>

                                <div class="summary-number text-success">
                                    <?= number_format($activeCount) ?>
                                </div>

                            </div>

                        </div>

                    </div>


                    <div class="col-md-3 mb-3">

                        <div class="card summary-card warning">

                            <div class="card-body">

                                <div class="text-muted">
                                    Inactive
                                </div>

                                <div class="summary-number text-warning">
                                    <?= number_format($inactiveCount) ?>
                                </div>

                            </div>

                        </div>

                    </div>


                    <div class="col-md-3 mb-3">

                        <div class="card summary-card danger">

                            <div class="card-body">

                                <div class="text-muted">
                                    Total Amount
                                </div>

                                <div class="summary-number">
                                    <?= money($totalAmount) ?>
                                </div>

                            </div>

                        </div>

                    </div>

                </div>


                <!-- EDIT FORM -->

                <?php if ($editFee): ?>

                    <div class="card">

                        <div class="card-header">

                            <i class="fas fa-edit mr-2"></i>

                            Edit Fee Structure

                        </div>

                        <div class="card-body">

                            <form method="POST">

                                <input
                                    type="hidden"
                                    name="csrf_token"
                                    value="<?= e($csrf_token) ?>"
                                >

                                <input
                                    type="hidden"
                                    name="action"
                                    value="update"
                                >

                                <input
                                    type="hidden"
                                    name="id"
                                    value="<?= (int)$editFee['id'] ?>"
                                >

                                <div class="row">


                                    <!-- CLASS -->

                                    <div class="col-md-4">

                                        <div class="form-group">

                                            <label>
                                                Class
                                                <span class="text-danger">*</span>
                                            </label>

                                            <?php if (!empty($classes)): ?>

                                                <select
                                                    name="class_id"
                                                    class="custom-select"
                                                    required
                                                >

                                                    <option value="">
                                                        Select Class
                                                    </option>

                                                    <?php foreach ($classes as $class): ?>

                                                        <option
                                                            value="<?= (int)$class['class_id'] ?>"
                                                            <?= (string)$formClassId === (string)$class['class_id'] ? 'selected' : '' ?>
                                                        >

                                                            <?= e($class['class_name']) ?>

                                                        </option>

                                                    <?php endforeach; ?>

                                                </select>

                                            <?php else: ?>

                                                <input
                                                    type="number"
                                                    name="class_id"
                                                    class="form-control"
                                                    value="<?= e($formClassId) ?>"
                                                    placeholder="Class ID"
                                                    required
                                                >

                                            <?php endif; ?>

                                        </div>

                                    </div>


                                    <!-- YEAR -->

                                    <div class="col-md-2">

                                        <div class="form-group">

                                            <label>
                                                Academic Year
                                            </label>

                                            <input
                                                type="text"
                                                name="academic_year"
                                                class="form-control"
                                                value="<?= e($formAcademicYear) ?>"
                                                required
                                            >

                                        </div>

                                    </div>


                                    <!-- TERM -->

                                    <div class="col-md-2">

                                        <div class="form-group">

                                            <label>
                                                Term
                                            </label>

                                            <select
                                                name="term"
                                                class="custom-select"
                                                required
                                            >

                                                <option
                                                    value="Term 1"
                                                    <?= $formTerm === 'Term 1' ? 'selected' : '' ?>
                                                >
                                                    Term 1
                                                </option>

                                                <option
                                                    value="Term 2"
                                                    <?= $formTerm === 'Term 2' ? 'selected' : '' ?>
                                                >
                                                    Term 2
                                                </option>

                                                <option
                                                    value="Term 3"
                                                    <?= $formTerm === 'Term 3' ? 'selected' : '' ?>
                                                >
                                                    Term 3
                                                </option>

                                            </select>

                                        </div>

                                    </div>


                                    <!-- AMOUNT -->

                                    <div class="col-md-2">

                                        <div class="form-group">

                                            <label>
                                                Amount
                                            </label>

                                            <input
                                                type="number"
                                                name="amount"
                                                class="form-control"
                                                min="0"
                                                step="0.01"
                                                value="<?= e($formAmount) ?>"
                                                required
                                            >

                                        </div>

                                    </div>


                                    <!-- DUE DATE -->

                                    <div class="col-md-2">

                                        <div class="form-group">

                                            <label>
                                                Due Date
                                            </label>

                                            <input
                                                type="date"
                                                name="due_date"
                                                class="form-control"
                                                value="<?= e($formDueDate) ?>"
                                            >

                                        </div>

                                    </div>


                                    <!-- FEE NAME -->

                                    <div class="col-md-4">

                                        <div class="form-group">

                                            <label>
                                                Fee Name
                                            </label>

                                            <input
                                                type="text"
                                                name="fee_name"
                                                class="form-control"
                                                value="<?= e($formFeeName) ?>"
                                                required
                                            >

                                        </div>

                                    </div>


                                    <!-- STATUS -->

                                    <div class="col-md-2">

                                        <div class="form-group">

                                            <label>
                                                Status
                                            </label>

                                            <select
                                                name="status"
                                                class="custom-select"
                                            >

                                                <option
                                                    value="active"
                                                    <?= $formStatus === 'active' ? 'selected' : '' ?>
                                                >
                                                    Active
                                                </option>

                                                <option
                                                    value="inactive"
                                                    <?= $formStatus === 'inactive' ? 'selected' : '' ?>
                                                >
                                                    Inactive
                                                </option>

                                            </select>

                                        </div>

                                    </div>


                                    <!-- DESCRIPTION -->

                                    <div class="col-md-6">

                                        <div class="form-group">

                                            <label>
                                                Description
                                            </label>

                                            <textarea
                                                name="description"
                                                class="form-control"
                                                rows="2"
                                            ><?= e($formDescription) ?></textarea>

                                        </div>

                                    </div>


                                    <div class="col-md-12">

                                        <button
                                            type="submit"
                                            class="btn btn-success"
                                        >

                                            <i class="fas fa-save mr-1"></i>

                                            Update Fee

                                        </button>

                                        <a
                                            href="fee_structure.php"
                                            class="btn btn-secondary"
                                        >

                                            Cancel

                                        </a>

                                    </div>

                                </div>

                            </form>

                        </div>

                    </div>

                <?php endif; ?>


                <!-- FILTERS -->

                <div class="card">

                    <div class="card-header">

                        <i class="fas fa-filter mr-2"></i>

                        Filter Fee Structure

                    </div>

                    <div class="card-body">

                        <form method="GET">

                            <div class="row">

                                <div class="col-md-3">

                                    <label>Search</label>

                                    <input
                                        type="text"
                                        name="search"
                                        class="form-control"
                                        placeholder="Fee name or description"
                                        value="<?= e($search) ?>"
                                    >

                                </div>


                                <div class="col-md-2">

                                    <label>Academic Year</label>

                                    <select
                                        name="academic_year"
                                        class="custom-select"
                                    >

                                        <option value="">
                                            All Years
                                        </option>

                                        <?php foreach ($years as $year): ?>

                                            <option
                                                value="<?= e($year) ?>"
                                                <?= $filter_year === $year ? 'selected' : '' ?>
                                            >

                                                <?= e($year) ?>

                                            </option>

                                        <?php endforeach; ?>

                                    </select>

                                </div>


                                <div class="col-md-2">

                                    <label>Term</label>

                                    <select
                                        name="term"
                                        class="custom-select"
                                    >

                                        <option value="">
                                            All Terms
                                        </option>

                                        <option
                                            value="Term 1"
                                            <?= $filter_term === 'Term 1' ? 'selected' : '' ?>
                                        >
                                            Term 1
                                        </option>

                                        <option
                                            value="Term 2"
                                            <?= $filter_term === 'Term 2' ? 'selected' : '' ?>
                                        >
                                            Term 2
                                        </option>

                                        <option
                                            value="Term 3"
                                            <?= $filter_term === 'Term 3' ? 'selected' : '' ?>
                                        >
                                            Term 3
                                        </option>

                                    </select>

                                </div>


                                <div class="col-md-2">

                                    <label>Class</label>

                                    <select
                                        name="class_id"
                                        class="custom-select"
                                    >

                                        <option value="">
                                            All Classes
                                        </option>

                                        <?php foreach ($classes as $class): ?>

                                            <option
                                                value="<?= (int)$class['class_id'] ?>"
                                                <?= $filter_class === (int)$class['class_id'] ? 'selected' : '' ?>
                                            >

                                                <?= e($class['class_name']) ?>

                                            </option>

                                        <?php endforeach; ?>

                                    </select>

                                </div>


                                <div class="col-md-2">

                                    <label>Status</label>

                                    <select
                                        name="status"
                                        class="custom-select"
                                    >

                                        <option value="">
                                            All
                                        </option>

                                        <option
                                            value="active"
                                            <?= $filter_status === 'active' ? 'selected' : '' ?>
                                        >
                                            Active
                                        </option>

                                        <option
                                            value="inactive"
                                            <?= $filter_status === 'inactive' ? 'selected' : '' ?>
                                        >
                                            Inactive
                                        </option>

                                    </select>

                                </div>


                                <div class="col-md-1">

                                    <label>&nbsp;</label>

                                    <button
                                        type="submit"
                                        class="btn btn-primary btn-block"
                                    >

                                        <i class="fas fa-search"></i>

                                    </button>

                                </div>

                            </div>

                        </form>

                    </div>

                </div>


                <!-- FEE TABLE -->

                <div class="card">

                    <div class="card-header d-flex justify-content-between">

                        <span>

                            <i class="fas fa-list-alt mr-2"></i>

                            Fee Structure

                        </span>

                        <span class="badge badge-primary">

                            <?= number_format($totalRecords) ?>

                        </span>

                    </div>


                    <div class="card-body p-0">

                        <?php if (empty($fees)): ?>

                            <div class="empty-state">

                                <i class="fas fa-file-invoice-dollar fa-3x mb-3"></i>

                                <h5>
                                    No Fee Structure Found
                                </h5>

                                <p>
                                    Add a fee structure for a class to get started.
                                </p>

                            </div>

                        <?php else: ?>

                            <div class="table-responsive">

                                <table class="table table-hover mb-0">

                                    <thead>

                                        <tr>

                                            <th>#</th>
                                            <th>Class</th>
                                            <th>Academic Year</th>
                                            <th>Term</th>
                                            <th>Fee Name</th>
                                            <th>Amount</th>
                                            <th>Due Date</th>
                                            <th>Status</th>
                                            <th>Actions</th>

                                        </tr>

                                    </thead>

                                    <tbody>

                                        <?php $number = 1; ?>

                                        <?php foreach ($fees as $fee): ?>

                                            <tr>

                                                <td>
                                                    <?= $number++ ?>
                                                </td>

                                                <td>

                                                    <strong>
                                                        <?= e($fee['class_name']) ?>
                                                    </strong>

                                                </td>

                                                <td>
                                                    <?= e($fee['academic_year']) ?>
                                                </td>

                                                <td>

                                                    <span class="badge badge-info">

                                                        <?= e($fee['term']) ?>

                                                    </span>

                                                </td>

                                                <td>

                                                    <strong>
                                                        <?= e($fee['fee_name']) ?>
                                                    </strong>

                                                    <?php if (!empty($fee['description'])): ?>

                                                        <br>

                                                        <small class="text-muted">

                                                            <?= e($fee['description']) ?>

                                                        </small>

                                                    <?php endif; ?>

                                                </td>

                                                <td class="amount">

                                                    <?= money($fee['amount']) ?>

                                                </td>

                                                <td>

                                                    <?php if (!empty($fee['due_date'])): ?>

                                                        <?= e(date(
                                                            'd M Y',
                                                            strtotime($fee['due_date'])
                                                        )) ?>

                                                    <?php else: ?>

                                                        <span class="text-muted">
                                                            Not set
                                                        </span>

                                                    <?php endif; ?>

                                                </td>

                                                <td>

                                                    <?php if ($fee['status'] === 'active'): ?>

                                                        <span class="badge badge-active">
                                                            Active
                                                        </span>

                                                    <?php else: ?>

                                                        <span class="badge badge-inactive">
                                                            Inactive
                                                        </span>

                                                    <?php endif; ?>

                                                </td>

                                                <td class="text-nowrap">

                                                    <a
                                                        href="fee_structure.php?edit=<?= (int)$fee['id'] ?>"
                                                        class="btn btn-sm btn-outline-primary"
                                                        title="Edit"
                                                    >

                                                        <i class="fas fa-edit"></i>

                                                    </a>


                                                    <form
                                                        method="POST"
                                                        style="display:inline;"
                                                        onsubmit="return confirm('Are you sure you want to delete this fee structure?');"
                                                    >

                                                        <input
                                                            type="hidden"
                                                            name="csrf_token"
                                                            value="<?= e($csrf_token) ?>"
                                                        >

                                                        <input
                                                            type="hidden"
                                                            name="action"
                                                            value="delete"
                                                        >

                                                        <input
                                                            type="hidden"
                                                            name="id"
                                                            value="<?= (int)$fee['id'] ?>"
                                                        >

                                                        <button
                                                            type="submit"
                                                            class="btn btn-sm btn-outline-danger"
                                                            title="Delete"
                                                        >

                                                            <i class="fas fa-trash"></i>

                                                        </button>

                                                    </form>

                                                </td>

                                            </tr>

                                        <?php endforeach; ?>

                                    </tbody>


                                    <tfoot>

                                        <tr class="font-weight-bold">

                                            <td
                                                colspan="5"
                                                class="text-right"
                                            >
                                                Total:
                                            </td>

                                            <td>

                                                <?= money($totalAmount) ?>

                                            </td>

                                            <td colspan="3"></td>

                                        </tr>

                                    </tfoot>

                                </table>

                            </div>

                        <?php endif; ?>

                    </div>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>


<!-- ADD FEE MODAL -->

<div
    class="modal fade"
    id="addFeeModal"
    tabindex="-1"
>

    <div class="modal-dialog modal-lg">

        <div class="modal-content">

            <form method="POST">

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e($csrf_token) ?>"
                >

                <input
                    type="hidden"
                    name="action"
                    value="add"
                >


                <div class="modal-header">

                    <h5 class="modal-title">

                        <i class="fas fa-plus-circle mr-2"></i>

                        Add Fee Structure

                    </h5>

                    <button
                        type="button"
                        class="close"
                        data-dismiss="modal"
                    >

                        <span>&times;</span>

                    </button>

                </div>


                <div class="modal-body">

                    <div class="row">


                        <!-- CLASS -->

                        <div class="col-md-6">

                            <div class="form-group">

                                <label>
                                    Class
                                    <span class="text-danger">*</span>
                                </label>

                                <?php if (!empty($classes)): ?>

                                    <select
                                        name="class_id"
                                        class="custom-select"
                                        required
                                    >

                                        <option value="">
                                            Select Class
                                        </option>

                                        <?php foreach ($classes as $class): ?>

                                            <option
                                                value="<?= (int)$class['class_id'] ?>"
                                            >

                                                <?= e($class['class_name']) ?>

                                            </option>

                                        <?php endforeach; ?>

                                    </select>

                                <?php else: ?>

                                    <input
                                        type="number"
                                        name="class_id"
                                        class="form-control"
                                        placeholder="Enter Class ID"
                                        required
                                    >

                                    <small class="text-muted">
                                        Class table could not be automatically detected.
                                    </small>

                                <?php endif; ?>

                            </div>

                        </div>


                        <!-- YEAR -->

                        <div class="col-md-3">

                            <div class="form-group">

                                <label>
                                    Academic Year
                                </label>

                                <input
                                    type="text"
                                    name="academic_year"
                                    class="form-control"
                                    value="<?= date('Y') ?>"
                                    required
                                >

                            </div>

                        </div>


                        <!-- TERM -->

                        <div class="col-md-3">

                            <div class="form-group">

                                <label>
                                    Term
                                </label>

                                <select
                                    name="term"
                                    class="custom-select"
                                    required
                                >

                                    <option value="Term 1">
                                        Term 1
                                    </option>

                                    <option value="Term 2">
                                        Term 2
                                    </option>

                                    <option value="Term 3">
                                        Term 3
                                    </option>

                                </select>

                            </div>

                        </div>


                        <!-- FEE NAME -->

                        <div class="col-md-6">

                            <div class="form-group">

                                <label>
                                    Fee Name
                                    <span class="text-danger">*</span>
                                </label>

                                <input
                                    type="text"
                                    name="fee_name"
                                    class="form-control"
                                    placeholder="e.g. Tuition Fees"
                                    required
                                >

                            </div>

                        </div>


                        <!-- AMOUNT -->

                        <div class="col-md-3">

                            <div class="form-group">

                                <label>
                                    Amount
                                    <span class="text-danger">*</span>
                                </label>

                                <input
                                    type="number"
                                    name="amount"
                                    class="form-control"
                                    min="0"
                                    step="0.01"
                                    placeholder="0.00"
                                    required
                                >

                            </div>

                        </div>


                        <!-- DUE DATE -->

                        <div class="col-md-3">

                            <div class="form-group">

                                <label>
                                    Due Date
                                </label>

                                <input
                                    type="date"
                                    name="due_date"
                                    class="form-control"
                                >

                            </div>

                        </div>


                        <!-- STATUS -->

                        <div class="col-md-4">

                            <div class="form-group">

                                <label>
                                    Status
                                </label>

                                <select
                                    name="status"
                                    class="custom-select"
                                >

                                    <option value="active">
                                        Active
                                    </option>

                                    <option value="inactive">
                                        Inactive
                                    </option>

                                </select>

                            </div>

                        </div>


                        <!-- DESCRIPTION -->

                        <div class="col-md-8">

                            <div class="form-group">

                                <label>
                                    Description
                                </label>

                                <textarea
                                    name="description"
                                    class="form-control"
                                    rows="2"
                                    placeholder="Optional description"
                                ></textarea>

                            </div>

                        </div>

                    </div>

                </div>


                <div class="modal-footer">

                    <button
                        type="button"
                        class="btn btn-secondary"
                        data-dismiss="modal"
                    >
                        Cancel
                    </button>

                    <button
                        type="submit"
                        class="btn btn-primary"
                    >

                        <i class="fas fa-save mr-1"></i>

                        Save Fee Structure

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>


<script src="/assets/js/sidebar-unified.js?v=20261106"></script>
</body>
</html>
