<?php
/**
 * School Management System - Bursar Student Payments
 * Compatible with either:
 *  - student_fee_account_id / notes payment schema, or
 *  - account_id / description payment schema.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator', 'bursar']);

$conn->set_charset('utf8mb4');
$userId = (int)($_SESSION['user_id'] ?? $_SESSION['id'] ?? 0);

if (empty($_SESSION['payments_csrf'])) {
    $_SESSION['payments_csrf'] = bin2hex(random_bytes(32));
}

function e($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function flashRedirect(string $message, string $type = 'success', array $query = []): void
{
    $_SESSION['payments_flash'] = ['message' => $message, 'type' => $type];
    $url = 'payments.php';
    if ($query) {
        $url .= '?' . http_build_query($query);
    }
    header('Location: ' . $url);
    exit;
}

function getColumns(mysqli $conn, string $table): array
{
    $out = [];
    $result = $conn->query("SHOW COLUMNS FROM `" . str_replace('`', '', $table) . "`");
    while ($row = $result->fetch_assoc()) {
        $out[$row['Field']] = $row;
    }
    return $out;
}

function tableExists(mysqli $conn, string $table): bool
{
    // Only internal table names are passed to this helper.
    $safe = $conn->real_escape_string($table);
    $result = $conn->query("SHOW TABLES LIKE '{$safe}'");
    return $result && $result->num_rows > 0;
}

function bindDynamic(mysqli_stmt $stmt, string $types, array &$params): void
{
    if ($types === '') {
        return;
    }
    $bind = [$types];
    foreach ($params as $key => &$value) {
        $bind[] = &$value;
    }
    call_user_func_array([$stmt, 'bind_param'], $bind);
}

function enumValues(?string $type): array
{
    if (!$type || stripos($type, 'enum(') !== 0) {
        return [];
    }
    preg_match_all("/'((?:[^'\\\\]|\\\\.)*)'/", $type, $matches);
    return array_map(static function ($v) {
        return stripcslashes($v);
    }, $matches[1] ?? []);
}

function enumChoice(?array $column, array $preferred, string $fallback): string
{
    if (!$column) {
        return $fallback;
    }
    $choices = enumValues($column['Type'] ?? null);
    if (!$choices) {
        return $fallback;
    }
    foreach ($preferred as $candidate) {
        if (in_array($candidate, $choices, true)) {
            return $candidate;
        }
    }
    return $choices[0];
}

function makeReceiptNumber(mysqli $conn, array $paymentColumns): string
{
    do {
        $receipt = 'RCP-' . date('YmdHis') . '-' . random_int(1000, 9999);
        if (!isset($paymentColumns['receipt_no'])) {
            return $receipt;
        }
        $stmt = $conn->prepare('SELECT id FROM fee_payments WHERE receipt_no = ? LIMIT 1');
        $stmt->bind_param('s', $receipt);
        $stmt->execute();
        $exists = $stmt->get_result()->num_rows > 0;
        $stmt->close();
    } while ($exists);
    return $receipt;
}

function parsePaymentDate(string $value): ?string
{
    $formats = ['!Y-m-d\\TH:i', '!Y-m-d H:i:s', '!Y-m-d H:i', '!Y-m-d'];
    foreach ($formats as $format) {
        $date = DateTime::createFromFormat($format, $value);
        $errors = DateTime::getLastErrors();
        if ($date && ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0))) {
            return $date->format('Y-m-d H:i:s');
        }
    }
    $timestamp = strtotime($value);
    return $timestamp === false ? null : date('Y-m-d H:i:s', $timestamp);
}

function accountStatus(array $accountColumns, float $newPaid, float $newBalance): ?string
{
    if (!isset($accountColumns['status'])) {
        return null;
    }
    if ($newBalance <= 0.00001) {
        return enumChoice($accountColumns['status'], ['paid'], 'paid');
    }
    if ($newPaid > 0) {
        return enumChoice($accountColumns['status'], ['partially_paid', 'partial'], 'partially_paid');
    }
    return enumChoice($accountColumns['status'], ['pending'], 'pending');
}

/* ---------- Check tables and adapt to the installed schema ---------- */
$schemaError = '';
$students = [];
$accounts = [];
$paymentMethods = [];
$payments = [];
$studentColumns = $accountColumns = $paymentColumns = $methodColumns = [];
$accountLinkColumn = '';
$paidColumns = [];
$primaryPaidColumn = '';
$yearJoin = '';
$termJoin = '';
$yearExpr = "''";
$termExpr = "''";

try {
    foreach (['students', 'student_fee_accounts', 'fee_payments', 'payment_methods'] as $table) {
        if (!tableExists($conn, $table)) {
            throw new RuntimeException("Required database table '{$table}' does not exist.");
        }
    }

    $studentColumns = getColumns($conn, 'students');
    $accountColumns = getColumns($conn, 'student_fee_accounts');
    $paymentColumns = getColumns($conn, 'fee_payments');
    $methodColumns = getColumns($conn, 'payment_methods');

    foreach (['id', 'first_name', 'last_name'] as $col) {
        if (!isset($studentColumns[$col])) {
            throw new RuntimeException("The students table is missing the '{$col}' column.");
        }
    }
    if (!isset($accountColumns['id'], $accountColumns['student_id'], $accountColumns['total_amount'])) {
        throw new RuntimeException('The student_fee_accounts table must contain id, student_id and total_amount columns.');
    }

    $paidColumns = array_values(array_filter(['amount_paid', 'total_paid'], static fn($c) => isset($accountColumns[$c])));
    if (!$paidColumns) {
        throw new RuntimeException('The student_fee_accounts table needs an amount_paid or total_paid column to track payments.');
    }
    $primaryPaidColumn = in_array('amount_paid', $paidColumns, true) ? 'amount_paid' : 'total_paid';

    if (isset($paymentColumns['student_fee_account_id'])) {
        $accountLinkColumn = 'student_fee_account_id';
    } elseif (isset($paymentColumns['account_id'])) {
        $accountLinkColumn = 'account_id';
    }
    if ($accountLinkColumn === '') {
        throw new RuntimeException('The fee_payments table must contain student_fee_account_id or account_id.');
    }
    foreach (['amount', 'payment_date', 'payment_method_id'] as $col) {
        if (!isset($paymentColumns[$col])) {
            throw new RuntimeException("The fee_payments table is missing the '{$col}' column.");
        }
    }

    /* Resolve year and term labels for either direct text columns or foreign keys. */
    if (isset($accountColumns['academic_year'])) {
        $yearExpr = "COALESCE(CAST(sfa.academic_year AS CHAR), '')";
    } elseif (isset($accountColumns['academic_year_id'])) {
        if (tableExists($conn, 'academic_years')) {
            $yearCols = getColumns($conn, 'academic_years');
            if (isset($yearCols['id'], $yearCols['year_name'])) {
                $yearJoin = ' LEFT JOIN academic_years ay ON ay.id = sfa.academic_year_id ';
                $yearExpr = "COALESCE(ay.year_name, CAST(sfa.academic_year_id AS CHAR), '')";
            } else {
                $yearExpr = "CAST(sfa.academic_year_id AS CHAR)";
            }
        } else {
            $yearExpr = "CAST(sfa.academic_year_id AS CHAR)";
        }
    }

    if (isset($accountColumns['term'])) {
        $termExpr = "COALESCE(CAST(sfa.term AS CHAR), '')";
    } elseif (isset($accountColumns['term_id'])) {
        if (tableExists($conn, 'terms')) {
            $termCols = getColumns($conn, 'terms');
            if (isset($termCols['id'], $termCols['term_name'])) {
                $termJoin = ' LEFT JOIN terms t ON t.id = sfa.term_id ';
                $termExpr = "COALESCE(t.term_name, CAST(sfa.term_id AS CHAR), '')";
            } else {
                $termExpr = "CAST(sfa.term_id AS CHAR)";
            }
        } else {
            $termExpr = "CAST(sfa.term_id AS CHAR)";
        }
    }

} catch (Throwable $ex) {
    $schemaError = $ex->getMessage();
    error_log('Payments page schema error: ' . $ex->getMessage());
}

/* ---------- POST actions ---------- */
if ($schemaError === '' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = (string)($_POST['csrf_token'] ?? '');
    if (!hash_equals((string)$_SESSION['payments_csrf'], $token)) {
        flashRedirect('Your form session has expired. Refresh the page and try again.', 'danger');
    }

    $action = (string)($_POST['action'] ?? '');

    try {
        if ($action === 'record_payment') {
            $accountId = filter_var($_POST['account_id'] ?? 0, FILTER_VALIDATE_INT) ?: 0;
            $methodId = filter_var($_POST['payment_method_id'] ?? 0, FILTER_VALIDATE_INT) ?: 0;
            $amountInput = trim((string)($_POST['amount'] ?? ''));
            $dateInput = trim((string)($_POST['payment_date'] ?? ''));
            $reference = trim((string)($_POST['reference_no'] ?? ''));
            $description = trim((string)($_POST['description'] ?? ''));

            if ($accountId < 1 || $methodId < 1) {
                throw new RuntimeException('Select a valid student fee account and payment method.');
            }
            if ($amountInput === '' || !is_numeric($amountInput) || (float)$amountInput <= 0) {
                throw new RuntimeException('Enter a payment amount greater than zero.');
            }
            $amount = round((float)$amountInput, 2);
            if ($amount > 999999999999.99) {
                throw new RuntimeException('The payment amount is too large.');
            }
            $paymentDateDb = parsePaymentDate($dateInput);
            if ($paymentDateDb === null) {
                throw new RuntimeException('Enter a valid payment date and time.');
            }

            $methodStmt = $conn->prepare('SELECT id FROM payment_methods WHERE id = ? AND status = \'active\' LIMIT 1');
            $methodStmt->bind_param('i', $methodId);
            $methodStmt->execute();
            $methodExists = $methodStmt->get_result()->num_rows > 0;
            $methodStmt->close();
            if (!$methodExists) {
                throw new RuntimeException('The selected payment method is inactive or does not exist.');
            }

            $discountExpr = isset($accountColumns['discount_amount']) ? 'COALESCE(discount_amount, 0)' : '0';
            $paidExpr = 'COALESCE(`' . $primaryPaidColumn . '`, 0)';
            $stmt = $conn->prepare("SELECT id, student_id, COALESCE(total_amount,0) AS total_amount, {$paidExpr} AS paid_amount, {$discountExpr} AS discount_amount FROM student_fee_accounts WHERE id = ? LIMIT 1 FOR UPDATE");

            $conn->begin_transaction();
            $stmt->bind_param('i', $accountId);
            $stmt->execute();
            $account = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$account) {
                throw new RuntimeException('The selected fee account was not found.');
            }

            $studentId = (int)$account['student_id'];
            $totalAmount = max(0, (float)$account['total_amount']);
            $oldPaid = max(0, (float)$account['paid_amount']);
            $discount = max(0, (float)$account['discount_amount']);
            $balance = max(0, $totalAmount - $discount - $oldPaid);

            if ($balance <= 0.00001) {
                throw new RuntimeException('This fee account has no outstanding balance.');
            }
            if ($amount > $balance + 0.00001) {
                throw new RuntimeException('Payment exceeds the outstanding balance of UGX ' . number_format($balance, 2) . '.');
            }

            $receipt = makeReceiptNumber($conn, $paymentColumns);
            $completedStatus = enumChoice($paymentColumns['status'] ?? null, ['completed', 'complete'], 'completed');

            /* Build INSERT from columns that actually exist in this database. */
            $insertValues = [];
            if (isset($paymentColumns['receipt_no'])) $insertValues['receipt_no'] = $receipt;
            if (isset($paymentColumns['student_fee_account_id'])) $insertValues['student_fee_account_id'] = $accountId;
            if (isset($paymentColumns['account_id'])) $insertValues['account_id'] = $accountId;
            if (isset($paymentColumns['student_id'])) $insertValues['student_id'] = $studentId;
            if (isset($paymentColumns['payment_method_id'])) $insertValues['payment_method_id'] = $methodId;
            if (isset($paymentColumns['amount'])) $insertValues['amount'] = $amount;
            if (isset($paymentColumns['payment_date'])) $insertValues['payment_date'] = $paymentDateDb;
            if (isset($paymentColumns['reference_no'])) $insertValues['reference_no'] = ($reference === '' ? null : $reference);
            if (isset($paymentColumns['description'])) $insertValues['description'] = ($description === '' ? null : $description);
            if (isset($paymentColumns['notes'])) $insertValues['notes'] = ($description === '' ? null : $description);
            if (isset($paymentColumns['received_by'])) $insertValues['received_by'] = ($userId > 0 ? $userId : null);
            if (isset($paymentColumns['status'])) $insertValues['status'] = $completedStatus;
            if (isset($paymentColumns['payer_name'])) {
                $nameStmt = $conn->prepare('SELECT CONCAT(first_name, \' \', last_name) AS full_name FROM students WHERE id = ? LIMIT 1');
                $nameStmt->bind_param('i', $studentId);
                $nameStmt->execute();
                $insertValues['payer_name'] = $nameStmt->get_result()->fetch_assoc()['full_name'] ?? null;
                $nameStmt->close();
            }

            $columnsSql = implode(', ', array_map(static fn($c) => '`' . str_replace('`', '', $c) . '`', array_keys($insertValues)));
            $placeholders = implode(', ', array_fill(0, count($insertValues), '?'));
            $insertSql = 'INSERT INTO fee_payments (' . $columnsSql . ') VALUES (' . $placeholders . ')';
            $insertStmt = $conn->prepare($insertSql);
            $insertParams = array_values($insertValues);
            $insertTypes = '';
            foreach ($insertParams as $value) {
                if (is_int($value)) $insertTypes .= 'i';
                elseif (is_float($value)) $insertTypes .= 'd';
                else $insertTypes .= 's';
            }
            bindDynamic($insertStmt, $insertTypes, $insertParams);
            $insertStmt->execute();
            $insertStmt->close();

            $newPaid = $oldPaid + $amount;
            $newBalance = max(0, $totalAmount - $discount - $newPaid);
            $newStatus = accountStatus($accountColumns, $newPaid, $newBalance);
            $sets = [];
            $updateParams = [];
            $updateTypes = '';
            foreach ($paidColumns as $paidCol) {
                $sets[] = '`' . $paidCol . '` = ?';
                $updateParams[] = $newPaid;
                $updateTypes .= 'd';
            }
            if (isset($accountColumns['balance'])) {
                $sets[] = '`balance` = ?';
                $updateParams[] = $newBalance;
                $updateTypes .= 'd';
            }
            if (isset($accountColumns['status']) && $newStatus !== null) {
                $sets[] = '`status` = ?';
                $updateParams[] = $newStatus;
                $updateTypes .= 's';
            }
            if ($sets) {
                $updateSql = 'UPDATE student_fee_accounts SET ' . implode(', ', $sets) . ' WHERE id = ?';
                $updateParams[] = $accountId;
                $updateTypes .= 'i';
                $updateStmt = $conn->prepare($updateSql);
                bindDynamic($updateStmt, $updateTypes, $updateParams);
                $updateStmt->execute();
                $updateStmt->close();
            }

            $conn->commit();
            flashRedirect('Payment recorded successfully. Receipt: ' . $receipt . '. Remaining balance: UGX ' . number_format($newBalance, 2) . '.', 'success', ['account_id' => $accountId]);
        }

        if ($action === 'reverse_payment') {
            $paymentId = filter_var($_POST['payment_id'] ?? 0, FILTER_VALIDATE_INT) ?: 0;
            if ($paymentId < 1) {
                throw new RuntimeException('Select a valid payment to reverse.');
            }

            $selectFields = ['id', '`' . $accountLinkColumn . '` AS linked_account_id', '`amount`', '`status`'];
            $stmt = $conn->prepare('SELECT ' . implode(', ', $selectFields) . ' FROM fee_payments WHERE id = ? LIMIT 1 FOR UPDATE');
            $conn->begin_transaction();
            $stmt->bind_param('i', $paymentId);
            $stmt->execute();
            $payment = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if (!$payment) throw new RuntimeException('Payment record not found.');
            if (($payment['status'] ?? '') !== 'completed' && ($payment['status'] ?? '') !== 'complete') {
                throw new RuntimeException('Only completed payments can be reversed.');
            }

            $accountId = (int)$payment['linked_account_id'];
            $paidExpr = 'COALESCE(`' . $primaryPaidColumn . '`, 0)';
            $discountExpr = isset($accountColumns['discount_amount']) ? 'COALESCE(discount_amount, 0)' : '0';
            $stmt = $conn->prepare("SELECT id, COALESCE(total_amount,0) AS total_amount, {$paidExpr} AS paid_amount, {$discountExpr} AS discount_amount FROM student_fee_accounts WHERE id = ? LIMIT 1 FOR UPDATE");
            $stmt->bind_param('i', $accountId);
            $stmt->execute();
            $account = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if (!$account) throw new RuntimeException('The related student fee account was not found.');

            $newPaid = max(0, (float)$account['paid_amount'] - (float)$payment['amount']);
            $newBalance = max(0, (float)$account['total_amount'] - (float)$account['discount_amount'] - $newPaid);
            $newAccountStatus = accountStatus($accountColumns, $newPaid, $newBalance);

            $paymentStatusChoices = enumValues($paymentColumns['status']['Type'] ?? null);
            $reversalChoices = ['cancelled', 'refunded', 'reversed'];
            if ($paymentStatusChoices && !array_intersect($reversalChoices, $paymentStatusChoices)) {
                throw new RuntimeException('The fee_payments status column does not allow a reversal/cancellation status. No changes were made.');
            }
            $paymentStatus = enumChoice($paymentColumns['status'] ?? null, $reversalChoices, 'cancelled');
            if (isset($paymentColumns['status'])) {
                $stmt = $conn->prepare('UPDATE fee_payments SET status = ? WHERE id = ?');
                $stmt->bind_param('si', $paymentStatus, $paymentId);
                $stmt->execute();
                $stmt->close();
            } else {
                throw new RuntimeException('Payment status cannot be updated in this database, so the payment was not reversed.');
            }

            $sets = [];
            $params = [];
            $types = '';
            foreach ($paidColumns as $paidCol) {
                $sets[] = '`' . $paidCol . '` = ?';
                $params[] = $newPaid;
                $types .= 'd';
            }
            if (isset($accountColumns['balance'])) {
                $sets[] = '`balance` = ?';
                $params[] = $newBalance;
                $types .= 'd';
            }
            if (isset($accountColumns['status']) && $newAccountStatus !== null) {
                $sets[] = '`status` = ?';
                $params[] = $newAccountStatus;
                $types .= 's';
            }
            $params[] = $accountId;
            $types .= 'i';
            $stmt = $conn->prepare('UPDATE student_fee_accounts SET ' . implode(', ', $sets) . ' WHERE id = ?');
            bindDynamic($stmt, $types, $params);
            $stmt->execute();
            $stmt->close();
            $conn->commit();
            flashRedirect('Payment marked ' . $paymentStatus . '. The fee-account balance has been recalculated.');
        }

        throw new RuntimeException('Invalid form submission.');
    } catch (Throwable $ex) {
        try { $conn->rollback(); } catch (Throwable $ignored) {}
        error_log('Student payment action failed: ' . $ex->getMessage());
        flashRedirect('Payment was not saved: ' . $ex->getMessage(), 'danger', isset($_POST['account_id']) ? ['account_id' => (int)$_POST['account_id']] : []);
    }
}

/* ---------- Load records for the page ---------- */
$flash = $_SESSION['payments_flash'] ?? null;
unset($_SESSION['payments_flash']);
$message = is_array($flash) ? ($flash['message'] ?? '') : '';
$messageType = is_array($flash) ? ($flash['type'] ?? 'success') : 'success';

$search = trim((string)($_GET['search'] ?? ''));
$statusFilter = trim((string)($_GET['status'] ?? ''));
$prefillAccountId = (int)($_GET['account_id'] ?? 0);

try {
    if ($schemaError === '') {
        $studentResult = $conn->query(
            'SELECT id, ' .
            (isset($studentColumns['admission_no']) ? 'admission_no' : "'' AS admission_no") . ', ' .
            (isset($studentColumns['lin_no']) ? 'lin_no' : "'' AS lin_no") . ', ' .
            (isset($studentColumns['student_payment_code']) ? 'student_payment_code' : "'' AS student_payment_code") . ', ' .
            (isset($studentColumns['student_section']) ? 'student_section' : "'Day' AS student_section") . ', ' .
            'first_name, last_name FROM students ORDER BY first_name, last_name'
        );
        while ($row = $studentResult->fetch_assoc()) $students[] = $row;

        $discountExpr = isset($accountColumns['discount_amount']) ? 'COALESCE(sfa.discount_amount, 0)' : '0';
        $paidExpr = 'COALESCE(sfa.`' . $primaryPaidColumn . '`, 0)';
        $yearSelect = $yearExpr . ' AS academic_year_label';
        $termSelect = $termExpr . ' AS term_label';
        $accountSql = "SELECT sfa.id, sfa.student_id, s.first_name, s.last_name, " .
            (isset($studentColumns['admission_no']) ? 's.admission_no' : "'' AS admission_no") . ", " .
            (isset($studentColumns['lin_no']) ? "COALESCE(s.lin_no,'')" : "''") . ' AS lin_no, ' .
            (isset($studentColumns['student_payment_code']) ? "COALESCE(s.student_payment_code,'')" : "''") . ' AS student_payment_code, ' .
            (isset($studentColumns['student_section']) ? "COALESCE(s.student_section,'Day')" : "'Day'") . ' AS student_section, ' .
            "COALESCE(sfa.total_amount,0) AS total_amount, {$paidExpr} AS amount_paid, {$discountExpr} AS discount_amount, " .
            "GREATEST(COALESCE(sfa.total_amount,0) - {$discountExpr} - {$paidExpr}, 0) AS calculated_balance, " .
            (isset($accountColumns['balance']) ? 'COALESCE(sfa.balance,0)' : "GREATEST(COALESCE(sfa.total_amount,0) - {$discountExpr} - {$paidExpr},0)") . " AS stored_balance, " .
            (isset($accountColumns['status']) ? 'sfa.status' : "'' AS status") . ", {$yearSelect}, {$termSelect} " .
            "FROM student_fee_accounts sfa INNER JOIN students s ON s.id = sfa.student_id {$yearJoin} {$termJoin} " .
            'ORDER BY s.first_name, s.last_name, sfa.id DESC';
        $accountResult = $conn->query($accountSql);
        while ($row = $accountResult->fetch_assoc()) $accounts[] = $row;

        $methodSql = 'SELECT id, method_name FROM payment_methods' . (isset($methodColumns['status']) ? " WHERE status = 'active'" : '') . ' ORDER BY method_name';
        $methodResult = $conn->query($methodSql);
        while ($row = $methodResult->fetch_assoc()) $paymentMethods[] = $row;

        /* Payment list joins through the account when the payment table has no student_id. */
        $studentJoinExpr = isset($paymentColumns['student_id'])
            ? 'fp.student_id'
            : 'sfa.student_id';
        $joins = " LEFT JOIN student_fee_accounts sfa ON sfa.id = fp.`{$accountLinkColumn}` " .
                 " LEFT JOIN students s ON s.id = {$studentJoinExpr} ";
        if (isset($paymentColumns['payment_method_id'])) {
            $joins .= ' LEFT JOIN payment_methods pm ON pm.id = fp.payment_method_id ';
            $methodExpr = 'COALESCE(pm.method_name, \'N/A\')';
        } else {
            $methodExpr = "'N/A'";
        }
        $receiptExpr = isset($paymentColumns['receipt_no']) ? 'fp.receipt_no' : "CONCAT('PAY-', fp.id)";
        $referenceExpr = isset($paymentColumns['reference_no']) ? "COALESCE(fp.reference_no, '')" : "''";
        $statusExpr = isset($paymentColumns['status']) ? 'fp.status' : "'completed'";
        $searchWhere = [];
        $searchParams = [];
        $searchTypes = '';
        if ($search !== '') {
            $searchWhere[] = '(' . $receiptExpr . ' LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ? OR ' . $referenceExpr . ' LIKE ?' . (isset($studentColumns['admission_no']) ? ' OR s.admission_no LIKE ?' : '') .
                (isset($studentColumns['lin_no']) ? ' OR s.lin_no LIKE ?' : '') .
                (isset($studentColumns['student_payment_code']) ? ' OR s.student_payment_code LIKE ?' : '') . ')';
            $like = '%' . $search . '%';
            $searchParams = [$like, $like, $like, $like];
            $searchTypes = 'ssss';
            if (isset($studentColumns['admission_no'])) {
                $searchParams[] = $like;
                $searchTypes .= 's';
            }
            if (isset($studentColumns['lin_no'])) {
                $searchParams[] = $like;
                $searchTypes .= 's';
            }
            if (isset($studentColumns['student_payment_code'])) {
                $searchParams[] = $like;
                $searchTypes .= 's';
            }
        }
        $allowedPaymentStatuses = ['completed', 'complete', 'cancelled', 'refunded', 'reversed'];
        if ($statusFilter !== '' && in_array($statusFilter, $allowedPaymentStatuses, true) && isset($paymentColumns['status'])) {
            $searchWhere[] = 'fp.status = ?';
            $searchParams[] = $statusFilter;
            $searchTypes .= 's';
        }
        $paymentsWhere = $searchWhere ? 'WHERE ' . implode(' AND ', $searchWhere) : '';
        $paymentSql = "SELECT fp.id, {$receiptExpr} AS receipt_no, fp.`{$accountLinkColumn}` AS account_id, " .
            (isset($paymentColumns['amount']) ? 'fp.amount' : '0 AS amount') . ', ' .
            (isset($paymentColumns['payment_date']) ? 'fp.payment_date' : 'fp.created_at AS payment_date') . ', ' .
            "{$referenceExpr} AS reference_no, {$statusExpr} AS status, {$methodExpr} AS method_name, " .
            "COALESCE(s.first_name,'') AS first_name, COALESCE(s.last_name,'') AS last_name, " .
            (isset($studentColumns['admission_no']) ? "COALESCE(s.admission_no,'')" : "''") . ' AS admission_no, ' .
            (isset($studentColumns['lin_no']) ? "COALESCE(s.lin_no,'')" : "''") . ' AS lin_no, ' .
            (isset($studentColumns['student_payment_code']) ? "COALESCE(s.student_payment_code,'')" : "''") . ' AS student_payment_code, ' .
            (isset($studentColumns['student_section']) ? "COALESCE(s.student_section,'Day')" : "'Day'") . ' AS student_section ' .
            "FROM fee_payments fp {$joins} {$paymentsWhere} ORDER BY fp.payment_date DESC, fp.id DESC LIMIT 300";
        $paymentStmt = $conn->prepare($paymentSql);
        bindDynamic($paymentStmt, $searchTypes, $searchParams);
        $paymentStmt->execute();
        $paymentResult = $paymentStmt->get_result();
        while ($row = $paymentResult->fetch_assoc()) $payments[] = $row;
        $paymentStmt->close();
    }
} catch (Throwable $ex) {
    $schemaError = $schemaError ?: $ex->getMessage();
    error_log('Payments page load error: ' . $ex->getMessage());
}

$totalCompleted = 0.0;
$totalReversed = 0.0;
foreach ($payments as $payment) {
    if (in_array($payment['status'], ['completed', 'complete'], true)) $totalCompleted += (float)$payment['amount'];
    if (in_array($payment['status'], ['reversed', 'cancelled', 'refunded'], true)) $totalReversed += (float)$payment['amount'];
}

/* Make an account lookup for preselecting ?account_id=1 and for dropdown labels. */
$accountById = [];
foreach ($accounts as $account) $accountById[(int)$account['id']] = $account;
$prefillAccount = $accountById[$prefillAccountId] ?? null;
$defaultDate = date('Y-m-d\\TH:i');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Student Payments | School Management System</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
*{box-sizing:border-box}
body{margin:0;background:#f5f6fa;font-family:Arial,sans-serif;color:#343a40}
.sidebar{position:fixed;top:0;left:0;bottom:0;width:250px;background:#212529;z-index:1030;overflow-y:auto;transition:left .25s}
.sidebar-header{padding:20px 15px;color:#fff;font-weight:700;border-bottom:1px solid rgba(255,255,255,.1)}
.sidebar-menu{padding:15px 10px}
.sidebar-section{color:#6c757d;font-size:11px;text-transform:uppercase;padding:12px 10px 6px}
.sidebar a{display:block;color:#ced4da;padding:12px 15px;margin-bottom:3px;text-decoration:none;border-radius:6px;font-size:14px}
.sidebar a:hover{background:#343a40;color:#fff}
.sidebar a.active{background:#dc3545;color:#fff}
.sidebar i{width:25px;text-align:center;margin-right:5px}
.main{margin-left:250px;min-height:100vh}
.topbar{padding:17px 25px;background:#fff;border-bottom:1px solid #e5e5e5;display:flex;align-items:center;justify-content:space-between}
.content{padding:24px}
.page-head,.panel,.stat-card{background:#fff;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,.05)}
.page-head{padding:21px;margin-bottom:20px}
.panel{padding:21px;margin-bottom:22px}
.stat-card{padding:18px;margin-bottom:18px;height:calc(100% - 18px)}
.stat-title{color:#6c757d;font-size:13px}
.stat-number{font-size:22px;font-weight:700;overflow-wrap:anywhere}
.form-control,.custom-select,.btn{border-radius:6px}
.form-control,.custom-select{min-height:40px}
.table th{background:#f8f9fa;border-top:0;font-size:13px;white-space:nowrap}
.table td{vertical-align:middle;font-size:13px}
.badge{padding:7px 9px}
.mobile-menu{display:none}
@media(max-width:991px){
 .sidebar{left:-250px;width:250px}
 .sidebar.show{left:0}
 .main{margin-left:0}
 .mobile-menu{display:inline-block}
 .content{padding:15px}
 .topbar{padding:12px 15px}
}
@media print{
 .sidebar,.topbar,.no-print,.mobile-menu{display:none!important}
 .main{margin:0}
 .content{padding:0}
 .panel,.stat-card,.page-head{box-shadow:none}
}
</style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<aside class="sidebar" id="sidebar">
 <div class="sidebar-header"><i class="fas fa-university"></i> <span>Bursar</span></div>
 <div class="sidebar-menu">
  <a href="/admin/bursar/index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
  <div class="sidebar-section">Students &amp; Fees</div>
  <a href="/admin/bursar/students_fees.php"><i class="fas fa-file-invoice-dollar"></i> Student Fees</a>
  <a href="/admin/bursar/students_fee_accounts.php"><i class="fas fa-file-invoice-dollar"></i> Student Fee Accounts</a>
  <a href="/admin/bursar/fee_structure.php"><i class="fas fa-list-alt"></i> Fee Structure</a>
  <a href="/admin/bursar/payments.php" class="active"><i class="fas fa-money-bill-wave"></i> Receive Payment</a>
  <a href="/admin/bursar/outstanding_fees.php"><i class="fas fa-exclamation-circle"></i> Outstanding Fees</a>
  <div class="sidebar-section">Finance</div>
  <a href="/admin/bursar/income.php"><i class="fas fa-arrow-circle-down"></i> Income</a>
  <a href="/admin/bursar/expenses.php"><i class="fas fa-arrow-circle-up"></i> Expenses</a>
  <a href="/admin/bursar/suppliers.php"><i class="fas fa-truck"></i> Suppliers</a>
  <a href="/admin/bursar/supplier_payments.php"><i class="fas fa-hand-holding-usd"></i> Supplier Payments</a>
  <div class="sidebar-section">Payroll &amp; Budget</div>
  <a href="/admin/bursar/salaries.php"><i class="fas fa-users"></i> Salaries</a>
  <a href="/admin/bursar/salary_payments.php"><i class="fas fa-money-check-alt"></i> Salary Payments</a>
  <a href="/admin/bursar/budgets.php"><i class="fas fa-chart-pie"></i> Budgets</a>
  <div class="sidebar-section">Reports</div>
  <a href="/admin/bursar/cashbook.php"><i class="fas fa-book"></i> Cashbook</a>
  <a href="/admin/bursar/financial_reports.php"><i class="fas fa-chart-line"></i> Financial Reports</a>
  <a href="/admin/bursar/income_report.php"><i class="fas fa-file-invoice"></i> Income Report</a>
  <a href="/admin/bursar/expense_report.php"><i class="fas fa-receipt"></i> Expense Report</a>
  <a href="/admin/bursar/fees_report.php"><i class="fas fa-file-alt"></i> Fees Report</a>
  <a href="/admin/bursar/profit_loss.php"><i class="fas fa-balance-scale"></i> Profit &amp; Loss</a>
  <div class="sidebar-section">System</div>
  <a href="/admin/dashboard.php"><i class="fas fa-user-shield"></i> Admin Dashboard</a>
  <a href="/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
 </div>
</aside>
<div class="main">
 <div class="topbar">
  <div><button class="btn btn-dark mobile-menu mr-2" id="mobileMenuBtn" type="button"><i class="fas fa-bars"></i></button><strong>Bursar Finance</strong></div>
  <div class="text-muted"><i class="fas fa-user-circle mr-1"></i><?= e($_SESSION['full_name'] ?? 'Bursar') ?></div>
 </div>
 <div class="content">
  <div class="page-head d-flex justify-content-between align-items-center flex-wrap">
   <div><h3 class="mb-1"><i class="fas fa-money-bill-wave text-success mr-2"></i>Student Payments</h3><div class="text-muted">Record payments against student fee accounts and issue receipt numbers.</div></div>
   <button class="btn btn-success mt-2 no-print" onclick="document.getElementById('paymentForm').scrollIntoView({behavior:'smooth'});"><i class="fas fa-plus-circle mr-1"></i>Record Payment</button>
  </div>

  <?php if ($schemaError !== ''): ?>
   <div class="alert alert-danger"><h5><i class="fas fa-exclamation-triangle mr-1"></i>Database/page configuration error</h5><div><?= e($schemaError) ?></div><div class="small mt-2">This error is also written to the hosting PHP error log. No payment was saved from this request.</div></div>
  <?php endif; ?>
  <?php if ($message !== ''): ?><div class="alert alert-<?= e($messageType) ?> alert-dismissible fade show"><?= e($message) ?><button type="button" class="close" data-dismiss="alert"><span>&times;</span></button></div><?php endif; ?>

  <div class="row">
   <div class="col-md-4"><div class="stat-card"><div class="stat-title">Completed Payments Shown</div><div class="stat-number text-success">UGX <?= number_format($totalCompleted,2) ?></div></div></div>
   <div class="col-md-4"><div class="stat-card"><div class="stat-title">Cancelled / Reversed / Refunded Shown</div><div class="stat-number text-danger">UGX <?= number_format($totalReversed,2) ?></div></div></div>
   <div class="col-md-4"><div class="stat-card"><div class="stat-title">Fee Accounts Available</div><div class="stat-number"><?= number_format(count($accounts)) ?></div></div></div>
  </div>

  <section class="panel no-print" id="paymentForm">
   <h5 class="mb-3"><i class="fas fa-edit text-success mr-2"></i>Record Student Payment</h5>
   <?php if ($schemaError === ''): ?>
   <form method="POST" action="payments.php<?= $prefillAccountId > 0 ? '?account_id=' . $prefillAccountId : '' ?>" id="recordPaymentForm">
    <input type="hidden" name="csrf_token" value="<?= e($_SESSION['payments_csrf']) ?>">
    <input type="hidden" name="action" value="record_payment">
    <div class="form-row">
     <div class="col-lg-6 form-group">
      <label for="account_id">Student Fee Account <span class="text-danger">*</span></label>
      <select name="account_id" id="account_id" class="custom-select" required>
       <option value="">-- Select student and fee account --</option>
       <?php foreach ($accounts as $account): $bal = (float)$account['calculated_balance']; ?>
        <option value="<?= (int)$account['id'] ?>" data-balance="<?= e($bal) ?>" <?= ((int)$account['id'] === $prefillAccountId) ? 'selected' : '' ?> <?= $bal <= 0.00001 ? 'disabled' : '' ?>>
         <?= e(($account['admission_no'] ? $account['admission_no'] . ' - ' : '') . $account['first_name'] . ' ' . $account['last_name']) ?> | LIN: <?= e($account['lin_no'] ?: '—') ?> | Payment Code: <?= e($account['student_payment_code'] ?: '—') ?> | <?= e($account['student_section'] ?: 'Day') ?> | <?= e($account['academic_year_label'] ?: 'Year N/A') ?> | <?= e($account['term_label'] ?: 'Term N/A') ?> | Balance: UGX <?= number_format($bal,2) ?><?= $bal <= 0.00001 ? ' [PAID]' : '' ?>
        </option>
       <?php endforeach; ?>
      </select>
      <small id="accountBalanceHelp" class="form-text text-muted">Choose the fee account to pay. Accounts with zero balance cannot be selected.</small>
     </div>
     <div class="col-lg-3 col-md-6 form-group">
      <label for="payment_method_id">Payment Method <span class="text-danger">*</span></label>
      <select name="payment_method_id" id="payment_method_id" class="custom-select" required>
       <option value="">-- Select method --</option>
       <?php foreach ($paymentMethods as $method): ?><option value="<?= (int)$method['id'] ?>"><?= e($method['method_name']) ?></option><?php endforeach; ?>
      </select>
     </div>
     <div class="col-lg-3 col-md-6 form-group">
      <label for="amount">Amount (UGX) <span class="text-danger">*</span></label>
      <input type="number" name="amount" id="amount" class="form-control" min="0.01" step="0.01" required placeholder="Enter amount">
      <small id="amountHelp" class="form-text text-muted">Select an account to see its maximum amount.</small>
     </div>
     <div class="col-md-4 form-group">
      <label for="payment_date">Payment Date and Time <span class="text-danger">*</span></label>
      <input type="datetime-local" name="payment_date" id="payment_date" class="form-control" value="<?= e($defaultDate) ?>" required>
     </div>
     <div class="col-md-4 form-group">
      <label for="reference_no">Reference / Transaction Number</label>
      <input type="text" name="reference_no" id="reference_no" maxlength="100" class="form-control" placeholder="Optional reference">
     </div>
     <div class="col-md-4 form-group">
      <label for="description">Description / Notes</label>
      <input type="text" name="description" id="description" class="form-control" placeholder="Optional note">
     </div>
    </div>
    <button type="submit" class="btn btn-success" id="savePaymentButton"><i class="fas fa-save mr-1"></i> Record Payment</button>
   </form>
   <?php endif; ?>
  </section>

  <section class="panel">
   <div class="d-flex justify-content-between align-items-center flex-wrap mb-3">
    <h5 class="mb-2"><i class="fas fa-list text-primary mr-2"></i>Payment Records</h5>
    <form method="GET" class="form-inline no-print">
     <input type="text" name="search" class="form-control mr-2 mb-2" placeholder="Receipt, student, reference" value="<?= e($search) ?>">
     <select name="status" class="custom-select mr-2 mb-2">
      <option value="">All statuses</option>
      <?php foreach (['completed','complete','cancelled','refunded','reversed'] as $status): ?><option value="<?= e($status) ?>" <?= $statusFilter === $status ? 'selected' : '' ?>><?= e(ucfirst($status)) ?></option><?php endforeach; ?>
     </select>
     <?php if ($prefillAccountId > 0): ?><input type="hidden" name="account_id" value="<?= $prefillAccountId ?>"><?php endif; ?>
     <button class="btn btn-primary mb-2" type="submit"><i class="fas fa-search mr-1"></i>Search</button>
     <a href="payments.php<?= $prefillAccountId > 0 ? '?account_id=' . $prefillAccountId : '' ?>" class="btn btn-outline-secondary mb-2 ml-2">Clear</a>
     <button type="button" onclick="window.print()" class="btn btn-outline-dark mb-2 ml-2"><i class="fas fa-print mr-1"></i>Print</button>
    </form>
   </div>
   <div class="table-responsive">
    <table class="table table-bordered table-hover">
     <thead><tr><th>#</th><th>Receipt No.</th><th>Student</th><th>Payment Method</th><th>Amount (UGX)</th><th>Date</th><th>Reference</th><th>Status</th><th class="no-print">Action</th></tr></thead>
     <tbody>
     <?php if (!$payments): ?>
      <tr><td colspan="9" class="text-center text-muted py-4"><i class="fas fa-receipt fa-2x mb-2"></i><br>No payment records found.</td></tr>
     <?php else: foreach ($payments as $i => $payment): ?>
      <tr>
       <td><?= $i + 1 ?></td>
       <td><strong><?= e($payment['receipt_no']) ?></strong></td>
       <td><strong><?= e(trim($payment['first_name'] . ' ' . $payment['last_name'])) ?></strong><br><small class="text-muted">Admission: <?= e($payment['admission_no'] ?: '—') ?></small><br><small class="text-muted">LIN: <?= e($payment['lin_no'] ?: '—') ?> | Payment Code: <?= e($payment['student_payment_code'] ?: '—') ?> | <?= e($payment['student_section'] ?: 'Day') ?></small></td>
       <td><?= e($payment['method_name']) ?></td>
       <td class="text-right font-weight-bold"><?= number_format((float)$payment['amount'],2) ?></td>
       <td><?= e(date('d M Y H:i', strtotime($payment['payment_date']))) ?></td>
       <td><?= e($payment['reference_no'] ?: '—') ?></td>
       <td>
        <?php if (in_array($payment['status'], ['completed','complete'], true)): ?><span class="badge badge-success">Completed</span>
        <?php elseif (in_array($payment['status'], ['cancelled','refunded','reversed'], true)): ?><span class="badge badge-danger"><?= e(ucfirst($payment['status'])) ?></span>
        <?php else: ?><span class="badge badge-secondary"><?= e(ucfirst($payment['status'])) ?></span><?php endif; ?>
       </td>
       <td class="no-print">
        <?php if (in_array($payment['status'], ['completed','complete'], true) && isset($paymentColumns['status'])): ?>
         <form method="POST" action="payments.php" onsubmit="return confirm('Reverse this payment and restore the amount to the student fee account?');">
          <input type="hidden" name="csrf_token" value="<?= e($_SESSION['payments_csrf']) ?>">
          <input type="hidden" name="action" value="reverse_payment">
          <input type="hidden" name="payment_id" value="<?= (int)$payment['id'] ?>">
          <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fas fa-undo mr-1"></i>Reverse</button>
         </form>
        <?php else: ?>—<?php endif; ?>
       </td>
      </tr>
     <?php endforeach; endif; ?>
     </tbody>
    </table>
   </div>
   <div class="small text-muted">Showing up to 300 matching records. This page saves into the configured fee-payments table and updates the matching student fee account in one database transaction.</div>
  </section>
  <p class="small text-muted text-center">School Management System &mdash; Bursar Payments</p>
 </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function(){
 const sidebar=document.getElementById('sidebar');
 const menu=document.getElementById('mobileMenuBtn');
 if(menu) menu.addEventListener('click',()=>sidebar.classList.toggle('show'));
 document.addEventListener('click',function(ev){
   if(window.innerWidth<=991 && sidebar.classList.contains('show') && !sidebar.contains(ev.target) && ev.target!==menu && !menu.contains(ev.target)) sidebar.classList.remove('show');
 });
 const account=document.getElementById('account_id');
 const amount=document.getElementById('amount');
 const amountHelp=document.getElementById('amountHelp');
 function updateLimit(){
   if(!account||!amount)return;
   const option=account.options[account.selectedIndex];
   const balance=option ? parseFloat(option.getAttribute('data-balance')||'0') : 0;
   if(account.value && balance>0){
     amount.max=balance.toFixed(2);
     amountHelp.textContent='Outstanding balance: UGX '+balance.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2});
     amountHelp.className='form-text text-muted';
   }else{
     amount.removeAttribute('max');
     amountHelp.textContent='Select an account with an outstanding balance.';
     amountHelp.className='form-text text-muted';
   }
   amount.setCustomValidity('');
 }
 if(account){account.addEventListener('change',updateLimit);updateLimit();}
 if(amount){amount.addEventListener('input',function(){const max=parseFloat(amount.max||'0');const value=parseFloat(amount.value||'0');if(max>0 && value>max){amount.setCustomValidity('Amount cannot exceed the outstanding balance.');amountHelp.className='form-text text-danger';amountHelp.textContent='Amount cannot exceed UGX '+max.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2});}else{amount.setCustomValidity('');updateLimit();}});}
 const form=document.getElementById('recordPaymentForm');
 if(form){form.addEventListener('submit',function(){const button=document.getElementById('savePaymentButton');if(button){button.disabled=true;button.innerHTML='<i class="fas fa-spinner fa-spin mr-1"></i>Saving payment...';}});}
})();
</script>
</body>
</html>
