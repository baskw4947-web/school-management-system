<?php
/**
 * School Management System - Bursar Income Report
 * Location: /admin/bursar/income_report.php
 * Read-only report for income_transactions, income_categories and payment_methods.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator', 'bursar']);

if (isset($conn) && $conn instanceof mysqli) {
    $db = $conn;
} elseif (isset($mysqli) && $mysqli instanceof mysqli) {
    $db = $mysqli;
} elseif (isset($connection) && $connection instanceof mysqli) {
    $db = $connection;
} else {
    http_response_code(500);
    exit('Database connection not found. Check config/database.php.');
}
$db->set_charset('utf8mb4');

function incomeReportE($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function incomeReportTableExists(mysqli $db, string $table): bool
{
    $safe = $db->real_escape_string($table);
    $result = $db->query("SHOW TABLES LIKE '{$safe}'");
    $exists = $result && $result->num_rows > 0;
    if ($result) $result->free();
    return $exists;
}

function incomeReportColumns(mysqli $db, string $table): array
{
    $columns = [];
    $result = $db->query('SHOW COLUMNS FROM `' . str_replace('`', '', $table) . '`');
    while ($row = $result->fetch_assoc()) $columns[$row['Field']] = $row;
    $result->free();
    return $columns;
}

function incomeReportBind(mysqli_stmt $stmt, string $types, array &$params): void
{
    if ($types === '' || !$params) return;
    $args = [$types];
    foreach ($params as &$param) $args[] = &$param;
    unset($param);
    call_user_func_array([$stmt, 'bind_param'], $args);
}

$schemaError = '';
$tableReady = false;
$transactions = [];
$categoryTotals = [];
$monthlyTotals = [];
$categories = [];
$statuses = ['completed', 'cancelled', 'reversed'];
$summary = ['count' => 0, 'completed_count' => 0, 'completed_total' => 0.0, 'cancelled_total' => 0.0, 'reversed_total' => 0.0, 'all_total' => 0.0];
$totalRows = 0;
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 25;
$search = trim((string)($_GET['search'] ?? ''));
$statusFilter = trim((string)($_GET['status'] ?? ''));
$categoryFilter = (int)($_GET['category_id'] ?? 0);
$dateFrom = trim((string)($_GET['from'] ?? ''));
$dateTo = trim((string)($_GET['to'] ?? ''));
$exportCsv = isset($_GET['export']) && $_GET['export'] === 'csv';

// Only accept real ISO dates as date filters.
$dateFromValid = $dateFrom !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom) && DateTime::createFromFormat('!Y-m-d', $dateFrom) !== false;
$dateToValid = $dateTo !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo) && DateTime::createFromFormat('!Y-m-d', $dateTo) !== false;

try {
    if (!incomeReportTableExists($db, 'income_transactions')) {
        throw new RuntimeException('The income_transactions table was not found. Open the Income Management page first or check the database selected in config/database.php.');
    }
    $txCols = incomeReportColumns($db, 'income_transactions');
    foreach (['id', 'amount', 'income_date'] as $required) {
        if (!isset($txCols[$required])) throw new RuntimeException("The income_transactions table is missing the '{$required}' column.");
    }
    $categoryCols = incomeReportTableExists($db, 'income_categories') ? incomeReportColumns($db, 'income_categories') : [];
    $methodCols = incomeReportTableExists($db, 'payment_methods') ? incomeReportColumns($db, 'payment_methods') : [];

    $numberCol = isset($txCols['transaction_no']) ? 'transaction_no' : (isset($txCols['receipt_no']) ? 'receipt_no' : null);
    $categoryIdCol = isset($txCols['category_id']) ? 'category_id' : null;
    $methodIdCol = isset($txCols['payment_method_id']) ? 'payment_method_id' : null;
    $referenceCol = isset($txCols['reference_no']) ? 'reference_no' : (isset($txCols['reference']) ? 'reference' : null);
    $descriptionCol = isset($txCols['description']) ? 'description' : (isset($txCols['notes']) ? 'notes' : null);
    $statusCol = isset($txCols['status']) ? 'status' : null;
    $receivedByCol = isset($txCols['received_by']) ? 'received_by' : (isset($txCols['created_by']) ? 'created_by' : null);

    if ($statusCol) {
        $rawStatus = (string)($txCols[$statusCol]['Type'] ?? '');
        if (stripos($rawStatus, 'enum(') === 0 && preg_match_all("/'((?:[^'\\\\]|\\\\.)*)'/", $rawStatus, $matches)) {
            $dbStatuses = array_map('stripcslashes', $matches[1] ?? []);
            if ($dbStatuses) $statuses = $dbStatuses;
        }
    }

    $categoryNameExpr = "'Uncategorised'";
    $categoryJoin = '';
    $canJoinCategory = $categoryIdCol && isset($categoryCols['id']) && isset($categoryCols['category_name']);
    if ($canJoinCategory) {
        $categoryJoin = ' LEFT JOIN income_categories ic ON ic.id = it.`' . $categoryIdCol . '` ';
        $categoryNameExpr = "COALESCE(ic.category_name, CONCAT('Category #', it.`{$categoryIdCol}`))";
    } elseif ($categoryIdCol) {
        $categoryNameExpr = "CONCAT('Category #', it.`{$categoryIdCol}`)";
    }

    $methodNameExpr = "'Not specified'";
    $methodJoin = '';
    $canJoinMethod = $methodIdCol && isset($methodCols['id']) && isset($methodCols['method_name']);
    if ($canJoinMethod) {
        $methodJoin = ' LEFT JOIN payment_methods pm ON pm.id = it.`' . $methodIdCol . '` ';
        $methodNameExpr = "COALESCE(pm.method_name, 'Not specified')";
    } elseif ($methodIdCol) {
        $methodNameExpr = "CONCAT('Method #', it.`{$methodIdCol}`)";
    }

    $conditions = [];
    $whereParams = [];
    $whereTypes = '';
    if ($dateFromValid) {
        $conditions[] = 'DATE(it.`income_date`) >= ?';
        $whereParams[] = $dateFrom; $whereTypes .= 's';
    }
    if ($dateToValid) {
        $conditions[] = 'DATE(it.`income_date`) <= ?';
        $whereParams[] = $dateTo; $whereTypes .= 's';
    }
    if ($statusCol && $statusFilter !== '' && in_array($statusFilter, $statuses, true)) {
        $conditions[] = 'it.`' . $statusCol . '` = ?';
        $whereParams[] = $statusFilter; $whereTypes .= 's';
    }
    if ($canJoinCategory && $categoryFilter > 0) {
        $conditions[] = 'it.`' . $categoryIdCol . '` = ?';
        $whereParams[] = $categoryFilter; $whereTypes .= 'i';
    }
    if ($search !== '') {
        $searchCols = [];
        foreach ([$numberCol, $referenceCol, $descriptionCol] as $col) {
            if ($col) $searchCols[] = 'CAST(it.`' . str_replace('`', '', $col) . '` AS CHAR) LIKE ?';
        }
        if ($canJoinCategory) $searchCols[] = 'ic.category_name LIKE ?';
        if ($canJoinMethod) $searchCols[] = 'pm.method_name LIKE ?';
        if ($searchCols) {
            $conditions[] = '(' . implode(' OR ', $searchCols) . ')';
            foreach ($searchCols as $_) { $whereParams[] = '%' . $search . '%'; $whereTypes .= 's'; }
        }
    }
    $whereSql = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';
    $joins = $categoryJoin . $methodJoin;
    $numberExpr = $numberCol ? "COALESCE(CAST(it.`{$numberCol}` AS CHAR), CONCAT('INC-', it.id))" : "CONCAT('INC-', it.id)";
    $referenceExpr = $referenceCol ? "COALESCE(CAST(it.`{$referenceCol}` AS CHAR), '')" : "''";
    $descriptionExpr = $descriptionCol ? "COALESCE(CAST(it.`{$descriptionCol}` AS CHAR), '')" : "''";
    $statusExpr = $statusCol ? "COALESCE(CAST(it.`{$statusCol}` AS CHAR), 'completed')" : "'completed'";
    $categoryIdExpr = $categoryIdCol ? "COALESCE(it.`{$categoryIdCol}`, 0)" : '0';
    $receivedExpr = $receivedByCol ? "COALESCE(it.`{$receivedByCol}`, 0)" : '0';
    $selectSql = "SELECT it.id, {$numberExpr} AS transaction_no, {$categoryIdExpr} AS category_id, {$categoryNameExpr} AS category_name, COALESCE(it.amount,0) AS amount, it.income_date, {$methodNameExpr} AS method_name, {$referenceExpr} AS reference_no, {$descriptionExpr} AS description, {$statusExpr} AS status, {$receivedExpr} AS received_by FROM income_transactions it {$joins} {$whereSql}";

    // Load category filter options separately from report filters.
    if ($canJoinCategory) {
        $catResult = $db->query("SELECT id, category_name FROM income_categories" . (isset($categoryCols['status']) ? " WHERE status = 'active' OR status IS NULL" : '') . ' ORDER BY category_name');
        while ($cat = $catResult->fetch_assoc()) $categories[] = $cat;
        $catResult->free();
    }

    // All filtered rows are used for exact summary and breakdowns. The display is paginated.
    $paramsForRows = $whereParams;
    $rowsResult = $db->prepare($selectSql . ' ORDER BY it.income_date DESC, it.id DESC');
    incomeReportBind($rowsResult, $whereTypes, $paramsForRows);
    $rowsResult->execute();
    $result = $rowsResult->get_result();
    $allRows = [];
    while ($row = $result->fetch_assoc()) $allRows[] = $row;
    $result->free();
    $rowsResult->close();
    $totalRows = count($allRows);

    foreach ($allRows as $row) {
        $amount = (float)$row['amount'];
        $st = strtolower(trim((string)$row['status']));
        $summary['all_total'] += $amount;
        if (in_array($st, ['completed', 'complete', 'paid', 'success', 'successful'], true)) {
            $summary['completed_total'] += $amount;
            $summary['completed_count']++;
        } elseif (in_array($st, ['cancelled', 'canceled'], true)) {
            $summary['cancelled_total'] += $amount;
        } elseif (in_array($st, ['reversed', 'refunded', 'void'], true)) {
            $summary['reversed_total'] += $amount;
        }
        $summary['count']++;
        $catName = (string)($row['category_name'] ?: 'Uncategorised');
        if (!isset($categoryTotals[$catName])) $categoryTotals[$catName] = ['count' => 0, 'amount' => 0.0];
        $month = $row['income_date'] ? date('Y-m', strtotime((string)$row['income_date'])) : 'Unknown';
        if (!isset($monthlyTotals[$month])) $monthlyTotals[$month] = ['count' => 0, 'amount' => 0.0];
        if (in_array($st, ['completed', 'complete', 'paid', 'success', 'successful'], true)) {
            $categoryTotals[$catName]['count']++;
            $categoryTotals[$catName]['amount'] += $amount;
            $monthlyTotals[$month]['count']++;
            $monthlyTotals[$month]['amount'] += $amount;
        }
    }

    // CSV export includes all rows matching the active filters, not just the current page.
    if ($exportCsv) {
        $filename = 'income-report-' . date('Y-m-d') . '.csv';
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, ['Transaction No.', 'Income Date', 'Category', 'Payment Method', 'Reference', 'Description', 'Status', 'Amount (UGX)']);
        foreach ($allRows as $row) {
            fputcsv($out, [$row['transaction_no'], $row['income_date'], $row['category_name'], $row['method_name'], $row['reference_no'], $row['description'], $row['status'], number_format((float)$row['amount'], 2, '.', '')]);
        }
        fclose($out);
        exit;
    }

    $summary['completed_total'] = round($summary['completed_total'], 2);
    $summary['cancelled_total'] = round($summary['cancelled_total'], 2);
    $summary['reversed_total'] = round($summary['reversed_total'], 2);
    $summary['all_total'] = round($summary['all_total'], 2);
    usort($categoryTotals, static fn($a, $b) => $b['amount'] <=> $a['amount']);
    krsort($monthlyTotals);
    $totalPages = max(1, (int)ceil($totalRows / $perPage));
    if ($page > $totalPages) $page = $totalPages;
    $transactions = array_slice($allRows, ($page - 1) * $perPage, $perPage);
    $tableReady = true;
} catch (Throwable $e) {
    error_log('income_report.php error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    $schemaError = $e instanceof RuntimeException ? $e->getMessage() : 'The income report could not load from the database. Check the hosting PHP error log for details.';
}

// Build links that preserve current filters when paging, exporting, or clearing.
$queryBase = $_GET;
unset($queryBase['page'], $queryBase['export']);
$exportQuery = $queryBase;
$exportQuery['export'] = 'csv';
function incomeReportUrl(array $query): string { return 'income_report.php' . ($query ? '?' . http_build_query($query) : ''); }
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Income Report | School Management System</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
:root{--navy:#212529;--navy2:#171a1d;--green:#229c62;--bg:#f4f6f9;--ink:#293548;--muted:#768295}*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--ink)}.sidebar{position:fixed;top:0;left:0;bottom:0;width:250px;background:var(--navy);overflow-y:auto;z-index:1050}.sidebar-header{padding:22px 18px;background:var(--navy2);color:#fff;font-size:18px;font-weight:700}.sidebar-section{padding:15px 16px 6px;color:#868e96;font-size:11px;text-transform:uppercase;letter-spacing:.6px;font-weight:bold}.sidebar a{display:block;color:#ced4da;padding:11px 16px;text-decoration:none;border-left:4px solid transparent;font-size:13px}.sidebar a:hover,.sidebar a.active{background:#343a40;color:#fff;border-left-color:#28a745}.sidebar a i{width:24px;text-align:center;margin-right:5px}.main{margin-left:250px;min-height:100vh}.topbar{padding:16px 25px;background:#fff;border-bottom:1px solid #e5e5e5;display:flex;justify-content:space-between;align-items:center;gap:12px}.content{padding:24px}.page-head,.panel,.stat-card{background:#fff;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,.045);border:1px solid #eef0f3}.page-head{padding:22px;margin-bottom:20px}.panel{padding:20px;margin-bottom:22px}.stat-card{padding:18px;height:100%;min-height:116px}.stat-title{font-size:12px;color:var(--muted);margin-bottom:9px}.stat-number{font-weight:700;font-size:22px;overflow-wrap:anywhere}.stat-icon{float:right;width:38px;height:38px;background:#e5f5ed;color:#218756;border-radius:10px;text-align:center;line-height:38px}.form-control,.custom-select{min-height:39px;font-size:13px;border-radius:6px}.btn{font-size:13px;border-radius:6px}.table th{background:#f8f9fb;color:#647184;font-size:11px;text-transform:uppercase;letter-spacing:.3px;white-space:nowrap;border-top:0}.table td{font-size:12px;vertical-align:middle}.section-title{font-size:16px;font-weight:700;margin-bottom:16px}.badge{padding:6px 8px;font-size:10px}.empty{text-align:center;color:#8994a5;padding:35px 10px}.mobile-menu{display:none}.help-text{color:#8490a0;font-size:11px}.table-responsive{border-radius:6px}@media(max-width:991px){.sidebar{left:-250px;transition:left .2s}.sidebar.show{left:0}.main{margin-left:0}.mobile-menu{display:inline-block}.content{padding:14px}.topbar{padding:12px 15px}.page-head{padding:16px}}@media print{.sidebar,.topbar,.no-print{display:none!important}.main{margin:0}.content{padding:0}.page-head,.panel,.stat-card{box-shadow:none;border:0}.table{font-size:10px}body{background:#fff}}
</style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-header"><i class="fas fa-school mr-2"></i>School Management<br><small class="text-muted">Bursar Panel</small></div>
  <div class="sidebar-section">Main</div>
  <a href="/admin/dashboard.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
  <a href="/admin/bursar/index.php"><i class="fas fa-chart-line"></i>Bursar Dashboard</a>
  <div class="sidebar-section">Fees</div>
  <a href="/admin/bursar/students_fee_accounts.php"><i class="fas fa-user-graduate"></i>Student Fee Accounts</a>
  <a href="/admin/bursar/fee_structure.php"><i class="fas fa-layer-group"></i>Fee Structure</a>
  <a href="/admin/bursar/payments.php"><i class="fas fa-cash-register"></i>Student Payments</a>
  <a href="/admin/bursar/outstanding_fees.php"><i class="fas fa-exclamation-circle"></i>Outstanding Fees</a>
  <a href="/admin/bursar/fees_report.php"><i class="fas fa-file-invoice"></i>Fees Report</a>
  <div class="sidebar-section">Finance</div>
  <a href="/admin/bursar/income.php"><i class="fas fa-arrow-down"></i>Income Management</a>
  <a href="/admin/bursar/income_report.php" class="active"><i class="fas fa-chart-bar"></i>Income Report</a>
  <a href="/admin/bursar/expenses.php"><i class="fas fa-arrow-up"></i>Expenses</a>
  <a href="/admin/bursar/expense_report.php"><i class="fas fa-file-alt"></i>Expense Report</a>
  <a href="/admin/bursar/suppliers.php"><i class="fas fa-truck"></i>Suppliers</a>
  <a href="/admin/bursar/supplier_payments.php"><i class="fas fa-file-invoice-dollar"></i>Supplier Payments</a>
  <a href="/admin/bursar/budgets.php"><i class="fas fa-wallet"></i>Budgets</a>
  <a href="/admin/bursar/cashbook.php"><i class="fas fa-book"></i>Cashbook</a>
  <a href="/admin/bursar/reports.php"><i class="fas fa-chart-pie"></i>Financial Reports</a>
  <a href="/admin/bursar/profit_loss.php"><i class="fas fa-balance-scale"></i>Profit &amp; Loss</a>
  <div class="sidebar-section">Account</div>
  <a href="/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
</aside>
<div class="main">
  <div class="topbar"><div><button class="btn btn-dark mobile-menu mr-2" id="mobileMenuBtn" type="button" aria-label="Open navigation"><i class="fas fa-bars"></i></button><strong>Bursar Finance / Income Report</strong></div><div class="text-muted small"><i class="fas fa-user-circle mr-1"></i><?= incomeReportE($_SESSION['full_name'] ?? 'Bursar') ?></div></div>
  <div class="content">
    <div class="page-head d-flex justify-content-between align-items-center flex-wrap">
      <div><div class="text-uppercase text-success small font-weight-bold mb-1">Financial reporting</div><h3 class="mb-1"><i class="fas fa-chart-bar text-success mr-2"></i>Income Report</h3><div class="text-muted small">Review income transactions recorded in the school's Other Income module.</div></div>
      <div class="no-print mt-3 mt-md-0"><a class="btn btn-outline-success mr-1" href="<?= incomeReportE(incomeReportUrl($exportQuery)) ?>"><i class="fas fa-file-csv mr-1"></i>Export CSV</a><button type="button" class="btn btn-outline-secondary" onclick="window.print()"><i class="fas fa-print mr-1"></i>Print</button></div>
    </div>
    <?php if ($schemaError !== ''): ?><div class="alert alert-danger"><h5><i class="fas fa-exclamation-triangle mr-1"></i>Database / page configuration error</h5><div><?= incomeReportE($schemaError) ?></div><div class="small mt-2">No data was changed. Details have been written to the hosting PHP error log.</div></div><?php endif; ?>
    <?php if ($tableReady): ?>
    <div class="row mb-1">
      <div class="col-sm-6 col-xl-3 mb-3"><div class="stat-card"><span class="stat-icon"><i class="fas fa-receipt"></i></span><div class="stat-title">Matching transactions</div><div class="stat-number"><?= number_format($summary['count']) ?></div></div></div>
      <div class="col-sm-6 col-xl-3 mb-3"><div class="stat-card"><span class="stat-icon"><i class="fas fa-check-circle"></i></span><div class="stat-title">Completed income</div><div class="stat-number text-success">UGX <?= number_format($summary['completed_total'], 2) ?></div><div class="help-text mt-1"><?= number_format($summary['completed_count']) ?> completed transaction(s)</div></div></div>
      <div class="col-sm-6 col-xl-3 mb-3"><div class="stat-card"><span class="stat-icon" style="background:#fff1df;color:#b77716"><i class="fas fa-ban"></i></span><div class="stat-title">Cancelled amount</div><div class="stat-number">UGX <?= number_format($summary['cancelled_total'], 2) ?></div></div></div>
      <div class="col-sm-6 col-xl-3 mb-3"><div class="stat-card"><span class="stat-icon" style="background:#fce9eb;color:#bd3544"><i class="fas fa-undo-alt"></i></span><div class="stat-title">Reversed / refunded</div><div class="stat-number">UGX <?= number_format($summary['reversed_total'], 2) ?></div></div></div>
    </div>
    <section class="panel no-print">
      <div class="section-title"><i class="fas fa-filter text-success mr-2"></i>Filter income transactions</div>
      <form method="get" action="income_report.php" class="form-row align-items-end">
        <div class="form-group col-lg-3 col-md-6"><label for="search">Search</label><input class="form-control" type="search" name="search" id="search" value="<?= incomeReportE($search) ?>" placeholder="Transaction, category, reference..."></div>
        <div class="form-group col-lg-2 col-md-6"><label for="from">From date</label><input class="form-control" type="date" name="from" id="from" value="<?= incomeReportE($dateFromValid ? $dateFrom : '') ?>"></div>
        <div class="form-group col-lg-2 col-md-6"><label for="to">To date</label><input class="form-control" type="date" name="to" id="to" value="<?= incomeReportE($dateToValid ? $dateTo : '') ?>"></div>
        <?php if ($categories): ?><div class="form-group col-lg-2 col-md-6"><label for="category_id">Category</label><select class="custom-select" name="category_id" id="category_id"><option value="0">All categories</option><?php foreach ($categories as $cat): ?><option value="<?= (int)$cat['id'] ?>" <?= $categoryFilter === (int)$cat['id'] ? 'selected' : '' ?>><?= incomeReportE($cat['category_name']) ?></option><?php endforeach; ?></select></div><?php endif; ?>
        <?php if ($statusCol ?? false): ?><div class="form-group col-lg-2 col-md-6"><label for="status">Status</label><select class="custom-select" name="status" id="status"><option value="">All statuses</option><?php foreach ($statuses as $st): ?><option value="<?= incomeReportE($st) ?>" <?= $statusFilter === $st ? 'selected' : '' ?>><?= incomeReportE(ucwords(str_replace('_', ' ', $st))) ?></option><?php endforeach; ?></select></div><?php endif; ?>
        <div class="form-group col-lg-1 col-md-6"><button class="btn btn-success btn-block" type="submit"><i class="fas fa-search"></i> Filter</button></div>
        <div class="form-group col-12 mb-0"><a href="income_report.php" class="small text-muted"><i class="fas fa-times mr-1"></i>Clear filters</a><span class="small text-muted ml-3">Amounts are shown in UGX. The report includes income_transactions only; student fee payments are not added separately.</span></div>
      </form>
    </section>
    <div class="row">
      <div class="col-lg-7"><section class="panel"><div class="section-title"><i class="fas fa-list text-success mr-2"></i>Income transaction details <span class="text-muted small font-weight-normal">(<?= number_format($totalRows) ?> records)</span></div>
        <div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Transaction</th><th>Date</th><th>Category</th><th>Method</th><th>Status</th><th class="text-right">Amount (UGX)</th></tr></thead><tbody>
        <?php if (!$transactions): ?><tr><td colspan="6"><div class="empty"><i class="fas fa-file-invoice-dollar fa-2x mb-2"></i><br><strong>No income records found</strong><div class="small mt-1">Try adjusting your date range or filters.</div></div></td></tr><?php else: foreach ($transactions as $tx): $st = strtolower(trim((string)$tx['status'])); $done = in_array($st, ['completed','complete','paid','success','successful'], true); $bad = in_array($st, ['cancelled','canceled','reversed','refunded','void'], true); ?>
          <tr><td><strong><?= incomeReportE($tx['transaction_no']) ?></strong><div class="text-muted small"><?= incomeReportE($tx['reference_no'] ?: '') ?></div></td><td><?= $tx['income_date'] ? incomeReportE(date('d M Y', strtotime((string)$tx['income_date']))) : '—' ?></td><td><?= incomeReportE($tx['category_name']) ?></td><td><?= incomeReportE($tx['method_name']) ?></td><td><span class="badge badge-<?= $done ? 'success' : ($bad ? 'danger' : 'secondary') ?>"><?= incomeReportE(ucwords(str_replace('_', ' ', $st ?: 'completed'))) ?></span></td><td class="text-right font-weight-bold <?= $done ? 'text-success' : 'text-muted' ?>"><?= number_format((float)$tx['amount'], 2) ?></td></tr>
          <?php if (trim((string)$tx['description']) !== ''): ?><tr class="text-muted"><td colspan="6" class="pt-0 border-top-0"><small><i class="far fa-comment-alt mr-1"></i><?= incomeReportE($tx['description']) ?></small></td></tr><?php endif; ?>
        <?php endforeach; endif; ?></tbody></table></div>
        <?php if (($totalPages ?? 1) > 1): $pageQ = $queryBase; ?><nav class="no-print mt-3"><ul class="pagination pagination-sm mb-0"><li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><?php $pageQ['page'] = max(1, $page - 1); ?><a class="page-link" href="<?= incomeReportE(incomeReportUrl($pageQ)) ?>">Previous</a></li><li class="page-item disabled"><span class="page-link">Page <?= $page ?> of <?= $totalPages ?></span></li><li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>"><?php $pageQ['page'] = min($totalPages, $page + 1); ?><a class="page-link" href="<?= incomeReportE(incomeReportUrl($pageQ)) ?>">Next</a></li></ul></nav><?php endif; ?>
      </section></div>
      <div class="col-lg-5"><section class="panel"><div class="section-title"><i class="fas fa-layer-group text-success mr-2"></i>Completed income by category</div><div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Category</th><th class="text-right">Records</th><th class="text-right">Amount (UGX)</th></tr></thead><tbody><?php if (!$categoryTotals): ?><tr><td colspan="3" class="text-muted text-center py-3">No category totals for these filters.</td></tr><?php else: foreach ($categoryTotals as $catName => $tot): ?><tr><td><?= incomeReportE($catName) ?></td><td class="text-right"><?= number_format($tot['count']) ?></td><td class="text-right font-weight-bold"><?= number_format($tot['amount'], 2) ?></td></tr><?php endforeach; endif; ?></tbody></table></div></section>
      <section class="panel"><div class="section-title"><i class="fas fa-calendar-alt text-success mr-2"></i>Completed income by month</div><div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Month</th><th class="text-right">Records</th><th class="text-right">Amount (UGX)</th></tr></thead><tbody><?php if (!$monthlyTotals): ?><tr><td colspan="3" class="text-muted text-center py-3">No monthly totals.</td></tr><?php else: foreach ($monthlyTotals as $month => $tot): ?><tr><td><?= incomeReportE($month === 'Unknown' ? $month : date('M Y', strtotime($month . '-01'))) ?></td><td class="text-right"><?= number_format($tot['count']) ?></td><td class="text-right font-weight-bold"><?= number_format($tot['amount'], 2) ?></td></tr><?php endforeach; endif; ?></tbody></table></div></section></div>
    </div>
    <?php endif; ?>
    <div class="text-center text-muted small pb-3">School Management System &mdash; Bursar Income Report</div>
  </div>
</div>
<script>
(function(){
  var sidebar=document.getElementById('sidebar'),button=document.getElementById('mobileMenuBtn');
  if(button&&sidebar)button.addEventListener('click',function(){sidebar.classList.toggle('show');});
  document.addEventListener('click',function(e){if(window.innerWidth<=991&&sidebar&&sidebar.classList.contains('show')&&!sidebar.contains(e.target)&&button&&!button.contains(e.target))sidebar.classList.remove('show');});
})();
</script>
</body>
</html>
