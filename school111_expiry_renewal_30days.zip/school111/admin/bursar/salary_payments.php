<?php
/**
 * School management system - salary payments / payroll disbursements.
 * Save as UTF-8 without BOM, with this opening PHP tag at the very start of the file.
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator', 'bursar']);

if (!isset($conn) || !($conn instanceof mysqli)) {
    http_response_code(500);
    exit('Database connection is unavailable. Please check config/database.php.');
}
$conn->set_charset('utf8mb4');

function salaryPayE($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}
function salaryPayFlash(string $type, string $message): void {
    $_SESSION['salary_payments_flash'] = ['type' => $type, 'message' => $message];
}
function salaryPayRedirect(string $url = 'salary_payments.php'): void {
    header('Location: ' . $url);
    exit;
}
function salaryPayUserId(): int {
    if (isset($_SESSION['user_id']) && is_numeric($_SESSION['user_id'])) return (int)$_SESSION['user_id'];
    if (isset($_SESSION['id']) && is_numeric($_SESSION['id'])) return (int)$_SESSION['id'];
    if (isset($_SESSION['user']) && is_array($_SESSION['user']) && isset($_SESSION['user']['id']) && is_numeric($_SESSION['user']['id'])) return (int)$_SESSION['user']['id'];
    return 0;
}
function salaryPayColumns(mysqli $conn, string $table): array {
    $columns = [];
    $result = $conn->query('SHOW COLUMNS FROM `' . str_replace('`', '``', $table) . '`');
    while ($row = $result->fetch_assoc()) $columns[$row['Field']] = $row;
    $result->free();
    return $columns;
}
function salaryPayFirstColumn(array $columns, array $candidates): ?string {
    foreach ($candidates as $candidate) if (isset($columns[$candidate])) return $candidate;
    return null;
}
function salaryPayEnumValues(string $type): array {
    if (stripos($type, 'enum(') !== 0) return [];
    preg_match_all("/'((?:[^'\\\\]|\\\\.)*)'/", $type, $matches);
    return array_map(static function ($value) { return stripcslashes($value); }, $matches[1] ?? []);
}
function salaryPayGenerateNumber(mysqli $conn, string $table, string $column, string $prefix): string {
    for ($i = 0; $i < 15; $i++) {
        $number = $prefix . date('Ymd-His') . '-' . strtoupper(bin2hex(random_bytes(2)));
        $sql = 'SELECT 1 FROM `' . str_replace('`', '``', $table) . '` WHERE `' . str_replace('`', '``', $column) . '` = ? LIMIT 1';
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('s', $number);
        $stmt->execute();
        $exists = (bool)$stmt->get_result()->fetch_row();
        $stmt->close();
        if (!$exists) return $number;
    }
    throw new RuntimeException('Could not generate a unique payment number. Please try again.');
}
function salaryPayBind(mysqli_stmt $stmt, string $types, array &$values): void {
    $args = [$types];
    foreach ($values as $key => &$value) $args[] = &$value;
    call_user_func_array([$stmt, 'bind_param'], $args);
}
function salaryPayStatusForColumn(array $columnInfo, string $preferred): string {
    $values = salaryPayEnumValues((string)($columnInfo['Type'] ?? ''));
    if (!$values) return $preferred;
    if (in_array($preferred, $values, true)) return $preferred;
    foreach (['completed', 'paid', 'success', 'active'] as $candidate) if (in_array($candidate, $values, true)) return $candidate;
    return (string)$values[0];
}
function salaryPayIsActive($status): bool {
    if ($status === null || $status === '') return true;
    if (is_numeric($status)) return (int)$status === 1;
    return !in_array(strtolower(trim((string)$status)), ['inactive', 'disabled', 'terminated', 'ended', 'cancelled', 'canceled', 'deleted', '0'], true);
}
function salaryPayIsCompleted($status): bool {
    return in_array(strtolower(trim((string)$status)), ['completed', 'paid', 'success', 'successful'], true);
}

if (empty($_SESSION['salary_payments_csrf'])) $_SESSION['salary_payments_csrf'] = bin2hex(random_bytes(32));
$csrfToken = (string)$_SESSION['salary_payments_csrf'];
$flash = $_SESSION['salary_payments_flash'] ?? null;
unset($_SESSION['salary_payments_flash']);
$pageError = '';
$schemaError = '';
$paymentColumns = [];
$salaryColumns = [];
$paymentTableExists = false;
$salaryTableExists = false;
$createdPaymentTable = false;
$hasPaymentEmployeeLink = false;
$salaryRows = [];
$salaryRowsById = [];
$methodOptions = [];
$methodLabels = [];
$paymentRows = [];
$paymentMap = [];
$salaryMap = [];
$statusValues = [];
$activeSalaryCount = 0;
$totalPaymentCount = 0;
$totalCompletedAmount = 0.0;
$thisMonthCompletedAmount = 0.0;
$totalPages = 1;
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 15;
$search = trim((string)($_GET['q'] ?? ''));
$dateFrom = trim((string)($_GET['from'] ?? ''));
$dateTo = trim((string)($_GET['to'] ?? ''));
$statusFilter = trim((string)($_GET['status'] ?? ''));

try {
    $tables = [];
    $tr = $conn->query('SHOW TABLES');
    while ($r = $tr->fetch_row()) $tables[] = (string)$r[0];
    $tr->free();
    $salaryTableExists = in_array('salaries', $tables, true);
    $paymentTableExists = in_array('salary_payments', $tables, true);

    if (!$salaryTableExists) {
        $schemaError = 'The salaries table was not found. Open the Staff Salaries page first and add salary records for the people you want to pay.';
    } else {
        $salaryColumns = salaryPayColumns($conn, 'salaries');
        if (!$paymentTableExists) {
            $conn->query("CREATE TABLE `salary_payments` (
                `id` INT(11) NOT NULL AUTO_INCREMENT,
                `payment_no` VARCHAR(50) NOT NULL,
                `salary_id` INT(11) NOT NULL,
                `salary_no` VARCHAR(50) DEFAULT NULL,
                `person_name` VARCHAR(150) NOT NULL,
                `person_role` VARCHAR(100) DEFAULT NULL,
                `salary_period` VARCHAR(7) NOT NULL,
                `amount` DECIMAL(12,2) NOT NULL,
                `payment_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `payment_method_id` INT(11) DEFAULT NULL,
                `reference_no` VARCHAR(100) DEFAULT NULL,
                `description` TEXT DEFAULT NULL,
                `paid_by` INT(11) NOT NULL,
                `status` ENUM('completed','cancelled','reversed') NOT NULL DEFAULT 'completed',
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uq_salary_payment_no` (`payment_no`),
                KEY `idx_salary_payment_salary` (`salary_id`),
                KEY `idx_salary_payment_date` (`payment_date`),
                KEY `idx_salary_payment_period` (`salary_period`),
                KEY `idx_salary_payment_status` (`status`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            $paymentTableExists = true;
            $createdPaymentTable = true;
        }
        $paymentColumns = salaryPayColumns($conn, 'salary_payments');

        $salaryMap = [
            'id' => salaryPayFirstColumn($salaryColumns, ['id', 'salary_id']),
            'number' => salaryPayFirstColumn($salaryColumns, ['salary_no', 'salary_number', 'record_no', 'salary_code']),
            'person_source' => salaryPayFirstColumn($salaryColumns, ['person_source', 'source_table', 'staff_source', 'employee_type', 'person_type']),
            'teacher_id' => salaryPayFirstColumn($salaryColumns, ['teacher_id']),
            'staff_id' => salaryPayFirstColumn($salaryColumns, ['staff_id', 'employee_id', 'personnel_id']),
            'person_id' => salaryPayFirstColumn($salaryColumns, ['person_id', 'staff_id', 'employee_id', 'teacher_id', 'user_id', 'personnel_id']),
            'name' => salaryPayFirstColumn($salaryColumns, ['person_name', 'employee_name', 'staff_name', 'teacher_name', 'full_name', 'name']),
            'role' => salaryPayFirstColumn($salaryColumns, ['person_role', 'job_title', 'position', 'designation', 'staff_role', 'role']),
            'basic' => salaryPayFirstColumn($salaryColumns, ['basic_salary', 'base_salary', 'salary_amount', 'monthly_salary', 'salary', 'gross_salary', 'basic_pay', 'amount']),
            'allowances' => salaryPayFirstColumn($salaryColumns, ['allowances', 'allowance', 'total_allowances']),
            'deductions' => salaryPayFirstColumn($salaryColumns, ['deductions', 'deduction', 'total_deductions']),
            'net' => salaryPayFirstColumn($salaryColumns, ['net_salary', 'net_pay', 'take_home_pay', 'take_home']),
            'frequency' => salaryPayFirstColumn($salaryColumns, ['pay_frequency', 'salary_frequency', 'frequency', 'payment_frequency']),
            'status' => salaryPayFirstColumn($salaryColumns, ['status', 'salary_status']),
        ];
        $paymentMap = [
            'id' => salaryPayFirstColumn($paymentColumns, ['id', 'payment_id']),
            'number' => salaryPayFirstColumn($paymentColumns, ['payment_no', 'salary_payment_no', 'payment_number', 'receipt_no']),
            'salary_id' => salaryPayFirstColumn($paymentColumns, ['salary_id', 'salary_record_id', 'salary_structure_id', 'staff_salary_id']),
            'teacher_id' => salaryPayFirstColumn($paymentColumns, ['teacher_id']),
            'staff_id' => salaryPayFirstColumn($paymentColumns, ['staff_id', 'employee_id', 'personnel_id']),
            'basic' => salaryPayFirstColumn($paymentColumns, ['basic_salary', 'base_salary', 'basic_pay']),
            'allowances' => salaryPayFirstColumn($paymentColumns, ['allowances', 'allowance', 'total_allowances']),
            'deductions' => salaryPayFirstColumn($paymentColumns, ['deductions', 'deduction', 'total_deductions']),
            'salary_no' => salaryPayFirstColumn($paymentColumns, ['salary_no', 'salary_number']),
            'name' => salaryPayFirstColumn($paymentColumns, ['person_name', 'employee_name', 'staff_name', 'teacher_name', 'full_name']),
            'role' => salaryPayFirstColumn($paymentColumns, ['person_role', 'job_title', 'position', 'designation']),
            'period' => salaryPayFirstColumn($paymentColumns, ['salary_period', 'pay_period', 'period', 'payroll_month', 'salary_month']),
            'amount' => salaryPayFirstColumn($paymentColumns, ['amount', 'payment_amount', 'paid_amount', 'net_amount', 'net_salary']),
            'date' => salaryPayFirstColumn($paymentColumns, ['payment_date', 'paid_date', 'transaction_date', 'date_paid', 'date']),
            'method_id' => salaryPayFirstColumn($paymentColumns, ['payment_method_id']),
            'method_text' => salaryPayFirstColumn($paymentColumns, ['payment_method', 'method', 'payment_type']),
            'reference' => salaryPayFirstColumn($paymentColumns, ['reference_no', 'reference_number', 'transaction_reference', 'transaction_id', 'receipt_no']),
            'notes' => salaryPayFirstColumn($paymentColumns, ['description', 'notes', 'remarks', 'narration']),
            'paid_by' => salaryPayFirstColumn($paymentColumns, ['paid_by', 'created_by', 'recorded_by', 'user_id']),
            'status' => salaryPayFirstColumn($paymentColumns, ['status', 'payment_status']),
            'created_at' => salaryPayFirstColumn($paymentColumns, ['created_at', 'recorded_at']),
        ];
        $statusValues = $paymentMap['status'] ? salaryPayEnumValues((string)$paymentColumns[$paymentMap['status']]['Type']) : [];
        $hasPaymentEmployeeLink = !empty($paymentMap['teacher_id']) || !empty($paymentMap['staff_id']);

        // Read salary records. The salary page stores person names directly on its default schema.
        if (!$salaryMap['id']) throw new RuntimeException('The salaries table needs an id or salary_id column.');
        $salaryResult = $conn->query('SELECT * FROM `salaries` ORDER BY `' . str_replace('`', '``', $salaryMap['id']) . '` DESC');
        while ($row = $salaryResult->fetch_assoc()) {
            $id = (int)$row[$salaryMap['id']];
            $name = $salaryMap['name'] ? trim((string)($row[$salaryMap['name']] ?? '')) : '';
            if ($name === '') $name = 'Staff member #' . ($salaryMap['person_id'] ? (int)($row[$salaryMap['person_id']] ?? 0) : $id);
            $role = $salaryMap['role'] ? trim((string)($row[$salaryMap['role']] ?? '')) : '';
            $salaryNo = $salaryMap['number'] ? trim((string)($row[$salaryMap['number']] ?? '')) : '';
            $basic = $salaryMap['basic'] ? (float)($row[$salaryMap['basic']] ?? 0) : 0.0;
            $allowances = $salaryMap['allowances'] ? (float)($row[$salaryMap['allowances']] ?? 0) : 0.0;
            $deductions = $salaryMap['deductions'] ? (float)($row[$salaryMap['deductions']] ?? 0) : 0.0;
            $net = $salaryMap['net'] ? (float)($row[$salaryMap['net']] ?? 0) : ($basic + $allowances - $deductions);
            if ($net <= 0 && ($basic + $allowances - $deductions) > 0) $net = $basic + $allowances - $deductions;
            $status = $salaryMap['status'] ? ($row[$salaryMap['status']] ?? '') : 'active';
            $row['_salary_id'] = $id;
            $row['_teacher_id'] = $salaryMap['teacher_id'] ? (int)($row[$salaryMap['teacher_id']] ?? 0) : 0;
            $row['_staff_id'] = $salaryMap['staff_id'] ? (int)($row[$salaryMap['staff_id']] ?? 0) : 0;
            $row['_person_id'] = $salaryMap['person_id'] ? (int)($row[$salaryMap['person_id']] ?? 0) : 0;
            $row['_person_source'] = $salaryMap['person_source'] ? strtolower(trim((string)($row[$salaryMap['person_source']] ?? ''))) : '';
            // Normalize an explicitly typed generic person_id so payment history can resolve the name.
            if ($row['_teacher_id'] < 1 && $row['_staff_id'] < 1 && $row['_person_id'] > 0) {
                $sourceText = $row['_person_source'] . ' ' . strtolower($role);
                if (strpos($sourceText, 'teacher') !== false) $row['_teacher_id'] = $row['_person_id'];
                elseif (strpos($sourceText, 'staff') !== false || strpos($sourceText, 'employee') !== false) $row['_staff_id'] = $row['_person_id'];
            }
            $row['_person_name'] = $name;
            $row['_person_role'] = $role;
            $row['_salary_no'] = $salaryNo;
            $row['_expected_amount'] = max(0, $net);
            $row['_active'] = salaryPayIsActive($status);
            $salaryRows[] = $row;
            $salaryRowsById[$id] = $row;
            if ($row['_active']) $activeSalaryCount++;
        }
        $salaryResult->free();

        // Load available methods if the payment-method table is present.
        if ($paymentMap['method_id'] && in_array('payment_methods', $tables, true)) {
            $methodColumns = salaryPayColumns($conn, 'payment_methods');
            $methodIdCol = salaryPayFirstColumn($methodColumns, ['id', 'payment_method_id']);
            $methodNameCol = salaryPayFirstColumn($methodColumns, ['method_name', 'name', 'payment_method', 'title']);
            $methodStatusCol = salaryPayFirstColumn($methodColumns, ['status', 'is_active']);
            if ($methodIdCol && $methodNameCol) {
                $sql = 'SELECT `' . $methodIdCol . '` AS method_id, `' . $methodNameCol . '` AS method_name FROM `payment_methods`';
                if ($methodStatusCol && $methodStatusCol === 'is_active') $sql .= ' WHERE `' . $methodStatusCol . '` = 1';
                elseif ($methodStatusCol && strtolower((string)$methodColumns[$methodStatusCol]['Type']) === "enum('active','inactive')") $sql .= " WHERE `" . $methodStatusCol . "` = 'active'";
                $sql .= ' ORDER BY `' . $methodNameCol . '`';
                $mr = $conn->query($sql);
                while ($m = $mr->fetch_assoc()) {
                    $methodOptions[] = $m;
                    $methodLabels[(int)$m['method_id']] = (string)$m['method_name'];
                }
                $mr->free();
            }
        }
    }
} catch (Throwable $e) {
    error_log('salary_payments.php setup error: ' . $e->getMessage());
    $schemaError = $e instanceof RuntimeException ? $e->getMessage() : 'The salary payments page could not read the database structure. Check that the salaries table exists and review the PHP error log.';
}

// Save / reverse / cancel payments. CSRF checks happen before any database changes.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $schemaError === '' && $paymentTableExists) {
    $postedToken = (string)($_POST['csrf_token'] ?? '');
    if (!hash_equals($csrfToken, $postedToken)) {
        salaryPayFlash('danger', 'Your form session expired. Refresh this page and try again.');
        salaryPayRedirect();
    }
    $action = (string)($_POST['action'] ?? '');
    try {
        if ($action === 'record_payment') {
            if (!$paymentMap['salary_id'] && !$hasPaymentEmployeeLink) throw new RuntimeException('The salary_payments table needs salary_id, teacher_id, or staff_id to link each payment to a salary record.');
            if (!$paymentMap['amount']) throw new RuntimeException('The salary_payments table needs amount or net_salary to store the payment amount.');
            if (!$salaryMap['id']) throw new RuntimeException('The salaries table needs an id or salary_id column.');

            $salaryId = (int)($_POST['salary_id'] ?? 0);
            $amount = filter_var($_POST['amount'] ?? null, FILTER_VALIDATE_FLOAT);
            $period = trim((string)($_POST['salary_period'] ?? date('Y-m')));
            $paymentDateInput = trim((string)($_POST['payment_date'] ?? date('Y-m-d')));
            $methodId = (int)($_POST['payment_method_id'] ?? 0);
            $methodText = trim((string)($_POST['payment_method'] ?? 'Cash'));
            $reference = trim((string)($_POST['reference'] ?? ''));
            $notes = trim((string)($_POST['notes'] ?? ''));
            $periodDate = DateTime::createFromFormat('!Y-m', $period);
            $paymentDateObj = DateTime::createFromFormat('!Y-m-d', $paymentDateInput);

            if ($salaryId < 1 || !isset($salaryRowsById[$salaryId])) throw new RuntimeException('Please select a valid salary record. Add the staff member on the Staff Salaries page first if they are missing.');
            if (!$salaryRowsById[$salaryId]['_active']) throw new RuntimeException('This salary record is inactive. Activate it on the Staff Salaries page before recording a payment.');
            if ($amount === false || !is_finite((float)$amount) || (float)$amount <= 0) throw new RuntimeException('Enter a valid payment amount greater than zero.');
            if (!$periodDate || $periodDate->format('Y-m') !== $period) throw new RuntimeException('Choose a valid salary period.');
            if (!$paymentDateObj || $paymentDateObj->format('Y-m-d') !== $paymentDateInput) throw new RuntimeException('Choose a valid payment date.');
            $salary = $salaryRowsById[$salaryId];
            $loggedInUserId = salaryPayUserId();

            $values = [];
            $types = '';
            $addValue = static function (?string $column, $value, string $type) use (&$values, &$types, $paymentColumns): void {
                if (!$column || !isset($paymentColumns[$column])) return;
                $values[$column] = $value;
                $types .= $type;
            };
            if ($paymentMap['number']) $addValue($paymentMap['number'], salaryPayGenerateNumber($conn, 'salary_payments', $paymentMap['number'], 'SALPAY-'), 's');
            $addValue($paymentMap['salary_id'], $salaryId, 'i');
            $paymentTeacherId = (int)($salary['_teacher_id'] ?? 0);
            $paymentStaffId = (int)($salary['_staff_id'] ?? 0);
            // If the salaries table uses only a generic person_id, infer the employee source if it is explicit.
            if ($paymentTeacherId < 1 && $paymentStaffId < 1 && !empty($salary['_person_id'])) {
                $source = strtolower((string)($salary['_person_source'] ?? ''));
                $roleText = strtolower((string)($salary['_person_role'] ?? ''));
                if (strpos($source, 'teacher') !== false || strpos($roleText, 'teacher') !== false) $paymentTeacherId = (int)$salary['_person_id'];
                elseif (strpos($source, 'staff') !== false || strpos($source, 'employee') !== false || strpos($roleText, 'staff') !== false || strpos($roleText, 'employee') !== false) $paymentStaffId = (int)$salary['_person_id'];
            }
            if ($paymentMap['teacher_id']) $addValue($paymentMap['teacher_id'], $paymentTeacherId > 0 ? $paymentTeacherId : null, 'i');
            if ($paymentMap['staff_id']) $addValue($paymentMap['staff_id'], $paymentStaffId > 0 ? $paymentStaffId : null, 'i');
            $employeeLinkWillBeStored = ($paymentMap['teacher_id'] && $paymentTeacherId > 0) || ($paymentMap['staff_id'] && $paymentStaffId > 0);
            if (!$paymentMap['salary_id'] && !$employeeLinkWillBeStored) {
                throw new RuntimeException('This salary record cannot be linked to a teacher or staff member in salary_payments. Make sure the salaries table has teacher_id or staff_id matching the employee, or a person_source/employee_type field identifying person_id.');
            }
            if ($paymentMap['basic']) $addValue($paymentMap['basic'], (float)($salaryMap['basic'] ? ($salary[$salaryMap['basic']] ?? 0) : 0), 'd');
            if ($paymentMap['allowances']) $addValue($paymentMap['allowances'], (float)($salaryMap['allowances'] ? ($salary[$salaryMap['allowances']] ?? 0) : 0), 'd');
            if ($paymentMap['deductions']) $addValue($paymentMap['deductions'], (float)($salaryMap['deductions'] ? ($salary[$salaryMap['deductions']] ?? 0) : 0), 'd');
            if ($paymentMap['salary_no']) $addValue($paymentMap['salary_no'], ($salary['_salary_no'] !== '' ? $salary['_salary_no'] : null), 's');
            if ($paymentMap['name']) $addValue($paymentMap['name'], $salary['_person_name'], 's');
            if ($paymentMap['role']) $addValue($paymentMap['role'], ($salary['_person_role'] !== '' ? $salary['_person_role'] : null), 's');
            if ($paymentMap['period']) {
                $periodColumnType = strtolower((string)($paymentColumns[$paymentMap['period']]['Type'] ?? ''));
                $periodToStore = $period;
                if (strpos($periodColumnType, 'date') !== false || strpos($periodColumnType, 'datetime') !== false || strpos($periodColumnType, 'timestamp') !== false) {
                    $periodToStore = $period . '-01';
                    if (strpos($periodColumnType, 'datetime') !== false || strpos($periodColumnType, 'timestamp') !== false) $periodToStore .= ' ' . date('H:i:s');
                }
                $addValue($paymentMap['period'], $periodToStore, 's');
            }
            $addValue($paymentMap['amount'], (float)$amount, 'd');
            if ($paymentMap['date']) {
                $dateType = strtolower((string)($paymentColumns[$paymentMap['date']]['Type'] ?? ''));
                $dateToStore = $paymentDateInput;
                if (strpos($dateType, 'datetime') !== false || strpos($dateType, 'timestamp') !== false) $dateToStore .= ' ' . date('H:i:s');
                $addValue($paymentMap['date'], $dateToStore, 's');
            }
            if ($paymentMap['method_id']) $addValue($paymentMap['method_id'], $methodId > 0 ? $methodId : null, 'i');
            if ($paymentMap['method_text']) $addValue($paymentMap['method_text'], ($methodText !== '' ? $methodText : null), 's');
            if ($paymentMap['reference']) $addValue($paymentMap['reference'], ($reference !== '' ? $reference : null), 's');
            if ($paymentMap['notes']) $addValue($paymentMap['notes'], ($notes !== '' ? $notes : null), 's');
            if ($paymentMap['paid_by']) {
                if ($loggedInUserId < 1 && strtoupper((string)$paymentColumns[$paymentMap['paid_by']]['Null']) === 'NO' && $paymentColumns[$paymentMap['paid_by']]['Default'] === null) {
                    throw new RuntimeException('Your logged-in user ID could not be identified. Sign out and sign back in, then try again.');
                }
                $addValue($paymentMap['paid_by'], $loggedInUserId ?: null, 'i');
            }
            if ($paymentMap['status']) $addValue($paymentMap['status'], salaryPayStatusForColumn($paymentColumns[$paymentMap['status']], 'completed'), 's');

            // Do not submit partial data into an unknown schema: detect unmapped required columns first.
            foreach ($paymentColumns as $columnName => $columnInfo) {
                if (array_key_exists($columnName, $values)) continue;
                if (stripos((string)$columnInfo['Extra'], 'auto_increment') !== false) continue;
                if (strtoupper((string)$columnInfo['Null']) === 'YES') continue;
                if ($columnInfo['Default'] !== null) continue;
                throw new RuntimeException('The salary_payments table has an unmapped required column named `' . $columnName . '` with no default value. Please share its Structure tab so the insert can be matched to your database.');
            }
            if (!$values) throw new RuntimeException('No compatible fields were found in the salary_payments table.');
            $columnSql = implode(', ', array_map(static fn($col) => '`' . str_replace('`', '``', $col) . '`', array_keys($values)));
            $placeholders = implode(', ', array_fill(0, count($values), '?'));
            $stmt = $conn->prepare('INSERT INTO `salary_payments` (' . $columnSql . ') VALUES (' . $placeholders . ')');
            salaryPayBind($stmt, $types, $values);
            $stmt->execute();
            $newId = $stmt->insert_id;
            $stmt->close();
            $paymentNumber = $paymentMap['number'] ? (string)($values[$paymentMap['number']] ?? '') : '';
            $message = 'Salary payment recorded for ' . $salary['_person_name'] . '. Amount: UGX ' . number_format((float)$amount, 2) . '.';
            if ($paymentNumber !== '') $message .= ' Payment No: ' . $paymentNumber . '.';
            if ($newId) $message .= ' Record ID: #' . $newId . '.';
            salaryPayFlash('success', $message);
            salaryPayRedirect();
        } elseif ($action === 'change_status') {
            if (!$paymentMap['id'] || !$paymentMap['status']) throw new RuntimeException('The salary_payments table does not support payment status changes.');
            $paymentId = (int)($_POST['payment_id'] ?? 0);
            $newStatus = trim((string)($_POST['new_status'] ?? ''));
            $enumValues = salaryPayEnumValues((string)$paymentColumns[$paymentMap['status']]['Type']);
            if ($paymentId < 1 || !in_array($newStatus, ['cancelled', 'reversed'], true)) throw new RuntimeException('Invalid payment status action.');
            if ($enumValues && !in_array($newStatus, $enumValues, true)) throw new RuntimeException('Your database does not support the requested payment status.');
            $stmt = $conn->prepare('SELECT `' . $paymentMap['status'] . '` FROM `salary_payments` WHERE `' . $paymentMap['id'] . '` = ? LIMIT 1');
            $stmt->bind_param('i', $paymentId);
            $stmt->execute();
            $currentStatusRow = $stmt->get_result()->fetch_row();
            $stmt->close();
            if (!$currentStatusRow) throw new RuntimeException('Payment record not found.');
            if (!salaryPayIsCompleted($currentStatusRow[0])) throw new RuntimeException('Only a completed payment can be cancelled or reversed.');
            $stmt = $conn->prepare('UPDATE `salary_payments` SET `' . $paymentMap['status'] . '` = ? WHERE `' . $paymentMap['id'] . '` = ?');
            $stmt->bind_param('si', $newStatus, $paymentId);
            $stmt->execute();
            $stmt->close();
            salaryPayFlash('success', 'Payment #' . $paymentId . ' marked as ' . $newStatus . '. The original payment record was retained for audit purposes.');
            salaryPayRedirect();
        }
    } catch (Throwable $e) {
        error_log('salary_payments.php save error: ' . $e->getMessage());
        $message = $e instanceof RuntimeException ? $e->getMessage() : 'The salary payment could not be saved. Check the salary_payments table structure and PHP error log.';
        salaryPayFlash('danger', $message);
        salaryPayRedirect();
    }
}

// Reload flash after post/redirect/get.
$flash = $_SESSION['salary_payments_flash'] ?? $flash;
unset($_SESSION['salary_payments_flash']);

$records = [];
$allPaymentCount = 0;
if ($schemaError === '' && $paymentTableExists && $paymentMap) {
    try {
        if ((!$paymentMap['salary_id'] && !$hasPaymentEmployeeLink) || !$paymentMap['amount']) {
            $schemaError = 'The salary_payments table must have salary_id, teacher_id or staff_id, and amount or net_salary columns to show payment history.';
        } else {
            $where = [];
            $whereValues = [];
            $whereTypes = '';
            if ($search !== '') {
                $searchParts = [];
                foreach (['number', 'salary_no', 'name', 'role', 'period', 'reference', 'notes', 'method_text'] as $key) {
                    $col = $paymentMap[$key] ?? null;
                    if ($col) $searchParts[] = 'CAST(p.`' . str_replace('`', '``', $col) . '` AS CHAR) LIKE ?';
                }
                if ($paymentMap['salary_id']) $searchParts[] = 'CAST(p.`' . str_replace('`', '``', $paymentMap['salary_id']) . '` AS CHAR) LIKE ?';
                if ($paymentMap['teacher_id']) $searchParts[] = 'CAST(p.`' . str_replace('`', '``', $paymentMap['teacher_id']) . '` AS CHAR) LIKE ?';
                if ($paymentMap['staff_id']) $searchParts[] = 'CAST(p.`' . str_replace('`', '``', $paymentMap['staff_id']) . '` AS CHAR) LIKE ?';
                if ($searchParts) {
                    $where[] = '(' . implode(' OR ', $searchParts) . ')';
                    $like = '%' . $search . '%';
                    foreach ($searchParts as $unused) { $whereValues[] = $like; $whereTypes .= 's'; }
                }
            }
            if ($paymentMap['date'] && $dateFrom !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom)) {
                $where[] = 'DATE(p.`' . str_replace('`', '``', $paymentMap['date']) . '`) >= ?';
                $whereValues[] = $dateFrom; $whereTypes .= 's';
            }
            if ($paymentMap['date'] && $dateTo !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo)) {
                $where[] = 'DATE(p.`' . str_replace('`', '``', $paymentMap['date']) . '`) <= ?';
                $whereValues[] = $dateTo; $whereTypes .= 's';
            }
            if ($paymentMap['status'] && $statusFilter !== '') {
                $where[] = 'p.`' . str_replace('`', '``', $paymentMap['status']) . '` = ?';
                $whereValues[] = $statusFilter; $whereTypes .= 's';
            }
            $whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';
            $countSql = 'SELECT COUNT(*) AS total FROM `salary_payments` p' . $whereSql;
            $countStmt = $conn->prepare($countSql);
            if ($whereTypes !== '') {
                $bindValues = $whereValues;
                salaryPayBind($countStmt, $whereTypes, $bindValues);
            }
            $countStmt->execute();
            $allPaymentCount = (int)($countStmt->get_result()->fetch_assoc()['total'] ?? 0);
            $countStmt->close();
            $totalPages = max(1, (int)ceil($allPaymentCount / $perPage));
            if ($page > $totalPages) $page = $totalPages;
            $offset = ($page - 1) * $perPage;
            $orderColumn = $paymentMap['date'] ?: ($paymentMap['id'] ?: $paymentMap['number']);
            $sql = 'SELECT p.* FROM `salary_payments` p' . $whereSql;
            if ($orderColumn) $sql .= ' ORDER BY p.`' . str_replace('`', '``', $orderColumn) . '` DESC';
            $sql .= ' LIMIT ' . (int)$perPage . ' OFFSET ' . (int)$offset;
            $stmt = $conn->prepare($sql);
            if ($whereTypes !== '') {
                $bindValues = $whereValues;
                salaryPayBind($stmt, $whereTypes, $bindValues);
            }
            $stmt->execute();
            $rs = $stmt->get_result();
            while ($row = $rs->fetch_assoc()) $paymentRows[] = $row;
            $stmt->close();

            // Summary values use the selected date/status/search filters.
            $amountCol = $paymentMap['amount'];
            $statusCol = $paymentMap['status'];
            $completedValue = $statusCol ? salaryPayStatusForColumn($paymentColumns[$statusCol], 'completed') : '';
            $summarySql = 'SELECT COUNT(*) AS total_count, COALESCE(SUM(CASE WHEN ' . ($statusCol ? 'p.`' . str_replace('`', '``', $statusCol) . '` = ?' : '1=1') . ' THEN p.`' . str_replace('`', '``', $amountCol) . '` ELSE 0 END),0) AS completed_amount';
            if ($paymentMap['date']) $summarySql .= ', COALESCE(SUM(CASE WHEN ' . ($statusCol ? 'p.`' . str_replace('`', '``', $statusCol) . '` = ? AND ' : '') . 'DATE(p.`' . str_replace('`', '``', $paymentMap['date']) . '`) >= ? THEN p.`' . str_replace('`', '``', $amountCol) . '` ELSE 0 END),0) AS month_amount';
            $summarySql .= ' FROM `salary_payments` p' . $whereSql;
            $sumStmt = $conn->prepare($summarySql);
            $summaryTypes = '';
            $summaryValues = [];
            if ($statusCol) { $summaryValues[] = $completedValue; $summaryTypes .= 's'; }
            if ($paymentMap['date']) {
                if ($statusCol) { $summaryValues[] = $completedValue; $summaryTypes .= 's'; }
                $summaryValues[] = date('Y-m-01'); $summaryTypes .= 's';
            }
            foreach ($whereValues as $idx => $val) { $summaryValues[] = $val; $summaryTypes .= $whereTypes[$idx] ?? 's'; }
            if ($summaryTypes !== '') salaryPayBind($sumStmt, $summaryTypes, $summaryValues);
            $sumStmt->execute();
            $sumRow = $sumStmt->get_result()->fetch_assoc() ?: [];
            $totalPaymentCount = (int)($sumRow['total_count'] ?? 0);
            $totalCompletedAmount = (float)($sumRow['completed_amount'] ?? 0);
            $thisMonthCompletedAmount = (float)($sumRow['month_amount'] ?? 0);
            $sumStmt->close();
        }
    } catch (Throwable $e) {
        error_log('salary_payments.php history error: ' . $e->getMessage());
        $pageError = 'Payment history could not be loaded. Check the salary_payments table structure and PHP error log.';
    }
}

$methodColType = $paymentMap['method_id'] ? strtolower((string)($paymentColumns[$paymentMap['method_id']]['Type'] ?? '')) : '';
$hasMethodOptions = !empty($methodOptions) && !empty($paymentMap['method_id']);
$canChangeStatus = !empty($paymentMap['id']) && !empty($paymentMap['status']) && (!$statusValues || (in_array('cancelled', $statusValues, true) || in_array('reversed', $statusValues, true)));
$defaultPaymentMethod = 'Cash';
$statusOptionsForFilter = $statusValues ?: ['completed', 'cancelled', 'reversed'];
$schemaSql = "CREATE TABLE `salary_payments` (\n  `id` INT(11) NOT NULL AUTO_INCREMENT,\n  `payment_no` VARCHAR(50) NOT NULL,\n  `salary_id` INT(11) NOT NULL,\n  `salary_no` VARCHAR(50) DEFAULT NULL,\n  `person_name` VARCHAR(150) NOT NULL,\n  `person_role` VARCHAR(100) DEFAULT NULL,\n  `salary_period` VARCHAR(7) NOT NULL,\n  `amount` DECIMAL(12,2) NOT NULL,\n  `payment_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,\n  `payment_method_id` INT(11) DEFAULT NULL,\n  `reference_no` VARCHAR(100) DEFAULT NULL,\n  `description` TEXT DEFAULT NULL,\n  `paid_by` INT(11) NOT NULL,\n  `status` ENUM('completed','cancelled','reversed') NOT NULL DEFAULT 'completed',\n  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n  PRIMARY KEY (`id`), UNIQUE KEY `uq_salary_payment_no` (`payment_no`), KEY `idx_salary_payment_salary` (`salary_id`), KEY `idx_salary_payment_date` (`payment_date`), KEY `idx_salary_payment_period` (`salary_period`), KEY `idx_salary_payment_status` (`status`)\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Salary Payments | School Management System</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
        body {
            background: #f5f6fa;
            font-family: Arial, sans-serif;
            color: #263348;
            margin: 0;
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            width: 250px;
            background: #212529;
            z-index: 1030;
            overflow-y: auto;
            color: #fff;
        }

        .sidebar-header {
            padding: 20px 15px;
            color: #fff;
            font-weight: 700;
            border-bottom: 1px solid rgba(255,255,255,.1);
        }

        .sidebar-menu {
            padding: 15px 10px;
        }

        .sidebar-section {
            color: #6c757d;
            font-size: 11px;
            text-transform: uppercase;
            padding: 12px 10px 6px;
        }

        .sidebar a {
            display: block;
            color: #ced4da;
            padding: 12px 15px;
            margin-bottom: 3px;
            text-decoration: none;
            border-radius: 6px;
            font-size: 13px;
        }

        .sidebar a:hover {
            background: #343a40;
            color: #fff;
        }

        .sidebar a.active {
            background: #dc3545;
            color: #fff;
        }

        .sidebar i {
            width: 25px;
            text-align: center;
            margin-right: 5px;
        }

        .main-content {
            margin-left: 250px;
            padding: 25px;
            min-height: 100vh;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            margin-bottom: 22px;
        }

        .topbar h2 {
            font-size: 25px;
            margin: 0;
            font-weight: 700;
            color: #192940;
        }

        .subheading {
            color: #6c757d;
            font-size: 13px;
            margin-top: 5px;
        }

        .panel {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,.05);
            padding: 22px;
            margin-bottom: 22px;
            border: none;
        }

        .panel-title {
            font-size: 17px;
            font-weight: 700;
            margin-bottom: 17px;
            color: #1d2d44;
        }

        .stat-card {
            background: #fff;
            border: none;
            border-radius: 10px;
            padding: 17px 19px;
            box-shadow: 0 2px 10px rgba(0,0,0,.06);
            height: 100%;
        }

        .stat-card .label {
            color: #6c757d;
            font-size: 13px;
        }

        .stat-card .value {
            font-size: 24px;
            font-weight: 700;
            margin-top: 6px;
        }

        .stat-card .symbol {
            float: right;
            width: 38px;
            height: 38px;
            line-height: 38px;
            text-align: center;
            border-radius: 9px;
            background: #eef4ff;
            color: #326bd1;
        }

        .form-control,
        .custom-select {
            border-radius: 6px;
            font-size: 13px;
            min-height: 38px;
        }

        label {
            font-size: 12px;
            color: #4e5c70;
            font-weight: 600;
        }

        .table th {
            background: #f8f9fa;
            border-top: none;
            font-size: 13px;
            white-space: nowrap;
        }

        .table td {
            vertical-align: middle;
            font-size: 13px;
        }

        .table thead th {
            color: #68768a;
            text-transform: uppercase;
            letter-spacing: .4px;
        }

        .btn {
            border-radius: 6px;
            font-size: 12px;
        }

        .btn-primary {
            background: #2865cf;
            border-color: #2865cf;
        }

        .badge {
            font-size: 10px;
            padding: 6px 8px;
        }

        .empty-state {
            padding: 35px 10px;
            text-align: center;
            color: #8290a4;
        }

        .empty-state i {
            font-size: 30px;
            margin-bottom: 12px;
            color: #bec8d7;
        }

        .footer-note {
            text-align: center;
            color: #97a1b1;
            font-size: 11px;
            padding: 7px 0 0;
        }

        .help-text,
        .small-muted {
            font-size: 11px;
            color: #8490a1;
        }

        .amount-field {
            font-weight: 700;
            font-size: 16px;
        }

        .alert {
            font-size: 13px;
        }

        @media (max-width: 991px) {
            .sidebar {
                width: 220px;
            }
            .main-content {
                margin-left: 220px;
            }
        }

        @media (max-width: 767px) {
            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
                top: auto;
                left: auto;
                bottom: auto;
            }
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            .topbar {
                align-items: flex-start;
                flex-direction: column;
            }
            .table-responsive {
                font-size: 12px;
            }
        }

        @media print {
            .sidebar,
            .no-print,
            #paymentForm,
            .footer-note {
                display: none !important;
            }
            .main-content {
                margin: 0;
                padding: 0;
            }
            body {
                background: #fff;
            }
            .panel,
            .stat-card {
                box-shadow: none;
                border: 0;
            }
            .table {
                font-size: 10px;
            }
        }
    </style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<button type="button" id="unifiedSidebarToggle" class="unified-sidebar-toggle" aria-label="Open navigation" aria-controls="sidebar" aria-expanded="false"><i class="fas fa-bars"></i></button>
<div id="unifiedSidebarOverlay" class="sidebar-overlay"></div>

<div class="sidebar no-print">
    <div class="sidebar-header">
        <i class="fas fa-university"></i>
        <span>Bursar</span>
    </div>

    <div class="sidebar-menu">
        <a href="/admin/bursar/index.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a>

        <div class="sidebar-section">Students &amp; Fees</div>
        <a href="/admin/bursar/students_fees.php"><i class="fas fa-file-invoice-dollar"></i>Student Fees</a>
        <a href="/admin/bursar/students_fee_accounts.php"><i class="fas fa-file-invoice-dollar"></i>Student Fee Accounts</a>
        <a href="/admin/bursar/fee_structure.php"><i class="fas fa-list-alt"></i>Fee Structure</a>
        <a href="/admin/bursar/payments.php"><i class="fas fa-money-bill-wave"></i>Receive Payment</a>
        <a href="/admin/bursar/outstanding_fees.php"><i class="fas fa-exclamation-circle"></i>Outstanding Fees</a>

        <div class="sidebar-section">Finance</div>
        <a href="/admin/bursar/income.php"><i class="fas fa-arrow-circle-down"></i>Income</a>
        <a href="/admin/bursar/expenses.php"><i class="fas fa-arrow-circle-up"></i>Expenses</a>
        <a href="/admin/bursar/suppliers.php"><i class="fas fa-truck"></i>Suppliers</a>
        <a href="/admin/bursar/supplier_payments.php"><i class="fas fa-hand-holding-usd"></i>Supplier Payments</a>

        <div class="sidebar-section">Payroll &amp; Budget</div>
        <a href="/admin/bursar/salaries.php"><i class="fas fa-users"></i>Salaries</a>
        <a href="/admin/bursar/salary_payments.php" class="active" aria-current="page"><i class="fas fa-money-check-alt"></i>Salary Payments</a>
        <a href="/admin/bursar/budgets.php"><i class="fas fa-chart-pie"></i>Budgets</a>

        <div class="sidebar-section">Reports</div>
        <a href="/admin/bursar/cashbook.php"><i class="fas fa-book"></i>Cashbook</a>
        <a href="/admin/bursar/financial_reports.php"><i class="fas fa-chart-line"></i>Financial Reports</a>
        <a href="/admin/bursar/income_report.php"><i class="fas fa-file-invoice"></i>Income Report</a>
        <a href="/admin/bursar/expense_report.php"><i class="fas fa-receipt"></i>Expense Report</a>
        <a href="/admin/bursar/fees_report.php"><i class="fas fa-file-alt"></i>Fees Report</a>
        <a href="/admin/bursar/profit_loss.php"><i class="fas fa-balance-scale"></i>Profit &amp; Loss</a>

        <div class="sidebar-section">System</div>
        <a href="/admin/dashboard.php"><i class="fas fa-user-shield"></i>Admin Dashboard</a>
        <a href="/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
    </div>
</div>
<div class="main-content">
 <header class="topbar"><div class="d-flex align-items-start"><div><div class="text-uppercase text-primary small font-weight-bold">Human resources / payroll</div><h2>Salary Payments</h2><div class="subheading">Record and track actual salary disbursements for teaching and non-teaching staff.</div></div></div><div class="no-print"><button type="button" class="btn btn-outline-primary" onclick="window.print()"><i class="fas fa-print mr-1"></i>Print</button></div></header>
 <?php if ($flash): ?><div class="alert alert-<?= salaryPayE($flash['type'] ?? 'info') ?> alert-dismissible fade show" role="alert"><?= salaryPayE($flash['message'] ?? '') ?><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div><?php endif; ?>
 <?php if ($createdPaymentTable): ?><div class="alert alert-info"><i class="fas fa-info-circle mr-1"></i>The <code>salary_payments</code> table did not exist, so the page created it using the payroll payment structure shown below.</div><?php endif; ?>
 <?php if ($schemaError !== ''): ?><div class="alert alert-danger"><strong>Database setup needs attention.</strong><br><?= salaryPayE($schemaError) ?><?php if (!$paymentTableExists && $salaryTableExists): ?><details class="mt-2"><summary>SQL to create salary_payments table</summary><pre class="mt-2 mb-0" style="white-space:pre-wrap"><?= salaryPayE($schemaSql) ?></pre></details><?php endif; ?></div><?php endif; ?>
 <?php if ($pageError !== ''): ?><div class="alert alert-warning"><?= salaryPayE($pageError) ?></div><?php endif; ?>
 <div class="row mb-4">
  <div class="col-md-6 col-xl-4 mb-3"><div class="stat-card"><span class="symbol"><i class="fas fa-receipt"></i></span><div class="label">Payments in current results</div><div class="value"><?= number_format($totalPaymentCount) ?></div></div></div>
  <div class="col-md-6 col-xl-4 mb-3"><div class="stat-card"><span class="symbol" style="background:#e1f7ef;color:#15945e"><i class="fas fa-wallet"></i></span><div class="label">Completed amount in results</div><div class="value">UGX <?= number_format($totalCompletedAmount, 2) ?></div></div></div>
  <div class="col-md-12 col-xl-4 mb-3"><div class="stat-card"><span class="symbol" style="background:#fff1dd;color:#b77516"><i class="fas fa-calendar-check"></i></span><div class="label">Completed this month (current filters)</div><div class="value">UGX <?= number_format($thisMonthCompletedAmount, 2) ?></div></div></div>
 </div>
 <section class="panel" id="paymentForm"><div class="panel-title"><i class="fas fa-plus-circle text-primary mr-2"></i>Record a Salary Payment</div>
  <?php if ($schemaError === '' && ((!$paymentMap['salary_id'] && !$hasPaymentEmployeeLink) || !$paymentMap['amount'])): ?><div class="alert alert-warning mb-0">The salary_payments table needs a salary record/employee link and an amount or net_salary column. Please check the table structure.</div>
  <?php elseif ($schemaError === ''): ?>
  <form method="POST" action="salary_payments.php" id="salaryPaymentForm"><input type="hidden" name="csrf_token" value="<?= salaryPayE($csrfToken) ?>"><input type="hidden" name="action" value="record_payment">
   <div class="form-row">
    <div class="form-group col-lg-6"><label for="salary_id">Staff salary record <span class="text-danger">*</span></label><select class="form-control" name="salary_id" id="salary_id" required><option value="">Select a staff salary record</option><?php foreach ($salaryRows as $salary): if (!$salary['_active']) continue; ?><option value="<?= (int)$salary['_salary_id'] ?>" data-amount="<?= number_format((float)$salary['_expected_amount'], 2, '.', '') ?>" data-name="<?= salaryPayE($salary['_person_name']) ?>"><?= salaryPayE($salary['_person_name']) ?><?= $salary['_person_role'] !== '' ? ' — ' . salaryPayE($salary['_person_role']) : '' ?><?= $salary['_salary_no'] !== '' ? ' (' . salaryPayE($salary['_salary_no']) . ')' : '' ?> — Expected: UGX <?= number_format((float)$salary['_expected_amount'], 2) ?></option><?php endforeach; ?></select><?php if ($activeSalaryCount === 0): ?><small class="text-danger d-block mt-1">No active salary records found. Add or activate salary records first on <a href="salaries.php">Staff Salaries</a>.</small><?php else: ?><small class="help-text">This list uses active salary records. Add a staff member or salary record on the Staff Salaries page if someone is missing.</small><?php endif; ?></div>
    <div class="form-group col-lg-3"><label for="salary_period">Salary period <span class="text-danger">*</span></label><input class="form-control" type="month" name="salary_period" id="salary_period" value="<?= salaryPayE(date('Y-m')) ?>" required><small class="help-text">Month and year the salary covers.</small></div>
    <div class="form-group col-lg-3"><label for="payment_date">Payment date <span class="text-danger">*</span></label><input class="form-control" type="date" name="payment_date" id="payment_date" value="<?= salaryPayE(date('Y-m-d')) ?>" required></div>
   </div>
   <div class="form-row">
    <div class="form-group col-lg-3"><label for="amount">Amount paid (UGX) <span class="text-danger">*</span></label><input class="form-control amount-field" type="number" name="amount" id="amount" min="0.01" step="0.01" required placeholder="0.00"><small class="help-text">Pre-filled with expected net salary; edit for a partial payment.</small></div>
    <?php if ($paymentMap['method_id']): ?><div class="form-group col-lg-3"><label for="payment_method_id">Payment method</label><?php if ($hasMethodOptions): ?><select class="form-control" name="payment_method_id" id="payment_method_id"><option value="">Not specified</option><?php foreach ($methodOptions as $method): ?><option value="<?= (int)$method['method_id'] ?>"><?= salaryPayE($method['method_name']) ?></option><?php endforeach; ?></select><?php else: ?><input class="form-control" type="number" min="1" name="payment_method_id" id="payment_method_id" placeholder="Payment method ID (optional)"><small class="help-text">No readable payment_methods list found; leave empty or enter an existing ID.</small><?php endif; ?></div><?php elseif ($paymentMap['method_text']): ?><div class="form-group col-lg-3"><label for="payment_method">Payment method</label><select class="form-control" name="payment_method" id="payment_method"><option>Cash</option><option>Bank Transfer</option><option>Mobile Money</option><option>Cheque</option><option>Other</option></select></div><?php endif; ?>
    <?php if ($paymentMap['reference']): ?><div class="form-group col-lg-3"><label for="reference">Reference / receipt number</label><input class="form-control" type="text" name="reference" id="reference" maxlength="100" placeholder="Bank or mobile money reference"></div><?php endif; ?>
    <?php if ($paymentMap['notes']): ?><div class="form-group col-lg-<?= ($paymentMap['method_id'] || $paymentMap['method_text']) && $paymentMap['reference'] ? '3' : '6' ?>"><label for="notes">Description / notes</label><input class="form-control" type="text" name="notes" id="notes" maxlength="500" placeholder="Optional payment notes"></div><?php endif; ?>
   </div>
   <button type="submit" class="btn btn-primary" id="recordPaymentButton" <?= $activeSalaryCount === 0 ? 'disabled' : '' ?>><i class="fas fa-save mr-1"></i>Record Salary Payment</button> <button type="reset" class="btn btn-outline-secondary"><i class="fas fa-undo mr-1"></i>Clear</button>
  </form>
  <?php endif; ?>
 </section>
 <section class="panel"><div class="d-flex flex-wrap align-items-center justify-content-between mb-3"><div class="panel-title mb-2"><i class="fas fa-list mr-2 text-primary"></i>Salary Payment History</div><span class="text-muted small mb-2"><?= number_format($allPaymentCount) ?> record(s)</span></div>
  <form method="GET" action="salary_payments.php" class="form-row align-items-end mb-3 no-print">
   <div class="form-group col-lg-4 col-md-6 mb-2"><label for="q">Search payments</label><input class="form-control" type="search" name="q" id="q" value="<?= salaryPayE($search) ?>" placeholder="Payment no., staff, salary no. or reference"></div>
   <div class="form-group col-lg-2 col-md-3 mb-2"><label for="from">From date</label><input class="form-control" type="date" name="from" id="from" value="<?= salaryPayE($dateFrom) ?>"></div>
   <div class="form-group col-lg-2 col-md-3 mb-2"><label for="to">To date</label><input class="form-control" type="date" name="to" id="to" value="<?= salaryPayE($dateTo) ?>"></div>
   <?php if ($paymentMap['status']): ?><div class="form-group col-lg-2 col-md-4 mb-2"><label for="status">Status</label><select class="form-control" name="status" id="status"><option value="">All statuses</option><?php foreach ($statusOptionsForFilter as $statusOption): ?><option value="<?= salaryPayE($statusOption) ?>" <?= $statusFilter === $statusOption ? 'selected' : '' ?>><?= salaryPayE(ucwords(str_replace('_', ' ', $statusOption))) ?></option><?php endforeach; ?></select></div><?php endif; ?>
   <div class="form-group col-lg-2 col-md-8 mb-2"><button type="submit" class="btn btn-primary mr-1"><i class="fas fa-search mr-1"></i>Filter</button><a href="salary_payments.php" class="btn btn-outline-secondary">Reset</a></div>
  </form>
  <div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Payment no.</th><th>Staff member</th><th>Salary period</th><th>Payment date</th><th>Method / reference</th><th>Status</th><th class="text-right">Amount (UGX)</th><th class="no-print">Actions</th></tr></thead><tbody>
  <?php if (!$paymentRows): ?><tr><td colspan="8"><div class="empty-state"><i class="fas fa-file-invoice-dollar d-block"></i><strong>No salary payments found</strong><div class="small mt-1">Record a payment above or adjust your filters.</div></div></td></tr><?php else: foreach ($paymentRows as $payment):
    $rowId = $paymentMap['id'] ? (int)($payment[$paymentMap['id']] ?? 0) : 0;
    $paymentNo = $paymentMap['number'] ? trim((string)($payment[$paymentMap['number']] ?? '')) : '';
    $salaryId = $paymentMap['salary_id'] ? (int)($payment[$paymentMap['salary_id']] ?? 0) : 0;
    $linkedSalary = $salaryId ? ($salaryRowsById[$salaryId] ?? null) : null;
    if (!$linkedSalary) {
        $paymentTeacherId = $paymentMap['teacher_id'] ? (int)($payment[$paymentMap['teacher_id']] ?? 0) : 0;
        $paymentStaffId = $paymentMap['staff_id'] ? (int)($payment[$paymentMap['staff_id']] ?? 0) : 0;
        foreach ($salaryRows as $candidateSalary) {
            if (($paymentTeacherId > 0 && (int)$candidateSalary['_teacher_id'] === $paymentTeacherId) || ($paymentStaffId > 0 && (int)$candidateSalary['_staff_id'] === $paymentStaffId)) {
                $linkedSalary = $candidateSalary;
                break;
            }
        }
    }
    $personName = $paymentMap['name'] ? trim((string)($payment[$paymentMap['name']] ?? '')) : '';
    if ($personName === '' && $linkedSalary) $personName = (string)$linkedSalary['_person_name'];
    if ($personName === '') {
        $employeeId = $paymentMap['teacher_id'] ? (int)($payment[$paymentMap['teacher_id']] ?? 0) : 0;
        if ($employeeId < 1 && $paymentMap['staff_id']) $employeeId = (int)($payment[$paymentMap['staff_id']] ?? 0);
        $personName = 'Staff member #' . ($employeeId ?: $salaryId ?: $rowId);
    }
    $personRole = $paymentMap['role'] ? trim((string)($payment[$paymentMap['role']] ?? '')) : '';
    if ($personRole === '' && $linkedSalary) $personRole = (string)$linkedSalary['_person_role'];
    $salaryNo = $paymentMap['salary_no'] ? trim((string)($payment[$paymentMap['salary_no']] ?? '')) : '';
    if ($salaryNo === '' && $linkedSalary) $salaryNo = (string)$linkedSalary['_salary_no'];
    $periodLabel = $paymentMap['period'] ? trim((string)($payment[$paymentMap['period']] ?? '')) : '';
    if (preg_match('/^\d{4}-\d{2}-\d{2}/', $periodLabel)) {
        $periodTimestamp = strtotime($periodLabel);
        if ($periodTimestamp) $periodLabel = date('M Y', $periodTimestamp);
    } elseif (preg_match('/^\d{4}-\d{2}$/', $periodLabel)) {
        $periodTimestamp = strtotime($periodLabel . '-01');
        if ($periodTimestamp) $periodLabel = date('M Y', $periodTimestamp);
    }
    $paidAt = $paymentMap['date'] ? ($payment[$paymentMap['date']] ?? '') : '';
    $methodLabel = $paymentMap['method_text'] ? trim((string)($payment[$paymentMap['method_text']] ?? '')) : '';
    if ($methodLabel === '' && $paymentMap['method_id']) {
        $methodIdForRow = (int)($payment[$paymentMap['method_id']] ?? 0);
        $methodLabel = $methodLabels[$methodIdForRow] ?? ($methodIdForRow > 0 ? 'Method ID ' . $methodIdForRow : '');
    }
    $referenceLabel = $paymentMap['reference'] ? trim((string)($payment[$paymentMap['reference']] ?? '')) : '';
    $notesLabel = $paymentMap['notes'] ? trim((string)($payment[$paymentMap['notes']] ?? '')) : '';
    $statusLabel = $paymentMap['status'] ? trim((string)($payment[$paymentMap['status']] ?? 'completed')) : 'Recorded';
    $isCompleted = salaryPayIsCompleted($statusLabel);
    $isReversed = in_array(strtolower($statusLabel), ['cancelled', 'canceled', 'reversed', 'void'], true);
    $availableActions = $statusValues ?: ['completed', 'cancelled', 'reversed'];
    ?><tr>
      <td><strong><?= $paymentNo !== '' ? salaryPayE($paymentNo) : ($rowId ? '#' . $rowId : 'Payment') ?></strong><?php if ($salaryNo !== ''): ?><div class="small-muted">Salary: <?= salaryPayE($salaryNo) ?></div><?php endif; ?><?php if ($rowId && $paymentNo !== ''): ?><div class="small-muted">ID: #<?= $rowId ?></div><?php endif; ?></td>
      <td><strong><?= salaryPayE($personName) ?></strong><?php if ($personRole !== ''): ?><div class="small-muted"><?= salaryPayE($personRole) ?></div><?php endif; ?></td>
      <td><?= $periodLabel !== '' ? salaryPayE($periodLabel) : '—' ?></td>
      <td><?= $paidAt && strtotime((string)$paidAt) ? salaryPayE(date('d M Y', strtotime((string)$paidAt))) : '—' ?></td>
      <td><?= $methodLabel !== '' ? '<div>' . salaryPayE($methodLabel) . '</div>' : '' ?><?= $referenceLabel !== '' ? '<div class="small-muted">Ref: ' . salaryPayE($referenceLabel) . '</div>' : '' ?><?= $notesLabel !== '' ? '<div class="small-muted">' . salaryPayE($notesLabel) . '</div>' : '' ?><?= $methodLabel === '' && $referenceLabel === '' && $notesLabel === '' ? '—' : '' ?></td>
      <td><span class="badge badge-<?= $isCompleted ? 'success' : ($isReversed ? 'danger' : 'secondary') ?>"><?= salaryPayE(ucwords(str_replace('_', ' ', $statusLabel))) ?></span></td>
      <td class="text-right font-weight-bold <?= $isCompleted ? 'text-success' : 'text-muted' ?>"><?= $isCompleted ? '' : '— ' ?><?= number_format((float)($payment[$paymentMap['amount']] ?? 0), 2) ?></td>
      <td class="no-print text-nowrap"><?php if ($canChangeStatus && $rowId && $isCompleted): ?><?php if (in_array('reversed', $availableActions, true)): ?><form method="POST" action="salary_payments.php" class="d-inline" onsubmit="return confirm('Reverse this completed salary payment? This keeps the original record for audit purposes.');"><input type="hidden" name="csrf_token" value="<?= salaryPayE($csrfToken) ?>"><input type="hidden" name="action" value="change_status"><input type="hidden" name="payment_id" value="<?= $rowId ?>"><input type="hidden" name="new_status" value="reversed"><button type="submit" class="btn btn-sm btn-outline-danger" title="Reverse payment"><i class="fas fa-undo-alt"></i> Reverse</button></form><?php elseif (in_array('cancelled', $availableActions, true)): ?><form method="POST" action="salary_payments.php" class="d-inline" onsubmit="return confirm('Cancel this salary payment? The original record will be retained.');"><input type="hidden" name="csrf_token" value="<?= salaryPayE($csrfToken) ?>"><input type="hidden" name="action" value="change_status"><input type="hidden" name="payment_id" value="<?= $rowId ?>"><input type="hidden" name="new_status" value="cancelled"><button type="submit" class="btn btn-sm btn-outline-danger" title="Cancel payment"><i class="fas fa-ban"></i></button></form><?php endif; ?><?php else: ?>—<?php endif; ?></td>
    </tr><?php endforeach; endif; ?>
  </tbody></table></div>
  <?php if ($totalPages > 1): $pageQuery = $_GET; ?><nav class="no-print mt-3" aria-label="Salary payment pages"><ul class="pagination flex-wrap mb-0"><?php $pageQuery['page'] = max(1, $page - 1); ?><li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="?<?= salaryPayE(http_build_query($pageQuery)) ?>">Previous</a></li><?php for ($p = max(1, $page - 2); $p <= min($totalPages, $page + 2); $p++): $pageQuery['page'] = $p; ?><li class="page-item <?= $p === $page ? 'active' : '' ?>"><a class="page-link" href="?<?= salaryPayE(http_build_query($pageQuery)) ?>"><?= $p ?></a></li><?php endfor; ?><?php $pageQuery['page'] = min($totalPages, $page + 1); ?><li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>"><a class="page-link" href="?<?= salaryPayE(http_build_query($pageQuery)) ?>">Next</a></li></ul></nav><?php endif; ?>
 </section>
 <div class="footer-note">School Management System &mdash; Bursar Salary Payments</div>
</div>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function(){
 var form=document.getElementById('salaryPaymentForm');
 var select=document.getElementById('salary_id');
 var amount=document.getElementById('amount');
 if(select&&amount){
  select.addEventListener('change',function(){
   var option=select.options[select.selectedIndex];
   if(option&&option.dataset.amount){amount.value=option.dataset.amount;}else{amount.value='';}
  });
 }
 if(form){
  form.addEventListener('submit',function(){
   var button=document.getElementById('recordPaymentButton');
   if(button){button.disabled=true;button.innerHTML='<i class="fas fa-spinner fa-spin mr-1"></i>Recording payment...';}
  });
 }
})();
</script>

<script src="/assets/js/sidebar-unified.js?v=20261106"></script>
</body>
</html>

