<?php
/**
 * School Management System - Bursar Supplier Management
 * Location: /admin/bursar/suppliers.php
 */

ob_start();
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator', 'bursar']);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    http_response_code(500);
    exit('Database connection was not found. Check config/database.php.');
}
$conn->set_charset('utf8mb4');

/* -------------------------- Helpers -------------------------- */
function supE($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function supLength(string $value): int
{
    return function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
}

function supRedirect(string $message, string $type = 'success'): void
{
    $_SESSION['suppliers_message'] = $message;
    $_SESSION['suppliers_message_type'] = $type;
    header('Location: suppliers.php');
    exit;
}

function supBind(mysqli_stmt $stmt, string $types, array &$values): void
{
    if ($types === '') {
        return;
    }
    $args = [$types];
    foreach ($values as $key => &$value) {
        $args[] = &$value;
    }
    call_user_func_array([$stmt, 'bind_param'], $args);
}

function supColumns(mysqli $db): array
{
    $columns = [];
    $result = $db->query('SHOW COLUMNS FROM `suppliers`');
    while ($row = $result->fetch_assoc()) {
        $columns[] = $row['Field'];
    }
    return $columns;
}

function supPickColumn(array $columns, array $candidates): ?string
{
    foreach ($candidates as $candidate) {
        if (in_array($candidate, $columns, true)) {
            return $candidate;
        }
    }
    return null;
}

function supIdent(string $identifier): string
{
    // Column names passed here come from the explicit candidate allowlists below.
    return '`' . str_replace('`', '``', $identifier) . '`';
}

/* -------------------------- CSRF -------------------------- */
if (empty($_SESSION['suppliers_csrf'])) {
    $_SESSION['suppliers_csrf'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['suppliers_csrf'];
$currentUserId = (int)($_SESSION['user_id'] ?? $_SESSION['id'] ?? 0);

$message = $_SESSION['suppliers_message'] ?? '';
$messageType = $_SESSION['suppliers_message_type'] ?? 'success';
unset($_SESSION['suppliers_message'], $_SESSION['suppliers_message_type']);
$pageError = '';
$editSupplier = null;
$suppliers = [];
$summary = ['total' => 0, 'active' => 0, 'inactive' => 0];
$totalRecords = 0;
$totalPages = 1;
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 10;

$form = [
    'id' => 0,
    'supplier_name' => '',
    'contact_person' => '',
    'phone' => '',
    'email' => '',
    'address' => '',
    'tin_no' => '',
    'notes' => '',
    'status' => 'active'
];

/* -------------------------- Database setup / compatible columns -------------------------- */
try {
    $conn->query("CREATE TABLE IF NOT EXISTS suppliers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        supplier_name VARCHAR(150) NOT NULL,
        contact_person VARCHAR(150) DEFAULT NULL,
        phone VARCHAR(40) DEFAULT NULL,
        email VARCHAR(150) DEFAULT NULL,
        address TEXT DEFAULT NULL,
        tin_no VARCHAR(60) DEFAULT NULL,
        notes TEXT DEFAULT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'active',
        created_by INT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_suppliers_name (supplier_name),
        INDEX idx_suppliers_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $columns = supColumns($conn);
    $idColumn = supPickColumn($columns, ['id', 'supplier_id']);
    if ($idColumn === null) {
        throw new RuntimeException('The suppliers table has no id or supplier_id column. Check its structure in phpMyAdmin.');
    }

    // Existing installations sometimes use alternative names. Reuse those names where possible.
    $nameColumn = supPickColumn($columns, ['supplier_name', 'name', 'company_name', 'supplier']);
    if ($nameColumn === null) {
        $conn->query("ALTER TABLE suppliers ADD COLUMN supplier_name VARCHAR(150) NOT NULL DEFAULT ''");
        $columns = supColumns($conn);
        $nameColumn = 'supplier_name';
    }

    $columnDefinitions = [
        'contact_person' => 'VARCHAR(150) DEFAULT NULL',
        'phone' => 'VARCHAR(40) DEFAULT NULL',
        'email' => 'VARCHAR(150) DEFAULT NULL',
        'address' => 'TEXT DEFAULT NULL',
        'tin_no' => 'VARCHAR(60) DEFAULT NULL',
        'notes' => 'TEXT DEFAULT NULL',
        'status' => "VARCHAR(20) NOT NULL DEFAULT 'active'",
        'created_by' => 'INT DEFAULT NULL',
        'created_at' => 'TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP',
        'updated_at' => 'TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'
    ];
    foreach ($columnDefinitions as $column => $definition) {
        if (!in_array($column, $columns, true)) {
            // Honour common existing alternatives instead of adding duplicate information fields.
            $alternatives = [
                'contact_person' => ['contact_name', 'contact'],
                'phone' => ['phone_number', 'telephone', 'contact_phone'],
                'email' => ['email_address'],
                'address' => ['physical_address'],
                'tin_no' => ['tin_number', 'tax_number', 'tin'],
                'notes' => ['description', 'remarks']
            ];
            $alternative = supPickColumn($columns, $alternatives[$column] ?? []);
            if ($alternative !== null) {
                continue;
            }
            $conn->query('ALTER TABLE `suppliers` ADD COLUMN ' . supIdent($column) . ' ' . $definition);
            $columns[] = $column;
        }
    }

    // Re-check columns after any compatibility changes.
    $columns = supColumns($conn);
    $nameColumn = supPickColumn($columns, ['supplier_name', 'name', 'company_name', 'supplier']);
    $idColumn = supPickColumn($columns, ['id', 'supplier_id']);
    $contactColumn = supPickColumn($columns, ['contact_person', 'contact_name', 'contact']);
    $phoneColumn = supPickColumn($columns, ['phone', 'phone_number', 'telephone', 'contact_phone']);
    $emailColumn = supPickColumn($columns, ['email', 'email_address']);
    $addressColumn = supPickColumn($columns, ['address', 'physical_address']);
    $tinColumn = supPickColumn($columns, ['tin_no', 'tin_number', 'tax_number', 'tin']);
    $notesColumn = supPickColumn($columns, ['notes', 'description', 'remarks']);
    $statusColumn = supPickColumn($columns, ['status']);
    $createdByColumn = supPickColumn($columns, ['created_by']);
    $createdAtColumn = supPickColumn($columns, ['created_at']);

    if (!$nameColumn || !$idColumn) {
        throw new RuntimeException('Could not identify the supplier name or ID column.');
    }

    /* -------------------------- POST actions -------------------------- */
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $postedToken = (string)($_POST['csrf_token'] ?? '');
        if ($postedToken === '' || !hash_equals((string)$csrfToken, $postedToken)) {
            supRedirect('Your security token expired. Refresh the page and try again.', 'danger');
        }

        $action = (string)($_POST['action'] ?? '');
        $supplierId = filter_var($_POST['supplier_id'] ?? 0, FILTER_VALIDATE_INT) ?: 0;

        if ($action === 'save') {
            $name = trim((string)($_POST['supplier_name'] ?? ''));
            $contact = trim((string)($_POST['contact_person'] ?? ''));
            $phone = trim((string)($_POST['phone'] ?? ''));
            $email = trim((string)($_POST['email'] ?? ''));
            $address = trim((string)($_POST['address'] ?? ''));
            $tin = trim((string)($_POST['tin_no'] ?? ''));
            $notes = trim((string)($_POST['notes'] ?? ''));
            $status = (string)($_POST['status'] ?? 'active');

            if ($name === '' || supLength($name) > 150) {
                supRedirect('Supplier name is required and must be 150 characters or fewer.', 'danger');
            }
            if (supLength($contact) > 150 || supLength($phone) > 40 || supLength($email) > 150 || supLength($tin) > 60) {
                supRedirect('One of the supplier details is longer than allowed.', 'danger');
            }
            if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                supRedirect('Enter a valid email address.', 'danger');
            }
            if (!in_array($status, ['active', 'inactive'], true)) {
                supRedirect('Select a valid supplier status.', 'danger');
            }

            $sets = [];
            $values = [];
            $types = '';
            $data = [
                $nameColumn => [$name, 's'],
                $contactColumn => [$contact, 's'],
                $phoneColumn => [$phone, 's'],
                $emailColumn => [$email, 's'],
                $addressColumn => [$address, 's'],
                $tinColumn => [$tin, 's'],
                $notesColumn => [$notes, 's'],
                $statusColumn => [$status, 's']
            ];
            foreach ($data as $column => $item) {
                if ($column === null) continue;
                // Avoid duplicate writes if an unusual schema maps two logical fields to one column.
                if (isset($seenColumns[$column])) continue;
                $seenColumns[$column] = true;
                $sets[] = supIdent($column) . ' = ?';
                $values[] = $item[0];
                $types .= $item[1];
            }

            if ($action === 'save' && $supplierId > 0) {
                $values[] = $supplierId;
                $types .= 'i';
                $sql = 'UPDATE suppliers SET ' . implode(', ', $sets) . ' WHERE ' . supIdent($idColumn) . ' = ?';
                $stmt = $conn->prepare($sql);
                supBind($stmt, $types, $values);
                $stmt->execute();
                $stmt->close();
                supRedirect('Supplier details updated successfully.');
            } else {
                if ($createdByColumn !== null) {
                    $sets[] = supIdent($createdByColumn);
                    $values[] = $currentUserId;
                    $types .= 'i';
                }
                $columnNames = [];
                $placeholders = [];
                foreach ($sets as $set) {
                    if (preg_match('/^(`[^`]+`) = \?$/', $set, $m)) {
                        $columnNames[] = $m[1];
                        $placeholders[] = '?';
                    } elseif (preg_match('/^(`[^`]+`)$/', $set, $m)) {
                        $columnNames[] = $m[1];
                        $placeholders[] = '?';
                    }
                }
                $sql = 'INSERT INTO suppliers (' . implode(', ', $columnNames) . ') VALUES (' . implode(', ', $placeholders) . ')';
                $stmt = $conn->prepare($sql);
                supBind($stmt, $types, $values);
                $stmt->execute();
                $stmt->close();
                supRedirect('Supplier added successfully.');
            }
        } elseif ($action === 'toggle_status') {
            if ($supplierId <= 0 || $statusColumn === null) {
                supRedirect('Invalid supplier or status column.', 'danger');
            }
            $newStatus = (string)($_POST['new_status'] ?? '');
            if (!in_array($newStatus, ['active', 'inactive'], true)) {
                supRedirect('Invalid status selected.', 'danger');
            }
            $stmt = $conn->prepare('UPDATE suppliers SET ' . supIdent($statusColumn) . ' = ? WHERE ' . supIdent($idColumn) . ' = ?');
            $stmt->bind_param('si', $newStatus, $supplierId);
            $stmt->execute();
            $changed = $stmt->affected_rows;
            $stmt->close();
            supRedirect($changed >= 0 ? 'Supplier status updated.' : 'Unable to update supplier.', $changed >= 0 ? 'success' : 'danger');
        } else {
            supRedirect('Invalid supplier action.', 'danger');
        }
    }

    /* -------------------------- Load edit record -------------------------- */
    $editId = filter_input(INPUT_GET, 'edit', FILTER_VALIDATE_INT) ?: 0;
    if ($editId > 0) {
        $selectFields = [
            supIdent($idColumn) . ' AS id',
            supIdent($nameColumn) . ' AS supplier_name',
            ($contactColumn ? supIdent($contactColumn) : "''") . ' AS contact_person',
            ($phoneColumn ? supIdent($phoneColumn) : "''") . ' AS phone',
            ($emailColumn ? supIdent($emailColumn) : "''") . ' AS email',
            ($addressColumn ? supIdent($addressColumn) : "''") . ' AS address',
            ($tinColumn ? supIdent($tinColumn) : "''") . ' AS tin_no',
            ($notesColumn ? supIdent($notesColumn) : "''") . ' AS notes',
            ($statusColumn ? supIdent($statusColumn) : "'active'") . ' AS status'
        ];
        $stmt = $conn->prepare('SELECT ' . implode(', ', $selectFields) . ' FROM suppliers WHERE ' . supIdent($idColumn) . ' = ? LIMIT 1');
        $stmt->bind_param('i', $editId);
        $stmt->execute();
        $editSupplier = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($editSupplier) {
            $form = array_merge($form, $editSupplier);
            $form['id'] = (int)$editSupplier['id'];
        } else {
            $message = 'Supplier not found.';
            $messageType = 'warning';
        }
    }

    /* -------------------------- Search / filters -------------------------- */
    $search = trim((string)($_GET['search'] ?? ''));
    $statusFilter = (string)($_GET['status'] ?? '');
    if (!in_array($statusFilter, ['', 'active', 'inactive'], true)) $statusFilter = '';
    $where = [];
    $params = [];
    $types = '';
    if ($search !== '') {
        $searchable = array_filter([$nameColumn, $contactColumn, $phoneColumn, $emailColumn, $tinColumn]);
        $searchable = array_values(array_unique($searchable));
        $parts = [];
        foreach ($searchable as $col) {
            $parts[] = supIdent($col) . ' LIKE ?';
            $params[] = '%' . $search . '%';
            $types .= 's';
        }
        if ($parts) $where[] = '(' . implode(' OR ', $parts) . ')';
    }
    if ($statusFilter !== '' && $statusColumn !== null) {
        $where[] = supIdent($statusColumn) . ' = ?';
        $params[] = $statusFilter;
        $types .= 's';
    }
    $whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';

    /* -------------------------- Summary -------------------------- */
    $summarySql = 'SELECT COUNT(*) AS total';
    if ($statusColumn !== null) {
        $summarySql .= ", SUM(CASE WHEN LOWER(" . supIdent($statusColumn) . ") = 'active' THEN 1 ELSE 0 END) AS active, SUM(CASE WHEN LOWER(" . supIdent($statusColumn) . ") = 'inactive' THEN 1 ELSE 0 END) AS inactive";
    } else {
        $summarySql .= ', 0 AS active, 0 AS inactive';
    }
    $summarySql .= ' FROM suppliers';
    $summaryResult = $conn->query($summarySql)->fetch_assoc();
    $summary = [
        'total' => (int)($summaryResult['total'] ?? 0),
        'active' => (int)($summaryResult['active'] ?? 0),
        'inactive' => (int)($summaryResult['inactive'] ?? 0)
    ];

    /* -------------------------- Pagination count -------------------------- */
    $countStmt = $conn->prepare('SELECT COUNT(*) AS total FROM suppliers' . $whereSql);
    $countValues = $params;
    supBind($countStmt, $types, $countValues);
    $countStmt->execute();
    $totalRecords = (int)$countStmt->get_result()->fetch_assoc()['total'];
    $countStmt->close();
    $totalPages = max(1, (int)ceil($totalRecords / $perPage));
    $page = min($page, $totalPages);
    $offset = ($page - 1) * $perPage;

    /* -------------------------- Supplier list -------------------------- */
    $selectFields = [
        supIdent($idColumn) . ' AS id',
        supIdent($nameColumn) . ' AS supplier_name',
        ($contactColumn ? supIdent($contactColumn) : "''") . ' AS contact_person',
        ($phoneColumn ? supIdent($phoneColumn) : "''") . ' AS phone',
        ($emailColumn ? supIdent($emailColumn) : "''") . ' AS email',
        ($addressColumn ? supIdent($addressColumn) : "''") . ' AS address',
        ($tinColumn ? supIdent($tinColumn) : "''") . ' AS tin_no',
        ($notesColumn ? supIdent($notesColumn) : "''") . ' AS notes',
        ($statusColumn ? supIdent($statusColumn) : "'active'") . ' AS status',
        ($createdAtColumn ? supIdent($createdAtColumn) : "NULL") . ' AS created_at'
    ];
    $orderColumn = $createdAtColumn ?: $idColumn;
    $listStmt = $conn->prepare('SELECT ' . implode(', ', $selectFields) . ' FROM suppliers' . $whereSql . ' ORDER BY ' . supIdent($orderColumn) . ' DESC LIMIT ? OFFSET ?');
    $listTypes = $types . 'ii';
    $listValues = $params;
    $listValues[] = $perPage;
    $listValues[] = $offset;
    supBind($listStmt, $listTypes, $listValues);
    $listStmt->execute();
    $result = $listStmt->get_result();
    while ($row = $result->fetch_assoc()) $suppliers[] = $row;
    $listStmt->close();

} catch (Throwable $ex) {
    error_log('Suppliers page error: ' . $ex->getMessage());
    $pageError = $ex->getMessage();
}

$fullName = $_SESSION['full_name'] ?? 'User';
$currentPage = basename($_SERVER['PHP_SELF'] ?? 'suppliers.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Suppliers | School Management System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body{margin:0;background:#f4f6f9;color:#343a40;font-family:Arial,Helvetica,sans-serif}
        .sidebar{position:fixed;top:0;left:0;bottom:0;width:250px;background:#212529;color:#fff;z-index:1050;overflow-y:auto;transition:left .25s ease}
        .sidebar-header{padding:20px 15px;color:#fff;font-weight:700;border-bottom:1px solid rgba(255,255,255,.1);font-size:18px}
        .sidebar-menu{padding:15px 10px}
        .sidebar-section{color:#6c757d;font-size:11px;text-transform:uppercase;padding:12px 10px 6px;letter-spacing:1px}
        .sidebar a{display:block;color:#ced4da;padding:12px 15px;margin-bottom:3px;text-decoration:none;border-radius:6px;font-size:14px;border-left:4px solid transparent}
        .sidebar a:hover{background:#343a40;color:#fff}
        .sidebar a.active{background:#dc3545;color:#fff}
        .sidebar i{width:25px;text-align:center;margin-right:5px}
        .main{margin-left:250px;padding:25px}
        .panel,.stat{background:#fff;border-radius:10px;padding:20px;box-shadow:0 2px 8px rgba(0,0,0,.05);margin-bottom:22px}
        .stat .label{font-size:13px;color:#6c757d}.stat .number{font-size:25px;font-weight:700}
        .form-control,.btn{border-radius:6px}.table th{background:#f1f3f5;white-space:nowrap}.table td{vertical-align:middle}
        .badge-status{padding:6px 9px;border-radius:16px;font-size:12px}.badge-active{background:#d4edda;color:#155724}.badge-inactive{background:#e2e3e5;color:#383d41}
        .menu-btn,.overlay{display:none}
        @media(max-width:991px){.sidebar{left:-250px}.sidebar.show{left:0}.main{margin-left:0;padding:15px}.menu-btn{display:inline-block}.overlay.show{display:block;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:1040}.panel{padding:15px}}
        @media print{.sidebar,.menu-btn,.overlay,.no-print{display:none!important}.main{margin:0;padding:0}.panel,.stat{box-shadow:none}}
    </style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<div class="overlay" id="overlay"></div>
<aside class="sidebar" id="sidebar">
    <div class="sidebar-header"><i class="fas fa-university"></i> <span>Bursar</span></div>
    <nav class="sidebar-menu">
        <div class="sidebar-section">Main</div>
        <a href="/admin/dashboard.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
        <a href="/admin/bursar/index.php"><i class="fas fa-chart-line"></i>Bursar Dashboard</a>

        <div class="sidebar-section">Students &amp; Fees</div>
        <a href="/admin/bursar/students_fees.php"><i class="fas fa-user-graduate"></i>Student Fees</a>
        <a href="/admin/bursar/students_fee_accounts.php"><i class="fas fa-file-invoice-dollar"></i>Student Fee Accounts</a>
        <a href="/admin/bursar/fee_structure.php"><i class="fas fa-list-alt"></i>Fee Structure</a>
        <a href="/admin/bursar/payments.php"><i class="fas fa-money-bill-wave"></i>Receive Payment</a>
        <a href="/admin/bursar/outstanding_fees.php"><i class="fas fa-exclamation-circle"></i>Outstanding Fees</a>

        <div class="sidebar-section">Finance</div>
        <a href="/admin/bursar/income.php"><i class="fas fa-arrow-circle-down"></i>Income</a>
        <a href="/admin/bursar/expenses.php"><i class="fas fa-arrow-circle-up"></i>Expenses</a>
        <a href="/admin/bursar/suppliers.php" class="active"><i class="fas fa-truck"></i>Suppliers</a>
        <a href="/admin/bursar/supplier_payments.php"><i class="fas fa-hand-holding-usd"></i>Supplier Payments</a>

        <div class="sidebar-section">Payroll &amp; Budget</div>
        <a href="/admin/bursar/salaries.php"><i class="fas fa-users"></i>Salaries</a>
        <a href="/admin/bursar/salary_payments.php"><i class="fas fa-money-check-alt"></i>Salary Payments</a>
        <a href="/admin/bursar/budgets.php"><i class="fas fa-chart-pie"></i>Budgets</a>

        <div class="sidebar-section">Reports</div>
        <a href="/admin/bursar/cashbook.php"><i class="fas fa-book"></i>Cashbook</a>
        <a href="/admin/bursar/financial_reports.php"><i class="fas fa-chart-line"></i>Financial Reports</a>
        <a href="/admin/bursar/income_report.php"><i class="fas fa-file-invoice"></i>Income Report</a>
        <a href="/admin/bursar/expense_report.php"><i class="fas fa-receipt"></i>Expense Report</a>
        <a href="/admin/bursar/fees_report.php"><i class="fas fa-file-alt"></i>Fees Report</a>
        <a href="/admin/bursar/profit_loss.php"><i class="fas fa-balance-scale"></i>Profit &amp; Loss</a>

        <div class="sidebar-section">System</div>
        <a href="/admin/dashboard.php"><i class="fas fa-user-shield"></i>Admin Dashboard</a>
        <a href="/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
    </nav>
</aside>

<main class="main">
    <div class="d-flex justify-content-between align-items-center flex-wrap mb-4">
        <div>
            <button class="btn btn-dark menu-btn mb-2" id="menuBtn" type="button" aria-label="Open menu"><i class="fas fa-bars"></i></button>
            <h3 class="mb-1"><i class="fas fa-truck text-primary mr-2"></i>Supplier Management</h3>
            <div class="text-muted">Manage school suppliers and their contact information.</div>
        </div>
        <div class="text-right mt-2"><strong><?= supE($fullName) ?></strong><div class="small text-muted">Bursar Module</div></div>
    </div>

    <?php if ($message !== ''): ?>
        <div class="alert alert-<?= supE(in_array($messageType, ['success','danger','warning','info'], true) ? $messageType : 'info') ?> alert-dismissible fade show">
            <?= supE($message) ?><button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
        </div>
    <?php endif; ?>

    <?php if ($pageError !== ''): ?>
        <div class="alert alert-danger">
            <h5><i class="fas fa-exclamation-triangle mr-1"></i> Suppliers page could not load</h5>
            <p class="mb-1">A database or PHP error occurred. The technical details are shown below to help diagnose the problem.</p>
            <code><?= supE($pageError) ?></code>
            <p class="small mt-2 mb-0">The full error has also been written to your hosting PHP error log.</p>
        </div>
    <?php else: ?>

    <div class="row">
        <div class="col-md-4"><div class="stat"><div class="label">Total Suppliers</div><div class="number"><?= number_format($summary['total']) ?></div></div></div>
        <div class="col-md-4"><div class="stat"><div class="label">Active Suppliers</div><div class="number text-success"><?= number_format($summary['active']) ?></div></div></div>
        <div class="col-md-4"><div class="stat"><div class="label">Inactive Suppliers</div><div class="number text-secondary"><?= number_format($summary['inactive']) ?></div></div></div>
    </div>

    <section class="panel" id="supplierForm">
        <h5 class="mb-3"><i class="fas fa-<?= !empty($form['id']) ? 'edit' : 'plus-circle' ?> text-primary mr-2"></i><?= !empty($form['id']) ? 'Edit Supplier' : 'Add New Supplier' ?></h5>
        <form method="POST" action="suppliers.php">
            <input type="hidden" name="csrf_token" value="<?= supE($csrfToken) ?>">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="supplier_id" value="<?= (int)$form['id'] ?>">
            <div class="row">
                <div class="col-md-6 col-lg-4 form-group">
                    <label for="supplier_name">Supplier / Company Name *</label>
                    <input class="form-control" type="text" id="supplier_name" name="supplier_name" maxlength="150" required value="<?= supE($form['supplier_name']) ?>" placeholder="Company or supplier name">
                </div>
                <div class="col-md-6 col-lg-4 form-group">
                    <label for="contact_person">Contact Person</label>
                    <input class="form-control" type="text" id="contact_person" name="contact_person" maxlength="150" value="<?= supE($form['contact_person']) ?>" placeholder="Contact person's name">
                </div>
                <div class="col-md-6 col-lg-4 form-group">
                    <label for="phone">Phone Number</label>
                    <input class="form-control" type="tel" id="phone" name="phone" maxlength="40" value="<?= supE($form['phone']) ?>" placeholder="e.g. 0700 000000">
                </div>
                <div class="col-md-6 col-lg-4 form-group">
                    <label for="email">Email Address</label>
                    <input class="form-control" type="email" id="email" name="email" maxlength="150" value="<?= supE($form['email']) ?>" placeholder="supplier@example.com">
                </div>
                <div class="col-md-6 col-lg-4 form-group">
                    <label for="tin_no">TIN / Tax Number</label>
                    <input class="form-control" type="text" id="tin_no" name="tin_no" maxlength="60" value="<?= supE($form['tin_no']) ?>">
                </div>
                <div class="col-md-6 col-lg-4 form-group">
                    <label for="status">Status</label>
                    <select class="form-control" id="status" name="status">
                        <option value="active" <?= $form['status'] === 'active' ? 'selected' : '' ?>>Active</option>
                        <option value="inactive" <?= $form['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                    </select>
                </div>
                <div class="col-md-6 form-group">
                    <label for="address">Address</label>
                    <textarea class="form-control" id="address" name="address" rows="2" placeholder="Supplier location/address"><?= supE($form['address']) ?></textarea>
                </div>
                <div class="col-md-6 form-group">
                    <label for="notes">Notes</label>
                    <textarea class="form-control" id="notes" name="notes" rows="2" placeholder="Products supplied or other details"><?= supE($form['notes']) ?></textarea>
                </div>
            </div>
            <button class="btn btn-primary" type="submit"><i class="fas fa-save mr-1"></i><?= !empty($form['id']) ? 'Update Supplier' : 'Save Supplier' ?></button>
            <?php if (!empty($form['id'])): ?><a href="suppliers.php" class="btn btn-secondary">Cancel Edit</a><?php endif; ?>
        </form>
    </section>

    <section class="panel">
        <h5 class="mb-3"><i class="fas fa-search text-primary mr-2"></i>Search Suppliers</h5>
        <form method="GET" action="suppliers.php">
            <div class="form-row align-items-end">
                <div class="col-md-7 form-group">
                    <label for="search">Name, contact, phone, email or TIN</label>
                    <input class="form-control" type="search" id="search" name="search" value="<?= supE($search ?? '') ?>" placeholder="Search suppliers...">
                </div>
                <div class="col-md-3 form-group">
                    <label for="filter_status">Status</label>
                    <select class="form-control" id="filter_status" name="status">
                        <option value="">All statuses</option>
                        <option value="active" <?= ($statusFilter ?? '') === 'active' ? 'selected' : '' ?>>Active</option>
                        <option value="inactive" <?= ($statusFilter ?? '') === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                    </select>
                </div>
                <div class="col-md-2 form-group">
                    <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-filter mr-1"></i>Filter</button>
                </div>
            </div>
            <a href="suppliers.php" class="btn btn-sm btn-outline-secondary">Clear filters</a>
        </form>
    </section>

    <section class="panel">
        <div class="d-flex justify-content-between align-items-center flex-wrap mb-3">
            <h5 class="mb-2"><i class="fas fa-list text-primary mr-2"></i>Supplier Register</h5>
            <span class="text-muted mb-2"><?= number_format($totalRecords) ?> supplier(s)</span>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead><tr><th>#</th><th>Supplier</th><th>Contact Person</th><th>Phone</th><th>Email</th><th>TIN</th><th>Status</th><th>Created</th><th class="no-print">Actions</th></tr></thead>
                <tbody>
                <?php if (!$suppliers): ?>
                    <tr><td colspan="9" class="text-center py-4"><i class="fas fa-truck fa-2x text-muted mb-2"></i><p class="mb-0">No suppliers found. Add your first supplier using the form above.</p></td></tr>
                <?php else: foreach ($suppliers as $i => $supplier): $active = strtolower((string)$supplier['status']) === 'active'; ?>
                    <tr>
                        <td><?= ($page - 1) * $perPage + $i + 1 ?></td>
                        <td><strong><?= supE($supplier['supplier_name']) ?></strong><?php if ($supplier['address']): ?><div class="small text-muted"><?= supE($supplier['address']) ?></div><?php endif; ?></td>
                        <td><?= supE($supplier['contact_person'] ?: '—') ?></td>
                        <td><?= supE($supplier['phone'] ?: '—') ?></td>
                        <td><?= supE($supplier['email'] ?: '—') ?></td>
                        <td><?= supE($supplier['tin_no'] ?: '—') ?></td>
                        <td><span class="badge-status <?= $active ? 'badge-active' : 'badge-inactive' ?>"><?= $active ? 'Active' : 'Inactive' ?></span></td>
                        <td><?= !empty($supplier['created_at']) ? supE(date('d M Y', strtotime($supplier['created_at']))) : '—' ?></td>
                        <td class="no-print text-nowrap">
                            <a class="btn btn-sm btn-warning mb-1" href="suppliers.php?edit=<?= (int)$supplier['id'] ?>#supplierForm" title="Edit supplier"><i class="fas fa-edit"></i></a>
                            <form method="POST" action="suppliers.php" class="d-inline" onsubmit="return confirm('<?= $active ? 'Deactivate' : 'Activate' ?> this supplier?');">
                                <input type="hidden" name="csrf_token" value="<?= supE($csrfToken) ?>">
                                <input type="hidden" name="action" value="toggle_status">
                                <input type="hidden" name="supplier_id" value="<?= (int)$supplier['id'] ?>">
                                <input type="hidden" name="new_status" value="<?= $active ? 'inactive' : 'active' ?>">
                                <button class="btn btn-sm <?= $active ? 'btn-outline-secondary' : 'btn-outline-success' ?> mb-1" type="submit" title="<?= $active ? 'Deactivate' : 'Activate' ?> supplier"><i class="fas fa-<?= $active ? 'ban' : 'check' ?>"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <?php if ($totalPages > 1): $query = $_GET; ?>
            <nav aria-label="Supplier pages"><ul class="pagination flex-wrap mb-0">
                <?php $query['page'] = max(1, $page - 1); ?><li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="?<?= supE(http_build_query($query)) ?>">Previous</a></li>
                <?php for ($p = max(1, $page - 2); $p <= min($totalPages, $page + 2); $p++): $query['page'] = $p; ?><li class="page-item <?= $p === $page ? 'active' : '' ?>"><a class="page-link" href="?<?= supE(http_build_query($query)) ?>"><?= $p ?></a></li><?php endfor; ?>
                <?php $query['page'] = min($totalPages, $page + 1); ?><li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>"><a class="page-link" href="?<?= supE(http_build_query($query)) ?>">Next</a></li>
            </ul></nav>
        <?php endif; ?>
    </section>
    <?php endif; ?>
    <div class="text-center text-muted small">School Management System &mdash; Supplier Management</div>
</main>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function () {
    var sidebar = document.getElementById('sidebar');
    var overlay = document.getElementById('overlay');
    var button = document.getElementById('menuBtn');
    function openMenu() { sidebar.classList.add('show'); overlay.classList.add('show'); }
    function closeMenu() { sidebar.classList.remove('show'); overlay.classList.remove('show'); }
    if (button) button.addEventListener('click', openMenu);
    overlay.addEventListener('click', closeMenu);
    document.addEventListener('keydown', function (event) { if (event.key === 'Escape') closeMenu(); });
})();
</script>
</body>
</html>
