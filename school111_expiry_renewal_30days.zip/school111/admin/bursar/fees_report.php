<?php
/**
 * School Management System - Bursar Fees Report
 * Location: /admin/bursar/fees_report.php
 * Uses the same session, MySQLi, and role setup as payments.php.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
ob_start();
$feesDebugRequested = isset($_GET['fees_debug']) && (string)$_GET['fees_debug'] === '1';
register_shutdown_function(static function () use ($feesDebugRequested): void {
    $lastError = error_get_last();
    if (!$lastError || !in_array($lastError['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR], true)) return;
    error_log('fees_report.php fatal error: ' . ($lastError['message'] ?? 'Unknown error') . ' in ' . ($lastError['file'] ?? 'unknown') . ':' . (int)($lastError['line'] ?? 0));
    while (ob_get_level() > 0) { if (!@ob_end_clean()) break; }
    if (!headers_sent()) http_response_code(500);
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Fees report error</title><style>body{font-family:Arial,sans-serif;background:#f4f6f9;color:#263348;padding:24px}.box{max-width:760px;margin:25px auto;padding:24px;background:#fff;border:1px solid #e1e7ef;border-radius:10px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f7f9fc;padding:12px;border-radius:6px}</style></head><body><div class="box"><h2>Fees report could not finish loading</h2><p>A PHP error stopped the report. The error has been written to the hosting PHP error log.</p>';
    $hasSession = isset($_SESSION) && (isset($_SESSION['user_id']) || isset($_SESSION['id']));
    if ($feesDebugRequested && $hasSession) echo '<p><strong>Diagnostic details:</strong></p><pre>' . htmlspecialchars((string)($lastError['message'] ?? 'Unknown error'), ENT_QUOTES, 'UTF-8') . "\n" . htmlspecialchars((string)($lastError['file'] ?? 'unknown'), ENT_QUOTES, 'UTF-8') . ':' . (int)($lastError['line'] ?? 0) . '</pre>';
    else echo '<p>While logged in, append <code>?fees_debug=1</code> to this page URL and share the displayed diagnostic message.</p>';
    echo '</div></body></html>';
});

require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator', 'bursar']);
$db = $conn ?? ($mysqli ?? ($connection ?? null));
if (!$db instanceof mysqli) {
    http_response_code(500);
    exit('Database connection was not found. Check config/database.php.');
}
$db->set_charset('utf8mb4');
$userId = (int)($_SESSION['user_id'] ?? $_SESSION['id'] ?? 0);

function fees_report_h($value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8'); }
function fees_report_ident(string $name): string { return '`' . str_replace('`', '``', $name) . '`'; }
function fees_report_columns(mysqli $db, string $table): array {
    $out = [];
    $result = $db->query('SHOW COLUMNS FROM ' . fees_report_ident($table));
    while ($row = $result->fetch_assoc()) $out[strtolower((string)$row['Field'])] = $row;
    $result->free();
    return $out;
}
function fees_report_first_col(array $columns, array $candidates): ?string {
    foreach ($candidates as $candidate) {
        $candidate = strtolower((string)$candidate);
        if (isset($columns[$candidate])) return (string)$columns[$candidate]['Field'];
    }
    return null;
}
function fees_report_table_exists(mysqli $db, string $table): bool {
    $safe = $db->real_escape_string($table);
    $result = $db->query("SHOW TABLES LIKE '{$safe}'");
    return $result && $result->num_rows > 0;
}
function fees_report_bind(mysqli_stmt $stmt, string $types, array &$values): void {
    if ($types === '') return;
    $args = [$types];
    foreach ($values as &$value) $args[] = &$value;
    call_user_func_array([$stmt, 'bind_param'], $args);
}
function fees_report_normalize_status(string $status, float $balance): string {
    $status = strtolower(trim($status));
    if (in_array($status, ['cancelled', 'canceled', 'inactive', 'disabled'], true)) return 'Cancelled';
    if ($balance <= 0.00001) return 'Paid';
    if ($status !== '') {
        if (strpos($status, 'partial') !== false) return 'Partially paid';
        if (in_array($status, ['paid', 'complete', 'completed'], true)) return 'Paid';
        if (in_array($status, ['pending', 'draft', 'active', 'unpaid'], true)) return $balance > 0 && $status === 'active' ? 'Outstanding' : ucfirst($status);
        return ucwords(str_replace('_', ' ', $status));
    }
    return 'Outstanding';
}

$schemaError = '';
$pageError = '';
$accountRows = [];
$paymentRows = [];
$yearOptions = [];
$termOptions = [];
$accountColumns = $studentColumns = $paymentColumns = $methodColumns = [];
$accountTableExists = $studentTableExists = $paymentTableExists = false;
$accountLinkColumn = $paymentDateColumn = $paymentAmountColumn = $paymentStatusColumn = null;
$search = trim((string)($_GET['search'] ?? ''));
$yearFilter = trim((string)($_GET['academic_year'] ?? ''));
$termFilter = trim((string)($_GET['term'] ?? ''));
$accountStatusFilter = trim((string)($_GET['account_status'] ?? ''));
$paymentStatusFilter = trim((string)($_GET['payment_status'] ?? ''));
$dateFrom = trim((string)($_GET['from'] ?? ''));
$dateTo = trim((string)($_GET['to'] ?? ''));
$export = trim((string)($_GET['export'] ?? ''));
$summary = ['fees'=>0.0, 'discounts'=>0.0, 'paid'=>0.0, 'balance'=>0.0, 'accounts'=>0, 'payments'=>0, 'period_paid'=>0.0];

try {
    $studentTableExists = fees_report_table_exists($db, 'students');
    $accountTableExists = fees_report_table_exists($db, 'student_fee_accounts');
    $paymentTableExists = fees_report_table_exists($db, 'fee_payments');
    if (!$studentTableExists) throw new RuntimeException('The students table was not found.');
    if (!$accountTableExists) throw new RuntimeException('The student_fee_accounts table was not found.');
    $studentColumns = fees_report_columns($db, 'students');
    $accountColumns = fees_report_columns($db, 'student_fee_accounts');
    if (!isset($studentColumns['id'], $studentColumns['first_name'], $studentColumns['last_name'])) throw new RuntimeException('The students table must contain id, first_name, and last_name.');
    if (!isset($accountColumns['id'], $accountColumns['student_id'], $accountColumns['total_amount'])) throw new RuntimeException('The student_fee_accounts table must contain id, student_id, and total_amount.');
    $paidColumn = fees_report_first_col($accountColumns, ['amount_paid', 'total_paid']);
    if (!$paidColumn) throw new RuntimeException('The student_fee_accounts table needs an amount_paid or total_paid column.');
    $discountColumn = fees_report_first_col($accountColumns, ['discount_amount', 'discount', 'discounts']);
    $yearColumn = fees_report_first_col($accountColumns, ['academic_year', 'school_year', 'year']);
    $yearIdColumn = $yearColumn ? null : fees_report_first_col($accountColumns, ['academic_year_id', 'school_year_id', 'year_id']);
    $termColumn = fees_report_first_col($accountColumns, ['term', 'term_name']);
    $termIdColumn = $termColumn ? null : fees_report_first_col($accountColumns, ['term_id']);
    $accountStatusColumn = fees_report_first_col($accountColumns, ['status', 'payment_status', 'account_status']);

    $yearJoin = '';
    $yearExpr = "''";
    if ($yearColumn) {
        $yearExpr = 'COALESCE(CAST(sfa.' . fees_report_ident($yearColumn) . ' AS CHAR), \'\')';
    } elseif ($yearIdColumn && fees_report_table_exists($db, 'academic_years')) {
        $yc = fees_report_columns($db, 'academic_years');
        $yId = fees_report_first_col($yc, ['id', 'academic_year_id']);
        $yName = fees_report_first_col($yc, ['year_name', 'academic_year', 'name', 'year']);
        if ($yId && $yName) { $yearJoin = ' LEFT JOIN academic_years ay ON ay.' . fees_report_ident($yId) . ' = sfa.' . fees_report_ident($yearIdColumn); $yearExpr = 'COALESCE(CAST(ay.' . fees_report_ident($yName) . ' AS CHAR), CAST(sfa.' . fees_report_ident($yearIdColumn) . ' AS CHAR), \'\')'; }
        else $yearExpr = 'CAST(sfa.' . fees_report_ident($yearIdColumn) . ' AS CHAR)';
    } elseif ($yearIdColumn) $yearExpr = 'CAST(sfa.' . fees_report_ident($yearIdColumn) . ' AS CHAR)';

    $termJoin = '';
    $termExpr = "''";
    if ($termColumn) {
        $termExpr = 'COALESCE(CAST(sfa.' . fees_report_ident($termColumn) . ' AS CHAR), \'\')';
    } elseif ($termIdColumn && fees_report_table_exists($db, 'terms')) {
        $tc = fees_report_columns($db, 'terms');
        $tId = fees_report_first_col($tc, ['id', 'term_id']);
        $tName = fees_report_first_col($tc, ['term_name', 'name', 'term']);
        if ($tId && $tName) { $termJoin = ' LEFT JOIN terms t ON t.' . fees_report_ident($tId) . ' = sfa.' . fees_report_ident($termIdColumn); $termExpr = 'COALESCE(CAST(t.' . fees_report_ident($tName) . ' AS CHAR), CAST(sfa.' . fees_report_ident($termIdColumn) . ' AS CHAR), \'\')'; }
        else $termExpr = 'CAST(sfa.' . fees_report_ident($termIdColumn) . ' AS CHAR)';
    } elseif ($termIdColumn) $termExpr = 'CAST(sfa.' . fees_report_ident($termIdColumn) . ' AS CHAR)';

    $admissionExpr = isset($studentColumns['admission_no']) ? 'COALESCE(s.' . fees_report_ident($studentColumns['admission_no']['Field']) . ', \'\')' : "''";
    $linExpr = isset($studentColumns['lin_no']) ? 'COALESCE(s.' . fees_report_ident($studentColumns['lin_no']['Field']) . ', \'\')' : "''";
    $paymentCodeExpr = isset($studentColumns['student_payment_code']) ? 'COALESCE(s.' . fees_report_ident($studentColumns['student_payment_code']['Field']) . ', \'\')' : "''";
    $studentSectionExpr = isset($studentColumns['student_section']) ? 'COALESCE(s.' . fees_report_ident($studentColumns['student_section']['Field']) . ', \'Day\')' : "'Day'";
    $discountExpr = $discountColumn ? 'COALESCE(sfa.' . fees_report_ident($discountColumn) . ',0)' : '0';
    $paidExpr = 'COALESCE(sfa.' . fees_report_ident($paidColumn) . ',0)';
    $statusExpr = $accountStatusColumn ? 'COALESCE(CAST(sfa.' . fees_report_ident($accountStatusColumn) . ' AS CHAR), \'\')' : "''";
    $accountSql = 'SELECT sfa.*, sfa.' . fees_report_ident($accountColumns['id']['Field']) . ' AS report_account_id, sfa.' . fees_report_ident($accountColumns['student_id']['Field']) . ' AS report_student_id, COALESCE(s.first_name, \'\') AS report_first_name, COALESCE(s.last_name, \'\') AS report_last_name, ' . $admissionExpr . ' AS report_admission_no, ' . $linExpr . ' AS report_lin_no, ' . $paymentCodeExpr . ' AS report_student_payment_code, ' . $studentSectionExpr . ' AS report_student_section, COALESCE(sfa.total_amount,0) AS report_total, ' . $discountExpr . ' AS report_discount, ' . $paidExpr . ' AS report_paid, GREATEST(COALESCE(sfa.total_amount,0)-' . $discountExpr . ',0) AS report_charged, GREATEST(COALESCE(sfa.total_amount,0)-' . $discountExpr . '-' . $paidExpr . ',0) AS report_balance, ' . $yearExpr . ' AS report_year, ' . $termExpr . ' AS report_term, ' . $statusExpr . ' AS report_status FROM student_fee_accounts sfa INNER JOIN students s ON s.id = sfa.student_id ' . $yearJoin . ' ' . $termJoin . ' ORDER BY s.first_name, s.last_name, sfa.id DESC';
    $ar = $db->query($accountSql);
    while ($row = $ar->fetch_assoc()) {
        $row['_display_status'] = fees_report_normalize_status((string)($row['report_status'] ?? ''), (float)$row['report_balance']);
        $yearValue = trim((string)($row['report_year'] ?? ''));
        $termValue = trim((string)($row['report_term'] ?? ''));
        if ($yearValue !== '') $yearOptions[$yearValue] = $yearValue;
        if ($termValue !== '') $termOptions[$termValue] = $termValue;
        $accountRows[] = $row;
    }
    $ar->free();

    // Payment history supports either account link used by the existing installation.
    if ($paymentTableExists) {
        $paymentColumns = fees_report_columns($db, 'fee_payments');
        $paymentAmountColumn = fees_report_first_col($paymentColumns, ['amount', 'payment_amount', 'paid_amount']);
        $paymentDateColumn = fees_report_first_col($paymentColumns, ['payment_date', 'paid_date', 'created_at', 'date_paid']);
        $paymentStatusColumn = fees_report_first_col($paymentColumns, ['status', 'payment_status']);
        $accountLinkColumn = fees_report_first_col($paymentColumns, ['student_fee_account_id', 'account_id']);
        $receiptColumn = fees_report_first_col($paymentColumns, ['receipt_no', 'receipt_number', 'payment_no', 'reference_no']);
        $referenceColumn = fees_report_first_col($paymentColumns, ['reference_no', 'transaction_reference', 'transaction_id']);
        $notesColumn = fees_report_first_col($paymentColumns, ['description', 'notes', 'remarks', 'narration']);
        $methodIdColumn = fees_report_first_col($paymentColumns, ['payment_method_id']);
        $methodTextColumn = fees_report_first_col($paymentColumns, ['payment_method', 'method', 'payment_type']);
        $joins = '';
        if ($accountLinkColumn) {
            $joins .= ' LEFT JOIN student_fee_accounts sfa ON sfa.id = fp.' . fees_report_ident($accountLinkColumn);
            $studentJoinExpr = isset($paymentColumns['student_id']) ? 'fp.' . fees_report_ident($paymentColumns['student_id']['Field']) : 'sfa.student_id';
        } elseif (isset($paymentColumns['student_id'])) {
            $studentJoinExpr = 'fp.' . fees_report_ident($paymentColumns['student_id']['Field']);
        } else {
            $studentJoinExpr = 'NULL';
        }
        $joins .= ' LEFT JOIN students s ON s.id = ' . $studentJoinExpr;
        $methodExpr = "'N/A'";
        if ($methodIdColumn && fees_report_table_exists($db, 'payment_methods')) {
            $methodColumns = fees_report_columns($db, 'payment_methods');
            $methodKey = fees_report_first_col($methodColumns, ['id', 'payment_method_id']);
            $methodName = fees_report_first_col($methodColumns, ['method_name', 'name', 'payment_method', 'title']);
            if ($methodKey && $methodName) {
                $joins .= ' LEFT JOIN payment_methods pm ON pm.' . fees_report_ident($methodKey) . ' = fp.' . fees_report_ident($methodIdColumn);
                $methodExpr = 'COALESCE(CAST(pm.' . fees_report_ident($methodName) . ' AS CHAR), \'N/A\')';
            }
        } elseif ($methodTextColumn) $methodExpr = 'COALESCE(CAST(fp.' . fees_report_ident($methodTextColumn) . ' AS CHAR), \'N/A\')';
        $receiptExpr = $receiptColumn ? 'COALESCE(CAST(fp.' . fees_report_ident($receiptColumn) . ' AS CHAR), CONCAT(\'PAY-\', fp.id))' : "CONCAT('PAY-', fp.id)";
        $referenceExpr = $referenceColumn ? 'COALESCE(CAST(fp.' . fees_report_ident($referenceColumn) . ' AS CHAR), \'\')' : "''";
        $dateExpr = $paymentDateColumn ? 'fp.' . fees_report_ident($paymentDateColumn) : "''";
        $amountExpr = $paymentAmountColumn ? 'COALESCE(fp.' . fees_report_ident($paymentAmountColumn) . ',0)' : '0';
        $statusExpr = $paymentStatusColumn ? 'COALESCE(CAST(fp.' . fees_report_ident($paymentStatusColumn) . ' AS CHAR), \'completed\')' : "'completed'";
        $notesExpr = $notesColumn ? 'COALESCE(CAST(fp.' . fees_report_ident($notesColumn) . ' AS CHAR), \'\')' : "''";
        $payWhere = [];
        $payValues = [];
        $payTypes = '';
        if ($paymentDateColumn && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom)) { $payWhere[] = 'DATE(' . $dateExpr . ') >= ?'; $payValues[] = $dateFrom; $payTypes .= 's'; }
        if ($paymentDateColumn && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo)) { $payWhere[] = 'DATE(' . $dateExpr . ') <= ?'; $payValues[] = $dateTo; $payTypes .= 's'; }
        if ($paymentStatusColumn && $paymentStatusFilter !== '') { $payWhere[] = 'CAST(fp.' . fees_report_ident($paymentStatusColumn) . ' AS CHAR) = ?'; $payValues[] = $paymentStatusFilter; $payTypes .= 's'; }
        if ($search !== '') {
            $srch = '(' . $receiptExpr . ' LIKE ? OR COALESCE(s.first_name,\'\') LIKE ? OR COALESCE(s.last_name,\'\') LIKE ? OR ' . $referenceExpr . ' LIKE ? OR ' . $notesExpr . ' LIKE ?';
            $searchCount = 5;
            if (isset($studentColumns['admission_no'])) { $srch .= ' OR CAST(s.' . fees_report_ident($studentColumns['admission_no']['Field']) . ' AS CHAR) LIKE ?'; $searchCount++; }
            if (isset($studentColumns['lin_no'])) { $srch .= ' OR CAST(s.' . fees_report_ident($studentColumns['lin_no']['Field']) . ' AS CHAR) LIKE ?'; $searchCount++; }
            if (isset($studentColumns['student_payment_code'])) { $srch .= ' OR CAST(s.' . fees_report_ident($studentColumns['student_payment_code']['Field']) . ' AS CHAR) LIKE ?'; $searchCount++; }
            $srch .= ')';
            $payWhere[] = $srch;
            $like = '%' . $search . '%';
            for ($i=0; $i<$searchCount; $i++) { $payValues[] = $like; $payTypes .= 's'; }
        }
        $paymentSql = 'SELECT fp.id AS report_payment_id, ' . $receiptExpr . ' AS report_receipt, ' . $amountExpr . ' AS report_payment_amount, ' . $dateExpr . ' AS report_payment_date, ' . $referenceExpr . ' AS report_reference, ' . $statusExpr . ' AS report_payment_status, ' . $methodExpr . ' AS report_method, ' . $notesExpr . ' AS report_notes, COALESCE(s.first_name, \'\') AS report_first_name, COALESCE(s.last_name, \'\') AS report_last_name, ' . (isset($studentColumns['admission_no']) ? 'COALESCE(s.' . fees_report_ident($studentColumns['admission_no']['Field']) . ', \'\')' : "''") . ' AS report_admission_no, ' . (isset($studentColumns['lin_no']) ? 'COALESCE(s.' . fees_report_ident($studentColumns['lin_no']['Field']) . ', \'\')' : "''") . ' AS report_lin_no, ' . (isset($studentColumns['student_payment_code']) ? 'COALESCE(s.' . fees_report_ident($studentColumns['student_payment_code']['Field']) . ', \'\')' : "''") . ' AS report_student_payment_code, ' . (isset($studentColumns['student_section']) ? 'COALESCE(s.' . fees_report_ident($studentColumns['student_section']['Field']) . ', \'Day\')' : "'Day'") . ' AS report_student_section FROM fee_payments fp ' . $joins . ($payWhere ? ' WHERE ' . implode(' AND ', $payWhere) : '') . ' ORDER BY ' . ($paymentDateColumn ? $dateExpr : 'fp.id') . ' DESC, fp.id DESC LIMIT 500';
        $ps = $db->prepare($paymentSql);
        fees_report_bind($ps, $payTypes, $payValues);
        $ps->execute();
        $pr = $ps->get_result();
        while ($row = $pr->fetch_assoc()) $paymentRows[] = $row;
        $ps->close();
    }
} catch (Throwable $ex) {
    $schemaError = $ex->getMessage();
    error_log('fees_report.php setup/load error: ' . $ex->getMessage());
}

// Apply account-report filters in PHP, which also supports direct-text or lookup-ID year/term schemas.
$filteredAccounts = [];
foreach ($accountRows as $row) {
    $fullName = trim((string)$row['report_first_name'] . ' ' . (string)$row['report_last_name']);
    if ($yearFilter !== '' && (string)$row['report_year'] !== $yearFilter) continue;
    if ($termFilter !== '' && (string)$row['report_term'] !== $termFilter) continue;
    if ($accountStatusFilter !== '' && strtolower((string)$row['_display_status']) !== strtolower($accountStatusFilter)) continue;
    if ($search !== '') {
        $haystack = strtolower($fullName . ' ' . (string)$row['report_admission_no'] . ' ' . (string)$row['report_lin_no'] . ' ' . (string)($row['report_student_payment_code'] ?? '') . ' ' . (string)$row['report_account_id']);
        if (strpos($haystack, strtolower($search)) === false) continue;
    }
    $filteredAccounts[] = $row;
    $summary['fees'] += (float)$row['report_charged'];
    $summary['discounts'] += (float)$row['report_discount'];
    $summary['paid'] += max(0, (float)$row['report_paid']);
    $summary['balance'] += max(0, (float)$row['report_balance']);
}
$summary['accounts'] = count($filteredAccounts);
$summary['payments'] = count($paymentRows);
foreach ($paymentRows as $row) {
    $status = strtolower(trim((string)$row['report_payment_status']));
    if (in_array($status, ['', 'completed', 'complete', 'paid', 'success', 'successful', 'confirmed', 'approved', 'posted', 'received', 'settled', 'processed'], true)) {
        $summary['period_paid'] += (float)$row['report_payment_amount'];
    }
}
ksort($yearOptions, SORT_NATURAL | SORT_FLAG_CASE);
ksort($termOptions, SORT_NATURAL | SORT_FLAG_CASE);

if ($export === 'accounts' && $schemaError === '') {
    while (ob_get_level() > 0) ob_end_clean();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="fees-account-report-' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Account ID','Admission No.','LIN No.','Student Payment Code','Student Section','Student','Academic Year','Term','Total Fees (UGX)','Discount (UGX)','Paid (UGX)','Balance (UGX)','Status']);
    foreach ($filteredAccounts as $row) fputcsv($out, [$row['report_account_id'],$row['report_admission_no'],$row['report_lin_no'],$row['report_student_payment_code'],$row['report_student_section'],trim($row['report_first_name'].' '.$row['report_last_name']),$row['report_year'],$row['report_term'],number_format((float)$row['report_total'],2,'.',''),number_format((float)$row['report_discount'],2,'.',''),number_format((float)$row['report_paid'],2,'.',''),number_format((float)$row['report_balance'],2,'.',''),$row['_display_status']]);
    fclose($out); exit;
}
if ($export === 'payments' && $schemaError === '') {
    while (ob_get_level() > 0) ob_end_clean();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="fees-payment-report-' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Payment ID','Receipt','Admission No.','LIN No.','Student Payment Code','Student Section','Student','Payment Date','Method','Reference','Status','Amount (UGX)','Notes']);
    foreach ($paymentRows as $row) fputcsv($out, [$row['report_payment_id'],$row['report_receipt'],$row['report_admission_no'],$row['report_lin_no'],$row['report_student_payment_code'],$row['report_student_section'],trim($row['report_first_name'].' '.$row['report_last_name']),$row['report_payment_date'],$row['report_method'],$row['report_reference'],$row['report_payment_status'],number_format((float)$row['report_payment_amount'],2,'.',''),$row['report_notes']]);
    fclose($out); exit;
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Fees Report | School Management System</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f6f9;font-family:Arial,Helvetica,sans-serif;color:#343a40}.sidebar{position:fixed;top:0;bottom:0;left:0;width:250px;background:#212529;overflow-y:auto;z-index:1050}.sidebar-header{padding:22px 18px;background:#171a1d;color:#fff;font-weight:700;font-size:18px}.sidebar a{display:block;color:#ced4da;padding:11px 16px;text-decoration:none;border-left:4px solid transparent;font-size:14px}.sidebar a:hover,.sidebar a.active{background:#343a40;color:#fff;border-left-color:#28a745}.sidebar a i{width:24px;text-align:center;margin-right:5px}.sidebar-section{padding:15px 16px 6px;color:#868e96;font-size:11px;text-transform:uppercase;font-weight:bold;letter-spacing:.5px}.main{margin-left:250px;min-height:100vh}.topbar{padding:17px 25px;background:#fff;border-bottom:1px solid #e5e5e5;display:flex;align-items:center;justify-content:space-between}.content{padding:24px}.page-head,.panel,.stat-card{background:#fff;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,.05)}.page-head{padding:21px;margin-bottom:20px}.panel{padding:21px;margin-bottom:22px}.stat-card{padding:18px;margin-bottom:18px;height:calc(100% - 18px)}.stat-title{color:#6c757d;font-size:13px}.stat-number{font-size:22px;font-weight:700;overflow-wrap:anywhere}.form-control,.custom-select,.btn{border-radius:6px}.form-control,.custom-select{min-height:40px}.table th{background:#f8f9fa;white-space:nowrap;font-size:12px}.table td{vertical-align:middle;font-size:13px}.badge{padding:7px 9px}.mobile-menu{display:none}.small-note{font-size:12px;color:#6c757d}@media(max-width:991px){.sidebar{left:-250px;transition:left .25s}.sidebar.show{left:0}.main{margin-left:0}.mobile-menu{display:inline-block}.content{padding:15px}.topbar{padding:12px 15px}}@media print{.sidebar,.topbar,.no-print,.mobile-menu{display:none!important}.main{margin:0}.content{padding:0}.panel,.stat-card,.page-head{box-shadow:none}}
</style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<aside class="sidebar" id="sidebar">
 <div class="sidebar-header"><i class="fas fa-school mr-2"></i>School Management<br><small class="text-muted">Bursar Panel</small></div>
 <div class="sidebar-section">Main</div><a href="/admin/dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a><a href="/admin/bursar/index.php"><i class="fas fa-chart-line"></i> Bursar Dashboard</a>
 <div class="sidebar-section">Fees</div><a href="/admin/bursar/students_fee_accounts.php"><i class="fas fa-user-graduate"></i> Student Fee Accounts</a><a href="/admin/bursar/fee_structure.php"><i class="fas fa-list-alt"></i> Fee Structure</a><a href="/admin/bursar/payments.php"><i class="fas fa-money-bill-wave"></i> Student Payments</a><a href="/admin/bursar/outstanding_fees.php"><i class="fas fa-exclamation-circle"></i> Outstanding Fees</a><a href="/admin/bursar/fees_report.php" class="active"><i class="fas fa-file-invoice-dollar"></i> Fees Report</a>
 <div class="sidebar-section">Finance</div><a href="/admin/bursar/income.php"><i class="fas fa-arrow-circle-down"></i> Other Income</a><a href="/admin/bursar/expenses.php"><i class="fas fa-arrow-circle-up"></i> Expenses</a><a href="/admin/bursar/suppliers.php"><i class="fas fa-truck"></i> Suppliers</a><a href="/admin/bursar/cashbook.php"><i class="fas fa-book"></i> Cashbook</a><a href="/admin/bursar/budgets.php"><i class="fas fa-wallet"></i> Budgets</a><a href="/admin/bursar/reports.php"><i class="fas fa-chart-bar"></i> Financial Reports</a>
 <div class="sidebar-section">System</div><a href="/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</aside>
<div class="main">
 <div class="topbar"><div><button class="btn btn-dark mobile-menu mr-2" id="mobileMenuBtn" type="button"><i class="fas fa-bars"></i></button><strong>Bursar Finance</strong></div><div class="text-muted"><i class="fas fa-user-circle mr-1"></i><?= fees_report_h($_SESSION['full_name'] ?? 'Bursar') ?></div></div>
 <div class="content">
  <div class="page-head d-flex justify-content-between align-items-center flex-wrap"><div><h3 class="mb-1"><i class="fas fa-file-invoice-dollar text-success mr-2"></i>Student Fees Report</h3><div class="text-muted">Review fees charged, discounts, payments received, and outstanding student balances.</div></div><div class="mt-2 no-print"><button class="btn btn-outline-dark mr-1" onclick="window.print()"><i class="fas fa-print mr-1"></i>Print</button><a class="btn btn-outline-success" href="fees_report.php?<?= fees_report_h(http_build_query(array_merge($_GET,['export'=>'accounts']))) ?>"><i class="fas fa-file-csv mr-1"></i>Export Accounts</a></div></div>
  <?php if ($schemaError !== ''): ?><div class="alert alert-danger"><h5><i class="fas fa-exclamation-triangle mr-1"></i>Database/page configuration error</h5><div><?= fees_report_h($schemaError) ?></div><div class="small mt-2">No database records were changed. This error has been written to the hosting PHP error log.</div></div><?php endif; ?>
  <?php if ($pageError !== ''): ?><div class="alert alert-warning"><?= fees_report_h($pageError) ?></div><?php endif; ?>
  <div class="row">
   <div class="col-md-6 col-xl-3"><div class="stat-card"><div class="stat-title">Fees Charged (after discounts)</div><div class="stat-number text-primary">UGX <?= number_format($summary['fees'],2) ?></div></div></div>
   <div class="col-md-6 col-xl-3"><div class="stat-card"><div class="stat-title">Payments Recorded</div><div class="stat-number text-success">UGX <?= number_format($summary['paid'],2) ?></div><div class="small-note">Based on selected fee accounts</div></div></div>
   <div class="col-md-6 col-xl-3"><div class="stat-card"><div class="stat-title">Outstanding Balance</div><div class="stat-number text-danger">UGX <?= number_format($summary['balance'],2) ?></div></div></div>
   <div class="col-md-6 col-xl-3"><div class="stat-card"><div class="stat-title">Fee Accounts</div><div class="stat-number"><?= number_format($summary['accounts']) ?></div><div class="small-note">Matching current filters</div></div></div>
  </div>
  <section class="panel no-print"><h5 class="mb-3"><i class="fas fa-filter text-success mr-2"></i>Report Filters</h5>
   <form method="GET" action="fees_report.php"><div class="form-row">
    <div class="form-group col-lg-3 col-md-6"><label for="search">Search student</label><input class="form-control" type="search" name="search" id="search" value="<?= fees_report_h($search) ?>" placeholder="Name, admission no., LIN, account ID"></div>
    <div class="form-group col-lg-2 col-md-6"><label for="academic_year">Academic year</label><select class="custom-select" name="academic_year" id="academic_year"><option value="">All years</option><?php foreach ($yearOptions as $opt): ?><option value="<?= fees_report_h($opt) ?>" <?= $yearFilter===$opt?'selected':'' ?>><?= fees_report_h($opt) ?></option><?php endforeach; ?></select></div>
    <div class="form-group col-lg-2 col-md-6"><label for="term">Term</label><select class="custom-select" name="term" id="term"><option value="">All terms</option><?php foreach ($termOptions as $opt): ?><option value="<?= fees_report_h($opt) ?>" <?= $termFilter===$opt?'selected':'' ?>><?= fees_report_h($opt) ?></option><?php endforeach; ?></select></div>
    <div class="form-group col-lg-2 col-md-6"><label for="account_status">Account status</label><select class="custom-select" name="account_status" id="account_status"><option value="">All account statuses</option><?php foreach (['Paid','Partially paid','Outstanding','Pending','Draft','Active','Cancelled'] as $opt): ?><option value="<?= fees_report_h($opt) ?>" <?= strcasecmp($accountStatusFilter,$opt)===0?'selected':'' ?>><?= fees_report_h($opt) ?></option><?php endforeach; ?></select></div>
    <div class="form-group col-lg-3 col-md-6 align-self-end"><button class="btn btn-success mr-1" type="submit"><i class="fas fa-search mr-1"></i>Apply</button><a class="btn btn-outline-secondary" href="fees_report.php">Reset</a></div>
   </div><div class="small-note">The account summary filters apply to the table and fee totals below. Payment date and status filters apply to the payment history report.</div></form>
  </section>
  <section class="panel">
   <div class="d-flex justify-content-between align-items-center flex-wrap mb-3"><h5 class="mb-2"><i class="fas fa-users text-primary mr-2"></i>Student Fee Accounts</h5><span class="text-muted small mb-2">Showing <?= number_format(count($filteredAccounts)) ?> matching accounts</span></div>
   <div class="table-responsive"><table class="table table-bordered table-hover"><thead><tr><th>#</th><th>Admission / LIN</th><th>Student</th><th>Academic Year</th><th>Term</th><th class="text-right">Total Fees</th><th class="text-right">Discount</th><th class="text-right">Paid</th><th class="text-right">Balance</th><th>Status</th></tr></thead><tbody>
   <?php if (!$filteredAccounts): ?><tr><td colspan="10" class="text-center text-muted py-4">No fee accounts match these filters.</td></tr><?php else: foreach ($filteredAccounts as $i=>$row): $st=strtolower($row['_display_status']); $badge=in_array($st,['paid'],true)?'success':(in_array($st,['outstanding','partially paid','pending'],true)?'warning':'secondary'); ?><tr><td><?= $i+1 ?></td><td><strong><?= fees_report_h($row['report_admission_no'] ?: '—') ?></strong><div class="small text-muted">LIN: <?= fees_report_h($row['report_lin_no'] ?: '—') ?></div><div class="small text-muted">Payment Code: <?= fees_report_h($row['report_student_payment_code'] ?: '—') ?></div></td><td><?= fees_report_h(trim($row['report_first_name'].' '.$row['report_last_name'])) ?><div class="small text-muted">Section: <?= fees_report_h($row['report_student_section'] ?: 'Day') ?> | Account #<?= (int)$row['report_account_id'] ?></div></td><td><?= fees_report_h($row['report_year'] ?: '—') ?></td><td><?= fees_report_h($row['report_term'] ?: '—') ?></td><td class="text-right"> <?= number_format((float)$row['report_total'],2) ?></td><td class="text-right"><?= number_format((float)$row['report_discount'],2) ?></td><td class="text-right text-success font-weight-bold"><?= number_format((float)$row['report_paid'],2) ?></td><td class="text-right text-danger font-weight-bold"><?= number_format((float)$row['report_balance'],2) ?></td><td><span class="badge badge-<?= $badge ?>"><?= fees_report_h($row['_display_status']) ?></span></td></tr><?php endforeach; endif; ?>
   </tbody><tfoot><tr class="font-weight-bold"><td colspan="5">TOTALS</td><td class="text-right"><?= number_format(array_sum(array_map(static fn($r)=>(float)$r['report_total'],$filteredAccounts)),2) ?></td><td class="text-right"><?= number_format($summary['discounts'],2) ?></td><td class="text-right text-success"><?= number_format($summary['paid'],2) ?></td><td class="text-right text-danger"><?= number_format($summary['balance'],2) ?></td><td></td></tr></tfoot></table></div>
  </section>
  <section class="panel">
   <div class="d-flex justify-content-between align-items-center flex-wrap"><h5 class="mb-3"><i class="fas fa-receipt text-success mr-2"></i>Payment History</h5><a class="btn btn-sm btn-outline-success mb-3 no-print" href="fees_report.php?<?= fees_report_h(http_build_query(array_merge($_GET,['export'=>'payments']))) ?>"><i class="fas fa-file-csv mr-1"></i>Export Payments</a></div>
   <form method="GET" action="fees_report.php" class="form-row align-items-end no-print mb-3">
    <?php if ($search!==''): ?><input type="hidden" name="search" value="<?= fees_report_h($search) ?>"><?php endif; ?><?php if ($yearFilter!==''): ?><input type="hidden" name="academic_year" value="<?= fees_report_h($yearFilter) ?>"><?php endif; ?><?php if ($termFilter!==''): ?><input type="hidden" name="term" value="<?= fees_report_h($termFilter) ?>"><?php endif; ?><?php if ($accountStatusFilter!==''): ?><input type="hidden" name="account_status" value="<?= fees_report_h($accountStatusFilter) ?>"><?php endif; ?>
    <div class="form-group col-md-3"><label for="from">Payment date from</label><input class="form-control" type="date" id="from" name="from" value="<?= fees_report_h($dateFrom) ?>"></div><div class="form-group col-md-3"><label for="to">Payment date to</label><input class="form-control" type="date" id="to" name="to" value="<?= fees_report_h($dateTo) ?>"></div>
    <div class="form-group col-md-3"><label for="payment_status">Payment status</label><select class="custom-select" id="payment_status" name="payment_status"><option value="">All payment statuses</option><?php foreach (['completed','complete','paid','pending','cancelled','refunded','reversed'] as $opt): ?><option value="<?= fees_report_h($opt) ?>" <?= $paymentStatusFilter===$opt?'selected':'' ?>><?= fees_report_h(ucfirst($opt)) ?></option><?php endforeach; ?></select></div><div class="form-group col-md-3"><button class="btn btn-success" type="submit"><i class="fas fa-filter mr-1"></i>Filter payments</button></div>
   </form>
   <div class="row mb-3"><div class="col-md-6"><div class="stat-card mb-2"><div class="stat-title">Payment rows shown</div><div class="stat-number"><?= number_format($summary['payments']) ?></div><div class="small-note">Maximum 500 rows</div></div></div><div class="col-md-6"><div class="stat-card mb-2"><div class="stat-title">Completed payments in current history filter</div><div class="stat-number text-success">UGX <?= number_format($summary['period_paid'],2) ?></div></div></div></div>
   <div class="table-responsive"><table class="table table-bordered table-hover"><thead><tr><th>#</th><th>Receipt No.</th><th>Student</th><th>Payment Date</th><th>Method</th><th>Reference / Notes</th><th>Status</th><th class="text-right">Amount (UGX)</th></tr></thead><tbody>
   <?php if (!$paymentRows): ?><tr><td colspan="8" class="text-center text-muted py-4">No payment records found for these filters.</td></tr><?php else: foreach ($paymentRows as $i=>$row): $pst=strtolower(trim((string)$row['report_payment_status'])); $pb=in_array($pst,['completed','complete','paid','success','successful','confirmed','approved','posted','received','settled','processed',''],true)?'success':(in_array($pst,['cancelled','canceled','refunded','reversed'],true)?'danger':'secondary'); $pd=$row['report_payment_date']??''; ?><tr><td><?= $i+1 ?></td><td><strong><?= fees_report_h($row['report_receipt'] ?: 'PAY-'.$row['report_payment_id']) ?></strong><div class="small text-muted">ID #<?= (int)$row['report_payment_id'] ?></div></td><td><?= fees_report_h(trim($row['report_first_name'].' '.$row['report_last_name']) ?: 'Unlinked student') ?><div class="small text-muted">Admission: <?= fees_report_h($row['report_admission_no'] ?: '—') ?></div><div class="small text-muted">LIN: <?= fees_report_h($row['report_lin_no'] ?: '—') ?> | Payment Code: <?= fees_report_h($row['report_student_payment_code'] ?: '—') ?> | <?= fees_report_h($row['report_student_section'] ?: 'Day') ?></div></td><td><?= $pd && strtotime((string)$pd)!==false ? fees_report_h(date('d M Y H:i',strtotime((string)$pd))) : '—' ?></td><td><?= fees_report_h($row['report_method'] ?: 'N/A') ?></td><td><?= fees_report_h($row['report_reference'] ?: '—') ?><?php if (trim((string)$row['report_notes'])!==''): ?><div class="small text-muted"><?= fees_report_h($row['report_notes']) ?></div><?php endif; ?></td><td><span class="badge badge-<?= $pb ?>"><?= fees_report_h(ucwords(str_replace('_',' ',$pst ?: 'completed'))) ?></span></td><td class="text-right font-weight-bold"><?= number_format((float)$row['report_payment_amount'],2) ?></td></tr><?php endforeach; endif; ?>
   </tbody></table></div><div class="small-note">The account summary uses the paid totals stored on student fee accounts. Payment history lists individual fee-payment records. Use both views when reconciling and avoid adding them together, as they describe the same collections from different perspectives.</div>
  </section>
  <p class="small text-muted text-center">School Management System &mdash; Bursar Fees Report</p>
 </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>(function(){const sidebar=document.getElementById('sidebar');const menu=document.getElementById('mobileMenuBtn');if(menu&&sidebar)menu.addEventListener('click',()=>sidebar.classList.toggle('show'));document.addEventListener('click',function(e){if(window.innerWidth<=991&&sidebar&&sidebar.classList.contains('show')&&!sidebar.contains(e.target)&&menu&&!menu.contains(e.target))sidebar.classList.remove('show');});})();</script>
</body>
</html>
