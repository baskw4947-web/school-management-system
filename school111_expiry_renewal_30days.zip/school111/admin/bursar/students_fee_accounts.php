<?php
/**
 * students_fee_accounts.php
 * Manage student fee accounts.
 */

error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');

require_once '../../config/database.php';
require_once '../../includes/auth.php';

requireRole(['administrator', 'assistant_administrator', 'bursar']);

$userId = (int)($_SESSION['user_id'] ?? $_SESSION['id'] ?? 0);

$message = '';
$error   = '';

/*
|--------------------------------------------------------------------------
| Helper functions
|--------------------------------------------------------------------------
*/

function clean($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function money($amount)
{
    return number_format((float)$amount, 2);
}

function getFeeStatus($total, $discount, $paid)
{
    $totalAfterDiscount = max((float)$total - (float)$discount, 0);
    $balance = max($totalAfterDiscount - (float)$paid, 0);

    if ($balance <= 0 && $totalAfterDiscount > 0) {
        return 'paid';
    }

    if ($paid > 0 && $balance > 0) {
        return 'partial';
    }

    return 'pending';
}

/*
|--------------------------------------------------------------------------
| DELETE FEE ACCOUNT
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_account'])) {

    $accountId = (int)($_POST['account_id'] ?? 0);

    if ($accountId <= 0) {
        $error = "Invalid fee account.";
    } else {

        /*
         * Do not allow deletion if payments already exist.
         */
        $check = $conn->prepare("
            SELECT COUNT(*) AS payment_count
            FROM fee_payments
            WHERE account_id = ?
        ");

        if ($check) {

            $check->bind_param("i", $accountId);
            $check->execute();

            $result = $check->get_result();
            $row = $result->fetch_assoc();

            $paymentCount = (int)($row['payment_count'] ?? 0);

            $check->close();

            if ($paymentCount > 0) {

                $error = "This fee account cannot be deleted because payments have already been recorded against it.";

            } else {

                $stmt = $conn->prepare("
                    DELETE FROM student_fee_accounts
                    WHERE id = ?
                ");

                if ($stmt) {

                    $stmt->bind_param("i", $accountId);

                    if ($stmt->execute()) {
                        $message = "Fee account deleted successfully.";
                    } else {
                        $error = "Unable to delete fee account: " . $stmt->error;
                    }

                    $stmt->close();

                } else {
                    $error = "Database error: " . $conn->error;
                }
            }

        } else {
            $error = "Unable to check payments: " . $conn->error;
        }
    }
}

/*
|--------------------------------------------------------------------------
| CREATE / UPDATE FEE ACCOUNT
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_account'])) {

    $accountId = (int)($_POST['account_id'] ?? 0);

    $studentId = (int)($_POST['student_id'] ?? 0);

    $academicYear = trim($_POST['academic_year'] ?? '');

    $term = trim($_POST['term'] ?? '');

    $totalAmount = (float)($_POST['total_amount'] ?? 0);

    $discountAmount = (float)($_POST['discount_amount'] ?? 0);

    $amountPaid = (float)($_POST['amount_paid'] ?? 0);

    /*
     * Validation
     */

    if ($studentId <= 0) {
        $error = "Please select a student.";
    } elseif ($academicYear === '') {
        $error = "Please enter the academic year.";
    } elseif (!in_array($term, ['Term 1', 'Term 2', 'Term 3'], true)) {
        $error = "Please select a valid term.";
    } elseif ($totalAmount < 0) {
        $error = "Total amount cannot be negative.";
    } elseif ($discountAmount < 0) {
        $error = "Discount cannot be negative.";
    } elseif ($discountAmount > $totalAmount) {
        $error = "Discount cannot be greater than the total amount.";
    } elseif ($amountPaid < 0) {
        $error = "Amount paid cannot be negative.";
    } elseif ($amountPaid > ($totalAmount - $discountAmount)) {
        $error = "Amount paid cannot be greater than the amount due after discount.";
    }

    if ($error === '') {

        $balance = max(
            $totalAmount - $discountAmount - $amountPaid,
            0
        );

        /*
         * Determine status
         */
        if ($balance <= 0 && ($totalAmount - $discountAmount) > 0) {
            $status = 'paid';
        } elseif ($amountPaid > 0) {
            $status = 'partial';
        } else {
            $status = 'pending';
        }

        /*
         * Keep total_paid synchronized with amount_paid.
         *
         * Your table contains both columns, so they are kept equal
         * when the fee account is manually created/updated.
         */
        $totalPaid = $amountPaid;

        /*
         * Check for duplicate student/year/term.
         */
        $duplicateSql = "
            SELECT id
            FROM student_fee_accounts
            WHERE student_id = ?
              AND academic_year = ?
              AND term = ?
        ";

        if ($accountId > 0) {
            $duplicateSql .= " AND id != ?";
        }

        $duplicate = $conn->prepare($duplicateSql);

        if ($duplicate) {

            if ($accountId > 0) {
                $duplicate->bind_param(
                    "issi",
                    $studentId,
                    $academicYear,
                    $term,
                    $accountId
                );
            } else {
                $duplicate->bind_param(
                    "iss",
                    $studentId,
                    $academicYear,
                    $term
                );
            }

            $duplicate->execute();

            $duplicateResult = $duplicate->get_result();

            if ($duplicateResult->num_rows > 0) {

                $error = "A fee account already exists for this student, academic year and term.";

            }

            $duplicate->close();

        } else {
            $error = "Database error while checking duplicate account: " . $conn->error;
        }
    }

    /*
     * Save account
     */
    if ($error === '') {

        if ($accountId > 0) {

            $stmt = $conn->prepare("
                UPDATE student_fee_accounts
                SET
                    student_id = ?,
                    academic_year = ?,
                    term = ?,
                    total_amount = ?,
                    total_paid = ?,
                    discount_amount = ?,
                    amount_paid = ?,
                    balance = ?,
                    status = ?
                WHERE id = ?
            ");

            if ($stmt) {

                $stmt->bind_param(
                    "issddddsi i",
                    $studentId,
                    $academicYear,
                    $term,
                    $totalAmount,
                    $totalPaid,
                    $discountAmount,
                    $amountPaid,
                    $balance,
                    $status,
                    $accountId
                );

                /*
                 * Fix spaces in type definition.
                 */
                $stmt->close();

                $stmt = $conn->prepare("
                    UPDATE student_fee_accounts
                    SET
                        student_id = ?,
                        academic_year = ?,
                        term = ?,
                        total_amount = ?,
                        total_paid = ?,
                        discount_amount = ?,
                        amount_paid = ?,
                        balance = ?,
                        status = ?
                    WHERE id = ?
                ");

                if ($stmt) {

                    $stmt->bind_param(
                        "issddddssi",
                        $studentId,
                        $academicYear,
                        $term,
                        $totalAmount,
                        $totalPaid,
                        $discountAmount,
                        $amountPaid,
                        $balance,
                        $status,
                        $accountId
                    );

                    if ($stmt->execute()) {
                        $message = "Fee account updated successfully.";
                    } else {
                        $error = "Unable to update fee account: " . $stmt->error;
                    }

                    $stmt->close();

                } else {
                    $error = "Database error: " . $conn->error;
                }

            } else {
                $error = "Database error: " . $conn->error;
            }

        } else {

            $stmt = $conn->prepare("
                INSERT INTO student_fee_accounts
                (
                    student_id,
                    academic_year,
                    term,
                    total_amount,
                    total_paid,
                    discount_amount,
                    amount_paid,
                    balance,
                    status
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            if ($stmt) {

                $stmt->bind_param(
                    "issddddds",
                    $studentId,
                    $academicYear,
                    $term,
                    $totalAmount,
                    $totalPaid,
                    $discountAmount,
                    $amountPaid,
                    $balance,
                    $status
                );

                if ($stmt->execute()) {
                    $message = "Fee account created successfully.";
                } else {
                    $error = "Unable to create fee account: " . $stmt->error;
                }

                $stmt->close();

            } else {
                $error = "Database error: " . $conn->error;
            }
        }
    }
}

/*
|--------------------------------------------------------------------------
| GET STUDENTS
|--------------------------------------------------------------------------
*/

$students = [];

$studentSql = "
    SELECT
        id,
        admission_no,
        lin_no,
        student_payment_code,
        student_section,
        first_name,
        last_name,
        other_names,
        status
    FROM students
    ORDER BY first_name ASC, last_name ASC
";

$studentResult = $conn->query($studentSql);

if ($studentResult) {

    while ($student = $studentResult->fetch_assoc()) {
        $students[] = $student;
    }

} else {
    $error = "Unable to load students: " . $conn->error;
}

/*
|--------------------------------------------------------------------------
| FILTERS
|--------------------------------------------------------------------------
*/

$search = trim($_GET['search'] ?? '');

$filterYear = trim($_GET['academic_year'] ?? '');

$filterTerm = trim($_GET['term'] ?? '');

$filterStatus = trim($_GET['status'] ?? '');

/*
|--------------------------------------------------------------------------
| GET FEE ACCOUNTS
|--------------------------------------------------------------------------
*/

$accounts = [];

$sql = "
    SELECT
        sfa.id,
        sfa.student_id,
        sfa.academic_year,
        sfa.term,
        sfa.total_amount,
        sfa.total_paid,
        sfa.discount_amount,
        sfa.amount_paid,
        sfa.balance,
        sfa.status,
        sfa.created_at,
        sfa.updated_at,

        s.admission_no,
        s.lin_no,
        s.student_payment_code,
        s.student_section,
        s.first_name,
        s.last_name,
        s.other_names,

        GREATEST(
            COALESCE(sfa.total_amount, 0)
            - COALESCE(sfa.discount_amount, 0)
            - COALESCE(sfa.amount_paid, 0),
            0
        ) AS calculated_balance

    FROM student_fee_accounts sfa

    INNER JOIN students s
        ON s.id = sfa.student_id

    WHERE 1=1
";

$params = [];
$types = '';

if ($search !== '') {

    $sql .= "
        AND (
            s.admission_no LIKE ?
            OR s.lin_no LIKE ?
            OR s.student_payment_code LIKE ?
            OR s.first_name LIKE ?
            OR s.last_name LIKE ?
            OR s.other_names LIKE ?
        )
    ";

    $searchLike = '%' . $search . '%';

    $params[] = $searchLike;
    $params[] = $searchLike;
    $params[] = $searchLike;
    $params[] = $searchLike;
    $params[] = $searchLike;
    $params[] = $searchLike;

    $types .= 'ssssss';
}

if ($filterYear !== '') {

    $sql .= " AND sfa.academic_year = ? ";

    $params[] = $filterYear;
    $types .= 's';
}

if ($filterTerm !== '') {

    $sql .= " AND sfa.term = ? ";

    $params[] = $filterTerm;
    $types .= 's';
}

if ($filterStatus !== '') {

    $sql .= " AND sfa.status = ? ";

    $params[] = $filterStatus;
    $types .= 's';
}

$sql .= "
    ORDER BY
        sfa.academic_year DESC,
        sfa.term ASC,
        s.first_name ASC,
        s.last_name ASC
";

$stmt = $conn->prepare($sql);

if ($stmt) {

    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }

    $stmt->execute();

    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $accounts[] = $row;
    }

    $stmt->close();

} else {

    $error = "Unable to load fee accounts: " . $conn->error;
}

/*
|--------------------------------------------------------------------------
| SUMMARY
|--------------------------------------------------------------------------
*/

$totalAccounts = count($accounts);

$totalFees = 0;
$totalDiscounts = 0;
$totalPaid = 0;
$totalBalance = 0;

$pendingCount = 0;
$partialCount = 0;
$paidCount = 0;
$overdueCount = 0;

foreach ($accounts as $account) {

    $totalFees += (float)$account['total_amount'];

    $totalDiscounts += (float)$account['discount_amount'];

    $totalPaid += (float)$account['amount_paid'];

    $totalBalance += (float)$account['calculated_balance'];

    switch ($account['status']) {

        case 'paid':
            $paidCount++;
            break;

        case 'partial':
            $partialCount++;
            break;

        case 'overdue':
            $overdueCount++;
            break;

        default:
            $pendingCount++;
            break;
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Student Fee Accounts - CLC School Management System</title>

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
    >

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
    >

    <style>

        body {
            background: #f5f6fa;
            font-family: Arial, sans-serif;
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            width: 250px;
            background: #212529;
            z-index: 1030;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 20px 15px;
            color: #fff;
            font-weight: 700;
            border-bottom: 1px solid rgba(255,255,255,.1);
        }

        .sidebar-menu {
            padding: 15px 10px;
        }

        .sidebar-section {
            color: #6c757d;
            font-size: 11px;
            text-transform: uppercase;
            padding: 12px 10px 6px;
        }

        .sidebar a {
            display: block;
            color: #ced4da;
            padding: 12px 15px;
            margin-bottom: 3px;
            text-decoration: none;
            border-radius: 6px;
        }

        .sidebar a:hover {
            background: #343a40;
            color: #fff;
        }

        .sidebar a.active {
            background: #dc3545;
            color: #fff;
        }

        .sidebar i {
            width: 25px;
            text-align: center;
            margin-right: 5px;
        }

        .main-content {
            margin-left: 250px;
            padding: 25px;
        }

        .page-title {
            font-weight: 700;
            margin-bottom: 5px;
        }

        .page-subtitle {
            color: #6c757d;
            margin-bottom: 25px;
        }

        .summary-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,.06);
        }

        .summary-number {
            font-size: 24px;
            font-weight: 700;
        }

        .summary-label {
            color: #6c757d;
            font-size: 13px;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,.05);
        }

        .table th {
            background: #f8f9fa;
            border-top: none;
            font-size: 13px;
            white-space: nowrap;
        }

        .table td {
            vertical-align: middle;
            font-size: 13px;
        }

        .student-name {
            font-weight: 600;
        }

        .admission-no {
            font-size: 12px;
            color: #6c757d;
        }

        .badge-status {
            padding: 7px 10px;
            border-radius: 20px;
        }

        .filter-card {
            margin-bottom: 20px;
        }

        .btn {
            border-radius: 6px;
        }

        .modal-header {
            background: #212529;
            color: #fff;
        }

        .modal-header .close {
            color: #fff;
        }

        .form-control,
        .custom-select {
            border-radius: 6px;
        }

        @media (max-width: 991px) {

            .sidebar {
                width: 220px;
            }

            .main-content {
                margin-left: 220px;
            }
        }

        @media (max-width: 767px) {

            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
            }

            .main-content {
                margin-left: 0;
                padding: 15px;
            }

            .table-responsive {
                font-size: 12px;
            }
        }

    </style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>

<body>
<button type="button" id="unifiedSidebarToggle" class="unified-sidebar-toggle" aria-label="Open navigation" aria-controls="sidebar" aria-expanded="false"><i class="fas fa-bars"></i></button>
<div id="unifiedSidebarOverlay" class="sidebar-overlay"></div>


<!-- =========================================================
     SIDEBAR
========================================================= -->

<div class="sidebar">

    <div class="sidebar-header">
    <i class="fas fa-university"></i>
    <span>Bursar</span>
</div>


    <div class="sidebar-menu">

        <a href="/admin/bursar/index.php">
            <i class="fas fa-tachometer-alt"></i>
            Dashboard
        </a>

        <div class="sidebar-section">
            Students & Fees
        </div>
        <a href="/admin/bursar/students_fees.php" >
            <i class="fas fa-file-invoice-dollar"></i>
            Student Fees
        </a>

        <a href="/admin/bursar/students_fee_accounts.php" class="active">
            <i class="fas fa-file-invoice-dollar"></i>
            Student Fee Accounts
        </a>

        <a href="/admin/bursar/fee_structure.php">
            <i class="fas fa-list-alt"></i>
            Fee Structure
        </a>

        <a href="/admin/bursar/payments.php">
            <i class="fas fa-money-bill-wave"></i>
            Receive Payment
        </a>

        <a href="/admin/bursar/outstanding_fees.php">
            <i class="fas fa-exclamation-circle"></i>
            Outstanding Fees
        </a>

        <div class="sidebar-section">
            Finance
        </div>

        <a href="/admin/bursar/income.php">
            <i class="fas fa-arrow-circle-down"></i>
            Income
        </a>

        <a href="/admin/bursar/expenses.php">
            <i class="fas fa-arrow-circle-up"></i>
            Expenses
        </a>

        <a href="/admin/bursar/suppliers.php">
            <i class="fas fa-truck"></i>
            Suppliers
        </a>

        <a href="/admin/bursar/supplier_payments.php">
            <i class="fas fa-hand-holding-usd"></i>
            Supplier Payments
        </a>

        <div class="sidebar-section">
            Payroll & Budget
        </div>

        <a href="/admin/bursar/salaries.php">
            <i class="fas fa-users"></i>
            Salaries
        </a>

        <a href="/admin/bursar/salary_payments.php">
            <i class="fas fa-money-check-alt"></i>
            Salary Payments
        </a>

        <a href="/admin/bursar/budgets.php">
            <i class="fas fa-chart-pie"></i>
            Budgets
        </a>

        <div class="sidebar-section">
            Reports
        </div>

        <a href="/admin/bursar/cashbook.php">
            <i class="fas fa-book"></i>
            Cashbook
        </a>

        <a href="/admin/bursar/financial_reports.php">
            <i class="fas fa-chart-line"></i>
            Financial Reports
        </a>

        <a href="/admin/bursar/income_report.php">
            <i class="fas fa-file-invoice"></i>
            Income Report
        </a>

        <a href="/admin/bursar/expense_report.php">
            <i class="fas fa-receipt"></i>
            Expense Report
        </a>

        <a href="/admin/bursar/fees_report.php">
            <i class="fas fa-file-alt"></i>
            Fees Report
        </a>

        <a href="/admin/bursar/profit_loss.php">
            <i class="fas fa-balance-scale"></i>
            Profit & Loss
        </a>

        <div class="sidebar-section">
            System
        </div>

        <a href="/admin/dashboard.php">
            <i class="fas fa-user-shield"></i>
            Admin Dashboard
        </a>

        <a href="/logout.php">
            <i class="fas fa-sign-out-alt"></i>
            Logout
        </a>

    </div>

</div>


<!-- =========================================================
     MAIN CONTENT
========================================================= -->

<div class="main-content">

    <div class="d-flex justify-content-between align-items-center mb-3">

        <div>
            <h2 class="page-title">
                <i class="fas fa-file-invoice-dollar text-danger"></i>
                Student Fee Accounts
            </h2>

            <div class="page-subtitle">
                Manage student fee accounts, payments, discounts and balances.
            </div>
        </div>

        <button
            class="btn btn-danger"
            data-toggle="modal"
            data-target="#addAccountModal"
        >
            <i class="fas fa-plus"></i>
            Create Fee Account
        </button>

    </div>


    <!-- =====================================================
         ALERTS
    ====================================================== -->

    <?php if ($message !== ''): ?>

        <div class="alert alert-success alert-dismissible fade show">

            <i class="fas fa-check-circle"></i>

            <?= clean($message) ?>

            <button type="button" class="close" data-dismiss="alert">
                <span>&times;</span>
            </button>

        </div>

    <?php endif; ?>


    <?php if ($error !== ''): ?>

        <div class="alert alert-danger alert-dismissible fade show">

            <i class="fas fa-exclamation-triangle"></i>

            <?= clean($error) ?>

            <button type="button" class="close" data-dismiss="alert">
                <span>&times;</span>
            </button>

        </div>

    <?php endif; ?>


    <!-- =====================================================
         SUMMARY CARDS
    ====================================================== -->

    <div class="row">

        <div class="col-md-6 col-xl-3 mb-4">

            <div class="card summary-card">

                <div class="card-body">

                    <div class="summary-label">
                        Total Fee Accounts
                    </div>

                    <div class="summary-number text-primary">
                        <?= $totalAccounts ?>
                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-6 col-xl-3 mb-4">

            <div class="card summary-card">

                <div class="card-body">

                    <div class="summary-label">
                        Total Fees
                    </div>

                    <div class="summary-number">
                        <?= money($totalFees) ?>
                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-6 col-xl-3 mb-4">

            <div class="card summary-card">

                <div class="card-body">

                    <div class="summary-label">
                        Total Paid
                    </div>

                    <div class="summary-number text-success">
                        <?= money($totalPaid) ?>
                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-6 col-xl-3 mb-4">

            <div class="card summary-card">

                <div class="card-body">

                    <div class="summary-label">
                        Outstanding Balance
                    </div>

                    <div class="summary-number text-danger">
                        <?= money($totalBalance) ?>
                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- =====================================================
         FILTERS
    ====================================================== -->

    <div class="card filter-card">

        <div class="card-body">

            <form method="GET">

                <div class="form-row">

                    <div class="col-md-4 mb-2">

                        <label>
                            Search Student
                        </label>

                        <input
                            type="text"
                            name="search"
                            class="form-control"
                            placeholder="Admission No, first name or last name"
                            value="<?= clean($search) ?>"
                        >

                    </div>


                    <div class="col-md-2 mb-2">

                        <label>
                            Academic Year
                        </label>

                        <input
                            type="text"
                            name="academic_year"
                            class="form-control"
                            placeholder="2026"
                            value="<?= clean($filterYear) ?>"
                        >

                    </div>


                    <div class="col-md-2 mb-2">

                        <label>
                            Term
                        </label>

                        <select
                            name="term"
                            class="custom-select"
                        >

                            <option value="">
                                All Terms
                            </option>

                            <option
                                value="Term 1"
                                <?= $filterTerm === 'Term 1' ? 'selected' : '' ?>
                            >
                                Term 1
                            </option>

                            <option
                                value="Term 2"
                                <?= $filterTerm === 'Term 2' ? 'selected' : '' ?>
                            >
                                Term 2
                            </option>

                            <option
                                value="Term 3"
                                <?= $filterTerm === 'Term 3' ? 'selected' : '' ?>
                            >
                                Term 3
                            </option>

                        </select>

                    </div>


                    <div class="col-md-2 mb-2">

                        <label>
                            Status
                        </label>

                        <select
                            name="status"
                            class="custom-select"
                        >

                            <option value="">
                                All Status
                            </option>

                            <option
                                value="pending"
                                <?= $filterStatus === 'pending' ? 'selected' : '' ?>
                            >
                                Pending
                            </option>

                            <option
                                value="partial"
                                <?= $filterStatus === 'partial' ? 'selected' : '' ?>
                            >
                                Partial
                            </option>

                            <option
                                value="paid"
                                <?= $filterStatus === 'paid' ? 'selected' : '' ?>
                            >
                                Paid
                            </option>

                            <option
                                value="overdue"
                                <?= $filterStatus === 'overdue' ? 'selected' : '' ?>
                            >
                                Overdue
                            </option>

                        </select>

                    </div>


                    <div class="col-md-2 mb-2 d-flex align-items-end">

                        <button
                            type="submit"
                            class="btn btn-dark mr-2"
                        >
                            <i class="fas fa-search"></i>
                            Filter
                        </button>

                        <a
                            href="students_fee_accounts.php"
                            class="btn btn-outline-secondary"
                        >
                            Reset
                        </a>

                    </div>

                </div>

            </form>

        </div>

    </div>


    <!-- =====================================================
         ACCOUNT TABLE
    ====================================================== -->

    <div class="card">

        <div class="card-header bg-white">

            <div class="d-flex justify-content-between align-items-center">

                <strong>
                    <i class="fas fa-list"></i>
                    Fee Accounts
                </strong>

                <span class="badge badge-secondary">
                    <?= $totalAccounts ?> account(s)
                </span>

            </div>

        </div>


        <div class="card-body p-0">

            <div class="table-responsive">

                <table class="table table-hover mb-0">

                    <thead>

                        <tr>

                            <th>#</th>

                            <th>Student</th>

                            <th>Academic Year</th>

                            <th>Term</th>

                            <th class="text-right">
                                Total Fee
                            </th>

                            <th class="text-right">
                                Discount
                            </th>

                            <th class="text-right">
                                Paid
                            </th>

                            <th class="text-right">
                                Balance
                            </th>

                            <th>Status</th>

                            <th class="text-center">
                                Actions
                            </th>

                        </tr>

                    </thead>

                    <tbody>

                    <?php if (empty($accounts)): ?>

                        <tr>

                            <td
                                colspan="10"
                                class="text-center py-5 text-muted"
                            >

                                <i class="fas fa-file-invoice fa-3x mb-3"></i>

                                <br>

                                No student fee accounts found.

                            </td>

                        </tr>

                    <?php else: ?>

                        <?php foreach ($accounts as $index => $account): ?>

                            <?php

                            $studentName = trim(
                                $account['first_name'] . ' ' .
                                ($account['other_names'] ?? '') . ' ' .
                                $account['last_name']
                            );

                            $balance = max(
                                (float)$account['calculated_balance'],
                                0
                            );

                            ?>

                            <tr>

                                <td>
                                    <?= $index + 1 ?>
                                </td>


                                <td>

                                    <div class="student-name">
                                        <?= clean($studentName) ?>
                                    </div>

                                    <div class="admission-no">
                                        Admission: <?= clean($account['admission_no']) ?>
                                    </div>
                                    <div class="admission-no">
                                        LIN: <?= clean($account['lin_no'] ?: '—') ?>
                                        &nbsp;|&nbsp; Payment Code: <?= clean($account['student_payment_code'] ?: '—') ?>
                                        &nbsp;|&nbsp; <?= clean($account['student_section'] ?: 'Day') ?>
                                    </div>

                                </td>


                                <td>
                                    <?= clean($account['academic_year']) ?>
                                </td>


                                <td>
                                    <?= clean($account['term']) ?>
                                </td>


                                <td class="text-right">

                                    <?= money($account['total_amount']) ?>

                                </td>


                                <td class="text-right text-warning">

                                    <?= money($account['discount_amount']) ?>

                                </td>


                                <td class="text-right text-success">

                                    <?= money($account['amount_paid']) ?>

                                </td>


                                <td class="text-right font-weight-bold
                                    <?= $balance > 0 ? 'text-danger' : 'text-success' ?>">

                                    <?= money($balance) ?>

                                </td>


                                <td>

                                    <?php if ($account['status'] === 'paid'): ?>

                                        <span class="badge badge-success badge-status">
                                            <i class="fas fa-check"></i>
                                            Paid
                                        </span>

                                    <?php elseif ($account['status'] === 'partial'): ?>

                                        <span class="badge badge-warning badge-status">
                                            <i class="fas fa-adjust"></i>
                                            Partial
                                        </span>

                                    <?php elseif ($account['status'] === 'overdue'): ?>

                                        <span class="badge badge-danger badge-status">
                                            <i class="fas fa-exclamation"></i>
                                            Overdue
                                        </span>

                                    <?php else: ?>

                                        <span class="badge badge-secondary badge-status">
                                            <i class="fas fa-clock"></i>
                                            Pending
                                        </span>

                                    <?php endif; ?>

                                </td>


                                <td class="text-center">

                                    <button
                                        type="button"
                                        class="btn btn-sm btn-outline-primary edit-account"
                                        data-id="<?= (int)$account['id'] ?>"
                                        data-student="<?= (int)$account['student_id'] ?>"
                                        data-year="<?= clean($account['academic_year']) ?>"
                                        data-term="<?= clean($account['term']) ?>"
                                        data-total="<?= htmlspecialchars($account['total_amount']) ?>"
                                        data-discount="<?= htmlspecialchars($account['discount_amount']) ?>"
                                        data-paid="<?= htmlspecialchars($account['amount_paid']) ?>"
                                        data-toggle="modal"
                                        data-target="#editAccountModal"
                                    >

                                        <i class="fas fa-edit"></i>

                                    </button>


                                    <?php if ((float)$account['amount_paid'] <= 0): ?>

                                        <button
                                            type="button"
                                            class="btn btn-sm btn-outline-danger delete-account"
                                            data-id="<?= (int)$account['id'] ?>"
                                            data-student="<?= clean($studentName) ?>"
                                            data-toggle="modal"
                                            data-target="#deleteModal"
                                        >

                                            <i class="fas fa-trash"></i>

                                        </button>

                                    <?php endif; ?>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>


</div>


<!-- =========================================================
     ADD ACCOUNT MODAL
========================================================= -->

<div
    class="modal fade"
    id="addAccountModal"
    tabindex="-1"
>

    <div class="modal-dialog modal-lg">

        <div class="modal-content">

            <form method="POST">

                <div class="modal-header">

                    <h5 class="modal-title">
                        <i class="fas fa-plus-circle"></i>
                        Create Student Fee Account
                    </h5>

                    <button
                        type="button"
                        class="close"
                        data-dismiss="modal"
                    >
                        <span>&times;</span>
                    </button>

                </div>


                <div class="modal-body">

                    <input
                        type="hidden"
                        name="save_account"
                        value="1"
                    >

                    <input
                        type="hidden"
                        name="account_id"
                        value="0"
                    >


                    <div class="form-group">

                        <label>
                            Student <span class="text-danger">*</span>
                        </label>

                        <select
                            name="student_id"
                            class="custom-select"
                            required
                        >

                            <option value="">
                                Select Student
                            </option>

                            <?php foreach ($students as $student): ?>

                                <?php

                                $studentName = trim(
                                    $student['first_name'] . ' ' .
                                    ($student['other_names'] ?? '') . ' ' .
                                    $student['last_name']
                                );

                                ?>

                                <option
                                    value="<?= (int)$student['id'] ?>"
                                >

                                    <?= clean($student['admission_no']) ?>
                                    -
                                    <?= clean($studentName) ?>
                                    | LIN: <?= clean($student['lin_no'] ?: '—') ?>
                                    | Payment Code: <?= clean($student['student_payment_code'] ?: '—') ?>
                                    | <?= clean($student['student_section'] ?: 'Day') ?>

                                    <?php if ($student['status'] !== 'active'): ?>
                                        (<?= clean(ucfirst($student['status'])) ?>)
                                    <?php endif; ?>

                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <div class="form-row">

                        <div class="form-group col-md-6">

                            <label>
                                Academic Year <span class="text-danger">*</span>
                            </label>

                            <input
                                type="text"
                                name="academic_year"
                                class="form-control"
                                placeholder="2026"
                                value="<?= date('Y') ?>"
                                required
                            >

                        </div>


                        <div class="form-group col-md-6">

                            <label>
                                Term <span class="text-danger">*</span>
                            </label>

                            <select
                                name="term"
                                class="custom-select"
                                required
                            >

                                <option value="">
                                    Select Term
                                </option>

                                <option value="Term 1">
                                    Term 1
                                </option>

                                <option value="Term 2">
                                    Term 2
                                </option>

                                <option value="Term 3">
                                    Term 3
                                </option>

                            </select>

                        </div>

                    </div>


                    <div class="form-row">

                        <div class="form-group col-md-4">

                            <label>
                                Total Fee
                            </label>

                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                name="total_amount"
                                id="add_total_amount"
                                class="form-control"
                                value="0.00"
                                required
                            >

                        </div>


                        <div class="form-group col-md-4">

                            <label>
                                Discount
                            </label>

                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                name="discount_amount"
                                id="add_discount_amount"
                                class="form-control"
                                value="0.00"
                            >

                        </div>


                        <div class="form-group col-md-4">

                            <label>
                                Amount Paid
                            </label>

                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                name="amount_paid"
                                id="add_amount_paid"
                                class="form-control"
                                value="0.00"
                            >

                        </div>

                    </div>


                    <div class="alert alert-light border">

                        <div class="row">

                            <div class="col-md-6">

                                <small class="text-muted">
                                    Amount Due
                                </small>

                                <h5 id="add_due">
                                    0.00
                                </h5>

                            </div>

                            <div class="col-md-6">

                                <small class="text-muted">
                                    Balance
                                </small>

                                <h5
                                    id="add_balance"
                                    class="text-danger"
                                >
                                    0.00
                                </h5>

                            </div>

                        </div>

                    </div>

                </div>


                <div class="modal-footer">

                    <button
                        type="button"
                        class="btn btn-secondary"
                        data-dismiss="modal"
                    >
                        Cancel
                    </button>

                    <button
                        type="submit"
                        class="btn btn-danger"
                    >

                        <i class="fas fa-save"></i>
                        Save Fee Account

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>


<!-- =========================================================
     EDIT ACCOUNT MODAL
========================================================= -->

<div
    class="modal fade"
    id="editAccountModal"
    tabindex="-1"
>

    <div class="modal-dialog modal-lg">

        <div class="modal-content">

            <form method="POST">

                <div class="modal-header">

                    <h5 class="modal-title">
                        <i class="fas fa-edit"></i>
                        Edit Student Fee Account
                    </h5>

                    <button
                        type="button"
                        class="close"
                        data-dismiss="modal"
                    >
                        <span>&times;</span>
                    </button>

                </div>


                <div class="modal-body">

                    <input
                        type="hidden"
                        name="save_account"
                        value="1"
                    >

                    <input
                        type="hidden"
                        name="account_id"
                        id="edit_account_id"
                    >


                    <div class="form-group">

                        <label>
                            Student
                        </label>

                        <select
                            name="student_id"
                            id="edit_student_id"
                            class="custom-select"
                            required
                        >

                            <option value="">
                                Select Student
                            </option>

                            <?php foreach ($students as $student): ?>

                                <?php

                                $studentName = trim(
                                    $student['first_name'] . ' ' .
                                    ($student['other_names'] ?? '') . ' ' .
                                    $student['last_name']
                                );

                                ?>

                                <option
                                    value="<?= (int)$student['id'] ?>"
                                >

                                    <?= clean($student['admission_no']) ?>
                                    -
                                    <?= clean($studentName) ?>
                                    | LIN: <?= clean($student['lin_no'] ?: '—') ?>
                                    | Payment Code: <?= clean($student['student_payment_code'] ?: '—') ?>
                                    | <?= clean($student['student_section'] ?: 'Day') ?>

                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <div class="form-row">

                        <div class="form-group col-md-6">

                            <label>
                                Academic Year
                            </label>

                            <input
                                type="text"
                                name="academic_year"
                                id="edit_academic_year"
                                class="form-control"
                                required
                            >

                        </div>


                        <div class="form-group col-md-6">

                            <label>
                                Term
                            </label>

                            <select
                                name="term"
                                id="edit_term"
                                class="custom-select"
                                required
                            >

                                <option value="Term 1">
                                    Term 1
                                </option>

                                <option value="Term 2">
                                    Term 2
                                </option>

                                <option value="Term 3">
                                    Term 3
                                </option>

                            </select>

                        </div>

                    </div>


                    <div class="form-row">

                        <div class="form-group col-md-4">

                            <label>
                                Total Fee
                            </label>

                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                name="total_amount"
                                id="edit_total_amount"
                                class="form-control"
                                required
                            >

                        </div>


                        <div class="form-group col-md-4">

                            <label>
                                Discount
                            </label>

                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                name="discount_amount"
                                id="edit_discount_amount"
                                class="form-control"
                            >

                        </div>


                        <div class="form-group col-md-4">

                            <label>
                                Amount Paid
                            </label>

                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                name="amount_paid"
                                id="edit_amount_paid"
                                class="form-control"
                            >

                        </div>

                    </div>


                    <div class="alert alert-light border">

                        <div class="row">

                            <div class="col-md-6">

                                <small class="text-muted">
                                    Amount Due
                                </small>

                                <h5 id="edit_due">
                                    0.00
                                </h5>

                            </div>

                            <div class="col-md-6">

                                <small class="text-muted">
                                    Balance
                                </small>

                                <h5
                                    id="edit_balance"
                                    class="text-danger"
                                >
                                    0.00
                                </h5>

                            </div>

                        </div>

                    </div>

                </div>


                <div class="modal-footer">

                    <button
                        type="button"
                        class="btn btn-secondary"
                        data-dismiss="modal"
                    >
                        Cancel
                    </button>

                    <button
                        type="submit"
                        class="btn btn-primary"
                    >

                        <i class="fas fa-save"></i>
                        Update Account

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>


<!-- =========================================================
     DELETE MODAL
========================================================= -->

<div
    class="modal fade"
    id="deleteModal"
    tabindex="-1"
>

    <div class="modal-dialog">

        <div class="modal-content">

            <form method="POST">

                <div class="modal-header bg-danger">

                    <h5 class="modal-title">
                        Confirm Delete
                    </h5>

                    <button
                        type="button"
                        class="close"
                        data-dismiss="modal"
                    >
                        <span>&times;</span>
                    </button>

                </div>


                <div class="modal-body">

                    <input
                        type="hidden"
                        name="delete_account"
                        value="1"
                    >

                    <input
                        type="hidden"
                        name="account_id"
                        id="delete_account_id"
                    >

                    <p>
                        Are you sure you want to delete the fee account for:
                    </p>

                    <h5 id="delete_student_name"></h5>

                    <div class="alert alert-warning mt-3">

                        <i class="fas fa-exclamation-triangle"></i>

                        This action cannot be undone.

                    </div>

                </div>


                <div class="modal-footer">

                    <button
                        type="button"
                        class="btn btn-secondary"
                        data-dismiss="modal"
                    >
                        Cancel
                    </button>

                    <button
                        type="submit"
                        class="btn btn-danger"
                    >

                        <i class="fas fa-trash"></i>
                        Delete Account

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>


<!-- =========================================================
     JAVASCRIPT
========================================================= -->

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>


<script>

$(document).ready(function () {

    /*
    |--------------------------------------------------------------------------
    | Calculate ADD balance
    |--------------------------------------------------------------------------
    */

    function calculateAddBalance() {

        let total = parseFloat($('#add_total_amount').val()) || 0;

        let discount = parseFloat($('#add_discount_amount').val()) || 0;

        let paid = parseFloat($('#add_amount_paid').val()) || 0;

        let due = Math.max(total - discount, 0);

        let balance = Math.max(due - paid, 0);

        $('#add_due').text(due.toFixed(2));

        $('#add_balance').text(balance.toFixed(2));
    }


    $('#add_total_amount, #add_discount_amount, #add_amount_paid')
        .on('input', calculateAddBalance);


    /*
    |--------------------------------------------------------------------------
    | Calculate EDIT balance
    |--------------------------------------------------------------------------
    */

    function calculateEditBalance() {

        let total = parseFloat($('#edit_total_amount').val()) || 0;

        let discount = parseFloat($('#edit_discount_amount').val()) || 0;

        let paid = parseFloat($('#edit_amount_paid').val()) || 0;

        let due = Math.max(total - discount, 0);

        let balance = Math.max(due - paid, 0);

        $('#edit_due').text(due.toFixed(2));

        $('#edit_balance').text(balance.toFixed(2));
    }


    $('#edit_total_amount, #edit_discount_amount, #edit_amount_paid')
        .on('input', calculateEditBalance);


    /*
    |--------------------------------------------------------------------------
    | EDIT BUTTON
    |--------------------------------------------------------------------------
    */

    $('.edit-account').on('click', function () {

        let button = $(this);

        $('#edit_account_id').val(button.data('id'));

        $('#edit_student_id').val(button.data('student'));

        $('#edit_academic_year').val(button.data('year'));

        $('#edit_term').val(button.data('term'));

        $('#edit_total_amount').val(button.data('total'));

        $('#edit_discount_amount').val(button.data('discount'));

        $('#edit_amount_paid').val(button.data('paid'));

        calculateEditBalance();

    });


    /*
    |--------------------------------------------------------------------------
    | DELETE BUTTON
    |--------------------------------------------------------------------------
    */

    $('.delete-account').on('click', function () {

        let button = $(this);

        $('#delete_account_id').val(button.data('id'));

        $('#delete_student_name').text(
            button.data('student')
        );

    });


    /*
    |--------------------------------------------------------------------------
    | Initial calculation
    |--------------------------------------------------------------------------
    */

    calculateAddBalance();

});

</script>


<script src="/assets/js/sidebar-unified.js?v=20261106"></script>
</body>

</html>