<?php
/**
 * School Management System - Bursar Budgets
 * Uses the same session, database, authentication and MySQLi settings as payments.php.
 * Save as UTF-8 without BOM. The opening PHP tag must be the first bytes in the file.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator', 'bursar']);

if (!isset($conn) || !($conn instanceof mysqli)) {
    http_response_code(500);
    exit('Database connection is unavailable. Please check config/database.php.');
}
$conn->set_charset('utf8mb4');
$userId = (int)($_SESSION['user_id'] ?? $_SESSION['id'] ?? 0);

if (empty($_SESSION['budgets_csrf'])) {
    $_SESSION['budgets_csrf'] = bin2hex(random_bytes(32));
}
$csrfToken = (string)$_SESSION['budgets_csrf'];

function budgetPageE($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function budgetPageTableExists(mysqli $conn, string $table): bool
{
    $safe = $conn->real_escape_string($table);
    $result = $conn->query("SHOW TABLES LIKE '{$safe}'");
    return $result && $result->num_rows > 0;
}

function budgetPageColumns(mysqli $conn, string $table): array
{
    $safeTable = str_replace('`', '', $table);
    $result = $conn->query("SHOW COLUMNS FROM `{$safeTable}`");
    $columns = [];
    while ($row = $result->fetch_assoc()) {
        $columns[$row['Field']] = $row;
    }
    $result->free();
    return $columns;
}

function budgetPagePick(array $columns, array $candidates): ?string
{
    foreach ($candidates as $candidate) {
        if (isset($columns[$candidate])) return $candidate;
    }
    return null;
}

function budgetPageEnumValues(?string $type): array
{
    if (!$type || stripos($type, 'enum(') !== 0) return [];
    preg_match_all("/'((?:[^'\\\\]|\\\\.)*)'/", $type, $matches);
    return array_map(static fn($v) => stripcslashes($v), $matches[1] ?? []);
}

function budgetPageEnumChoice(?array $column, array $preferred, string $fallback): string
{
    if (!$column) return $fallback;
    $values = budgetPageEnumValues($column['Type'] ?? null);
    if (!$values) return $fallback;
    foreach ($preferred as $candidate) {
        if (in_array($candidate, $values, true)) return $candidate;
    }
    return $values[0];
}

function budgetPageBind(mysqli_stmt $stmt, string $types, array &$values): void
{
    if ($types === '') return;
    $args = [$types];
    foreach ($values as &$value) $args[] = &$value;
    call_user_func_array([$stmt, 'bind_param'], $args);
}

function budgetPageRedirect(): void
{
    header('Location: budgets.php');
    exit;
}

function budgetPageFlash(string $type, string $message): void
{
    $_SESSION['budgets_flash'] = ['type' => $type, 'message' => $message];
}

function budgetPageDate(?string $date): bool
{
    if ($date === null || $date === '') return true;
    $parsed = DateTime::createFromFormat('!Y-m-d', $date);
    $errors = DateTime::getLastErrors();
    return $parsed !== false && $parsed->format('Y-m-d') === $date &&
        ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0));
}

function budgetPageMakeCode(mysqli $conn, ?string $codeColumn): string
{
    if (!$codeColumn) return '';
    for ($i = 0; $i < 10; $i++) {
        $code = 'BUD-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(2)));
        $stmt = $conn->prepare('SELECT 1 FROM `budgets` WHERE `' . str_replace('`', '', $codeColumn) . '` = ? LIMIT 1');
        $stmt->bind_param('s', $code);
        $stmt->execute();
        $exists = (bool)$stmt->get_result()->fetch_row();
        $stmt->close();
        if (!$exists) return $code;
    }
    throw new RuntimeException('A unique budget code could not be generated. Please try again.');
}

$schemaError = '';
$pageError = '';
$createdBudgetTable = false;
$budgetColumns = [];
$budgetMap = [];
$statusValues = [];
$allRows = [];
$shownRows = [];
$spentByBudget = [];
$hasExpenseBudgetLink = false;
$flash = $_SESSION['budgets_flash'] ?? null;
unset($_SESSION['budgets_flash']);
$search = trim((string)($_GET['search'] ?? ''));
$yearFilter = trim((string)($_GET['year'] ?? ''));
$statusFilter = trim((string)($_GET['status'] ?? ''));
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 15;
$totalPages = 1;
$totalAllocated = 0.0;
$activeAllocated = 0.0;
$activeCount = 0;
$closedCount = 0;

try {
    if (!budgetPageTableExists($conn, 'budgets')) {
        $conn->query("CREATE TABLE `budgets` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `budget_code` VARCHAR(40) DEFAULT NULL,
            `budget_name` VARCHAR(180) NOT NULL,
            `category` VARCHAR(100) DEFAULT NULL,
            `fiscal_year` VARCHAR(20) DEFAULT NULL,
            `start_date` DATE DEFAULT NULL,
            `end_date` DATE DEFAULT NULL,
            `allocated_amount` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
            `description` TEXT DEFAULT NULL,
            `status` ENUM('draft','active','closed','cancelled') NOT NULL DEFAULT 'active',
            `created_by` INT DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uq_budgets_code` (`budget_code`),
            KEY `idx_budgets_year` (`fiscal_year`),
            KEY `idx_budgets_status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $createdBudgetTable = true;
    }

    $budgetColumns = budgetPageColumns($conn, 'budgets');
    $budgetMap = [
        'id' => budgetPagePick($budgetColumns, ['id', 'budget_id']),
        'code' => budgetPagePick($budgetColumns, ['budget_code', 'budget_no', 'code', 'reference_no']),
        'name' => budgetPagePick($budgetColumns, ['budget_name', 'name', 'title', 'budget_title']),
        'category' => budgetPagePick($budgetColumns, ['category', 'budget_category', 'category_name', 'department']),
        'year' => budgetPagePick($budgetColumns, ['fiscal_year', 'budget_year', 'academic_year', 'year']),
        'start' => budgetPagePick($budgetColumns, ['start_date', 'period_start', 'budget_start_date']),
        'end' => budgetPagePick($budgetColumns, ['end_date', 'period_end', 'budget_end_date']),
        'amount' => budgetPagePick($budgetColumns, ['allocated_amount', 'budget_amount', 'planned_amount', 'amount', 'total_amount', 'total_budget']),
        'description' => budgetPagePick($budgetColumns, ['description', 'notes', 'remarks', 'details']),
        'status' => budgetPagePick($budgetColumns, ['status', 'budget_status']),
        'created_by' => budgetPagePick($budgetColumns, ['created_by', 'entered_by', 'user_id', 'created_user_id']),
        'created_at' => budgetPagePick($budgetColumns, ['created_at', 'date_created', 'created_on'])
    ];

    if (!$budgetMap['id']) throw new RuntimeException('The budgets table must contain an id or budget_id column.');
    if (!$budgetMap['name']) throw new RuntimeException('The budgets table needs a budget_name, name or title column.');
    if (!$budgetMap['amount']) throw new RuntimeException('The budgets table needs a total_budget, allocated_amount, budget_amount or amount column.');
    if ($budgetMap['status']) $statusValues = budgetPageEnumValues((string)($budgetColumns[$budgetMap['status']]['Type'] ?? ''));

    // Optional expense linkage: report spending only when expenses can be linked to a budget.
    if (budgetPageTableExists($conn, 'expenses')) {
        $expenseColumns = budgetPageColumns($conn, 'expenses');
        $expenseBudgetId = budgetPagePick($expenseColumns, ['budget_id', 'budget_ref_id', 'budget_allocation_id']);
        $expenseAmount = budgetPagePick($expenseColumns, ['amount', 'expense_amount', 'total_amount', 'paid_amount']);
        $expenseStatus = budgetPagePick($expenseColumns, ['status', 'payment_status']);
        if ($expenseBudgetId && $expenseAmount) {
            $hasExpenseBudgetLink = true;
            $expenseSql = 'SELECT `' . $expenseBudgetId . '` AS budget_id, COALESCE(SUM(`' . $expenseAmount . '`),0) AS spent FROM `expenses`';
            $expenseParams = [];
            $expenseTypes = '';
            if ($expenseStatus) {
                $expenseType = strtolower((string)($expenseColumns[$expenseStatus]['Type'] ?? ''));
                if (strpos($expenseType, 'enum(') === 0) {
                    $expenseStatusValues = budgetPageEnumValues($expenseType);
                    $excluded = array_values(array_intersect(['cancelled','canceled','reversed','rejected','void'], $expenseStatusValues));
                    if ($excluded) {
                        $marks = implode(',', array_fill(0, count($excluded), '?'));
                        $expenseSql .= ' WHERE LOWER(`' . $expenseStatus . '`) NOT IN (' . $marks . ')';
                        $expenseParams = $excluded;
                        $expenseTypes = str_repeat('s', count($excluded));
                    }
                }
            }
            $expenseSql .= ' GROUP BY `' . $expenseBudgetId . '`';
            $expenseStmt = $conn->prepare($expenseSql);
            if ($expenseTypes !== '') budgetPageBind($expenseStmt, $expenseTypes, $expenseParams);
            $expenseStmt->execute();
            $expenseResult = $expenseStmt->get_result();
            while ($expenseRow = $expenseResult->fetch_assoc()) $spentByBudget[(int)$expenseRow['budget_id']] = (float)$expenseRow['spent'];
            $expenseStmt->close();
        }
    }
} catch (Throwable $ex) {
    $schemaError = $ex->getMessage();
    error_log('Budgets page setup error: ' . $ex->getMessage());
}

// Save, edit, delete or change status. No write is attempted if schema detection failed.
if ($schemaError === '' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $postedToken = (string)($_POST['csrf_token'] ?? '');
    if (!hash_equals($csrfToken, $postedToken)) {
        budgetPageFlash('danger', 'Your form session expired. Refresh the page and try again.');
        budgetPageRedirect();
    }
    $action = (string)($_POST['action'] ?? '');

    try {
        if ($action === 'save_budget') {
            $id = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT) ?: 0;
            $name = trim((string)($_POST['budget_name'] ?? ''));
            $category = trim((string)($_POST['category'] ?? ''));
            $year = trim((string)($_POST['fiscal_year'] ?? date('Y')));
            $startDate = trim((string)($_POST['start_date'] ?? ''));
            $endDate = trim((string)($_POST['end_date'] ?? ''));
            $amountInput = trim((string)($_POST['allocated_amount'] ?? ''));
            $description = trim((string)($_POST['description'] ?? ''));
            $statusInput = trim((string)($_POST['status'] ?? 'active'));

            if ($name === '') throw new RuntimeException('Enter a budget name.');
            if (mb_strlen($name) > 150) throw new RuntimeException('The budget name is too long (maximum 150 characters).');
            if ($year !== '' && mb_strlen($year) > 20) throw new RuntimeException('The fiscal year must not exceed 20 characters.');
            if ($amountInput === '' || !is_numeric($amountInput) || !is_finite((float)$amountInput) || (float)$amountInput < 0) {
                throw new RuntimeException('Enter a valid budget amount of zero or more.');
            }
            if ($year === '') throw new RuntimeException('Enter the financial / academic year.');
            if ($startDate === '' || $endDate === '') throw new RuntimeException('Select both the start date and end date.');
            if (!budgetPageDate($startDate) || !budgetPageDate($endDate)) throw new RuntimeException('Enter valid start and end dates.');
            if ($startDate !== '' && $endDate !== '' && $startDate > $endDate) throw new RuntimeException('The end date cannot be before the start date.');
            $amount = round((float)$amountInput, 2);
            $status = $budgetMap['status'] ? budgetPageEnumChoice($budgetColumns[$budgetMap['status']], [$statusInput, 'active', 'draft', 'open'], 'active') : null;
            $data = [];
            $types = '';
            $put = static function (?string $column, $value, string $type) use (&$data, &$types, $budgetColumns): void {
                if ($column && isset($budgetColumns[$column])) {
                    $data[$column] = $value;
                    $types .= $type;
                }
            };
            $put($budgetMap['name'], $name, 's');
            $put($budgetMap['category'], $category !== '' ? $category : null, 's');
            $put($budgetMap['year'], $year !== '' ? $year : null, 's');
            $put($budgetMap['start'], $startDate !== '' ? $startDate : null, 's');
            $put($budgetMap['end'], $endDate !== '' ? $endDate : null, 's');
            $put($budgetMap['amount'], $amount, 'd');
            $put($budgetMap['description'], $description !== '' ? $description : null, 's');
            if ($budgetMap['status']) $put($budgetMap['status'], $status, 's');

            if ($id < 1 && $budgetMap['code']) $put($budgetMap['code'], budgetPageMakeCode($conn, $budgetMap['code']), 's');
            if ($id < 1 && $budgetMap['created_by']) {
                $createdByInfo = $budgetColumns[$budgetMap['created_by']];
                $createdByRequired = strtoupper((string)($createdByInfo['Null'] ?? 'YES')) === 'NO' && ($createdByInfo['Default'] ?? null) === null;
                if ($createdByRequired && $userId < 1) {
                    throw new RuntimeException('Your user ID could not be identified. Please sign out and sign in again before creating a budget.');
                }
                $put($budgetMap['created_by'], $userId > 0 ? $userId : null, 'i');
            }
            if ($id < 1 && $budgetMap['created_at'] && $budgetColumns[$budgetMap['created_at']]['Default'] === null && strtoupper((string)$budgetColumns[$budgetMap['created_at']]['Null']) === 'NO') {
                $put($budgetMap['created_at'], date('Y-m-d H:i:s'), 's');
            }

            // Refuse an incomplete insert when this installation has custom required columns.
            if ($id < 1) {
                foreach ($budgetColumns as $columnName => $columnInfo) {
                    if (array_key_exists($columnName, $data)) continue;
                    if (stripos((string)($columnInfo['Extra'] ?? ''), 'auto_increment') !== false) continue;
                    if (strtoupper((string)($columnInfo['Null'] ?? 'YES')) === 'YES') continue;
                    if (($columnInfo['Default'] ?? null) !== null) continue;
                    throw new RuntimeException("The budgets table has another required column named '{$columnName}' without a default value. Please share its Structure tab so this page can match it.");
                }
            }

            if ($id > 0) {
                $check = $conn->prepare('SELECT `' . $budgetMap['id'] . '` FROM `budgets` WHERE `' . $budgetMap['id'] . '` = ? LIMIT 1');
                $check->bind_param('i', $id);
                $check->execute();
                $found = (bool)$check->get_result()->fetch_row();
                $check->close();
                if (!$found) throw new RuntimeException('The budget record was not found. Refresh the page and try again.');
                if (!$data) throw new RuntimeException('No editable budget columns were found.');
                $setSql = [];
                foreach (array_keys($data) as $column) $setSql[] = '`' . str_replace('`', '', $column) . '` = ?';
                $values = array_values($data);
                $values[] = $id;
                $updateTypes = $types . 'i';
                $stmt = $conn->prepare('UPDATE `budgets` SET ' . implode(', ', $setSql) . ' WHERE `' . $budgetMap['id'] . '` = ?');
                budgetPageBind($stmt, $updateTypes, $values);
                $stmt->execute();
                $stmt->close();
                budgetPageFlash('success', 'Budget updated successfully.');
            } else {
                if (!$data) throw new RuntimeException('No compatible columns were found for a budget record.');
                $colSql = implode(', ', array_map(static fn($col) => '`' . str_replace('`', '', $col) . '`', array_keys($data)));
                $marks = implode(', ', array_fill(0, count($data), '?'));
                $stmt = $conn->prepare('INSERT INTO `budgets` (' . $colSql . ') VALUES (' . $marks . ')');
                $values = array_values($data);
                budgetPageBind($stmt, $types, $values);
                $stmt->execute();
                $stmt->close();
                budgetPageFlash('success', 'Budget created successfully.');
            }
            budgetPageRedirect();
        }

        if ($action === 'change_status') {
            if (!$budgetMap['id'] || !$budgetMap['status']) throw new RuntimeException('This budgets table does not have a supported status column.');
            $id = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT) ?: 0;
            $requestedStatus = trim((string)($_POST['new_status'] ?? ''));
            $allowedStatus = $statusValues ?: ['draft', 'active', 'closed', 'cancelled'];
            if ($id < 1 || !in_array($requestedStatus, $allowedStatus, true)) throw new RuntimeException('Select a valid budget and status.');
            $stmt = $conn->prepare('UPDATE `budgets` SET `' . $budgetMap['status'] . '` = ? WHERE `' . $budgetMap['id'] . '` = ?');
            $stmt->bind_param('si', $requestedStatus, $id);
            $stmt->execute();
            $changed = $stmt->affected_rows;
            $stmt->close();
            budgetPageFlash('success', $changed >= 0 ? 'Budget status updated.' : 'Budget status update submitted.');
            budgetPageRedirect();
        }

        if ($action === 'delete_budget') {
            $id = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT) ?: 0;
            if ($id < 1) throw new RuntimeException('Select a valid budget to delete.');
            // Prevent deletion if the expenses table already refers to this budget.
            if (budgetPageTableExists($conn, 'expenses')) {
                $expenseColumns = budgetPageColumns($conn, 'expenses');
                $expenseBudgetId = budgetPagePick($expenseColumns, ['budget_id', 'budget_ref_id', 'budget_allocation_id']);
                if ($expenseBudgetId) {
                    $check = $conn->prepare('SELECT 1 FROM `expenses` WHERE `' . $expenseBudgetId . '` = ? LIMIT 1');
                    $check->bind_param('i', $id);
                    $check->execute();
                    $isReferenced = (bool)$check->get_result()->fetch_row();
                    $check->close();
                    if ($isReferenced) throw new RuntimeException('This budget is linked to expense records, so it cannot be deleted. Change its status to closed instead.');
                }
            }
            $stmt = $conn->prepare('DELETE FROM `budgets` WHERE `' . $budgetMap['id'] . '` = ?');
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $deleted = $stmt->affected_rows;
            $stmt->close();
            budgetPageFlash($deleted ? 'success' : 'warning', $deleted ? 'Budget deleted.' : 'No budget was deleted; the record may already have been removed.');
            budgetPageRedirect();
        }

        throw new RuntimeException('Invalid form action. Refresh the page and try again.');
    } catch (Throwable $ex) {
        error_log('Budgets page save error: ' . $ex->getMessage());
        budgetPageFlash('danger', $ex instanceof RuntimeException ? $ex->getMessage() : 'The budget could not be saved. Check the hosting PHP error log.');
        budgetPageRedirect();
    }
}

// Load and filter records.
if ($schemaError === '') {
    try {
        $where = [];
        $params = [];
        $types = '';
        if ($search !== '') {
            $searchable = [];
            foreach (['code', 'name', 'category', 'year', 'description'] as $key) {
                if ($budgetMap[$key]) $searchable[] = 'CAST(`' . str_replace('`', '', $budgetMap[$key]) . '` AS CHAR) LIKE ?';
            }
            if ($searchable) {
                $where[] = '(' . implode(' OR ', $searchable) . ')';
                foreach ($searchable as $_) { $params[] = '%' . $search . '%'; $types .= 's'; }
            }
        }
        if ($yearFilter !== '' && $budgetMap['year']) {
            $where[] = 'CAST(`' . str_replace('`', '', $budgetMap['year']) . '` AS CHAR) = ?';
            $params[] = $yearFilter;
            $types .= 's';
        }
        if ($statusFilter !== '' && $budgetMap['status']) {
            $where[] = '`' . str_replace('`', '', $budgetMap['status']) . '` = ?';
            $params[] = $statusFilter;
            $types .= 's';
        }
        $whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';
        $orderCol = $budgetMap['id'];
        $sql = 'SELECT * FROM `budgets`' . $whereSql . ' ORDER BY `' . str_replace('`', '', $orderCol) . '` DESC';
        $stmt = $conn->prepare($sql);
        if ($types !== '') budgetPageBind($stmt, $types, $params);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $id = (int)($row[$budgetMap['id']] ?? 0);
            $row['_budget_id'] = $id;
            $row['_code'] = $budgetMap['code'] ? (string)($row[$budgetMap['code']] ?? '') : '';
            $row['_name'] = (string)($row[$budgetMap['name']] ?? 'Untitled budget');
            $row['_category'] = $budgetMap['category'] ? (string)($row[$budgetMap['category']] ?? '') : '';
            $row['_year'] = $budgetMap['year'] ? (string)($row[$budgetMap['year']] ?? '') : '';
            $row['_start'] = $budgetMap['start'] ? (string)($row[$budgetMap['start']] ?? '') : '';
            $row['_end'] = $budgetMap['end'] ? (string)($row[$budgetMap['end']] ?? '') : '';
            $row['_amount'] = (float)($row[$budgetMap['amount']] ?? 0);
            $row['_description'] = $budgetMap['description'] ? (string)($row[$budgetMap['description']] ?? '') : '';
            $row['_status'] = $budgetMap['status'] ? (string)($row[$budgetMap['status']] ?? 'active') : 'active';
            $row['_spent'] = (float)($spentByBudget[$id] ?? 0);
            $row['_remaining'] = $row['_amount'] - $row['_spent'];
            $allRows[] = $row;
        }
        $stmt->close();

        foreach ($allRows as $row) {
            $totalAllocated += $row['_amount'];
            $statusLower = strtolower(trim($row['_status']));
            if (in_array($statusLower, ['active', 'approved', 'open', 'in_progress', 'in progress'], true)) {
                $activeAllocated += $row['_amount'];
                $activeCount++;
            }
            if (in_array($statusLower, ['closed', 'cancelled', 'canceled', 'complete', 'completed'], true)) $closedCount++;
        }
        $totalPages = max(1, (int)ceil(count($allRows) / $perPage));
        if ($page > $totalPages) $page = $totalPages;
        $shownRows = array_slice($allRows, ($page - 1) * $perPage, $perPage);
    } catch (Throwable $ex) {
        $pageError = 'Budgets could not be loaded: ' . $ex->getMessage();
        error_log('Budgets page load error: ' . $ex->getMessage());
    }
}

$editId = max(0, (int)($_GET['edit'] ?? 0));
$editBudget = null;
if ($editId > 0 && $schemaError === '' && $pageError === '') {
    foreach ($allRows as $row) {
        if ((int)$row['_budget_id'] === $editId) { $editBudget = $row; break; }
    }
    if (!$editBudget) {
        try {
            $stmt = $conn->prepare('SELECT * FROM `budgets` WHERE `' . $budgetMap['id'] . '` = ? LIMIT 1');
            $stmt->bind_param('i', $editId);
            $stmt->execute();
            $record = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if ($record) {
                $record['_budget_id'] = $editId;
                $record['_code'] = $budgetMap['code'] ? (string)($record[$budgetMap['code']] ?? '') : '';
                $record['_name'] = (string)($record[$budgetMap['name']] ?? '');
                $record['_category'] = $budgetMap['category'] ? (string)($record[$budgetMap['category']] ?? '') : '';
                $record['_year'] = $budgetMap['year'] ? (string)($record[$budgetMap['year']] ?? '') : '';
                $record['_start'] = $budgetMap['start'] ? (string)($record[$budgetMap['start']] ?? '') : '';
                $record['_end'] = $budgetMap['end'] ? (string)($record[$budgetMap['end']] ?? '') : '';
                $record['_amount'] = (float)($record[$budgetMap['amount']] ?? 0);
                $record['_description'] = $budgetMap['description'] ? (string)($record[$budgetMap['description']] ?? '') : '';
                $record['_status'] = $budgetMap['status'] ? (string)($record[$budgetMap['status']] ?? 'active') : 'active';
                $editBudget = $record;
            }
        } catch (Throwable $ex) {
            error_log('Budgets page edit load error: ' . $ex->getMessage());
        }
    }
}

$allowedStatuses = $statusValues ?: ['draft', 'active', 'closed', 'cancelled'];
$formStatusDefault = $editBudget['_status'] ?? budgetPageEnumChoice($budgetMap['status'] ? $budgetColumns[$budgetMap['status']] : null, ['active', 'approved', 'open'], 'active');
$filterYearOptions = [];
foreach ($allRows as $row) if ($row['_year'] !== '') $filterYearOptions[$row['_year']] = $row['_year'];
uksort($filterYearOptions, static fn($a, $b) => strnatcmp((string)$b, (string)$a));
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Budgets | School Management System</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
*{box-sizing:border-box}
body{background:#f5f6fa;font-family:Arial,sans-serif;color:#263348;margin:0}
.sidebar{position:fixed;top:0;left:0;bottom:0;width:250px;background:#212529;z-index:1030;overflow-y:auto;color:#fff}
.sidebar-header{padding:20px 15px;color:#fff;font-weight:700;border-bottom:1px solid rgba(255,255,255,.1)}
.sidebar-menu{padding:15px 10px}
.sidebar-section{color:#6c757d;font-size:11px;text-transform:uppercase;padding:12px 10px 6px}
.sidebar a{display:block;color:#ced4da;padding:12px 15px;margin-bottom:3px;text-decoration:none;border-radius:6px;font-size:13px}
.sidebar a:hover{background:#343a40;color:#fff}
.sidebar a.active{background:#dc3545;color:#fff}
.sidebar i{width:25px;text-align:center;margin-right:5px}
.main{margin-left:250px;padding:25px;min-height:100vh}
.topbar{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:22px}
.content{padding:0}
.page-head,.panel,.stat-card{background:#fff;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,.05)}
.page-head{padding:21px;margin-bottom:20px}
.panel{padding:22px;margin-bottom:22px;border:none}
.stat-card{padding:17px 19px;margin-bottom:18px;height:calc(100% - 18px)}
.stat-title{color:#6c757d;font-size:13px}
.stat-number{font-size:24px;font-weight:700;overflow-wrap:anywhere}
.form-control,.custom-select{border-radius:6px;font-size:13px;min-height:38px}
label{font-size:12px;color:#4e5c70;font-weight:600}
.table th{background:#f8f9fa;border-top:none;font-size:13px;white-space:nowrap}
.table thead th{color:#68768a;text-transform:uppercase;letter-spacing:.4px}
.table td{vertical-align:middle;font-size:13px}
.btn{border-radius:6px;font-size:12px}
.badge{font-size:10px;padding:6px 8px}
.muted-small{font-size:11px;color:#89929c}
.progress{height:7px;min-width:75px}
.amount{white-space:nowrap;font-weight:700}
.alert{font-size:13px}
@media(max-width:991px){.sidebar{width:220px}.main{margin-left:220px}}
@media(max-width:767px){.sidebar{position:relative;width:100%;height:auto;top:auto;left:auto;bottom:auto}.main{margin-left:0;padding:15px}.topbar{align-items:flex-start;flex-direction:column}.table-responsive{font-size:12px}}
@media print{.sidebar,.topbar,.no-print,.mobile-menu{display:none!important}.main{margin:0;padding:0}.content{padding:0}body{background:#fff}.panel,.stat-card,.page-head{box-shadow:none;border:0}.table{font-size:10px}}
</style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<button type="button" id="unifiedSidebarToggle" class="unified-sidebar-toggle" aria-label="Open navigation" aria-controls="sidebar" aria-expanded="false"><i class="fas fa-bars"></i></button>
<div id="unifiedSidebarOverlay" class="sidebar-overlay"></div>

<div class="sidebar no-print">
    <div class="sidebar-header">
        <i class="fas fa-university"></i>
        <span>Bursar</span>
    </div>

    <div class="sidebar-menu">
        <a href="/admin/bursar/index.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a>

        <div class="sidebar-section">Students &amp; Fees</div>
        <a href="/admin/bursar/students_fees.php"><i class="fas fa-file-invoice-dollar"></i>Student Fees</a>
        <a href="/admin/bursar/students_fee_accounts.php"><i class="fas fa-file-invoice-dollar"></i>Student Fee Accounts</a>
        <a href="/admin/bursar/fee_structure.php"><i class="fas fa-list-alt"></i>Fee Structure</a>
        <a href="/admin/bursar/payments.php"><i class="fas fa-money-bill-wave"></i>Receive Payment</a>
        <a href="/admin/bursar/outstanding_fees.php"><i class="fas fa-exclamation-circle"></i>Outstanding Fees</a>

        <div class="sidebar-section">Finance</div>
        <a href="/admin/bursar/income.php"><i class="fas fa-arrow-circle-down"></i>Income</a>
        <a href="/admin/bursar/expenses.php"><i class="fas fa-arrow-circle-up"></i>Expenses</a>
        <a href="/admin/bursar/suppliers.php"><i class="fas fa-truck"></i>Suppliers</a>
        <a href="/admin/bursar/supplier_payments.php"><i class="fas fa-hand-holding-usd"></i>Supplier Payments</a>

        <div class="sidebar-section">Payroll &amp; Budget</div>
        <a href="/admin/bursar/salaries.php"><i class="fas fa-users"></i>Salaries</a>
        <a href="/admin/bursar/salary_payments.php"><i class="fas fa-money-check-alt"></i>Salary Payments</a>
        <a href="/admin/bursar/budgets.php" class="active" aria-current="page"><i class="fas fa-chart-pie"></i>Budgets</a>

        <div class="sidebar-section">Reports</div>
        <a href="/admin/bursar/cashbook.php"><i class="fas fa-book"></i>Cashbook</a>
        <a href="/admin/bursar/financial_reports.php"><i class="fas fa-chart-line"></i>Financial Reports</a>
        <a href="/admin/bursar/income_report.php"><i class="fas fa-file-invoice"></i>Income Report</a>
        <a href="/admin/bursar/expense_report.php"><i class="fas fa-receipt"></i>Expense Report</a>
        <a href="/admin/bursar/fees_report.php"><i class="fas fa-file-alt"></i>Fees Report</a>
        <a href="/admin/bursar/profit_loss.php"><i class="fas fa-balance-scale"></i>Profit &amp; Loss</a>

        <div class="sidebar-section">System</div>
        <a href="/admin/dashboard.php"><i class="fas fa-user-shield"></i>Admin Dashboard</a>
        <a href="/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
    </div>
</div>
<div class="main">
 <div class="topbar">
  <div><strong>Bursar Finance</strong></div>
  <div class="text-muted"><i class="fas fa-user-circle mr-1"></i><?= budgetPageE($_SESSION['full_name'] ?? 'Bursar') ?></div>
 </div>
 <div class="content">
  <div class="page-head d-flex justify-content-between align-items-center flex-wrap">
   <div><h3 class="mb-1"><i class="fas fa-wallet text-success mr-2"></i>Budget Management</h3><div class="text-muted">Plan, monitor and manage school budgets by category and financial year.</div></div>
   <div class="mt-2 no-print"><button type="button" class="btn btn-success" onclick="document.getElementById('budgetForm').scrollIntoView({behavior:'smooth'});"><i class="fas fa-plus-circle mr-1"></i>New Budget</button> <button type="button" class="btn btn-outline-secondary" onclick="window.print()"><i class="fas fa-print mr-1"></i>Print</button></div>
  </div>

  <?php if ($createdBudgetTable): ?><div class="alert alert-info"><i class="fas fa-info-circle mr-1"></i>The budgets table did not exist, so this page created it with the standard budget fields.</div><?php endif; ?>
  <?php if ($schemaError !== ''): ?><div class="alert alert-danger"><h5><i class="fas fa-exclamation-triangle mr-1"></i>Database / page configuration error</h5><div><?= budgetPageE($schemaError) ?></div><div class="small mt-2">No budget was changed. Details have been written to the hosting PHP error log.</div></div><?php endif; ?>
  <?php if ($pageError !== ''): ?><div class="alert alert-warning"><?= budgetPageE($pageError) ?></div><?php endif; ?>
  <?php if (is_array($flash) && !empty($flash['message'])): ?><div class="alert alert-<?= budgetPageE($flash['type'] ?? 'info') ?> alert-dismissible fade show" role="alert"><?= budgetPageE($flash['message']) ?><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div><?php endif; ?>

  <div class="row">
   <div class="col-md-6 col-xl-4"><div class="stat-card"><div class="stat-title">Total Budget Allocation (Current Filters)</div><div class="stat-number text-primary">UGX <?= number_format($totalAllocated, 2) ?></div></div></div>
   <div class="col-md-6 col-xl-4"><div class="stat-card"><div class="stat-title">Active Budget Allocation</div><div class="stat-number text-success">UGX <?= number_format($activeAllocated, 2) ?></div><div class="muted-small mt-1"><?= number_format($activeCount) ?> active / approved budgets</div></div></div>
   <div class="col-md-12 col-xl-4"><div class="stat-card"><div class="stat-title">Closed / Cancelled Budgets</div><div class="stat-number"><?= number_format($closedCount) ?></div><div class="muted-small mt-1">Based on the current filters</div></div></div>
  </div>

  <?php if ($schemaError === ''): ?>
  <section class="panel no-print" id="budgetForm">
   <h5 class="mb-3"><i class="fas fa-edit text-success mr-2"></i><?= $editBudget ? 'Edit Budget' : 'Create a Budget' ?></h5>
   <form method="POST" action="budgets.php<?= $editBudget ? '?edit=' . (int)$editBudget['_budget_id'] : '' ?>" id="budgetEntryForm">
    <input type="hidden" name="csrf_token" value="<?= budgetPageE($csrfToken) ?>">
    <input type="hidden" name="action" value="save_budget">
    <input type="hidden" name="id" value="<?= (int)($editBudget['_budget_id'] ?? 0) ?>">
    <div class="form-row">
     <div class="form-group col-lg-6"><label for="budget_name">Budget Name <span class="text-danger">*</span></label><input type="text" class="form-control" name="budget_name" id="budget_name" maxlength="150" required value="<?= budgetPageE($editBudget['_name'] ?? '') ?>" placeholder="e.g. Term 1 Teaching Materials"></div>
     <?php if ($budgetMap['category']): ?><div class="form-group col-lg-3 col-md-6"><label for="category">Category / Department</label><input type="text" class="form-control" name="category" id="category" maxlength="100" value="<?= budgetPageE($editBudget['_category'] ?? '') ?>" placeholder="e.g. Academics"></div><?php endif; ?>
     <?php if ($budgetMap['year']): ?><div class="form-group col-lg-3 col-md-6"><label for="fiscal_year">Financial / Academic Year</label><input type="text" class="form-control" name="fiscal_year" id="fiscal_year" maxlength="20" required value="<?= budgetPageE($editBudget['_year'] ?? date('Y')) ?>" placeholder="e.g. 2026"></div><?php endif; ?>
    </div>
    <div class="form-row">
     <?php if ($budgetMap['start']): ?><div class="form-group col-md-3"><label for="start_date">Start Date</label><input type="date" class="form-control" name="start_date" id="start_date" required value="<?= budgetPageE(($editBudget['_start'] ?? '') ? substr((string)$editBudget['_start'], 0, 10) : '') ?>"></div><?php endif; ?>
     <?php if ($budgetMap['end']): ?><div class="form-group col-md-3"><label for="end_date">End Date</label><input type="date" class="form-control" name="end_date" id="end_date" required value="<?= budgetPageE(($editBudget['_end'] ?? '') ? substr((string)$editBudget['_end'], 0, 10) : '') ?>"></div><?php endif; ?>
     <div class="form-group col-md-3"><label for="allocated_amount">Allocated Amount (UGX) <span class="text-danger">*</span></label><input type="number" class="form-control" name="allocated_amount" id="allocated_amount" min="0" step="0.01" required value="<?= isset($editBudget['_amount']) ? budgetPageE(number_format((float)$editBudget['_amount'], 2, '.', '')) : '' ?>" placeholder="0.00"></div>
     <?php if ($budgetMap['status']): ?><div class="form-group col-md-3"><label for="status">Status</label><select class="custom-select" name="status" id="status"><?php foreach ($allowedStatuses as $statusOption): ?><option value="<?= budgetPageE($statusOption) ?>" <?= $formStatusDefault === $statusOption ? 'selected' : '' ?>><?= budgetPageE(ucwords(str_replace('_', ' ', $statusOption))) ?></option><?php endforeach; ?></select></div><?php endif; ?>
    </div>
    <?php if ($budgetMap['description']): ?><div class="form-group"><label for="description">Description / Notes</label><textarea class="form-control" name="description" id="description" rows="2" placeholder="Purpose, approved activities or notes"><?= budgetPageE($editBudget['_description'] ?? '') ?></textarea></div><?php endif; ?>
    <button type="submit" class="btn btn-success"><i class="fas fa-save mr-1"></i><?= $editBudget ? 'Update Budget' : 'Save Budget' ?></button>
    <?php if ($editBudget): ?> <a href="budgets.php" class="btn btn-outline-secondary">Cancel Edit</a><?php else: ?> <button type="reset" class="btn btn-outline-secondary">Clear</button><?php endif; ?>
   </form>
  </section>
  <?php endif; ?>

  <section class="panel">
   <div class="d-flex justify-content-between align-items-center flex-wrap mb-3"><h5 class="mb-2"><i class="fas fa-list text-primary mr-2"></i>Budget Records</h5><span class="small text-muted mb-2"><?= number_format(count($allRows)) ?> matching record(s)</span></div>
   <form method="GET" action="budgets.php" class="form-row align-items-end mb-3 no-print">
    <div class="form-group col-lg-5 col-md-6 mb-2"><label for="search">Search budgets</label><input type="search" class="form-control" name="search" id="search" value="<?= budgetPageE($search) ?>" placeholder="Budget name, code, category, year"></div>
    <?php if ($budgetMap['year']): ?><div class="form-group col-lg-2 col-md-3 mb-2"><label for="year">Year</label><select class="custom-select" name="year" id="year"><option value="">All years</option><?php foreach ($filterYearOptions as $filterYearOption): ?><option value="<?= budgetPageE($filterYearOption) ?>" <?= $yearFilter === $filterYearOption ? 'selected' : '' ?>><?= budgetPageE($filterYearOption) ?></option><?php endforeach; ?></select></div><?php endif; ?>
    <?php if ($budgetMap['status']): ?><div class="form-group col-lg-2 col-md-3 mb-2"><label for="status_filter">Status</label><select class="custom-select" name="status" id="status_filter"><option value="">All statuses</option><?php foreach ($allowedStatuses as $filterStatus): ?><option value="<?= budgetPageE($filterStatus) ?>" <?= $statusFilter === $filterStatus ? 'selected' : '' ?>><?= budgetPageE(ucwords(str_replace('_', ' ', $filterStatus))) ?></option><?php endforeach; ?></select></div><?php endif; ?>
    <div class="form-group col-lg-3 col-md-12 mb-2"><button type="submit" class="btn btn-primary"><i class="fas fa-search mr-1"></i>Filter</button> <a href="budgets.php" class="btn btn-outline-secondary">Reset</a></div>
   </form>
   <?php if (!$hasExpenseBudgetLink): ?><div class="alert alert-light border py-2 small"><i class="fas fa-info-circle text-info mr-1"></i>Budget spending is shown only when your <code>expenses</code> table has a <code>budget_id</code> link. Your page can still create and track budget allocations without that link.</div><?php endif; ?>
   <div class="table-responsive"><table class="table table-bordered table-hover mb-0"><thead><tr><th>Budget</th><?php if ($budgetMap['category']): ?><th>Category</th><?php endif; ?><?php if ($budgetMap['year']): ?><th>Year</th><?php endif; ?><th>Period</th><th class="text-right">Allocated (UGX)</th><th class="text-right">Spent (UGX)</th><th class="text-right">Remaining (UGX)</th><?php if ($budgetMap['status']): ?><th>Status</th><?php endif; ?><th class="no-print">Actions</th></tr></thead><tbody>
    <?php if (!$shownRows): ?><tr><td colspan="<?= 6 + (int)(bool)$budgetMap['category'] + (int)(bool)$budgetMap['year'] + (int)(bool)$budgetMap['status'] ?>" class="text-center text-muted py-4"><i class="fas fa-wallet fa-2x mb-2"></i><br>No budgets found. Use the form above to create the first budget.</td></tr><?php else: foreach ($shownRows as $row):
      $rowStatus = strtolower(trim((string)$row['_status']));
      $badgeClass = in_array($rowStatus, ['active','approved','open','in_progress','in progress'], true) ? 'success' : (in_array($rowStatus, ['closed','cancelled','canceled','rejected'], true) ? 'secondary' : 'warning');
      $utilization = $row['_amount'] > 0 ? min(100, max(0, ($row['_spent'] / $row['_amount']) * 100)) : 0;
    ?>
     <tr>
      <td><strong><?= budgetPageE($row['_name']) ?></strong><?php if ($row['_code'] !== ''): ?><div class="muted-small"><?= budgetPageE($row['_code']) ?></div><?php endif; ?><?php if ($row['_description'] !== ''): ?><div class="muted-small"><?= budgetPageE(mb_strimwidth($row['_description'], 0, 90, '…')) ?></div><?php endif; ?></td>
      <?php if ($budgetMap['category']): ?><td><?= budgetPageE($row['_category'] !== '' ? $row['_category'] : '—') ?></td><?php endif; ?>
      <?php if ($budgetMap['year']): ?><td><?= budgetPageE($row['_year'] !== '' ? $row['_year'] : '—') ?></td><?php endif; ?>
      <td><?= $row['_start'] !== '' ? budgetPageE(date('d M Y', strtotime($row['_start']))) : '—' ?><?php if ($row['_end'] !== ''): ?><div class="muted-small">to <?= budgetPageE(date('d M Y', strtotime($row['_end']))) ?></div><?php endif; ?></td>
      <td class="text-right amount"><?= number_format($row['_amount'], 2) ?></td>
      <td class="text-right"><?php if ($hasExpenseBudgetLink): ?><?= number_format($row['_spent'], 2) ?><div class="progress mt-1"><div class="progress-bar <?= $utilization >= 100 ? 'bg-danger' : 'bg-info' ?>" role="progressbar" style="width:<?= $utilization ?>%" aria-valuenow="<?= (int)$utilization ?>" aria-valuemin="0" aria-valuemax="100"></div></div><?php else: ?>—<?php endif; ?></td>
      <td class="text-right <?= $hasExpenseBudgetLink && $row['_remaining'] < 0 ? 'text-danger' : '' ?>"><?= $hasExpenseBudgetLink ? number_format($row['_remaining'], 2) : '—' ?></td>
      <?php if ($budgetMap['status']): ?><td><span class="badge badge-<?= $badgeClass ?>"><?= budgetPageE(ucwords(str_replace('_', ' ', $row['_status']))) ?></span></td><?php endif; ?>
      <td class="no-print text-nowrap"><a class="btn btn-sm btn-outline-primary" href="budgets.php?edit=<?= (int)$row['_budget_id'] ?>" title="Edit"><i class="fas fa-edit"></i></a>
       <?php if ($budgetMap['status'] && count($allowedStatuses) > 1): ?><div class="dropdown d-inline"><button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Status</button><div class="dropdown-menu dropdown-menu-right"><?php foreach ($allowedStatuses as $statusAction): if ($statusAction === $row['_status']) continue; ?><form method="POST" action="budgets.php" class="m-0"><input type="hidden" name="csrf_token" value="<?= budgetPageE($csrfToken) ?>"><input type="hidden" name="action" value="change_status"><input type="hidden" name="id" value="<?= (int)$row['_budget_id'] ?>"><input type="hidden" name="new_status" value="<?= budgetPageE($statusAction) ?>"><button type="submit" class="dropdown-item"><?= budgetPageE(ucwords(str_replace('_', ' ', $statusAction))) ?></button></form><?php endforeach; ?></div></div><?php endif; ?>
       <form method="POST" action="budgets.php" class="d-inline" onsubmit="return confirm('Delete this budget? This cannot be undone.');"><input type="hidden" name="csrf_token" value="<?= budgetPageE($csrfToken) ?>"><input type="hidden" name="action" value="delete_budget"><input type="hidden" name="id" value="<?= (int)$row['_budget_id'] ?>"><button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="fas fa-trash"></i></button></form>
      </td>
     </tr>
    <?php endforeach; endif; ?>
   </tbody></table></div>
   <?php if ($totalPages > 1): $query = $_GET; ?><nav class="no-print mt-3" aria-label="Budget pages"><ul class="pagination mb-0 flex-wrap"><?php $query['page'] = max(1, $page - 1); ?><li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="?<?= budgetPageE(http_build_query($query)) ?>">Previous</a></li><?php for ($p = max(1, $page - 2); $p <= min($totalPages, $page + 2); $p++): $query['page'] = $p; ?><li class="page-item <?= $p === $page ? 'active' : '' ?>"><a class="page-link" href="?<?= budgetPageE(http_build_query($query)) ?>"><?= $p ?></a></li><?php endfor; ?><?php $query['page'] = min($totalPages, $page + 1); ?><li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>"><a class="page-link" href="?<?= budgetPageE(http_build_query($query)) ?>">Next</a></li></ul></nav><?php endif; ?>
  </section>
  <div class="text-center text-muted small mb-3">School Management System &mdash; Bursar Budget Management</div>
 </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function(){
 var form=document.getElementById('budgetEntryForm');
 if(form)form.addEventListener('submit',function(){var button=form.querySelector('button[type="submit"]');if(button){button.disabled=true;button.innerHTML='<i class="fas fa-spinner fa-spin mr-1"></i>Saving budget...';}});
})();
</script>

<script src="/assets/js/sidebar-unified.js?v=20261106"></script>
</body>
</html>
