<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);


require_once "../../config/database.php";
require_once "../../includes/auth.php";

requireRole([
    'administrator',
    'assistant_administrator',
    'bursar'
]);

/*
|--------------------------------------------------------------------------
| Helper Functions
|--------------------------------------------------------------------------
*/

function tableExists($conn, $table)
{
    $table = $conn->real_escape_string($table);

    $result = $conn->query("
        SELECT COUNT(*) AS total
        FROM information_schema.tables
        WHERE table_schema = DATABASE()
        AND table_name = '$table'
    ");

    if (!$result) {
        return false;
    }

    $row = $result->fetch_assoc();

    return ((int)$row['total'] > 0);
}

function getNumber($conn, $sql)
{
    $result = $conn->query($sql);

    if (!$result) {
        return 0;
    }

    $row = $result->fetch_row();

    return $row ? (float)$row[0] : 0;
}

function money($amount)
{
    return number_format((float)$amount, 2);
}


/*
|--------------------------------------------------------------------------
| Dashboard Statistics
|--------------------------------------------------------------------------
*/

$totalStudents = 0;
$totalExpected = 0;
$totalPaid = 0;
$totalBalance = 0;
$todayCollected = 0;
$paymentCount = 0;


/*
|--------------------------------------------------------------------------
| Student Fee Accounts
|--------------------------------------------------------------------------
*/

if (tableExists($conn, 'student_fee_accounts')) {

    $totalStudents = getNumber(
        $conn,
        "SELECT COUNT(DISTINCT student_id)
         FROM student_fee_accounts"
    );

    $totalExpected = getNumber(
        $conn,
        "SELECT COALESCE(SUM(total_amount), 0)
         FROM student_fee_accounts"
    );

    $totalPaid = getNumber(
        $conn,
        "SELECT COALESCE(SUM(total_paid), 0)
         FROM student_fee_accounts"
    );

    $totalBalance = $totalExpected - $totalPaid;
}


/*
|--------------------------------------------------------------------------
| Today's Collections
|--------------------------------------------------------------------------
*/

if (tableExists($conn, 'fee_payments')) {

    $todayCollected = getNumber(
        $conn,
        "SELECT COALESCE(SUM(amount), 0)
         FROM fee_payments
         WHERE DATE(payment_date) = CURDATE()
         AND status = 'completed'"
    );

    $paymentCount = getNumber(
        $conn,
        "SELECT COUNT(*)
         FROM fee_payments
         WHERE status = 'completed'"
    );
}


/*
|--------------------------------------------------------------------------
| Recent Payments
|--------------------------------------------------------------------------
*/

$recentPayments = [];

if (
    tableExists($conn, 'fee_payments') &&
    tableExists($conn, 'student_fee_accounts') &&
    tableExists($conn, 'students') &&
    tableExists($conn, 'payment_methods')
) {

    $sql = "
    SELECT
        fp.id,
        fp.receipt_no,
        fp.amount,
        fp.payment_date,
        fp.reference_no,

        s.admission_no,
        s.lin_no,
        s.student_payment_code,
        s.student_section,

        CONCAT(
            s.first_name,
            ' ',
            s.last_name
        ) AS student_name,

        pm.method_name

    FROM fee_payments fp

    INNER JOIN student_fee_accounts sfa
        ON fp.account_id = sfa.id

    INNER JOIN students s
        ON fp.student_id = s.id

    INNER JOIN payment_methods pm
        ON fp.payment_method_id = pm.id

    WHERE fp.status = 'completed'

    ORDER BY fp.payment_date DESC

    LIMIT 10
";
    $result = $conn->query($sql);

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $recentPayments[] = $row;
        }
    }
}


/*
|--------------------------------------------------------------------------
| Outstanding Students
|--------------------------------------------------------------------------
*/

$outstandingStudents = 0;

if (tableExists($conn, 'student_fee_accounts')) {

    $outstandingStudents = getNumber(
        $conn,
        "SELECT COUNT(*)
         FROM student_fee_accounts
         WHERE balance > 0"
    );
}


/*
|--------------------------------------------------------------------------
| Current User
|--------------------------------------------------------------------------
*/

$fullName = $_SESSION['full_name'] ?? 'Bursar';
$role = $_SESSION['role'] ?? '';

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Bursar Dashboard - School Management System</title>

<link rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

<link rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<style>

    body {
        margin: 0;
        background: #f4f6f9;
        font-family: Arial, Helvetica, sans-serif;
    }

    /*
    |--------------------------------------------------------------------------
    | Sidebar
    |--------------------------------------------------------------------------
    */

    .sidebar {
        position: fixed;
        top: 0;
        left: 0;
        width: 250px;
        height: 100vh;
        background: #343a40;
        color: #fff;
        z-index: 1050;
        transition: all 0.3s ease;
        overflow-y: auto;
    }

    .sidebar-header {
        height: 70px;
        display: flex;
        align-items: center;
        padding: 0 20px;
        background: #212529;
        font-size: 19px;
        font-weight: bold;
    }

    .sidebar-header i {
        margin-right: 10px;
    }

    .sidebar-menu {
        padding: 15px 0;
    }

    .sidebar-menu a {
        display: flex;
        align-items: center;
        color: #ced4da;
        text-decoration: none;
        padding: 13px 20px;
        font-size: 15px;
        transition: 0.2s;
    }

    .sidebar-menu a i {
        width: 30px;
        font-size: 16px;
    }

    .sidebar-menu a:hover,
    .sidebar-menu a.active {
        background: #007bff;
        color: #fff;
    }

    .sidebar-section {
        padding: 15px 20px 7px;
        font-size: 11px;
        color: #868e96;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    /*
    |--------------------------------------------------------------------------
    | Main Content
    |--------------------------------------------------------------------------
    */

    .main-content {
        margin-left: 250px;
        min-height: 100vh;
        transition: all 0.3s ease;
    }

    /*
    |--------------------------------------------------------------------------
    | Top Header
    |--------------------------------------------------------------------------
    */

    .topbar {
        height: 70px;
        background: #fff;
        border-bottom: 1px solid #dee2e6;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 25px;
    }

    .menu-btn {
        border: none;
        background: transparent;
        font-size: 22px;
        color: #343a40;
        cursor: pointer;
    }

    .user-info {
        display: flex;
        align-items: center;
    }

    .user-avatar {
        width: 38px;
        height: 38px;
        border-radius: 50%;
        background: #007bff;
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 10px;
    }

    /*
    |--------------------------------------------------------------------------
    | Page Content
    |--------------------------------------------------------------------------
    */

    .page-content {
        padding: 25px;
    }

    .page-title {
        font-weight: 600;
        color: #343a40;
        margin-bottom: 5px;
    }

    .page-subtitle {
        color: #6c757d;
        margin-bottom: 25px;
    }

    /*
    |--------------------------------------------------------------------------
    | Statistics Cards
    |--------------------------------------------------------------------------
    */

    .stat-card {
        border: none;
        border-radius: 10px;
        background: #fff;
        box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        margin-bottom: 25px;
        overflow: hidden;
    }

    .stat-card .card-body {
        padding: 20px;
    }

    .stat-icon {
        width: 55px;
        height: 55px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 22px;
    }

    .icon-blue {
        background: #007bff;
    }

    .icon-green {
        background: #28a745;
    }

    .icon-red {
        background: #dc3545;
    }

    .icon-orange {
        background: #fd7e14;
    }

    .stat-title {
        color: #6c757d;
        font-size: 14px;
        margin-bottom: 5px;
    }

    .stat-value {
        font-size: 24px;
        font-weight: bold;
        color: #343a40;
    }

    /*
    |--------------------------------------------------------------------------
    | Module Cards
    |--------------------------------------------------------------------------
    */

    .module-card {
        background: #fff;
        border: none;
        border-radius: 10px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        height: 100%;
        transition: all 0.2s ease;
    }

    .module-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.10);
    }

    .module-card .card-body {
        padding: 20px;
    }

    .module-icon {
        width: 50px;
        height: 50px;
        border-radius: 10px;
        background: #e9f2ff;
        color: #007bff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        margin-bottom: 15px;
    }

    .module-card h5 {
        font-size: 17px;
        font-weight: 600;
        color: #343a40;
    }

    .module-card p {
        color: #6c757d;
        font-size: 13px;
        min-height: 38px;
    }

    /*
    |--------------------------------------------------------------------------
    | Tables
    |--------------------------------------------------------------------------
    */

    .content-card {
        background: #fff;
        border: none;
        border-radius: 10px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        margin-bottom: 25px;
    }

    .content-card .card-header {
        background: #fff;
        border-bottom: 1px solid #eee;
        padding: 17px 20px;
        font-weight: 600;
    }

    .table th {
        border-top: none;
        font-size: 13px;
        color: #6c757d;
    }

    .table td {
        vertical-align: middle;
        font-size: 14px;
    }

    /*
    |--------------------------------------------------------------------------
    | Mobile
    |--------------------------------------------------------------------------
    */

    .overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 1040;
    }

    @media (max-width: 768px) {

        .sidebar {
            left: -250px;
        }

        .sidebar.show {
            left: 0;
        }

        .main-content {
            margin-left: 0;
        }

        .overlay.show {
            display: block;
        }

        .page-content {
            padding: 15px;
        }

        .topbar {
            padding: 0 15px;
        }

        .user-info .user-name {
            display: none;
        }

    }

</style>


    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>

<body>

<!-- ============================================================
     SIDEBAR
============================================================ -->

<div class="sidebar" id="sidebar">


<div class="sidebar-header">
    <i class="fas fa-university"></i>
    <span>Bursar</span>
</div>

<div class="sidebar-menu">

    <a href="/admin/bursar/index.php" class="active">
        <i class="fas fa-tachometer-alt"></i>
        <span>Dashboard</span>
    </a>

    <div class="sidebar-section">
        Fees
    </div>

    <a href="/admin/bursar/students_fees.php">
        <i class="fas fa-user-graduate"></i>
        <span>Student Fees</span>
    </a>
    <a href="/admin/bursar/students_fee_accounts.php">
        <i class="fas fa-user-graduate"></i>
        <span>Student Fee Accounts</span>
    </a>

    <a href="/admin/bursar/fee_structure.php">
        <i class="fas fa-list-alt"></i>
        <span>Fee Structure</span>
    </a>

    <a href="/admin/bursar/payments.php">
        <i class="fas fa-money-bill-wave"></i>
        <span>Receive Payment</span>
    </a>

    <a href="/admin/bursar/outstanding_fees.php">
        <i class="fas fa-exclamation-circle"></i>
        <span>Outstanding Fees</span>
    </a>

    <div class="sidebar-section">
        Finance
    </div>

    <a href="/admin/bursar/income.php">
        <i class="fas fa-arrow-circle-down"></i>
        <span>Income</span>
    </a>

    <a href="/admin/bursar/expenses.php">
        <i class="fas fa-arrow-circle-up"></i>
        <span>Expenses</span>
    </a>

    <a href="/admin/bursar/suppliers.php">
        <i class="fas fa-truck"></i>
        <span>Suppliers</span>
    </a>

    <a href="/admin/bursar/supplier_payments.php">
        <i class="fas fa-hand-holding-usd"></i>
        <span>Supplier Payments</span>
    </a>

    <div class="sidebar-section">
        Payroll & Budget
    </div>

    <a href="/admin/bursar/salaries.php">
        <i class="fas fa-users"></i>
        <span>Salaries</span>
    </a>

    <a href="/admin/bursar/salary_payments.php">
        <i class="fas fa-money-check-alt"></i>
        <span>Salary Payments</span>
    </a>

    <a href="/admin/bursar/budgets.php">
        <i class="fas fa-chart-pie"></i>
        <span>Budgets</span>
    </a>

    <div class="sidebar-section">
        Reports
    </div>

    <a href="/admin/bursar/cashbook.php">
        <i class="fas fa-book"></i>
        <span>Cashbook</span>
    </a>

    <a href="/admin/bursar/reports.php">
        <i class="fas fa-chart-line"></i>
        <span>Financial Reports</span>
    </a>

    <a href="/admin/bursar/income_report.php">
        <i class="fas fa-file-invoice-dollar"></i>
        <span>Income Report</span>
    </a>

    <a href="/admin/bursar/expense_report.php">
        <i class="fas fa-file-invoice"></i>
        <span>Expense Report</span>
    </a>

    <a href="/admin/bursar/fees_report.php">
        <i class="fas fa-file-alt"></i>
        <span>Fees Report</span>
    </a>

    <a href="/admin/bursar/profit_loss.php">
        <i class="fas fa-balance-scale"></i>
        <span>Profit & Loss</span>
    </a>

    <div class="sidebar-section">
        System
    </div>

    <a href="/admin/dashboard.php">
        <i class="fas fa-home"></i>
        <span>Admin Dashboard</span>
    </a>

    <a href="/logout.php">
        <i class="fas fa-sign-out-alt"></i>
        <span>Logout</span>
    </a>

</div>
```

</div>

<!-- Mobile Overlay -->

<div class="overlay" id="overlay"></div>

<!-- ============================================================
     MAIN CONTENT
============================================================ -->

<div class="main-content">


<!-- Topbar -->

<div class="topbar">

    <button class="menu-btn" id="menuBtn">
        <i class="fas fa-bars"></i>
    </button>

    <div class="user-info">

        <div class="user-avatar">
            <i class="fas fa-user"></i>
        </div>

        <div class="user-name">
            <strong><?php echo htmlspecialchars($fullName); ?></strong>
            <br>
            <small class="text-muted">
                <?php echo htmlspecialchars(ucwords(str_replace('_', ' ', $role))); ?>
            </small>
        </div>

    </div>

</div>


<!-- Page -->

<div class="page-content">

    <h2 class="page-title">
        Bursar Dashboard
    </h2>

    <p class="page-subtitle">
        Manage school fees, payments, income, expenses and financial records.
    </p>


    <!-- ====================================================
         STATISTICS
    ===================================================== -->

    <div class="row">

        <!-- Students -->

        <div class="col-xl-3 col-md-6">

            <div class="stat-card">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>
                            <div class="stat-title">
                                Students With Accounts
                            </div>

                            <div class="stat-value">
                                <?php echo number_format($totalStudents); ?>
                            </div>
                        </div>

                        <div class="stat-icon icon-blue">
                            <i class="fas fa-user-graduate"></i>
                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- Expected -->

        <div class="col-xl-3 col-md-6">

            <div class="stat-card">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <div class="stat-title">
                                Total Expected
                            </div>

                            <div class="stat-value">
                                <?php echo money($totalExpected); ?>
                            </div>

                        </div>

                        <div class="stat-icon icon-blue">
                            <i class="fas fa-file-invoice-dollar"></i>
                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- Collected -->

        <div class="col-xl-3 col-md-6">

            <div class="stat-card">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <div class="stat-title">
                                Total Collected
                            </div>

                            <div class="stat-value text-success">
                                <?php echo money($totalPaid); ?>
                            </div>

                        </div>

                        <div class="stat-icon icon-green">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- Outstanding -->

        <div class="col-xl-3 col-md-6">

            <div class="stat-card">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <div class="stat-title">
                                Outstanding
                            </div>

                            <div class="stat-value text-danger">
                                <?php echo money(max(0, $totalBalance)); ?>
                            </div>

                        </div>

                        <div class="stat-icon icon-red">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- ====================================================
         TODAY
    ===================================================== -->

    <div class="row">

        <div class="col-md-6">

            <div class="stat-card">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <div class="stat-title">
                                Today's Collections
                            </div>

                            <div class="stat-value text-success">
                                <?php echo money($todayCollected); ?>
                            </div>

                            <small class="text-muted">
                                Money received today
                            </small>

                        </div>

                        <div class="stat-icon icon-green">
                            <i class="fas fa-calendar-day"></i>
                        </div>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-6">

            <div class="stat-card">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <div class="stat-title">
                                Students With Outstanding Fees
                            </div>

                            <div class="stat-value text-danger">
                                <?php echo number_format($outstandingStudents); ?>
                            </div>

                            <small class="text-muted">
                                Accounts with a balance
                            </small>

                        </div>

                        <div class="stat-icon icon-orange">
                            <i class="fas fa-users"></i>
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- ====================================================
         QUICK ACTIONS
    ===================================================== -->

    <div class="content-card">

        <div class="card-header">
            <i class="fas fa-bolt text-warning"></i>
            Quick Actions
        </div>

        <div class="card-body">

            <div class="row">

                <div class="col-lg-3 col-md-6 mb-3">

                    <a href="payments.php"
                       class="btn btn-success btn-block">

                        <i class="fas fa-money-bill-wave"></i>
                        Receive Payment

                    </a>

                </div>

                <div class="col-lg-3 col-md-6 mb-3">

                    <a href="students_fees.php"
                       class="btn btn-primary btn-block">

                        <i class="fas fa-user-graduate"></i>
                        Student Fees

                    </a>

                </div>

                <div class="col-lg-3 col-md-6 mb-3">

                    <a href="income.php"
                       class="btn btn-info btn-block">

                        <i class="fas fa-plus-circle"></i>
                        Record Income

                    </a>

                </div>

                <div class="col-lg-3 col-md-6 mb-3">

                    <a href="expenses.php"
                       class="btn btn-danger btn-block">

                        <i class="fas fa-minus-circle"></i>
                        Record Expense

                    </a>

                </div>

            </div>

        </div>

    </div>


    <!-- ====================================================
         FINANCIAL MODULES
    ===================================================== -->

    <h5 class="mb-3">
        Financial Management
    </h5>

    <div class="row">


        <!-- Student Fees -->

        <div class="col-lg-4 col-md-6 mb-4">

            <div class="module-card">

                <div class="card-body">

                    <div class="module-icon">
                        <i class="fas fa-user-graduate"></i>
                    </div>

                    <h5>Student Fees</h5>

                    <p>
                        View student accounts, fee charges,
                        payments and outstanding balances.
                    </p>

                    <a href="students_fees.php"
                       class="btn btn-sm btn-primary">

                        Open Module
                        <i class="fas fa-arrow-right"></i>

                    </a>

                </div>

            </div>

        </div>


        <!-- Fee Structure -->

        <div class="col-lg-4 col-md-6 mb-4">

            <div class="module-card">

                <div class="card-body">

                    <div class="module-icon">
                        <i class="fas fa-list-alt"></i>
                    </div>

                    <h5>Fee Structure</h5>

                    <p>
                        Configure school fees by academic year,
                        term, class and fee type.
                    </p>

                    <a href="fee_structure.php"
                       class="btn btn-sm btn-primary">

                        Configure Fees
                        <i class="fas fa-arrow-right"></i>

                    </a>

                </div>

            </div>

        </div>


        <!-- Payments -->

        <div class="col-lg-4 col-md-6 mb-4">

            <div class="module-card">

                <div class="card-body">

                    <div class="module-icon">
                        <i class="fas fa-cash-register"></i>
                    </div>

                    <h5>Payments</h5>

                    <p>
                        Receive student payments and generate
                        official receipts.
                    </p>

                    <a href="payments.php"
                       class="btn btn-sm btn-success">

                        Receive Payment
                        <i class="fas fa-arrow-right"></i>

                    </a>

                </div>

            </div>

        </div>


        <!-- Income -->

        <div class="col-lg-4 col-md-6 mb-4">

            <div class="module-card">

                <div class="card-body">

                    <div class="module-icon">
                        <i class="fas fa-arrow-circle-down"></i>
                    </div>

                    <h5>Other Income</h5>

                    <p>
                        Record income received from sources
                        other than student fees.
                    </p>

                    <a href="income.php"
                       class="btn btn-sm btn-info">

                        Manage Income
                        <i class="fas fa-arrow-right"></i>

                    </a>

                </div>

            </div>

        </div>


        <!-- Expenses -->

        <div class="col-lg-4 col-md-6 mb-4">

            <div class="module-card">

                <div class="card-body">

                    <div class="module-icon">
                        <i class="fas fa-arrow-circle-up"></i>
                    </div>

                    <h5>Expenses</h5>

                    <p>
                        Record and manage school expenses
                        and expenditure.
                    </p>

                    <a href="expenses.php"
                       class="btn btn-sm btn-danger">

                        Manage Expenses
                        <i class="fas fa-arrow-right"></i>

                    </a>

                </div>

            </div>

        </div>


        <!-- Suppliers -->

        <div class="col-lg-4 col-md-6 mb-4">

            <div class="module-card">

                <div class="card-body">

                    <div class="module-icon">
                        <i class="fas fa-truck"></i>
                    </div>

                    <h5>Suppliers</h5>

                    <p>
                        Manage school suppliers and
                        supplier payments.
                    </p>

                    <a href="suppliers.php"
                       class="btn btn-sm btn-primary">

                        Manage Suppliers
                        <i class="fas fa-arrow-right"></i>

                    </a>

                </div>

            </div>

        </div>


        <!-- Salaries -->

        <div class="col-lg-4 col-md-6 mb-4">

            <div class="module-card">

                <div class="card-body">

                    <div class="module-icon">
                        <i class="fas fa-users"></i>
                    </div>

                    <h5>Payroll</h5>

                    <p>
                        Manage staff salaries and salary
                        payments.
                    </p>

                    <a href="salaries.php"
                       class="btn btn-sm btn-primary">

                        Payroll
                        <i class="fas fa-arrow-right"></i>

                    </a>

                </div>

            </div>

        </div>


        <!-- Budgets -->

        <div class="col-lg-4 col-md-6 mb-4">

            <div class="module-card">

                <div class="card-body">

                    <div class="module-icon">
                        <i class="fas fa-chart-pie"></i>
                    </div>

                    <h5>Budgets</h5>

                    <p>
                        Plan school income and expenditure
                        through budgets.
                    </p>

                    <a href="budgets.php"
                       class="btn btn-sm btn-primary">

                        Manage Budgets
                        <i class="fas fa-arrow-right"></i>

                    </a>

                </div>

            </div>

        </div>


        <!-- Reports -->

        <div class="col-lg-4 col-md-6 mb-4">

            <div class="module-card">

                <div class="card-body">

                    <div class="module-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>

                    <h5>Financial Reports</h5>

                    <p>
                        View income, expenses, fees,
                        cashbook and profit & loss reports.
                    </p>

                    <a href="reports.php"
                       class="btn btn-sm btn-dark">

                        View Reports
                        <i class="fas fa-arrow-right"></i>

                    </a>

                </div>

            </div>

        </div>

    </div>


    <!-- ====================================================
         RECENT PAYMENTS
    ===================================================== -->

    <div class="content-card">

        <div class="card-header d-flex justify-content-between align-items-center">

            <span>
                <i class="fas fa-history"></i>
                Recent Fee Payments
            </span>

            <a href="payments.php"
               class="btn btn-sm btn-outline-primary">

                View All

            </a>

        </div>

        <div class="card-body p-0">

            <?php if (count($recentPayments) > 0): ?>

                <div class="table-responsive">

                    <table class="table table-hover mb-0">

                        <thead>

                            <tr>

                                <th>Receipt</th>
                                <th>Student</th>
                                <th>Admission No.</th>
                                <th>LIN No.</th>
                                <th>Student Payment Code</th>
                                <th>Student Section</th>
                                <th>Method</th>
                                <th>Date</th>
                                <th class="text-right">
                                    Amount
                                </th>

                            </tr>

                        </thead>

                        <tbody>

                            <?php foreach ($recentPayments as $payment): ?>

                                <tr>

                                    <td>
                                        <a href="payment_receipt.php?id=<?php echo (int)$payment['id']; ?>">
                                            <?php echo htmlspecialchars($payment['receipt_no']); ?>
                                        </a>
                                    </td>

                                    <td>
                                        <?php echo htmlspecialchars($payment['student_name']); ?>
                                    </td>

                                    <td>
                                        <?php echo htmlspecialchars($payment['admission_no']); ?>
                                    </td>

                                    <td>
                                        <?php echo htmlspecialchars($payment['lin_no'] ?: '—'); ?>
                                    </td>

                                    <td>
                                        <?php echo htmlspecialchars($payment['student_payment_code'] ?: '—'); ?>
                                    </td>

                                    <td>
                                        <?php echo htmlspecialchars($payment['student_section'] ?: 'Day'); ?>
                                    </td>

                                    <td>
                                        <span class="badge badge-light">
                                            <?php echo htmlspecialchars($payment['method_name']); ?>
                                        </span>
                                    </td>

                                    <td>
                                        <?php
                                        echo date(
                                            'd M Y H:i',
                                            strtotime($payment['payment_date'])
                                        );
                                        ?>
                                    </td>

                                    <td class="text-right font-weight-bold text-success">

                                        <?php echo money($payment['amount']); ?>

                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php else: ?>

                <div class="text-center p-5">

                    <i class="fas fa-receipt fa-3x text-muted mb-3"></i>

                    <h5>No payments yet</h5>

                    <p class="text-muted mb-3">
                        Fee payments will appear here after
                        the bursar records them.
                    </p>

                    <a href="payments.php"
                       class="btn btn-primary">

                        <i class="fas fa-plus"></i>
                        Receive First Payment

                    </a>

                </div>

            <?php endif; ?>

        </div>

    </div>


    <!-- ====================================================
         FOOTER
    ===================================================== -->

    <div class="text-center text-muted py-3">

        <small>
            School Management System &copy;
            <?php echo date('Y'); ?>
            — Bursar Module
        </small>

    </div>

</div>
```

</div>

<!-- ============================================================
     JAVASCRIPT
============================================================ -->

<script>

    const menuBtn = document.getElementById('menuBtn');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');

    menuBtn.addEventListener('click', function () {

        sidebar.classList.toggle('show');
        overlay.classList.toggle('show');

    });

    overlay.addEventListener('click', function () {

        sidebar.classList.remove('show');
        overlay.classList.remove('show');

    });

    document.addEventListener('keydown', function (event) {

        if (event.key === 'Escape') {

            sidebar.classList.remove('show');
            overlay.classList.remove('show');

        }

    });

</script>

</body>
</html>
