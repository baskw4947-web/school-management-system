<?php
/**
 * School Management System - Bursar Financial Reports
 * Location: /admin/bursar/reports.php
 * Uses the same session/database/auth settings as the working payments.php page.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
ob_start();
$reportsDebugRequested = isset($_GET['reports_debug']) && (string)$_GET['reports_debug'] === '1';
register_shutdown_function(static function () use ($reportsDebugRequested): void {
    $lastError = error_get_last();
    if (!$lastError || !in_array($lastError['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR], true)) return;
    error_log('reports.php fatal error: ' . ($lastError['message'] ?? 'Unknown error') . ' in ' . ($lastError['file'] ?? 'unknown') . ':' . (int)($lastError['line'] ?? 0));
    while (ob_get_level() > 0) { if (!@ob_end_clean()) break; }
    if (!headers_sent()) http_response_code(500);
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Financial reports error</title><style>body{font-family:Arial,sans-serif;background:#f4f6fa;color:#243247;padding:25px}.box{max-width:760px;margin:30px auto;background:#fff;padding:24px;border:1px solid #e3e8f0;border-radius:10px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f8fafc;padding:12px;border-radius:6px}</style></head><body><div class="box"><h2>Financial reports could not finish loading</h2><p>A PHP error stopped this page. The error was written to the hosting PHP error log.</p>';
    $hasSession = isset($_SESSION) && (isset($_SESSION['user_id']) || isset($_SESSION['id']));
    if ($reportsDebugRequested && $hasSession) echo '<p><strong>Diagnostic details:</strong></p><pre>' . htmlspecialchars((string)($lastError['message'] ?? 'Unknown error'), ENT_QUOTES, 'UTF-8') . "\n" . htmlspecialchars((string)($lastError['file'] ?? 'unknown'), ENT_QUOTES, 'UTF-8') . ':' . (int)($lastError['line'] ?? 0) . '</pre>';
    else echo '<p>While logged in, append <code>?reports_debug=1</code> to this page URL and share the displayed diagnostic message.</p>';
    echo '</div></body></html>';
});

require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator', 'bursar']);
$db = $conn ?? ($mysqli ?? ($connection ?? null));
if (!$db instanceof mysqli) {
    http_response_code(500);
    exit('Database connection was not found. Check config/database.php.');
}
$db->set_charset('utf8mb4');
$userId = (int)($_SESSION['user_id'] ?? $_SESSION['id'] ?? 0);

function bursar_reports_h($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}
function bursar_reports_ident(string $name): string {
    return '`' . str_replace('`', '``', $name) . '`';
}
function bursar_reports_first_col(array $columns, array $candidates): ?string {
    foreach ($candidates as $candidate) {
        $key = strtolower((string)$candidate);
        if (isset($columns[$key])) return is_array($columns[$key]) ? (string)($columns[$key]['Field'] ?? $candidate) : (string)$columns[$key];
    }
    return null;
}
function bursar_reports_columns(mysqli $db, string $table): array {
    $out = [];
    $result = $db->query('SHOW COLUMNS FROM ' . bursar_reports_ident($table));
    while ($row = $result->fetch_assoc()) $out[strtolower((string)$row['Field'])] = $row;
    $result->free();
    return $out;
}
function bursar_reports_date(array $row, array $candidates): ?int {
    foreach ($candidates as $candidate) {
        if (!array_key_exists($candidate, $row) || $row[$candidate] === null || trim((string)$row[$candidate]) === '') continue;
        $raw = trim((string)$row[$candidate]);
        if ($raw === '0000-00-00' || $raw === '0000-00-00 00:00:00') continue;
        $ts = strtotime($raw);
        if ($ts !== false) return $ts;
    }
    return null;
}
function bursar_reports_effective(string $status): bool {
    $status = strtolower(trim($status));
    if ($status === '') return true;
    return in_array($status, ['completed', 'complete', 'paid', 'success', 'successful', 'confirmed', 'approved', 'posted', 'received', 'settled', 'processed', 'done', '1'], true);
}
function bursar_reports_lookup_map(mysqli $db, ?string $table, array $idOptions, array $nameOptions): array {
    if (!$table) return [];
    try {
        $cols = bursar_reports_columns($db, $table);
        $idCol = bursar_reports_first_col($cols, $idOptions);
        $nameCol = bursar_reports_first_col($cols, $nameOptions);
        if (!$idCol || !$nameCol) {
            $first = isset($cols['first_name']) ? $cols['first_name']['Field'] : null;
            $last = isset($cols['last_name']) ? $cols['last_name']['Field'] : null;
            if (!$idCol || (!$first && !$last)) return [];
            $fn = $first ? "NULLIF(TRIM(CAST(" . bursar_reports_ident($first) . " AS CHAR)), '')" : "''";
            $ln = $last ? "NULLIF(TRIM(CAST(" . bursar_reports_ident($last) . " AS CHAR)), '')" : "''";
            $sql = 'SELECT ' . bursar_reports_ident($idCol) . ' AS lookup_id, CONCAT_WS(\' \',' . $fn . ', ' . $ln . ') AS lookup_name FROM ' . bursar_reports_ident($table);
        } else {
            $sql = 'SELECT ' . bursar_reports_ident($idCol) . ' AS lookup_id, ' . bursar_reports_ident($nameCol) . ' AS lookup_name FROM ' . bursar_reports_ident($table);
        }
        $rs = $db->query($sql); $map = [];
        while ($row = $rs->fetch_assoc()) {
            $id = (string)($row['lookup_id'] ?? ''); $name = trim((string)($row['lookup_name'] ?? ''));
            if ($id !== '' && $name !== '') $map[$id] = $name;
        }
        $rs->free(); return $map;
    } catch (Throwable $e) { error_log('reports lookup error (' . $table . '): ' . $e->getMessage()); return []; }
}
function bursar_reports_money($value): string {
    return number_format((float)$value, 2);
}
function bursar_reports_valid_date(string $value): bool {
    $date = DateTime::createFromFormat('!Y-m-d', $value);
    return $date !== false && $date->format('Y-m-d') === $value;
}

$today = date('Y-m-d');
$from = trim((string)($_GET['from'] ?? date('Y-m-01')));
$to = trim((string)($_GET['to'] ?? $today));
$q = trim((string)($_GET['q'] ?? ''));
$sourceFilter = trim((string)($_GET['source'] ?? ''));
$statusFilter = trim((string)($_GET['status'] ?? ''));
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 25;
$errors = [];
if (!bursar_reports_valid_date($from) || !bursar_reports_valid_date($to)) $errors[] = 'Please choose valid From and To dates.';
if (!$errors && $from > $to) $errors[] = 'The From date cannot be later than the To date.';

$tableMap = [];
$columnCache = [];
$loadWarnings = [];
$allRows = [];
$sourceSummary = [];
$categorySummary = [];
$monthSummary = [];
$allStatusOptions = [];
$studentNames = [];
$supplierNames = [];
$incomeCategories = [];
$expenseCategories = [];
$methodNames = [];
$totalReceipts = 0.0;
$totalPayments = 0.0;
$periodRowCount = 0;
$availableSourceCount = 0;

$sources = [
    ['table'=>'fee_payments','direction'=>'in','kind'=>'Student fees','date'=>['payment_date','paid_date','transaction_date','created_at'],'amount'=>['amount','paid_amount','payment_amount'],'number'=>['receipt_no','payment_no','transaction_no','receipt_number'],'status'=>['status','payment_status'],'reference'=>['reference_no','reference_number','transaction_reference'],'notes'=>['description','notes','remarks','narration'],'category'=>'Student fees'],
    ['table'=>'income_transactions','direction'=>'in','kind'=>'Other income','date'=>['income_date','transaction_date','date','created_at'],'amount'=>['amount','income_amount','total_amount'],'number'=>['transaction_no','income_no','receipt_no','reference_no'],'status'=>['status','payment_status'],'reference'=>['reference_no','reference_number'],'notes'=>['description','notes','remarks'],'category_id'=>['category_id','income_category_id'],'category'=>'Other income'],
    ['table'=>'expense_transactions','direction'=>'out','kind'=>'Expenses','date'=>['expense_date','transaction_date','date','created_at'],'amount'=>['amount','expense_amount','total_amount'],'number'=>['transaction_no','expense_no','reference_no'],'status'=>['status','payment_status'],'reference'=>['reference_no','reference_number'],'notes'=>['description','notes','remarks'],'category_id'=>['category_id','expense_category_id'],'category'=>'Expenses','person'=>['payee_name','supplier_name','payee','supplier']],
    ['table'=>'supplier_payments','direction'=>'out','kind'=>'Supplier payments','date'=>['payment_date','paid_date','transaction_date','date','created_at'],'amount'=>['amount','paid_amount','payment_amount','total_amount'],'number'=>['payment_no','transaction_no','receipt_no','reference_no'],'status'=>['status','payment_status'],'reference'=>['reference_no','reference_number','transaction_reference'],'notes'=>['description','notes','remarks','narration'],'category'=>'Supplier payments','person'=>['supplier_name','payee_name','supplier','payee'],'person_id'=>['supplier_id']],
    ['table'=>'salary_payments','direction'=>'out','kind'=>'Salary payments','date'=>['payment_date','paid_date','transaction_date','created_at'],'amount'=>['net_salary','amount','paid_amount','payment_amount','net_amount'],'number'=>['payment_no','transaction_no','receipt_no'],'status'=>['status','payment_status'],'reference'=>['reference_no','reference_number','transaction_reference'],'notes'=>['notes','description','remarks','narration'],'category'=>'Staff salaries','person'=>['person_name','employee_name','staff_name','teacher_name','full_name']]
];

if (!$errors) {
    try {
        $tr = $db->query('SHOW TABLES');
        while ($r = $tr->fetch_row()) $tableMap[strtolower((string)$r[0])] = (string)$r[0];
        $tr->free();
        foreach (['fee_payments','income_transactions','expense_transactions','supplier_payments','salary_payments'] as $expected) {
            $real = $tableMap[strtolower($expected)] ?? null;
            if ($real) {
                try { $columnCache[strtolower($real)] = bursar_reports_columns($db, $real); }
                catch (Throwable $e) { error_log('reports column read error (' . $real . '): ' . $e->getMessage()); }
            }
        }
        $incomeCatTable = $tableMap['income_categories'] ?? null;
        $expenseCatTable = $tableMap['expense_categories'] ?? null;
        $studentsTable = $tableMap['students'] ?? null;
        $suppliersTable = $tableMap['suppliers'] ?? null;
        $methodsTable = $tableMap['payment_methods'] ?? null;
        $incomeCategories = bursar_reports_lookup_map($db, $incomeCatTable, ['id','category_id'], ['category_name','name','title']);
        $expenseCategories = bursar_reports_lookup_map($db, $expenseCatTable, ['id','category_id'], ['category_name','name','title']);
        $studentNames = bursar_reports_lookup_map($db, $studentsTable, ['id','student_id'], ['full_name','student_name','name']);
        $studentIdentifiers = [];
        if ($studentsTable) {
            try {
                $studentIdentifierCols = $columnCache[strtolower($studentsTable)] ?? bursar_reports_columns($db, $studentsTable);
                $studentIdentifierId = bursar_reports_first_col($studentIdentifierCols, ['id','student_id']);
                $studentIdentifierLin = bursar_reports_first_col($studentIdentifierCols, ['lin_no']);
                $studentIdentifierPayment = bursar_reports_first_col($studentIdentifierCols, ['student_payment_code']);
                $studentIdentifierSection = bursar_reports_first_col($studentIdentifierCols, ['student_section']);
                if ($studentIdentifierId) {
                    $studentIdentifierSelect = [bursar_reports_ident($studentIdentifierId) . ' AS sid'];
                    $studentIdentifierSelect[] = $studentIdentifierLin ? bursar_reports_ident($studentIdentifierLin) . ' AS lin_no' : "'' AS lin_no";
                    $studentIdentifierSelect[] = $studentIdentifierPayment ? bursar_reports_ident($studentIdentifierPayment) . ' AS payment_code' : "'' AS payment_code";
                    $studentIdentifierSelect[] = $studentIdentifierSection ? bursar_reports_ident($studentIdentifierSection) . ' AS student_section' : "'Day' AS student_section";
                    $identifierResult = $db->query('SELECT ' . implode(', ', $studentIdentifierSelect) . ' FROM ' . bursar_reports_ident($studentsTable));
                    while ($identifierRow = $identifierResult->fetch_assoc()) {
                        $studentIdentifiers[(string)$identifierRow['sid']] = $identifierRow;
                    }
                    $identifierResult->free();
                }
            } catch (Throwable $e) { error_log('reports student identifier lookup: ' . $e->getMessage()); }
        }
        if ($studentsTable) {
            try {
                $sc = $columnCache[strtolower($studentsTable)] ?? bursar_reports_columns($db, $studentsTable);
                if (isset($sc['id']) && (isset($sc['first_name']) || isset($sc['last_name']))) {
                    $fn = isset($sc['first_name']) ? "NULLIF(TRIM(CAST(" . bursar_reports_ident($sc['first_name']['Field']) . " AS CHAR)), '')" : "''";
                    $ln = isset($sc['last_name']) ? "NULLIF(TRIM(CAST(" . bursar_reports_ident($sc['last_name']['Field']) . " AS CHAR)), '')" : "''";
                    $rs = $db->query('SELECT ' . bursar_reports_ident($sc['id']['Field']) . ' AS pid, CONCAT_WS(\' \',' . $fn . ', ' . $ln . ') AS pname FROM ' . bursar_reports_ident($studentsTable));
                    while ($r = $rs->fetch_assoc()) if (trim((string)$r['pname']) !== '') $studentNames[(string)$r['pid']] = trim((string)$r['pname']);
                    $rs->free();
                }
            } catch (Throwable $e) { error_log('reports student-name lookup: ' . $e->getMessage()); }
        }
        $supplierNames = bursar_reports_lookup_map($db, $suppliersTable, ['id','supplier_id'], ['supplier_name','name','company_name']);
        $methodNames = bursar_reports_lookup_map($db, $methodsTable, ['id','payment_method_id'], ['method_name','name','payment_method','title']);

        $startTs = strtotime($from . ' 00:00:00');
        $endTs = strtotime($to . ' 23:59:59');
        foreach ($sources as $source) {
            $table = $tableMap[strtolower($source['table'])] ?? null;
            if (!$table) continue;
            $availableSourceCount++;
            $cols = $columnCache[strtolower($table)] ?? bursar_reports_columns($db, $table);
            $dateCol = bursar_reports_first_col($cols, $source['date']);
            $amountCol = bursar_reports_first_col($cols, $source['amount']);
            if (!$dateCol || !$amountCol) {
                $loadWarnings[] = $table . ' was not included because a compatible date or amount column could not be identified.';
                continue;
            }
            try {
                $rs = $db->query('SELECT * FROM ' . bursar_reports_ident($table) . ' ORDER BY ' . (isset($cols['id']) ? bursar_reports_ident($cols['id']['Field']) . ' DESC' : bursar_reports_ident($dateCol) . ' DESC'));
                while ($raw = $rs->fetch_assoc()) {
                    $dateCandidates = [$dateCol];
                    foreach (['payment_date','paid_date','income_date','expense_date','transaction_date','created_at','date'] as $candidate) {
                        if (isset($cols[$candidate]) && !in_array($cols[$candidate]['Field'], $dateCandidates, true)) $dateCandidates[] = $cols[$candidate]['Field'];
                    }
                    $dateTs = bursar_reports_date($raw, $dateCandidates);
                    if ($dateTs === null || $dateTs < $startTs || $dateTs > $endTs) continue;
                    $statusCol = bursar_reports_first_col($cols, $source['status']);
                    $status = $statusCol ? trim((string)($raw[$statusCol] ?? '')) : 'completed';
                    if ($status === '') $status = 'completed';
                    $amount = abs((float)($raw[$amountCol] ?? 0));
                    $effective = bursar_reports_effective($status);
                    $numberCol = bursar_reports_first_col($cols, $source['number']);
                    $referenceCol = bursar_reports_first_col($cols, $source['reference']);
                    $notesCol = bursar_reports_first_col($cols, $source['notes']);
                    $person = '';
                    if (!empty($source['person'])) {
                        $personCol = bursar_reports_first_col($cols, $source['person']);
                        if ($personCol) $person = trim((string)($raw[$personCol] ?? ''));
                    }
                    $studentIdentifiersLabel = '';
                    if ($table === ($tableMap['fee_payments'] ?? '') && $table === 'fee_payments') {
                        $studentIdCol = bursar_reports_first_col($cols, ['student_id']);
                        $studentId = $studentIdCol ? (string)($raw[$studentIdCol] ?? '') : '';
                        if ($studentId === '') {
                            $accountCol = bursar_reports_first_col($cols, ['student_fee_account_id','account_id','fee_account_id']);
                            $accountId = $accountCol ? (string)($raw[$accountCol] ?? '') : '';
                            if ($accountId !== '' && isset($tableMap['student_fee_accounts'])) {
                                try {
                                    $accCols = $columnCache['student_fee_accounts'] ?? bursar_reports_columns($db, $tableMap['student_fee_accounts']);
                                    $accId = bursar_reports_first_col($accCols, ['id','account_id']);
                                    $accStud = bursar_reports_first_col($accCols, ['student_id']);
                                    if ($accId && $accStud) {
                                        $as = $db->prepare('SELECT ' . bursar_reports_ident($accStud) . ' FROM ' . bursar_reports_ident($tableMap['student_fee_accounts']) . ' WHERE ' . bursar_reports_ident($accId) . ' = ? LIMIT 1');
                                        $as->bind_param('s', $accountId); $as->execute(); $studentId = (string)($as->get_result()->fetch_row()[0] ?? ''); $as->close();
                                    }
                                } catch (Throwable $e) { error_log('reports fee account lookup: ' . $e->getMessage()); }
                            }
                        }
                        if ($studentId !== '' && isset($studentNames[$studentId])) $person = $studentNames[$studentId];
                        elseif ($person === '') $person = $studentId !== '' ? 'Student #' . $studentId : 'Student fee account';
                        if ($studentId !== '' && isset($studentIdentifiers[$studentId])) {
                            $identifier = $studentIdentifiers[$studentId];
                            $studentIdentifiersLabel = 'LIN: ' . (trim((string)($identifier['lin_no'] ?? '')) ?: '—')
                                . ' | Payment Code: ' . (trim((string)($identifier['payment_code'] ?? '')) ?: '—')
                                . ' | ' . (trim((string)($identifier['student_section'] ?? 'Day')) ?: 'Day');
                        }
                    }
                    if ($table === 'salary_payments' && $person === '') {
                        $teacherId = (string)($raw['teacher_id'] ?? '');
                        $staffId = (string)($raw['staff_id'] ?? '');
                        $person = $teacherId !== '' ? 'Teacher #' . $teacherId : ($staffId !== '' ? 'Staff member #' . $staffId : 'Staff salary');
                    }
                    if ($table === 'supplier_payments' && $person === '') {
                        $sid = (string)($raw['supplier_id'] ?? '');
                        if ($sid !== '' && isset($supplierNames[$sid])) $person = $supplierNames[$sid];
                        elseif ($sid !== '') $person = 'Supplier #' . $sid;
                    }
                    $category = (string)$source['category'];
                    $directCategory = bursar_reports_first_col($cols, ['category_name','category','income_category','expense_category']);
                    if ($directCategory && trim((string)($raw[$directCategory] ?? '')) !== '') $category = trim((string)$raw[$directCategory]);
                    elseif (isset($source['category_id'])) {
                        $catCol = bursar_reports_first_col($cols, $source['category_id']);
                        $catId = $catCol ? (string)($raw[$catCol] ?? '') : '';
                        $catMap = $source['direction'] === 'in' ? $incomeCategories : $expenseCategories;
                        if ($catId !== '' && isset($catMap[$catId])) $category = $catMap[$catId];
                        elseif ($catId !== '') $category .= ' #' . $catId;
                    }
                    $notes = $notesCol ? trim((string)($raw[$notesCol] ?? '')) : '';
                    $number = $numberCol ? trim((string)($raw[$numberCol] ?? '')) : '';
                    if ($number === '') $number = strtoupper(substr($table, 0, 3)) . '-' . (string)($raw['id'] ?? '');
                    $reference = $referenceCol ? trim((string)($raw[$referenceCol] ?? '')) : '';
                    $row = [
                        'date_ts'=>$dateTs, 'date'=>date('Y-m-d H:i:s', $dateTs), 'month'=>date('Y-m', $dateTs),
                        'source'=>$source['kind'], 'table'=>$table, 'id'=>(int)($raw['id'] ?? 0), 'number'=>$number,
                        'direction'=>$source['direction'], 'category'=>$category, 'person'=>$person, 'student_identifiers'=>$studentIdentifiersLabel,
                        'reference'=>$reference, 'notes'=>$notes, 'status'=>$status, 'amount'=>$amount, 'effective'=>$effective
                    ];
                    $allRows[] = $row;
                    $allStatusOptions[$status] = true;
                    if (!isset($sourceSummary[$source['kind']])) $sourceSummary[$source['kind']] = ['direction'=>$source['direction'],'records'=>0,'effective_records'=>0,'amount'=>0.0,'pending'=>0,'table'=>$table];
                    $sourceSummary[$source['kind']]['records']++;
                    if ($effective) {
                        $sourceSummary[$source['kind']]['effective_records']++;
                        $sourceSummary[$source['kind']]['amount'] += $amount;
                        if ($source['direction'] === 'in') $totalReceipts += $amount; else $totalPayments += $amount;
                        $ck = $source['direction'] . '|' . $category;
                        if (!isset($categorySummary[$ck])) $categorySummary[$ck] = ['direction'=>$source['direction'],'category'=>$category,'count'=>0,'amount'=>0.0];
                        $categorySummary[$ck]['count']++; $categorySummary[$ck]['amount'] += $amount;
                        if (!isset($monthSummary[$row['month']])) $monthSummary[$row['month']] = ['in'=>0.0,'out'=>0.0,'records'=>0];
                        $monthSummary[$row['month']][$source['direction']] += $amount;
                        $monthSummary[$row['month']]['records']++;
                    } else {
                        $sourceSummary[$source['kind']]['pending']++;
                    }
                }
                $rs->free();
            } catch (Throwable $e) {
                $loadWarnings[] = 'Could not read ' . $table . '; its records were omitted from this report.';
                error_log('reports source error (' . $table . '): ' . $e->getMessage());
            }
        }
    } catch (Throwable $e) {
        $errors[] = 'The financial report could not read the database structure. Check config/database.php and the PHP error log.';
        error_log('reports.php setup error: ' . $e->getMessage());
    }
}

usort($allRows, static fn($a, $b) => $b['date_ts'] <=> $a['date_ts']);
ksort($monthSummary);
$categoriesIn = array_values(array_filter($categorySummary, static fn($r) => $r['direction'] === 'in'));
$categoriesOut = array_values(array_filter($categorySummary, static fn($r) => $r['direction'] === 'out'));
usort($categoriesIn, static fn($a, $b) => $b['amount'] <=> $a['amount']);
usort($categoriesOut, static fn($a, $b) => $b['amount'] <=> $a['amount']);
$filteredRows = array_values(array_filter($allRows, static function ($row) use ($q, $sourceFilter, $statusFilter): bool {
    if ($sourceFilter !== '' && $row['source'] !== $sourceFilter) return false;
    if ($statusFilter !== '' && strtolower($row['status']) !== strtolower($statusFilter)) return false;
    if ($q !== '') {
        $haystack = strtolower(implode(' ', [$row['date'],$row['source'],$row['number'],$row['category'],$row['person'],$row['student_identifiers'],$row['reference'],$row['notes'],$row['status'],$row['amount']]));
        if (strpos($haystack, strtolower($q)) === false) return false;
    }
    return true;
}));
$periodRowCount = count($allRows);
$totalFiltered = count($filteredRows);
$totalPages = max(1, (int)ceil($totalFiltered / $perPage));
if ($page > $totalPages) $page = $totalPages;
$displayRows = array_slice($filteredRows, ($page - 1) * $perPage, $perPage);
$netMovement = $totalReceipts - $totalPayments;

if (isset($_GET['export']) && $_GET['export'] === 'csv' && !$errors) {
    $filename = 'bursar-financial-report-' . $from . '-to-' . $to . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Date','Source','Transaction No.','Direction','Category','Student / Staff / Payee','Student Identifiers','Reference','Status','Effective','Amount (UGX)','Description']);
    foreach ($filteredRows as $row) fputcsv($out, [$row['date'],$row['source'],$row['number'],$row['direction']==='in'?'Receipt':'Payment',$row['category'],$row['person'],$row['student_identifiers'],$row['reference'],$row['status'],$row['effective']?'Yes':'No',number_format($row['amount'],2,'.',''),$row['notes']]);
    fclose($out);
    exit;
}
$statusList = array_keys($allStatusOptions); sort($statusList);
$exportQuery = $_GET; $exportQuery['export'] = 'csv'; unset($exportQuery['page']);
$sourceList = array_keys($sourceSummary); sort($sourceList);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Financial Reports | School Management System</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
:root{--navy:#17243a;--navy2:#243754;--bg:#f4f6fa;--blue:#2865cf;--muted:#778398}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:#263348;font-family:Arial,Helvetica,sans-serif}.sidebar{position:fixed;top:0;left:0;bottom:0;width:250px;background:var(--navy);color:#fff;overflow-y:auto;z-index:1040;padding:20px 0}.brand{padding:0 22px 22px;border-bottom:1px solid rgba(255,255,255,.12);margin-bottom:16px}.brand h5{margin:0;font-weight:700}.brand small{color:#b8c5d8}.nav-label{color:#95a7c0;text-transform:uppercase;font-size:10px;letter-spacing:1.2px;padding:14px 22px 5px}.sidebar a{color:#d8e1ed;display:block;padding:10px 22px;text-decoration:none;font-size:13px;border-left:3px solid transparent}.sidebar a i{width:22px}.sidebar a:hover,.sidebar a.active{background:var(--navy2);color:#fff;border-left-color:#70a7ff}.main{margin-left:250px;padding:26px;min-height:100vh}.topbar{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:22px}.topbar h2{font-size:25px;margin:0;font-weight:700;color:#192940}.subheading{color:var(--muted);font-size:13px;margin-top:5px}.panel{background:#fff;border-radius:10px;box-shadow:0 3px 15px rgba(24,42,70,.055);padding:22px;margin-bottom:22px;border:1px solid #edf0f5}.panel-title{font-size:17px;font-weight:700;margin-bottom:17px;color:#1d2d44}.stat-card{background:#fff;border:1px solid #edf0f5;border-radius:10px;padding:17px 19px;box-shadow:0 3px 15px rgba(24,42,70,.04);height:100%;min-height:125px}.stat-card .label{color:var(--muted);font-size:12px}.stat-card .value{font-size:22px;font-weight:700;margin-top:8px;overflow-wrap:anywhere}.stat-card .symbol{float:right;width:38px;height:38px;line-height:38px;text-align:center;border-radius:9px;background:#eef4ff;color:#326bd1}.form-control{font-size:13px;min-height:38px}label{font-size:12px;color:#4e5c70;font-weight:600}.table thead th{background:#f7f9fc;color:#68768a;font-size:10px;text-transform:uppercase;letter-spacing:.4px;border-top:0;white-space:nowrap}.table td{font-size:12px;vertical-align:middle}.btn{font-size:12px}.btn-primary{background:var(--blue);border-color:var(--blue)}.badge{font-size:10px;padding:6px 8px}.empty-state{padding:30px 10px;text-align:center;color:#8290a4}.footer-note{text-align:center;color:#97a1b1;font-size:11px;padding:7px 0 0}.mobile-menu{display:none}.small-muted{font-size:11px;color:#8490a1}.amount-in{color:#16845b;font-weight:700;white-space:nowrap}.amount-out{color:#c33d4b;font-weight:700;white-space:nowrap}.alert{font-size:13px}.positive{color:#16845b}.negative{color:#c33d4b}.mini-bar{height:8px;background:#e8edf5;border-radius:10px;overflow:hidden;min-width:55px}.mini-bar span{display:block;height:100%;background:#326bd1;border-radius:10px}.category-name{min-width:130px;overflow-wrap:anywhere}.table td.detail-cell{min-width:190px;max-width:300px;overflow-wrap:anywhere}@media(max-width:991px){.sidebar{transform:translateX(-100%);transition:transform .2s}.sidebar.show{transform:translateX(0)}.main{margin-left:0;padding:18px}.mobile-menu{display:inline-block!important}.topbar h2{font-size:22px}.panel{padding:16px}}@media print{.sidebar,.no-print,.footer-note{display:none!important}.main{margin:0;padding:0}body{background:#fff}.panel,.stat-card{box-shadow:none;border:0}.table{font-size:10px}}
</style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<nav id="sidebar" class="sidebar no-print">
 <div class="brand"><h5><i class="fas fa-school mr-2"></i>School Management</h5><small>Bursar &amp; Finance</small></div>
 <div class="nav-label">Main</div><a href="/admin/dashboard.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a><a href="/admin/bursar/index.php"><i class="fas fa-chart-line"></i>Bursar Dashboard</a>
 <div class="nav-label">Fees</div><a href="/admin/bursar/students_fee_accounts.php"><i class="fas fa-user-graduate"></i>Student Fee Accounts</a><a href="/admin/bursar/fee_structure.php"><i class="fas fa-layer-group"></i>Fee Structure</a><a href="/admin/bursar/payments.php"><i class="fas fa-cash-register"></i>Receive Student Payment</a><a href="/admin/bursar/outstanding_fees.php"><i class="fas fa-exclamation-circle"></i>Outstanding Fees</a>
 <div class="nav-label">Finance</div><a href="/admin/bursar/income.php"><i class="fas fa-arrow-down"></i>Income</a><a href="/admin/bursar/expenses.php"><i class="fas fa-arrow-up"></i>Expenses</a><a href="/admin/bursar/suppliers.php"><i class="fas fa-truck"></i>Suppliers</a><a href="/admin/bursar/supplier_payments.php"><i class="fas fa-file-invoice-dollar"></i>Supplier Payments</a><a href="/admin/bursar/budgets.php"><i class="fas fa-wallet"></i>Budgets</a><a href="/admin/bursar/cashbook.php"><i class="fas fa-book"></i>Cashbook</a>
 <div class="nav-label">Payroll</div><a href="/admin/bursar/salaries.php"><i class="fas fa-users"></i>Staff Salaries</a><a href="/admin/bursar/salary_payments.php"><i class="fas fa-money-check-alt"></i>Salary Payments</a>
 <div class="nav-label">Reports</div><a class="active" href="/admin/bursar/reports.php"><i class="fas fa-chart-bar"></i>Financial Reports</a><a href="/admin/bursar/fees_report.php"><i class="fas fa-file-alt"></i>Fees Report</a><a href="/admin/bursar/profit_loss.php"><i class="fas fa-balance-scale"></i>Profit &amp; Loss</a>
 <div class="nav-label">Account</div><a href="/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
</nav>
<main class="main">
 <header class="topbar"><div class="d-flex align-items-start"><button type="button" id="mobileMenuBtn" class="btn btn-outline-secondary mobile-menu mr-3" aria-label="Open navigation"><i class="fas fa-bars"></i></button><div><div class="text-uppercase text-primary small font-weight-bold">Bursar / Finance</div><h2>Financial Reports</h2><div class="subheading">Review school receipts, expenses, supplier payments and staff salary disbursements.</div></div></div><div class="no-print d-flex flex-wrap" style="gap:8px"><button type="button" onclick="window.print()" class="btn btn-outline-primary"><i class="fas fa-print mr-1"></i>Print Report</button><a class="btn btn-outline-success" href="?<?= bursar_reports_h(http_build_query($exportQuery)) ?>"><i class="fas fa-file-csv mr-1"></i>Export CSV</a></div></header>
 <?php if ($errors): ?><div class="alert alert-danger"><strong><i class="fas fa-exclamation-triangle mr-1"></i>Report filter issue</strong><br><?= bursar_reports_h(implode(' ', $errors)) ?></div><?php endif; ?>
 <?php foreach ($loadWarnings as $warning): ?><div class="alert alert-warning py-2"><i class="fas fa-exclamation-circle mr-1"></i><?= bursar_reports_h($warning) ?></div><?php endforeach; ?>
 <?php if ($availableSourceCount === 0 && !$errors): ?><div class="alert alert-warning">No compatible finance transaction tables were found. Check that fee_payments, income_transactions, expense_transactions, supplier_payments, or salary_payments exist in the connected database.</div><?php endif; ?>
 <section class="panel no-print"><div class="panel-title"><i class="fas fa-filter text-primary mr-2"></i>Report filters</div><form method="get" action="reports.php" class="form-row align-items-end">
  <div class="form-group col-xl-2 col-md-4"><label for="from">From date</label><input class="form-control" type="date" name="from" id="from" value="<?= bursar_reports_h($from) ?>" required></div>
  <div class="form-group col-xl-2 col-md-4"><label for="to">To date</label><input class="form-control" type="date" name="to" id="to" value="<?= bursar_reports_h($to) ?>" required></div>
  <div class="form-group col-xl-3 col-md-4"><label for="q">Search transaction details</label><input class="form-control" type="search" name="q" id="q" value="<?= bursar_reports_h($q) ?>" placeholder="Receipt, payee, category, reference"></div>
  <div class="form-group col-xl-2 col-md-4"><label for="source">Source</label><select class="form-control" name="source" id="source"><option value="">All sources</option><?php foreach ($sourceList as $src): ?><option value="<?= bursar_reports_h($src) ?>" <?= $sourceFilter===$src?'selected':'' ?>><?= bursar_reports_h($src) ?></option><?php endforeach; ?></select></div>
  <div class="form-group col-xl-2 col-md-4"><label for="status">Status</label><select class="form-control" name="status" id="status"><option value="">All statuses</option><?php foreach ($statusList as $s): ?><option value="<?= bursar_reports_h($s) ?>" <?= strtolower($statusFilter)===strtolower($s)?'selected':'' ?>><?= bursar_reports_h(ucwords(str_replace('_',' ',$s))) ?></option><?php endforeach; ?></select></div>
  <div class="form-group col-xl-1 col-md-4"><button type="submit" class="btn btn-primary btn-block"><i class="fas fa-search"></i></button></div>
 </form><div class="small text-muted">Summary totals and category/month summaries use the selected date range. Search, source and status filters apply to the transaction list and CSV export. Only transactions marked completed, paid, received, approved or another recognized settled status count toward financial totals.</div></section>
 <div class="row mb-2">
  <div class="col-sm-6 col-xl-3 mb-3"><div class="stat-card"><span class="symbol"><i class="fas fa-arrow-circle-down"></i></span><div class="label">Recorded receipts</div><div class="value text-success">UGX <?= bursar_reports_money($totalReceipts) ?></div><div class="small-muted">Student fees + other income</div></div></div>
  <div class="col-sm-6 col-xl-3 mb-3"><div class="stat-card"><span class="symbol" style="background:#fff0f1;color:#c33d4b"><i class="fas fa-arrow-circle-up"></i></span><div class="label">Recorded disbursements</div><div class="value text-danger">UGX <?= bursar_reports_money($totalPayments) ?></div><div class="small-muted">Expenses + suppliers + salaries</div></div></div>
  <div class="col-sm-6 col-xl-3 mb-3"><div class="stat-card"><span class="symbol" style="background:#e1f7ef;color:#16845b"><i class="fas fa-balance-scale"></i></span><div class="label">Net recorded movement</div><div class="value <?= $netMovement>=0?'positive':'negative' ?>">UGX <?= bursar_reports_money($netMovement) ?></div><div class="small-muted">Receipts minus disbursements</div></div></div>
  <div class="col-sm-6 col-xl-3 mb-3"><div class="stat-card"><span class="symbol" style="background:#fff5df;color:#ac7813"><i class="fas fa-receipt"></i></span><div class="label">Transactions in period</div><div class="value"><?= number_format($periodRowCount) ?></div><div class="small-muted">Before list filters</div></div></div>
 </div>
 <section class="panel"><div class="panel-title"><i class="fas fa-layer-group text-primary mr-2"></i>Summary by finance module</div><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Module</th><th>Flow</th><th class="text-right">Records in period</th><th class="text-right">Settled records</th><th class="text-right">Amount (UGX)</th><th class="text-right">Not settled</th></tr></thead><tbody>
 <?php if (!$sourceSummary): ?><tr><td colspan="6" class="text-center text-muted py-4">No compatible financial transactions were found for the selected period.</td></tr><?php else: foreach ($sourceSummary as $name=>$summary): ?><tr><td><strong><?= bursar_reports_h($name) ?></strong><div class="small-muted"><?= bursar_reports_h($summary['table']) ?></div></td><td><?= $summary['direction']==='in'?'<span class="badge badge-success">Receipt</span>':'<span class="badge badge-danger">Payment</span>' ?></td><td class="text-right"><?= number_format($summary['records']) ?></td><td class="text-right"><?= number_format($summary['effective_records']) ?></td><td class="text-right font-weight-bold <?= $summary['direction']==='in'?'text-success':'text-danger' ?>"><?= bursar_reports_money($summary['amount']) ?></td><td class="text-right"><?= number_format($summary['pending']) ?></td></tr><?php endforeach; endif; ?>
 </tbody></table></div><div class="small text-muted mt-2">Totals are based on the transaction tables available in your database. If the same event is recorded in more than one module, it can be counted more than once in the combined figures. Reconcile any overlapping expense, supplier-payment or payroll entries before using these totals as final accounts.</div></section>
 <div class="row">
  <div class="col-lg-6"><section class="panel"><div class="panel-title"><i class="fas fa-chart-pie text-success mr-2"></i>Receipt categories</div><div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Category</th><th class="text-right">Records</th><th class="text-right">Amount (UGX)</th></tr></thead><tbody><?php if (!$categoriesIn): ?><tr><td colspan="3" class="text-center text-muted py-3">No settled receipts for this period.</td></tr><?php else: foreach ($categoriesIn as $cat): ?><tr><td class="category-name"><?= bursar_reports_h($cat['category']) ?></td><td class="text-right"><?= number_format($cat['count']) ?></td><td class="text-right font-weight-bold text-success"><?= bursar_reports_money($cat['amount']) ?></td></tr><?php endforeach; endif; ?></tbody></table></div></section></div>
  <div class="col-lg-6"><section class="panel"><div class="panel-title"><i class="fas fa-chart-pie text-danger mr-2"></i>Payment / expense categories</div><div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Category</th><th class="text-right">Records</th><th class="text-right">Amount (UGX)</th></tr></thead><tbody><?php if (!$categoriesOut): ?><tr><td colspan="3" class="text-center text-muted py-3">No settled payments for this period.</td></tr><?php else: foreach ($categoriesOut as $cat): ?><tr><td class="category-name"><?= bursar_reports_h($cat['category']) ?></td><td class="text-right"><?= number_format($cat['count']) ?></td><td class="text-right font-weight-bold text-danger"><?= bursar_reports_money($cat['amount']) ?></td></tr><?php endforeach; endif; ?></tbody></table></div></section></div>
 </div>
 <section class="panel"><div class="panel-title"><i class="fas fa-calendar-alt text-primary mr-2"></i>Monthly movement</div><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Month</th><th class="text-right">Records</th><th class="text-right">Receipts (UGX)</th><th class="text-right">Payments (UGX)</th><th class="text-right">Net movement (UGX)</th><th>Relative activity</th></tr></thead><tbody>
 <?php if (!$monthSummary): ?><tr><td colspan="6" class="text-center text-muted py-4">No settled transactions to summarize by month.</td></tr><?php else: $monthRows=array_reverse($monthSummary,true); $maxMonthly=1.0; foreach($monthRows as $mr) $maxMonthly=max($maxMonthly,$mr['in'],$mr['out']); foreach ($monthRows as $ym=>$m): $mNet=$m['in']-$m['out']; $barWidth=(int)round(max($m['in'],$m['out'])/$maxMonthly*100); ?><tr><td><strong><?= bursar_reports_h(date('F Y', strtotime($ym.'-01'))) ?></strong></td><td class="text-right"><?= number_format($m['records']) ?></td><td class="text-right text-success"><?= bursar_reports_money($m['in']) ?></td><td class="text-right text-danger"><?= bursar_reports_money($m['out']) ?></td><td class="text-right font-weight-bold <?= $mNet>=0?'text-success':'text-danger' ?>"><?= bursar_reports_money($mNet) ?></td><td><div class="mini-bar" title="Relative to largest monthly receipt/payment"><span style="width:<?= $barWidth ?>%"></span></div></td></tr><?php endforeach; endif; ?>
 </tbody></table></div></section>
 <section class="panel"><div class="d-flex justify-content-between align-items-center flex-wrap mb-3"><div><div class="panel-title mb-1"><i class="fas fa-list text-primary mr-2"></i>Transaction details</div><div class="small text-muted">Showing <?= number_format(count($displayRows)) ?> of <?= number_format($totalFiltered) ?> matching rows.</div></div><a class="btn btn-outline-success no-print mt-2" href="?<?= bursar_reports_h(http_build_query($exportQuery)) ?>"><i class="fas fa-file-csv mr-1"></i>Export filtered CSV</a></div>
 <div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Date</th><th>Transaction</th><th>Source / category</th><th>Student / staff / payee</th><th>Reference / details</th><th>Status</th><th class="text-right">Amount (UGX)</th></tr></thead><tbody>
 <?php if (!$displayRows): ?><tr><td colspan="7"><div class="empty-state"><i class="fas fa-file-invoice-dollar fa-2x d-block mb-2"></i><strong>No transactions match these filters</strong><div class="small mt-1">Try a wider date range or clear the search filters.</div></div></td></tr><?php else: foreach ($displayRows as $row): $good=$row['effective']; ?><tr><td><?= bursar_reports_h(date('d M Y', $row['date_ts'])) ?><div class="small-muted"><?= bursar_reports_h(date('H:i', $row['date_ts'])) ?></div></td><td><strong><?= bursar_reports_h($row['number']) ?></strong></td><td><?= bursar_reports_h($row['source']) ?><div class="small-muted"><?= bursar_reports_h($row['category']) ?></div></td><td class="detail-cell"><?= bursar_reports_h($row['person']!==''?$row['person']:'—') ?><?php if (!empty($row['student_identifiers'])): ?><div class="small-muted"><?= bursar_reports_h($row['student_identifiers']) ?></div><?php endif; ?></td><td class="detail-cell"><?= $row['reference']!==''?'<div>Ref: '.bursar_reports_h($row['reference']).'</div>':'' ?><?= $row['notes']!==''?'<div class="small-muted">'.bursar_reports_h($row['notes']).'</div>':'' ?><?= $row['reference']==='' && $row['notes']===''?'—':'' ?></td><td><span class="badge badge-<?= $good?'success':'secondary' ?>"><?= bursar_reports_h(ucwords(str_replace('_',' ',$row['status']))) ?></span></td><td class="text-right <?= $row['direction']==='in'?'amount-in':'amount-out' ?>"><?= $row['direction']==='in'?'+':'−' ?> <?= bursar_reports_money($row['amount']) ?><?php if (!$good): ?><div class="small-muted">Excluded from totals</div><?php endif; ?></td></tr><?php endforeach; endif; ?>
 </tbody></table></div>
 <?php if ($totalPages>1): $pq=$_GET; ?><nav class="no-print mt-3" aria-label="Transaction pages"><ul class="pagination flex-wrap mb-0"><?php $pq['page']=max(1,$page-1); ?><li class="page-item <?= $page<=1?'disabled':'' ?>"><a class="page-link" href="?<?= bursar_reports_h(http_build_query($pq)) ?>">Previous</a></li><?php for($p=max(1,$page-2);$p<=min($totalPages,$page+2);$p++):$pq['page']=$p; ?><li class="page-item <?= $p===$page?'active':'' ?>"><a class="page-link" href="?<?= bursar_reports_h(http_build_query($pq)) ?>"><?= $p ?></a></li><?php endfor; $pq['page']=min($totalPages,$page+1); ?><li class="page-item <?= $page>=$totalPages?'disabled':'' ?>"><a class="page-link" href="?<?= bursar_reports_h(http_build_query($pq)) ?>">Next</a></li></ul></nav><?php endif; ?>
 </section>
 <div class="footer-note">School Management System &mdash; Bursar Financial Reports</div>
</main>
<script>
(function(){var sidebar=document.getElementById('sidebar'),btn=document.getElementById('mobileMenuBtn');if(btn&&sidebar)btn.addEventListener('click',function(){sidebar.classList.toggle('show');});document.addEventListener('click',function(e){if(window.innerWidth<=991&&sidebar&&sidebar.classList.contains('show')&&!sidebar.contains(e.target)&&btn&&!btn.contains(e.target))sidebar.classList.remove('show');});})();
</script>
</body></html>
