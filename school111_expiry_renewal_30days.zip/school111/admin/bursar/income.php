<?php
/**
 * School Management System
 * Bursar - Income Management
 *
 * File:
 * /admin/bursar/income.php
 *
 * Tables:
 * income_categories
 * income_transactions
 * payment_methods
 * users
 *
 * IMPORTANT:
 * No output should appear before this point.
 */

ob_start();

require_once "../../config/database.php";
require_once "../../includes/auth.php";

/*
|--------------------------------------------------------------------------
| ROLE-BASED ACCESS
|--------------------------------------------------------------------------
*/
requireRole([
    'administrator',
    'assistant_administrator',
    'bursar'
]);

/*
|--------------------------------------------------------------------------
| SESSION USER
|--------------------------------------------------------------------------
*/
$received_by = isset($_SESSION['user_id']) ? (int) $_SESSION['user_id'] : 0;

if ($received_by <= 0) {
    header("Location: ../../login.php");
    exit;
}

/*
|--------------------------------------------------------------------------
| DATABASE CONNECTION
|--------------------------------------------------------------------------
|
| This supports common connection variable names.
|
*/
if (isset($conn) && $conn instanceof mysqli) {
    $db = $conn;
} elseif (isset($mysqli) && $mysqli instanceof mysqli) {
    $db = $mysqli;
} elseif (isset($connection) && $connection instanceof mysqli) {
    $db = $connection;
} else {
    http_response_code(500);
    exit("Database connection not found. Check config/database.php.");
}

// MySQLi throws clear exceptions instead of silently failing. The handler below
// ensures a database problem never becomes an unexplained blank page.
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
set_exception_handler(function (Throwable $exception) {
    error_log("Income page error: " . $exception->getMessage() . " in " . $exception->getFile() . ":" . $exception->getLine());
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: text/html; charset=UTF-8');
    }
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Income page error</title><style>body{font-family:Arial,sans-serif;background:#f4f6f9;padding:24px;color:#343a40}.box{max-width:900px;margin:30px auto;background:#fff;border-left:5px solid #dc3545;border-radius:8px;padding:24px;box-shadow:0 2px 10px #0001}code{overflow-wrap:anywhere}</style></head><body><div class="box"><h2>Income page could not load</h2><p>The page encountered a database or PHP error instead of displaying a blank screen.</p><p><strong>Error:</strong> <code>' . htmlspecialchars($exception->getMessage(), ENT_QUOTES, 'UTF-8') . '</code></p><p>Check the hosting PHP error log for the full technical details.</p><p><a href="income.php">Return to Income Management</a></p></div></body></html>';
});

/*
|--------------------------------------------------------------------------
| ENSURE INCOME TABLES AND REQUIRED COLUMNS
|--------------------------------------------------------------------------
| This creates the income tables when they are missing and adds expected
| columns when an older version of the income module uses an incomplete schema.
*/
$db->query("CREATE TABLE IF NOT EXISTS income_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL,
    description TEXT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_income_category_name (category_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$db->query("CREATE TABLE IF NOT EXISTS payment_methods (
    id INT AUTO_INCREMENT PRIMARY KEY,
    method_name VARCHAR(50) NOT NULL,
    description VARCHAR(255) NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_income_payment_method (method_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$db->query("CREATE TABLE IF NOT EXISTS income_transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transaction_no VARCHAR(50) NOT NULL,
    category_id INT NOT NULL,
    amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
    income_date DATETIME NOT NULL,
    payment_method_id INT NULL DEFAULT NULL,
    reference_no VARCHAR(100) NULL,
    description TEXT NULL,
    received_by INT NULL DEFAULT NULL,
    status ENUM('completed','cancelled','reversed') NOT NULL DEFAULT 'completed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_income_transaction_no (transaction_no),
    INDEX idx_income_date (income_date),
    INDEX idx_income_category (category_id),
    INDEX idx_income_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

function incomeEnsureColumn(mysqli $db, string $table, string $column, string $definition): void
{
    // These identifiers are hard-coded in this file, not user input.
    $found = false;
    $result = $db->query("SHOW COLUMNS FROM `{$table}` LIKE '" . $db->real_escape_string($column) . "'");
    if ($result) {
        $found = $result->num_rows > 0;
        $result->free();
    }
    if (!$found) {
        $db->query("ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}");
    }
}

// Bring incomplete tables from earlier versions up to the column layout used below.
incomeEnsureColumn($db, 'income_categories', 'category_name', "VARCHAR(100) NOT NULL DEFAULT 'Other'");
incomeEnsureColumn($db, 'income_categories', 'description', 'TEXT NULL');
incomeEnsureColumn($db, 'income_categories', 'status', "VARCHAR(20) NOT NULL DEFAULT 'active'");
incomeEnsureColumn($db, 'payment_methods', 'method_name', "VARCHAR(50) NOT NULL DEFAULT 'Cash'");
incomeEnsureColumn($db, 'income_transactions', 'transaction_no', 'VARCHAR(50) NULL');
incomeEnsureColumn($db, 'income_transactions', 'category_id', 'INT NOT NULL DEFAULT 0');
incomeEnsureColumn($db, 'income_transactions', 'amount', 'DECIMAL(14,2) NOT NULL DEFAULT 0.00');
incomeEnsureColumn($db, 'income_transactions', 'income_date', 'DATETIME NULL');
incomeEnsureColumn($db, 'income_transactions', 'payment_method_id', 'INT NULL DEFAULT NULL');
incomeEnsureColumn($db, 'income_transactions', 'reference_no', 'VARCHAR(100) NULL');
incomeEnsureColumn($db, 'income_transactions', 'description', 'TEXT NULL');
incomeEnsureColumn($db, 'income_transactions', 'received_by', 'INT NULL DEFAULT NULL');
incomeEnsureColumn($db, 'income_transactions', 'status', "VARCHAR(20) NOT NULL DEFAULT 'completed'");
incomeEnsureColumn($db, 'income_transactions', 'created_at', 'TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP');

// Seed sensible defaults without duplicating existing school categories/methods.
foreach (['School Fees', 'Donations', 'Grants', 'Fundraising', 'Sale of Items', 'Other Income'] as $defaultCategory) {
    $seed = $db->prepare("INSERT INTO income_categories (category_name, status) SELECT ?, 'active' WHERE NOT EXISTS (SELECT 1 FROM income_categories WHERE category_name = ?)");
    $seed->bind_param('ss', $defaultCategory, $defaultCategory);
    $seed->execute();
    $seed->close();
}
foreach (['Cash', 'Mobile Money', 'Bank', 'Cheque'] as $defaultMethod) {
    $seed = $db->prepare("INSERT INTO payment_methods (method_name) SELECT ? WHERE NOT EXISTS (SELECT 1 FROM payment_methods WHERE method_name = ?)");
    $seed->bind_param('ss', $defaultMethod, $defaultMethod);
    $seed->execute();
    $seed->close();
}

/*
|--------------------------------------------------------------------------
| HELPER FUNCTIONS
|--------------------------------------------------------------------------
*/

function clean($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function redirectWithMessage($message, $type = 'success')
{
    header(
        "Location: income.php?message=" .
        urlencode($message) .
        "&type=" .
        urlencode($type)
    );
    exit;
}

// mysqli_stmt::bind_param requires each parameter to be passed by reference.
function incomeBindParams(mysqli_stmt $stmt, string $types, array &$params): void
{
    if ($types === '' || count($params) === 0) {
        return;
    }
    $arguments = [$types];
    foreach ($params as $key => &$value) {
        $arguments[] = &$value;
    }
    unset($value);
    call_user_func_array([$stmt, 'bind_param'], $arguments);
}

/*
|--------------------------------------------------------------------------
| CSRF TOKEN
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['income_csrf_token'])) {
    $_SESSION['income_csrf_token'] = bin2hex(random_bytes(32));
}

$csrf_token = $_SESSION['income_csrf_token'];

/*
|--------------------------------------------------------------------------
| FORM DEFAULTS
|--------------------------------------------------------------------------
*/

$form_transaction_no = '';
$form_category_id = '';
$form_amount = '';
$form_income_date = date('Y-m-d\TH:i');
$form_payment_method_id = '';
$form_reference_no = '';
$form_description = '';

/*
|--------------------------------------------------------------------------
| EDIT MODE
|--------------------------------------------------------------------------
*/

$edit_id = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;

if ($edit_id > 0) {

    $stmt = $db->prepare("
        SELECT
            id,
            transaction_no,
            category_id,
            amount,
            income_date,
            payment_method_id,
            reference_no,
            description,
            status
        FROM income_transactions
        WHERE id = ?
        LIMIT 1
    ");

    if ($stmt) {

        $stmt->bind_param("i", $edit_id);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($result && $row = $result->fetch_assoc()) {

            $form_transaction_no = $row['transaction_no'];
            $form_category_id = $row['category_id'];
            $form_amount = $row['amount'];

            /*
             * datetime-local expects:
             * YYYY-MM-DDTHH:MM
             */
            $form_income_date = date(
                'Y-m-d\TH:i',
                strtotime($row['income_date'])
            );

            $form_payment_method_id = $row['payment_method_id'];
            $form_reference_no = $row['reference_no'];
            $form_description = $row['description'];

        } else {
            redirectWithMessage(
                "Income transaction was not found.",
                "danger"
            );
        }

        $stmt->close();

    } else {
        redirectWithMessage(
            "Unable to load income transaction.",
            "danger"
        );
    }
}

/*
|--------------------------------------------------------------------------
| HANDLE POST
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /*
    |--------------------------------------------------------------------------
    | CSRF CHECK
    |--------------------------------------------------------------------------
    */

    $posted_token = $_POST['csrf_token'] ?? '';

    if (
        empty($posted_token) ||
        !hash_equals($csrf_token, $posted_token)
    ) {
        redirectWithMessage(
            "Invalid security token. Please try again.",
            "danger"
        );
    }

    /*
    |--------------------------------------------------------------------------
    | ACTION
    |--------------------------------------------------------------------------
    */

    $action = $_POST['action'] ?? '';

    /*
    |--------------------------------------------------------------------------
    | ADD / UPDATE INCOME
    |--------------------------------------------------------------------------
    */

    if ($action === 'save_income') {

        $transaction_id = isset($_POST['transaction_id'])
            ? (int)$_POST['transaction_id']
            : 0;

        $category_id = isset($_POST['category_id'])
            ? (int)$_POST['category_id']
            : 0;

        $amount = isset($_POST['amount'])
            ? trim($_POST['amount'])
            : '';

        $income_date = isset($_POST['income_date'])
            ? trim($_POST['income_date'])
            : '';

        $payment_method_id = isset($_POST['payment_method_id'])
            ? (int)$_POST['payment_method_id']
            : 0;

        $reference_no = isset($_POST['reference_no'])
            ? trim($_POST['reference_no'])
            : '';

        $description = isset($_POST['description'])
            ? trim($_POST['description'])
            : '';

        /*
        |--------------------------------------------------------------------------
        | VALIDATION
        |--------------------------------------------------------------------------
        */

        $errors = [];

        if ($category_id <= 0) {
            $errors[] = "Please select an income category.";
        }

        if ($amount === '' || !is_numeric($amount)) {
            $errors[] = "Please enter a valid amount.";
        } elseif ((float)$amount <= 0) {
            $errors[] = "Amount must be greater than zero.";
        }

        if ($income_date === '') {
            $errors[] = "Please select the income date.";
        }

        /*
        |--------------------------------------------------------------------------
        | VALIDATE CATEGORY
        |--------------------------------------------------------------------------
        */

        if ($category_id > 0) {

            $stmt = $db->prepare("
                SELECT id
                FROM income_categories
                WHERE id = ?
                AND status = 'active'
                LIMIT 1
            ");

            if ($stmt) {

                $stmt->bind_param("i", $category_id);
                $stmt->execute();

                $result = $stmt->get_result();

                if (!$result || $result->num_rows === 0) {
                    $errors[] = "Selected income category is invalid.";
                }

                $stmt->close();
            }
        }

        /*
        |--------------------------------------------------------------------------
        | PAYMENT METHOD
        |--------------------------------------------------------------------------
        */

        if ($payment_method_id > 0) {

            $stmt = $db->prepare("
                SELECT id
                FROM payment_methods
                WHERE id = ?
                LIMIT 1
            ");

            if ($stmt) {

                $stmt->bind_param("i", $payment_method_id);
                $stmt->execute();

                $result = $stmt->get_result();

                if (!$result || $result->num_rows === 0) {
                    $errors[] = "Selected payment method is invalid.";
                }

                $stmt->close();
            }
        }

        /*
        |--------------------------------------------------------------------------
        | PROCESS ERRORS
        |--------------------------------------------------------------------------
        */

        if (!empty($errors)) {

            $_SESSION['income_form_error'] = implode(
                "<br>",
                array_map('clean', $errors)
            );

            $_SESSION['income_old'] = [
                'category_id' => $category_id,
                'amount' => $amount,
                'income_date' => $income_date,
                'payment_method_id' => $payment_method_id,
                'reference_no' => $reference_no,
                'description' => $description
            ];

            header("Location: income.php");
            exit;
        }

        /*
        |--------------------------------------------------------------------------
        | FORMAT DATE
        |--------------------------------------------------------------------------
        */

        $timestamp = strtotime($income_date);

        if ($timestamp === false) {
            redirectWithMessage(
                "Invalid income date.",
                "danger"
            );
        }

        $mysql_income_date = date(
            'Y-m-d H:i:s',
            $timestamp
        );

        $amount = number_format(
            (float)$amount,
            2,
            '.',
            ''
        );

        /*
        |--------------------------------------------------------------------------
        | UPDATE EXISTING TRANSACTION
        |--------------------------------------------------------------------------
        */

        if ($transaction_id > 0) {

            /*
             * Do not allow editing cancelled/reversed transactions.
             */

            $stmt = $db->prepare("
                SELECT status
                FROM income_transactions
                WHERE id = ?
                LIMIT 1
            ");

            if (!$stmt) {
                redirectWithMessage(
                    "Unable to verify transaction.",
                    "danger"
                );
            }

            $stmt->bind_param("i", $transaction_id);
            $stmt->execute();

            $result = $stmt->get_result();
            $existing = $result ? $result->fetch_assoc() : null;

            $stmt->close();

            if (!$existing) {
                redirectWithMessage(
                    "Transaction not found.",
                    "danger"
                );
            }

            if ($existing['status'] !== 'completed') {
                redirectWithMessage(
                    "Only completed transactions can be edited.",
                    "danger"
                );
            }

            $stmt = $db->prepare("
                UPDATE income_transactions
                SET
                    category_id = ?,
                    amount = ?,
                    income_date = ?,
                    payment_method_id = NULLIF(?, 0),
                    reference_no = NULLIF(?, ''),
                    description = ?
                WHERE id = ?
                AND status = 'completed'
                LIMIT 1
            ");

            if (!$stmt) {
                redirectWithMessage(
                    "Unable to prepare transaction update.",
                    "danger"
                );
            }

            $stmt->bind_param(
                "idsissi",
                $category_id,
                $amount,
                $mysql_income_date,
                $payment_method_id,
                $reference_no,
                $description,
                $transaction_id
            );

            if ($stmt->execute()) {

                $stmt->close();

                redirectWithMessage(
                    "Income transaction updated successfully."
                );

            } else {

                $error = $stmt->error;
                $stmt->close();

                redirectWithMessage(
                    "Unable to update income transaction: " . $error,
                    "danger"
                );
            }
        }

        /*
        |--------------------------------------------------------------------------
        | CREATE NEW TRANSACTION
        |--------------------------------------------------------------------------
        */

        $transaction_no = '';

        /*
         * Generate transaction number.
         *
         * Example:
         * INC-20261008-0001
         */

        $date_prefix = date('Ymd', $timestamp);

        $stmt = $db->prepare("
            SELECT transaction_no
            FROM income_transactions
            WHERE transaction_no LIKE ?
            ORDER BY id DESC
            LIMIT 1
        ");

        if (!$stmt) {
            redirectWithMessage(
                "Unable to generate transaction number.",
                "danger"
            );
        }

        $like_prefix = "INC-" . $date_prefix . "-%";

        $stmt->bind_param("s", $like_prefix);
        $stmt->execute();

        $result = $stmt->get_result();
        $last = $result ? $result->fetch_assoc() : null;

        $stmt->close();

        if ($last && !empty($last['transaction_no'])) {

            $parts = explode('-', $last['transaction_no']);

            $last_number = (int)end($parts);

            $next_number = $last_number + 1;

        } else {

            $next_number = 1;
        }

        $transaction_no = sprintf(
            "INC-%s-%04d",
            $date_prefix,
            $next_number
        );

        /*
        |--------------------------------------------------------------------------
        | INSERT
        |--------------------------------------------------------------------------
        */

        $stmt = $db->prepare("
            INSERT INTO income_transactions
            (
                transaction_no,
                category_id,
                amount,
                income_date,
                payment_method_id,
                reference_no,
                description,
                received_by,
                status
            )
            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                NULLIF(?, 0),
                NULLIF(?, ''),
                NULLIF(?, ''),
                ?,
                'completed'
            )
        ");

        if (!$stmt) {
            redirectWithMessage(
                "Unable to prepare income transaction.",
                "danger"
            );
        }

        $stmt->bind_param(
            "sidsissi",
            $transaction_no,
            $category_id,
            $amount,
            $mysql_income_date,
            $payment_method_id,
            $reference_no,
            $description,
            $received_by
        );

        if ($stmt->execute()) {

            $stmt->close();

            redirectWithMessage(
                "Income recorded successfully. Transaction: " .
                $transaction_no
            );

        } else {

            $error = $stmt->error;
            $stmt->close();

            redirectWithMessage(
                "Unable to save income: " . $error,
                "danger"
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | CANCEL TRANSACTION
    |--------------------------------------------------------------------------
    */

    elseif ($action === 'cancel_income') {

        $transaction_id = isset($_POST['transaction_id'])
            ? (int)$_POST['transaction_id']
            : 0;

        if ($transaction_id <= 0) {
            redirectWithMessage(
                "Invalid transaction.",
                "danger"
            );
        }

        $stmt = $db->prepare("
            UPDATE income_transactions
            SET status = 'cancelled'
            WHERE id = ?
            AND status = 'completed'
            LIMIT 1
        ");

        if (!$stmt) {
            redirectWithMessage(
                "Unable to cancel transaction.",
                "danger"
            );
        }

        $stmt->bind_param("i", $transaction_id);

        if ($stmt->execute() && $stmt->affected_rows > 0) {

            $stmt->close();

            redirectWithMessage(
                "Income transaction cancelled successfully."
            );

        } else {

            $stmt->close();

            redirectWithMessage(
                "Transaction could not be cancelled.",
                "danger"
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | REVERSE TRANSACTION
    |--------------------------------------------------------------------------
    */

    elseif ($action === 'reverse_income') {

        $transaction_id = isset($_POST['transaction_id'])
            ? (int)$_POST['transaction_id']
            : 0;

        if ($transaction_id <= 0) {
            redirectWithMessage(
                "Invalid transaction.",
                "danger"
            );
        }

        $stmt = $db->prepare("
            UPDATE income_transactions
            SET status = 'reversed'
            WHERE id = ?
            AND status = 'completed'
            LIMIT 1
        ");

        if (!$stmt) {
            redirectWithMessage(
                "Unable to reverse transaction.",
                "danger"
            );
        }

        $stmt->bind_param("i", $transaction_id);

        if ($stmt->execute() && $stmt->affected_rows > 0) {

            $stmt->close();

            redirectWithMessage(
                "Income transaction reversed successfully."
            );

        } else {

            $stmt->close();

            redirectWithMessage(
                "Transaction could not be reversed.",
                "danger"
            );
        }
    }
}

/*
|--------------------------------------------------------------------------
| LOAD OLD FORM DATA AFTER VALIDATION ERROR
|--------------------------------------------------------------------------
*/

if (isset($_SESSION['income_old'])) {

    $old = $_SESSION['income_old'];

    $form_category_id = $old['category_id'] ?? '';
    $form_amount = $old['amount'] ?? '';
    $form_income_date = $old['income_date'] ?? date('Y-m-d\TH:i');
    $form_payment_method_id = $old['payment_method_id'] ?? '';
    $form_reference_no = $old['reference_no'] ?? '';
    $form_description = $old['description'] ?? '';

    unset($_SESSION['income_old']);
}

$form_error = $_SESSION['income_form_error'] ?? '';
unset($_SESSION['income_form_error']);

/*
|--------------------------------------------------------------------------
| MESSAGE
|--------------------------------------------------------------------------
*/

$message = $_GET['message'] ?? '';
$message_type = $_GET['type'] ?? 'success';

$allowed_message_types = [
    'success',
    'danger',
    'warning',
    'info'
];

if (!in_array($message_type, $allowed_message_types, true)) {
    $message_type = 'info';
}

/*
|--------------------------------------------------------------------------
| INCOME CATEGORIES
|--------------------------------------------------------------------------
*/

$categories = [];

$result = $db->query("
    SELECT
        id,
        category_name,
        description
    FROM income_categories
    WHERE status = 'active'
    ORDER BY category_name ASC
");

if ($result) {

    while ($row = $result->fetch_assoc()) {
        $categories[] = $row;
    }

    $result->free();
}

/*
|--------------------------------------------------------------------------
| PAYMENT METHODS
|--------------------------------------------------------------------------
*/

$payment_methods = [];

$result = $db->query("
    SELECT
        id,
        method_name
    FROM payment_methods
    ORDER BY method_name ASC
");

if ($result) {

    while ($row = $result->fetch_assoc()) {
        $payment_methods[] = $row;
    }

    $result->free();
}

/*
|--------------------------------------------------------------------------
| FILTERS
|--------------------------------------------------------------------------
*/

$search = trim($_GET['search'] ?? '');
$filter_category = isset($_GET['category_id'])
    ? (int)$_GET['category_id']
    : 0;

$date_from = trim($_GET['date_from'] ?? '');
$date_to = trim($_GET['date_to'] ?? '');

foreach (['date_from', 'date_to'] as $dateFilterName) {
    $dateValue = ($dateFilterName === 'date_from') ? $date_from : $date_to;
    if ($dateValue !== '') {
        $parsedDate = DateTime::createFromFormat('!Y-m-d', $dateValue);
        if (!$parsedDate || $parsedDate->format('Y-m-d') !== $dateValue) {
            if ($dateFilterName === 'date_from') { $date_from = ''; }
            else { $date_to = ''; }
        }
    }
}

$filter_status = trim($_GET['status'] ?? 'completed');

/*
|--------------------------------------------------------------------------
| VALID STATUS
|--------------------------------------------------------------------------
*/

$statuses = [
    'completed',
    'cancelled',
    'reversed'
];

if (!in_array($filter_status, $statuses, true)) {
    $filter_status = '';
}

/*
|--------------------------------------------------------------------------
| BUILD FILTER QUERY
|--------------------------------------------------------------------------
*/

$where = [];
$params = [];
$types = '';

if ($search !== '') {

    $where[] = "
        (
            it.transaction_no LIKE ?
            OR it.reference_no LIKE ?
            OR it.description LIKE ?
            OR ic.category_name LIKE ?
            OR u.full_name LIKE ?
        )
    ";

    $search_like = '%' . $search . '%';

    $params[] = $search_like;
    $params[] = $search_like;
    $params[] = $search_like;
    $params[] = $search_like;
    $params[] = $search_like;

    $types .= 'sssss';
}

if ($filter_category > 0) {

    $where[] = "it.category_id = ?";

    $params[] = $filter_category;

    $types .= 'i';
}

if ($date_from !== '') {

    $where[] = "DATE(it.income_date) >= ?";

    $params[] = $date_from;

    $types .= 's';
}

if ($date_to !== '') {

    $where[] = "DATE(it.income_date) <= ?";

    $params[] = $date_to;

    $types .= 's';
}

if ($filter_status !== '') {

    $where[] = "it.status = ?";

    $params[] = $filter_status;

    $types .= 's';
}

$where_sql = '';

if (!empty($where)) {
    $where_sql = 'WHERE ' . implode(' AND ', $where);
}

/*
|--------------------------------------------------------------------------
| TOTAL INCOME
|--------------------------------------------------------------------------
*/

$total_income = 0;

$sql_total = "
    SELECT COALESCE(SUM(it.amount), 0) AS total
    FROM income_transactions it
    LEFT JOIN income_categories ic
        ON ic.id = it.category_id
    LEFT JOIN users u
        ON u.id = it.received_by
    $where_sql
";

$stmt = $db->prepare($sql_total);

if ($stmt) {

    if (!empty($params)) {
        incomeBindParams($stmt, $types, $params);
    }

    $stmt->execute();

    $result = $stmt->get_result();

    if ($result && $row = $result->fetch_assoc()) {
        $total_income = (float)$row['total'];
    }

    $stmt->close();
}

/*
|--------------------------------------------------------------------------
| TODAY'S INCOME
|--------------------------------------------------------------------------
*/

$today_income = 0;

$sql_today = "
    SELECT COALESCE(SUM(amount), 0) AS total
    FROM income_transactions
    WHERE status = 'completed'
    AND DATE(income_date) = CURDATE()
";

$result = $db->query($sql_today);

if ($result && $row = $result->fetch_assoc()) {
    $today_income = (float)$row['total'];
}

/*
|--------------------------------------------------------------------------
| THIS MONTH'S INCOME
|--------------------------------------------------------------------------
*/

$month_income = 0;

$sql_month = "
    SELECT COALESCE(SUM(amount), 0) AS total
    FROM income_transactions
    WHERE status = 'completed'
    AND YEAR(income_date) = YEAR(CURDATE())
    AND MONTH(income_date) = MONTH(CURDATE())
";

$result = $db->query($sql_month);

if ($result && $row = $result->fetch_assoc()) {
    $month_income = (float)$row['total'];
}

/*
|--------------------------------------------------------------------------
| TRANSACTION COUNT
|--------------------------------------------------------------------------
*/

$transaction_count = 0;

$sql_count = "
    SELECT COUNT(*) AS total
    FROM income_transactions it
    LEFT JOIN income_categories ic
        ON ic.id = it.category_id
    LEFT JOIN users u
        ON u.id = it.received_by
    $where_sql
";

$stmt = $db->prepare($sql_count);

if ($stmt) {

    if (!empty($params)) {
        incomeBindParams($stmt, $types, $params);
    }

    $stmt->execute();

    $result = $stmt->get_result();

    if ($result && $row = $result->fetch_assoc()) {
        $transaction_count = (int)$row['total'];
    }

    $stmt->close();
}

/*
|--------------------------------------------------------------------------
| LOAD TRANSACTIONS
|--------------------------------------------------------------------------
*/

$transactions = [];

$sql_transactions = "
    SELECT
        it.id,
        it.transaction_no,
        it.category_id,
        it.amount,
        it.income_date,
        it.payment_method_id,
        it.reference_no,
        it.description,
        it.received_by,
        it.status,
        it.created_at,

        ic.category_name,

        pm.method_name AS payment_method,

        u.full_name AS received_by_name

    FROM income_transactions it

    LEFT JOIN income_categories ic
        ON ic.id = it.category_id

    LEFT JOIN payment_methods pm
        ON pm.id = it.payment_method_id

    LEFT JOIN users u
        ON u.id = it.received_by

    $where_sql

    ORDER BY it.income_date DESC, it.id DESC

    LIMIT 500
";

$stmt = $db->prepare($sql_transactions);

if ($stmt) {

    if (!empty($params)) {
        incomeBindParams($stmt, $types, $params);
    }

    $stmt->execute();

    $result = $stmt->get_result();

    if ($result) {

        while ($row = $result->fetch_assoc()) {
            $transactions[] = $row;
        }
    }

    $stmt->close();
}

/*
|--------------------------------------------------------------------------
| PAGE VARIABLES
|--------------------------------------------------------------------------
*/

$is_editing = $edit_id > 0 && $form_transaction_no !== '';

$full_name = $_SESSION['full_name'] ?? 'User';
$user_role = $_SESSION['role'] ?? '';

?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Income Management | School Management System
    </title>

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
    >

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
    >

    <style>

        body {
            background: #f4f6f9;
            font-family: Arial, sans-serif;
        }

        /*
        |--------------------------------------------------------------------------
        | SIDEBAR
        |--------------------------------------------------------------------------
        */

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            width: 250px;
            background: #212529;
            color: #fff;
            z-index: 1050;
            overflow-y: auto;
            transition: left .25s ease;
        }

        .sidebar-header {
            padding: 20px 15px;
            color: #fff;
            font-weight: 700;
            border-bottom: 1px solid rgba(255,255,255,.1);
            font-size: 18px;
        }

        .sidebar-menu {
            padding: 15px 10px;
        }

        .sidebar-section {
            color: #6c757d;
            font-size: 11px;
            text-transform: uppercase;
            padding: 12px 10px 6px;
            letter-spacing: 1px;
        }

        .sidebar a {
            display: block;
            color: #ced4da;
            padding: 12px 15px;
            margin-bottom: 3px;
            text-decoration: none;
            border-radius: 6px;
            font-size: 14px;
            transition: background .2s ease, color .2s ease;
        }

        .sidebar a:hover {
            background: #343a40;
            color: #fff;
        }

        .sidebar a.active {
            background: #dc3545;
            color: #fff;
        }

        .sidebar i {
            width: 25px;
            text-align: center;
            margin-right: 5px;
        }

        /*
        |--------------------------------------------------------------------------
        | MAIN
        |--------------------------------------------------------------------------
        */

        .main-content {
            margin-left: 250px;
            padding: 25px;
            transition: all 0.3s ease;
        }

        .topbar {
            background: white;
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,.06);
        }

        /*
        |--------------------------------------------------------------------------
        | CARDS
        |--------------------------------------------------------------------------
        */

        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,.05);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 21px;
            background: #e9f5ff;
            color: #007bff;
        }

        .stat-title {
            font-size: 13px;
            color: #6c757d;
            margin-bottom: 4px;
        }

        .stat-value {
            font-size: 24px;
            font-weight: 700;
        }

        /*
        |--------------------------------------------------------------------------
        | CONTENT CARD
        |--------------------------------------------------------------------------
        */

        .content-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,.05);
            margin-bottom: 25px;
        }

        .content-card-header {
            padding: 18px 20px;
            border-bottom: 1px solid #eee;
        }

        .content-card-body {
            padding: 20px;
        }

        /*
        |--------------------------------------------------------------------------
        | TABLE
        |--------------------------------------------------------------------------
        */

        .table thead th {
            background: #f8f9fa;
            border-top: none;
            font-size: 13px;
            white-space: nowrap;
        }

        .table td {
            vertical-align: middle;
            font-size: 14px;
        }

        .transaction-number {
            font-weight: 600;
            color: #007bff;
        }

        .amount {
            font-weight: 700;
        }

        /*
        |--------------------------------------------------------------------------
        | MOBILE
        |--------------------------------------------------------------------------
        */

        .mobile-menu {
            display: none;
            margin-right: 10px;
        }

        @media (max-width: 991px) {

            .sidebar {
                left: -250px;
                width: 250px;
            }

            .sidebar.show {
                left: 0;
            }

            .main-content {
                margin-left: 0;
                padding: 15px;
            }

            .mobile-menu {
                display: inline-block;
            }
        }

        /*
        |--------------------------------------------------------------------------
        | OVERLAY
        |--------------------------------------------------------------------------
        */

        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,.45);
            z-index: 1040;
        }

        .sidebar-overlay.show {
            display: block;
        }

        /*
        |--------------------------------------------------------------------------
        | PRINT
        |--------------------------------------------------------------------------
        */

        @media print {

            .sidebar,
            .topbar,
            .no-print,
            .sidebar-overlay {
                display: none !important;
            }

            .main-content {
                margin-left: 0 !important;
                padding: 0 !important;
            }

            body {
                background: white;
            }
        }

    </style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>

<body>

<!-- ============================================================
     SIDEBAR
============================================================= -->
<aside class="sidebar" id="sidebar">
    <div class="sidebar-header"><i class="fas fa-university"></i> <span>Bursar</span></div>
    <nav class="sidebar-menu">
        <a href="/admin/bursar/index.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
        <div class="sidebar-section">Students &amp; Fees</div>
        <a href="/admin/bursar/students_fees.php"><i class="fas fa-file-invoice-dollar"></i>Student Fees</a>
        <a href="/admin/bursar/students_fee_accounts.php"><i class="fas fa-file-invoice-dollar"></i>Student Fee Accounts</a>
        <a href="/admin/bursar/fee_structure.php"><i class="fas fa-list-alt"></i>Fee Structure</a>
        <a href="/admin/bursar/payments.php"><i class="fas fa-money-bill-wave"></i>Receive Payment</a>
        <a href="/admin/bursar/outstanding_fees.php"><i class="fas fa-exclamation-circle"></i>Outstanding Fees</a>
        <div class="sidebar-section">Finance</div>
        <a href="/admin/bursar/income.php" class="active"><i class="fas fa-arrow-circle-down"></i>Income</a>
        <a href="/admin/bursar/expenses.php"><i class="fas fa-arrow-circle-up"></i>Expenses</a>
        <a href="/admin/bursar/suppliers.php"><i class="fas fa-truck"></i>Suppliers</a>
        <a href="/admin/bursar/supplier_payments.php"><i class="fas fa-hand-holding-usd"></i>Supplier Payments</a>
        <div class="sidebar-section">Payroll &amp; Budget</div>
        <a href="/admin/bursar/salaries.php"><i class="fas fa-users"></i>Salaries</a>
        <a href="/admin/bursar/salary_payments.php"><i class="fas fa-money-check-alt"></i>Salary Payments</a>
        <a href="/admin/bursar/budgets.php"><i class="fas fa-chart-pie"></i>Budgets</a>
        <div class="sidebar-section">Reports</div>
        <a href="/admin/bursar/cashbook.php"><i class="fas fa-book"></i>Cashbook</a>
        <a href="/admin/bursar/financial_reports.php"><i class="fas fa-chart-line"></i>Financial Reports</a>
        <a href="/admin/bursar/income_report.php"><i class="fas fa-file-invoice"></i>Income Report</a>
        <a href="/admin/bursar/expense_report.php"><i class="fas fa-receipt"></i>Expense Report</a>
        <a href="/admin/bursar/fees_report.php"><i class="fas fa-file-alt"></i>Fees Report</a>
        <a href="/admin/bursar/profit_loss.php"><i class="fas fa-balance-scale"></i>Profit &amp; Loss</a>
        <div class="sidebar-section">System</div>
        <a href="/admin/dashboard.php"><i class="fas fa-user-shield"></i>Admin Dashboard</a>
        <a href="/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
    </nav>
</aside>

<div
    class="sidebar-overlay"
    id="sidebarOverlay"
></div>


<!-- ============================================================
     MAIN CONTENT
============================================================= -->

<div class="main-content">

    <!-- TOP BAR -->

    <div class="topbar d-flex align-items-center justify-content-between">

        <div>

            <button
                type="button"
                class="btn btn-outline-primary mobile-menu"
                id="mobileMenuButton"
            >
                <i class="fas fa-bars"></i>
            </button>

            <strong>
                Income Management
            </strong>

        </div>

        <div class="text-right">

            <div>
                <strong>
                    <?php echo clean($full_name); ?>
                </strong>
            </div>

            <small class="text-muted">
                <?php echo clean(ucwords(str_replace('_', ' ', $user_role))); ?>
            </small>

        </div>

    </div>


    <!-- PAGE HEADER -->

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

        <div>

            <h3 class="mb-1">
                <i class="fas fa-arrow-circle-down text-success"></i>
                School Income
            </h3>

            <p class="text-muted mb-0">
                Record and manage money received by the school.
            </p>

        </div>

        <div class="mt-2 mt-md-0">

            <button
                class="btn btn-success"
                data-toggle="collapse"
                data-target="#incomeForm"
            >

                <i class="fas fa-plus"></i>

                <?php echo $is_editing ? 'Edit Income' : 'Add Income'; ?>

            </button>

            <button
                type="button"
                class="btn btn-secondary"
                onclick="window.print()"
            >

                <i class="fas fa-print"></i>
                Print

            </button>

        </div>

    </div>


    <!-- ========================================================
         MESSAGES
    ========================================================= -->

    <?php if ($message !== ''): ?>

        <div class="alert alert-<?php echo clean($message_type); ?> alert-dismissible fade show">

            <?php echo clean($message); ?>

            <button
                type="button"
                class="close"
                data-dismiss="alert"
            >
                <span>&times;</span>
            </button>

        </div>

    <?php endif; ?>


    <?php if ($form_error !== ''): ?>

        <div class="alert alert-danger alert-dismissible fade show">

            <strong>
                Please correct the following:
            </strong>

            <br>

            <?php echo $form_error; ?>

            <button
                type="button"
                class="close"
                data-dismiss="alert"
            >
                <span>&times;</span>
            </button>

        </div>

    <?php endif; ?>


    <!-- ========================================================
         STATISTICS
    ========================================================= -->

    <div class="row">

        <div class="col-md-6 col-xl-3">

            <div class="stat-card">

                <div class="d-flex align-items-center">

                    <div class="stat-icon mr-3">
                        <i class="fas fa-money-bill-wave"></i>
                    </div>

                    <div>

                        <div class="stat-title">
                            Filtered Income
                        </div>

                        <div class="stat-value">
                            <?php echo number_format($total_income, 2); ?>
                        </div>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-6 col-xl-3">

            <div class="stat-card">

                <div class="d-flex align-items-center">

                    <div class="stat-icon mr-3">
                        <i class="fas fa-calendar-day"></i>
                    </div>

                    <div>

                        <div class="stat-title">
                            Today's Income
                        </div>

                        <div class="stat-value">
                            <?php echo number_format($today_income, 2); ?>
                        </div>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-6 col-xl-3">

            <div class="stat-card">

                <div class="d-flex align-items-center">

                    <div class="stat-icon mr-3">
                        <i class="fas fa-calendar-alt"></i>
                    </div>

                    <div>

                        <div class="stat-title">
                            This Month
                        </div>

                        <div class="stat-value">
                            <?php echo number_format($month_income, 2); ?>
                        </div>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-6 col-xl-3">

            <div class="stat-card">

                <div class="d-flex align-items-center">

                    <div class="stat-icon mr-3">
                        <i class="fas fa-receipt"></i>
                    </div>

                    <div>

                        <div class="stat-title">
                            Transactions
                        </div>

                        <div class="stat-value">
                            <?php echo number_format($transaction_count); ?>
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- ========================================================
         INCOME FORM
    ========================================================= -->

    <div
        class="content-card collapse <?php echo $is_editing ? 'show' : ''; ?>"
        id="incomeForm"
    >

        <div class="content-card-header">

            <h5 class="mb-0">

                <?php if ($is_editing): ?>

                    <i class="fas fa-edit text-primary"></i>
                    Edit Income Transaction

                <?php else: ?>

                    <i class="fas fa-plus-circle text-success"></i>
                    Record New Income

                <?php endif; ?>

            </h5>

        </div>


        <div class="content-card-body">

            <form
                method="POST"
                action="income.php"
            >

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?php echo clean($csrf_token); ?>"
                >

                <input
                    type="hidden"
                    name="action"
                    value="save_income"
                >

                <?php if ($is_editing): ?>

                    <input
                        type="hidden"
                        name="transaction_id"
                        value="<?php echo (int)$edit_id; ?>"
                    >

                <?php endif; ?>


                <div class="row">

                    <!-- TRANSACTION NUMBER -->

                    <div class="col-md-6 col-lg-3">

                        <div class="form-group">

                            <label>
                                Transaction No.
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                value="<?php
                                    echo $is_editing
                                        ? clean($form_transaction_no)
                                        : 'Automatically generated';
                                ?>"
                                readonly
                            >

                            <small class="text-muted">
                                Automatically generated when saved.
                            </small>

                        </div>

                    </div>


                    <!-- CATEGORY -->

                    <div class="col-md-6 col-lg-3">

                        <div class="form-group">

                            <label>
                                Income Category
                                <span class="text-danger">*</span>
                            </label>

                            <select
                                name="category_id"
                                class="form-control"
                                required
                            >

                                <option value="">
                                    -- Select Category --
                                </option>

                                <?php foreach ($categories as $category): ?>

                                    <option
                                        value="<?php echo (int)$category['id']; ?>"
                                        <?php
                                        echo (
                                            (int)$form_category_id ===
                                            (int)$category['id']
                                        )
                                        ? 'selected'
                                        : '';
                                        ?>
                                    >

                                        <?php
                                        echo clean(
                                            $category['category_name']
                                        );
                                        ?>

                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                    </div>


                    <!-- AMOUNT -->

                    <div class="col-md-6 col-lg-3">

                        <div class="form-group">

                            <label>
                                Amount
                                <span class="text-danger">*</span>
                            </label>

                            <input
                                type="number"
                                name="amount"
                                class="form-control"
                                min="0.01"
                                step="0.01"
                                placeholder="0.00"
                                value="<?php echo clean($form_amount); ?>"
                                required
                            >

                        </div>

                    </div>


                    <!-- DATE -->

                    <div class="col-md-6 col-lg-3">

                        <div class="form-group">

                            <label>
                                Income Date
                                <span class="text-danger">*</span>
                            </label>

                            <input
                                type="datetime-local"
                                name="income_date"
                                class="form-control"
                                value="<?php echo clean($form_income_date); ?>"
                                required
                            >

                        </div>

                    </div>


                    <!-- PAYMENT METHOD -->

                    <div class="col-md-6 col-lg-4">

                        <div class="form-group">

                            <label>
                                Payment Method
                            </label>

                            <select
                                name="payment_method_id"
                                class="form-control"
                            >

                                <option value="">
                                    -- Select Payment Method --
                                </option>

                                <?php foreach ($payment_methods as $method): ?>

                                    <option
                                        value="<?php echo (int)$method['id']; ?>"
                                        <?php
                                        echo (
                                            (int)$form_payment_method_id ===
                                            (int)$method['id']
                                        )
                                        ? 'selected'
                                        : '';
                                        ?>
                                    >

                                        <?php
                                        echo clean(
                                            $method['method_name']
                                        );
                                        ?>

                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                    </div>


                    <!-- REFERENCE -->

                    <div class="col-md-6 col-lg-4">

                        <div class="form-group">

                            <label>
                                Reference No.
                            </label>

                            <input
                                type="text"
                                name="reference_no"
                                class="form-control"
                                maxlength="100"
                                placeholder="Receipt / bank / mobile money reference"
                                value="<?php echo clean($form_reference_no); ?>"
                            >

                        </div>

                    </div>


                    <!-- RECEIVED BY -->

                    <div class="col-md-6 col-lg-4">

                        <div class="form-group">

                            <label>
                                Received By
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                value="<?php echo clean($full_name); ?>"
                                readonly
                            >

                            <small class="text-muted">
                                Current logged-in user.
                            </small>

                        </div>

                    </div>


                    <!-- DESCRIPTION -->

                    <div class="col-12">

                        <div class="form-group">

                            <label>
                                Description
                            </label>

                            <textarea
                                name="description"
                                class="form-control"
                                rows="3"
                                maxlength="1000"
                                placeholder="Enter additional information about this income..."
                            ><?php echo clean($form_description); ?></textarea>

                        </div>

                    </div>

                </div>


                <div class="d-flex justify-content-end">

                    <?php if ($is_editing): ?>

                        <a
                            href="income.php"
                            class="btn btn-secondary mr-2"
                        >
                            Cancel
                        </a>

                        <button
                            type="submit"
                            class="btn btn-primary"
                        >

                            <i class="fas fa-save"></i>
                            Update Income

                        </button>

                    <?php else: ?>

                        <button
                            type="reset"
                            class="btn btn-light mr-2"
                        >

                            <i class="fas fa-undo"></i>
                            Reset

                        </button>

                        <button
                            type="submit"
                            class="btn btn-success"
                        >

                            <i class="fas fa-save"></i>
                            Save Income

                        </button>

                    <?php endif; ?>

                </div>

            </form>

        </div>

    </div>


    <!-- ========================================================
         FILTERS
    ========================================================= -->

    <div class="content-card no-print">

        <div class="content-card-header">

            <h5 class="mb-0">

                <i class="fas fa-filter"></i>
                Search & Filter Income

            </h5>

        </div>


        <div class="content-card-body">

            <form
                method="GET"
                action="income.php"
            >

                <div class="row">

                    <!-- SEARCH -->

                    <div class="col-md-6 col-lg-3">

                        <div class="form-group">

                            <label>
                                Search
                            </label>

                            <input
                                type="text"
                                name="search"
                                class="form-control"
                                placeholder="Transaction, reference, category..."
                                value="<?php echo clean($search); ?>"
                            >

                        </div>

                    </div>


                    <!-- CATEGORY -->

                    <div class="col-md-6 col-lg-3">

                        <div class="form-group">

                            <label>
                                Category
                            </label>

                            <select
                                name="category_id"
                                class="form-control"
                            >

                                <option value="">
                                    All Categories
                                </option>

                                <?php foreach ($categories as $category): ?>

                                    <option
                                        value="<?php echo (int)$category['id']; ?>"
                                        <?php
                                        echo (
                                            $filter_category ===
                                            (int)$category['id']
                                        )
                                        ? 'selected'
                                        : '';
                                        ?>
                                    >

                                        <?php
                                        echo clean(
                                            $category['category_name']
                                        );
                                        ?>

                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                    </div>


                    <!-- DATE FROM -->

                    <div class="col-md-6 col-lg-2">

                        <div class="form-group">

                            <label>
                                Date From
                            </label>

                            <input
                                type="date"
                                name="date_from"
                                class="form-control"
                                value="<?php echo clean($date_from); ?>"
                            >

                        </div>

                    </div>


                    <!-- DATE TO -->

                    <div class="col-md-6 col-lg-2">

                        <div class="form-group">

                            <label>
                                Date To
                            </label>

                            <input
                                type="date"
                                name="date_to"
                                class="form-control"
                                value="<?php echo clean($date_to); ?>"
                            >

                        </div>

                    </div>


                    <!-- STATUS -->

                    <div class="col-md-6 col-lg-2">

                        <div class="form-group">

                            <label>
                                Status
                            </label>

                            <select
                                name="status"
                                class="form-control"
                            >

                                <option
                                    value=""
                                    <?php echo $filter_status === ''
                                        ? 'selected'
                                        : ''; ?>
                                >
                                    All Statuses
                                </option>

                                <option
                                    value="completed"
                                    <?php echo $filter_status === 'completed'
                                        ? 'selected'
                                        : ''; ?>
                                >
                                    Completed
                                </option>

                                <option
                                    value="cancelled"
                                    <?php echo $filter_status === 'cancelled'
                                        ? 'selected'
                                        : ''; ?>
                                >
                                    Cancelled
                                </option>

                                <option
                                    value="reversed"
                                    <?php echo $filter_status === 'reversed'
                                        ? 'selected'
                                        : ''; ?>
                                >
                                    Reversed
                                </option>

                            </select>

                        </div>

                    </div>

                </div>


                <div>

                    <button
                        type="submit"
                        class="btn btn-primary"
                    >

                        <i class="fas fa-search"></i>
                        Search

                    </button>

                    <a
                        href="income.php"
                        class="btn btn-light"
                    >

                        <i class="fas fa-sync"></i>
                        Clear Filters

                    </a>

                </div>

            </form>

        </div>

    </div>


    <!-- ========================================================
         TRANSACTIONS TABLE
    ========================================================= -->

    <div class="content-card">

        <div class="content-card-header d-flex justify-content-between align-items-center">

            <h5 class="mb-0">

                <i class="fas fa-list"></i>
                Income Transactions

            </h5>

            <span class="badge badge-primary">

                <?php echo number_format($transaction_count); ?>
                Records

            </span>

        </div>


        <div class="table-responsive">

            <table class="table table-hover table-bordered mb-0">

                <thead>

                    <tr>

                        <th>
                            #
                        </th>

                        <th>
                            Transaction No.
                        </th>

                        <th>
                            Category
                        </th>

                        <th>
                            Amount
                        </th>

                        <th>
                            Date
                        </th>

                        <th>
                            Payment
                        </th>

                        <th>
                            Reference
                        </th>

                        <th>
                            Received By
                        </th>

                        <th>
                            Status
                        </th>

                        <th class="no-print">
                            Actions
                        </th>

                    </tr>

                </thead>

                <tbody>

                    <?php if (empty($transactions)): ?>

                        <tr>

                            <td
                                colspan="10"
                                class="text-center py-5"
                            >

                                <i
                                    class="fas fa-receipt fa-3x text-muted mb-3"
                                ></i>

                                <h5>
                                    No income transactions found
                                </h5>

                                <p class="text-muted mb-0">
                                    Try changing your filters or record a new income transaction.
                                </p>

                            </td>

                        </tr>

                    <?php else: ?>

                        <?php foreach ($transactions as $index => $transaction): ?>

                            <tr>

                                <td>
                                    <?php echo $index + 1; ?>
                                </td>


                                <td>

                                    <span class="transaction-number">

                                        <?php
                                        echo clean(
                                            $transaction['transaction_no']
                                        );
                                        ?>

                                    </span>

                                </td>


                                <td>

                                    <strong>

                                        <?php
                                        echo clean(
                                            $transaction['category_name']
                                                ?: 'Unknown Category'
                                        );
                                        ?>

                                    </strong>

                                    <?php if (!empty($transaction['description'])): ?>

                                        <br>

                                        <small class="text-muted">

                                            <?php
                                            echo clean(
                                                (function_exists('mb_strimwidth')
                                                    ? mb_strimwidth($transaction['description'], 0, 70, '...')
                                                    : (strlen($transaction['description']) > 70 ? substr($transaction['description'], 0, 67) . '...' : $transaction['description'])
                                                )
                                            );
                                            ?>

                                        </small>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    <span class="amount">

                                        <?php
                                        echo number_format(
                                            (float)$transaction['amount'],
                                            2
                                        );
                                        ?>

                                    </span>

                                </td>


                                <td>

                                    <?php
                                    echo date(
                                        'd M Y',
                                        strtotime(
                                            $transaction['income_date']
                                        )
                                    );
                                    ?>

                                    <br>

                                    <small class="text-muted">

                                        <?php
                                        echo date(
                                            'H:i',
                                            strtotime(
                                                $transaction['income_date']
                                            )
                                        );
                                        ?>

                                    </small>

                                </td>


                                <td>

                                    <?php
                                    echo clean(
                                        $transaction['payment_method']
                                            ?: 'Not specified'
                                    );
                                    ?>

                                </td>


                                <td>

                                    <?php if (!empty($transaction['reference_no'])): ?>

                                        <?php
                                        echo clean(
                                            $transaction['reference_no']
                                        );
                                        ?>

                                    <?php else: ?>

                                        <span class="text-muted">
                                            —
                                        </span>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    <?php
                                    echo clean(
                                        $transaction['received_by_name']
                                            ?: 'Unknown'
                                    );
                                    ?>

                                </td>


                                <td>

                                    <?php if ($transaction['status'] === 'completed'): ?>

                                        <span class="badge badge-success">
                                            Completed
                                        </span>

                                    <?php elseif ($transaction['status'] === 'cancelled'): ?>

                                        <span class="badge badge-danger">
                                            Cancelled
                                        </span>

                                    <?php elseif ($transaction['status'] === 'reversed'): ?>

                                        <span class="badge badge-warning">
                                            Reversed
                                        </span>

                                    <?php endif; ?>

                                </td>


                                <!-- ACTIONS -->

                                <td class="no-print">

                                    <div class="btn-group">

                                        <?php if ($transaction['status'] === 'completed'): ?>

                                            <a
                                                href="income.php?edit=<?php echo (int)$transaction['id']; ?>"
                                                class="btn btn-sm btn-outline-primary"
                                                title="Edit"
                                            >

                                                <i class="fas fa-edit"></i>

                                            </a>


                                            <button
                                                type="button"
                                                class="btn btn-sm btn-outline-warning"
                                                title="Reverse"
                                                onclick="reverseIncome(
                                                    <?php echo (int)$transaction['id']; ?>,
                                                    '<?php echo clean($transaction['transaction_no']); ?>'
                                                )"
                                            >

                                                <i class="fas fa-undo"></i>

                                            </button>


                                            <button
                                                type="button"
                                                class="btn btn-sm btn-outline-danger"
                                                title="Cancel"
                                                onclick="cancelIncome(
                                                    <?php echo (int)$transaction['id']; ?>,
                                                    '<?php echo clean($transaction['transaction_no']); ?>'
                                                )"
                                            >

                                                <i class="fas fa-times"></i>

                                            </button>

                                        <?php else: ?>

                                            <span class="text-muted">
                                                No actions
                                            </span>

                                        <?php endif; ?>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                </tbody>

                <?php if (!empty($transactions)): ?>

                    <tfoot>

                        <tr class="font-weight-bold">

                            <td
                                colspan="3"
                                class="text-right"
                            >

                                TOTAL:

                            </td>

                            <td>

                                <?php
                                echo number_format(
                                    $total_income,
                                    2
                                );
                                ?>

                            </td>

                            <td colspan="6"></td>

                        </tr>

                    </tfoot>

                <?php endif; ?>

            </table>

        </div>

    </div>


    <!-- ========================================================
         FOOTER
    ========================================================= -->

    <div class="text-center text-muted small py-3">

        School Management System &copy;
        <?php echo date('Y'); ?>

        <br>

        Income Management

    </div>

</div>


<!-- ============================================================
     HIDDEN FORM FOR CANCEL / REVERSE
============================================================= -->

<form
    method="POST"
    action="income.php"
    id="transactionActionForm"
    style="display:none;"
>

    <input
        type="hidden"
        name="csrf_token"
        value="<?php echo clean($csrf_token); ?>"
    >

    <input
        type="hidden"
        name="action"
        id="transactionAction"
    >

    <input
        type="hidden"
        name="transaction_id"
        id="transactionId"
    >

</form>


<!-- ============================================================
     JAVASCRIPT
============================================================= -->

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

<script>

    /*
    |--------------------------------------------------------------------------
    | MOBILE SIDEBAR
    |--------------------------------------------------------------------------
    */

    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');
    const mobileMenuButton = document.getElementById('mobileMenuButton');

    if (mobileMenuButton) {

        mobileMenuButton.addEventListener('click', function () {

            sidebar.classList.toggle('show');
            sidebarOverlay.classList.toggle('show');

        });

    }

    if (sidebarOverlay) {

        sidebarOverlay.addEventListener('click', function () {

            sidebar.classList.remove('show');
            sidebarOverlay.classList.remove('show');

        });

    }


    /*
    |--------------------------------------------------------------------------
    | CANCEL INCOME
    |--------------------------------------------------------------------------
    */

    function cancelIncome(id, transactionNo) {

        const confirmed = confirm(
            "Are you sure you want to CANCEL income transaction " +
            transactionNo +
            "?\n\n" +
            "This will mark the transaction as cancelled."
        );

        if (!confirmed) {
            return;
        }

        document.getElementById('transactionAction').value =
            'cancel_income';

        document.getElementById('transactionId').value =
            id;

        document.getElementById('transactionActionForm').submit();

    }


    /*
    |--------------------------------------------------------------------------
    | REVERSE INCOME
    |--------------------------------------------------------------------------
    */

    function reverseIncome(id, transactionNo) {

        const confirmed = confirm(
            "Are you sure you want to REVERSE income transaction " +
            transactionNo +
            "?\n\n" +
            "This should only be used when the original income needs to be reversed."
        );

        if (!confirmed) {
            return;
        }

        document.getElementById('transactionAction').value =
            'reverse_income';

        document.getElementById('transactionId').value =
            id;

        document.getElementById('transactionActionForm').submit();

    }

</script>

</body>
</html>

<?php
ob_end_flush();
?>
