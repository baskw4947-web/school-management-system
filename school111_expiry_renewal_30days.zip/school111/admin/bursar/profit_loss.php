<?php
/**
 * School Management System - Bursar Profit & Loss Report
 * Location: /admin/bursar/profit_loss.php
 * Reads completed transactions from income_transactions, fee_payments (optional),
 * and expense_transactions. It does not modify the database.
 */
ob_start();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

set_exception_handler(function (Throwable $ex): void {
    error_log('Profit & Loss page error: ' . $ex->getMessage() . ' in ' . $ex->getFile() . ':' . $ex->getLine());
    if (!headers_sent()) http_response_code(500);
    while (ob_get_level() > 0) { @ob_end_clean(); }
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Profit &amp; Loss Error</title><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"></head><body class="bg-light"><main class="container py-5"><div class="alert alert-danger"><h4>Profit &amp; Loss report could not load</h4><p class="mb-0">A database or PHP error occurred. Technical details have been written to the hosting PHP error log. Check that the income, fee-payment and expense table structures match the working finance pages.</p></div><a class="btn btn-primary" href="profit_loss.php">Reload report</a></main></body></html>';
    exit;
});

require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator', 'bursar']);

$db = $conn ?? ($mysqli ?? ($connection ?? null));
if (!$db instanceof mysqli) {
    throw new RuntimeException('Database connection not found. Check config/database.php.');
}
$db->set_charset('utf8mb4');

function pl_h($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}
function pl_money($value): string {
    return number_format((float)$value, 2);
}
function pl_valid_date(string $value): bool {
    if ($value === '') return false;
    $d = DateTime::createFromFormat('!Y-m-d', $value);
    return $d !== false && $d->format('Y-m-d') === $value;
}
function pl_bind(mysqli_stmt $stmt, string $types, array &$params): void {
    if ($types === '') return;
    $args = [$types];
    foreach ($params as &$param) $args[] = &$param;
    unset($param);
    call_user_func_array([$stmt, 'bind_param'], $args);
}
function pl_exists(mysqli $db, string $table): bool {
    $safe = $db->real_escape_string($table);
    $rs = $db->query("SHOW TABLES LIKE '{$safe}'");
    $exists = $rs && $rs->num_rows > 0;
    if ($rs) $rs->free();
    return $exists;
}
function pl_columns(mysqli $db, string $table): array {
    $out = [];
    $q = str_replace('`', '``', $table);
    $rs = $db->query("SHOW COLUMNS FROM `{$q}`");
    while ($r = $rs->fetch_assoc()) $out[$r['Field']] = $r;
    $rs->free();
    return $out;
}
function pl_pick(array $cols, array $choices): ?string {
    foreach ($choices as $c) if (isset($cols[$c])) return $c;
    return null;
}
function pl_qi(string $identifier): string {
    return '`' . str_replace('`', '``', $identifier) . '`';
}

/** Build a source description from a real database table and supported column names. */
function pl_source_config(mysqli $db, string $table, string $kind, string $label): ?array {
    if (!pl_exists($db, $table)) return null;
    $cols = pl_columns($db, $table);
    $id = pl_pick($cols, ['id', 'payment_id', 'transaction_id', 'expense_id', 'income_id']);
    $date = pl_pick($cols, ['income_date', 'payment_date', 'expense_date', 'transaction_date', 'date_paid', 'date', 'created_at']);
    $amount = pl_pick($cols, ['amount', 'payment_amount', 'paid_amount', 'total_amount', 'net_amount']);
    if (!$id || !$date || !$amount) {
        throw new RuntimeException("The {$table} table needs an ID, date and amount column before it can be included in the Profit & Loss report.");
    }
    $cfg = [
        'table' => $table, 'kind' => $kind, 'label' => $label, 'cols' => $cols,
        'id' => $id, 'date' => $date, 'amount' => $amount,
        'status' => pl_pick($cols, ['status', 'payment_status', 'transaction_status']),
        'number' => pl_pick($cols, ['transaction_no', 'receipt_no', 'payment_no', 'expense_no', 'reference_no', 'receipt_number']),
        'reference' => pl_pick($cols, ['reference_no', 'reference_number', 'transaction_reference', 'receipt_no']),
        'description' => pl_pick($cols, ['description', 'notes', 'remarks', 'narration', 'purpose', 'details']),
        'payee' => pl_pick($cols, ['payee_name', 'payer_name', 'supplier_name', 'person_name', 'employee_name']),
        'category_id' => pl_pick($cols, ['category_id', 'expense_category_id', 'income_category_id']),
        'category_table' => null, 'category_name' => null, 'category_id_key' => null,
    ];
    if ($kind === 'income' && pl_exists($db, 'income_categories')) {
        $catCols = pl_columns($db, 'income_categories');
        $cfg['category_table'] = 'income_categories';
        $cfg['category_name'] = pl_pick($catCols, ['category_name', 'name', 'title']);
        $cfg['category_id_key'] = pl_pick($catCols, ['id', 'category_id']);
    } elseif ($kind === 'expense' && pl_exists($db, 'expense_categories')) {
        $catCols = pl_columns($db, 'expense_categories');
        $cfg['category_table'] = 'expense_categories';
        $cfg['category_name'] = pl_pick($catCols, ['category_name', 'name', 'title']);
        $cfg['category_id_key'] = pl_pick($catCols, ['id', 'category_id']);
    }
    if (!$cfg['category_table'] || !$cfg['category_name'] || !$cfg['category_id_key'] || !$cfg['category_id']) {
        $cfg['category_table'] = null;
        $cfg['category_name'] = null;
        $cfg['category_id_key'] = null;
    }
    return $cfg;
}

/** Load filtered completed totals, category/month breakdowns and the transaction list. */
function pl_load_source(mysqli $db, array $cfg, string $dateFrom, string $dateTo, string $search, bool $exportAll): array {
    $table = pl_qi($cfg['table']);
    $alias = 't';
    $dateExpr = $alias . '.' . pl_qi($cfg['date']);
    $amountExpr = $alias . '.' . pl_qi($cfg['amount']);
    $idExpr = $alias . '.' . pl_qi($cfg['id']);
    $numberExpr = $cfg['number'] ? "COALESCE(NULLIF(CAST({$alias}." . pl_qi($cfg['number']) . " AS CHAR),''), CONCAT('" . strtoupper(substr($cfg['kind'], 0, 3)) . "-', {$idExpr}))" : "CONCAT('" . strtoupper(substr($cfg['kind'], 0, 3)) . "-', {$idExpr})";
    $statusExpr = $cfg['status'] ? "LOWER(COALESCE(CAST({$alias}." . pl_qi($cfg['status']) . " AS CHAR),''))" : "'completed'";
    $descriptionExpr = $cfg['description'] ? "COALESCE(CAST({$alias}." . pl_qi($cfg['description']) . " AS CHAR),'')" : "''";
    $referenceExpr = $cfg['reference'] ? "COALESCE(CAST({$alias}." . pl_qi($cfg['reference']) . " AS CHAR),'')" : "''";
    $payeeExpr = $cfg['payee'] ? "COALESCE(CAST({$alias}." . pl_qi($cfg['payee']) . " AS CHAR),'')" : "''";
    $joins = '';
    if ($cfg['category_table']) {
        $categoryExpr = "COALESCE(c." . pl_qi($cfg['category_name']) . ",'Uncategorised')";
        $joins = ' LEFT JOIN ' . pl_qi($cfg['category_table']) . ' c ON c.' . pl_qi($cfg['category_id_key']) . ' = ' . $alias . '.' . pl_qi($cfg['category_id']);
    } else {
        $categoryExpr = "'" . ($cfg['kind'] === 'fees' ? 'Student Fees' : ($cfg['kind'] === 'expense' ? 'Uncategorised expense' : 'Other income')) . "'";
    }
    $where = [];
    $params = [];
    $types = '';
    if ($dateFrom !== '') { $where[] = "DATE({$dateExpr}) >= ?"; $params[] = $dateFrom; $types .= 's'; }
    if ($dateTo !== '') { $where[] = "DATE({$dateExpr}) <= ?"; $params[] = $dateTo; $types .= 's'; }
    if ($cfg['status']) {
        // These are the statuses that indicate cash actually received or paid.
        $where[] = "{$statusExpr} IN ('completed','complete','paid','success','successful')";
    }
    if ($search !== '') {
        $searchFields = [$numberExpr, $descriptionExpr, $referenceExpr, $payeeExpr, $categoryExpr];
        $ors = [];
        foreach ($searchFields as $fieldExpr) {
            $ors[] = "CAST({$fieldExpr} AS CHAR) LIKE ?";
            $params[] = '%' . $search . '%';
            $types .= 's';
        }
        $where[] = '(' . implode(' OR ', $ors) . ')';
    }
    $whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';
    $fromSql = " FROM {$table} {$alias} {$joins} {$whereSql}";
    $summarySql = "SELECT COUNT(*) AS record_count, COALESCE(SUM({$amountExpr}),0) AS total_amount" . $fromSql;
    $bind = $params;
    $stmt = $db->prepare($summarySql);
    pl_bind($stmt, $types, $bind);
    $stmt->execute();
    $summary = $stmt->get_result()->fetch_assoc() ?: ['record_count' => 0, 'total_amount' => 0];
    $stmt->close();

    $catSql = "SELECT {$categoryExpr} AS category_name, COUNT(*) AS record_count, COALESCE(SUM({$amountExpr}),0) AS total_amount" . $fromSql . ' GROUP BY category_name ORDER BY total_amount DESC, category_name ASC';
    $bind = $params;
    $stmt = $db->prepare($catSql);
    pl_bind($stmt, $types, $bind);
    $stmt->execute();
    $categoryRows = [];
    $rs = $stmt->get_result();
    while ($r = $rs->fetch_assoc()) $categoryRows[] = $r;
    $stmt->close();

    $monthSql = "SELECT DATE_FORMAT({$dateExpr}, '%Y-%m') AS month_key, DATE_FORMAT({$dateExpr}, '%b %Y') AS month_label, COUNT(*) AS record_count, COALESCE(SUM({$amountExpr}),0) AS total_amount" . $fromSql . ' GROUP BY month_key, month_label ORDER BY month_key ASC';
    $bind = $params;
    $stmt = $db->prepare($monthSql);
    pl_bind($stmt, $types, $bind);
    $stmt->execute();
    $monthRows = [];
    $rs = $stmt->get_result();
    while ($r = $rs->fetch_assoc()) $monthRows[] = $r;
    $stmt->close();

    $recordSql = "SELECT {$idExpr} AS source_id, {$dateExpr} AS transaction_date, {$amountExpr} AS amount, {$numberExpr} AS transaction_no, {$categoryExpr} AS category_name, {$statusExpr} AS status, {$descriptionExpr} AS description, {$referenceExpr} AS reference_no, {$payeeExpr} AS payee_name" . $fromSql . " ORDER BY {$dateExpr} DESC, {$idExpr} DESC";
    if (!$exportAll) $recordSql .= ' LIMIT 500';
    $bind = $params;
    $stmt = $db->prepare($recordSql);
    pl_bind($stmt, $types, $bind);
    $stmt->execute();
    $records = [];
    $rs = $stmt->get_result();
    while ($r = $rs->fetch_assoc()) {
        $r['source'] = $cfg['label'];
        $r['kind'] = $cfg['kind'];
        $records[] = $r;
    }
    $stmt->close();
    return ['summary' => $summary, 'categories' => $categoryRows, 'months' => $monthRows, 'records' => $records];
}

$dateFrom = trim((string)($_GET['date_from'] ?? date('Y-m-01')));
$dateTo = trim((string)($_GET['date_to'] ?? date('Y-m-d')));
if (!pl_valid_date($dateFrom)) $dateFrom = '';
if (!pl_valid_date($dateTo)) $dateTo = '';
if ($dateFrom !== '' && $dateTo !== '' && $dateFrom > $dateTo) { $tmp = $dateFrom; $dateFrom = $dateTo; $dateTo = $tmp; }
$search = trim((string)($_GET['search'] ?? ''));
$includeFees = !isset($_GET['include_fees']) || (string)$_GET['include_fees'] === '1';
$exportCsv = (string)($_GET['export'] ?? '') === 'csv';
$pageError = '';
$schemaError = '';
$sourceResults = [];
$records = [];
$incomeCategories = [];
$expenseCategories = [];
$monthly = [];
$totals = ['fees' => 0.0, 'other_income' => 0.0, 'expenses' => 0.0, 'fees_count' => 0, 'income_count' => 0, 'expense_count' => 0];
$availableSources = [];

try {
    if (pl_exists($db, 'income_transactions')) {
        $cfg = pl_source_config($db, 'income_transactions', 'income', 'Other Income');
        $res = pl_load_source($db, $cfg, $dateFrom, $dateTo, $search, $exportCsv);
        $sourceResults['income'] = $res;
        $totals['other_income'] = (float)$res['summary']['total_amount'];
        $totals['income_count'] = (int)$res['summary']['record_count'];
        $availableSources[] = 'Other income';
        foreach ($res['categories'] as $row) $incomeCategories[] = $row;
        foreach ($res['months'] as $row) {
            $key = (string)$row['month_key'];
            if (!isset($monthly[$key])) $monthly[$key] = ['month_key'=>$key, 'month_label'=>$row['month_label'], 'income'=>0.0, 'fees'=>0.0, 'expenses'=>0.0];
            $monthly[$key]['income'] += (float)$row['total_amount'];
        }
        $records = array_merge($records, $res['records']);
    } else {
        $schemaError = 'The income_transactions table was not found. Open the Income page first to initialise it, then reload this report.';
    }

    if ($includeFees && pl_exists($db, 'fee_payments')) {
        $cfg = pl_source_config($db, 'fee_payments', 'fees', 'Student Fee Payments');
        $res = pl_load_source($db, $cfg, $dateFrom, $dateTo, $search, $exportCsv);
        $sourceResults['fees'] = $res;
        $totals['fees'] = (float)$res['summary']['total_amount'];
        $totals['fees_count'] = (int)$res['summary']['record_count'];
        $availableSources[] = 'Student fee payments';
        foreach ($res['months'] as $row) {
            $key = (string)$row['month_key'];
            if (!isset($monthly[$key])) $monthly[$key] = ['month_key'=>$key, 'month_label'=>$row['month_label'], 'income'=>0.0, 'fees'=>0.0, 'expenses'=>0.0];
            $monthly[$key]['fees'] += (float)$row['total_amount'];
        }
        $records = array_merge($records, $res['records']);
    }

    if (pl_exists($db, 'expense_transactions')) {
        $cfg = pl_source_config($db, 'expense_transactions', 'expense', 'Expenses');
        $res = pl_load_source($db, $cfg, $dateFrom, $dateTo, $search, $exportCsv);
        $sourceResults['expense'] = $res;
        $totals['expenses'] = (float)$res['summary']['total_amount'];
        $totals['expense_count'] = (int)$res['summary']['record_count'];
        $availableSources[] = 'Expenses';
        foreach ($res['categories'] as $row) $expenseCategories[] = $row;
        foreach ($res['months'] as $row) {
            $key = (string)$row['month_key'];
            if (!isset($monthly[$key])) $monthly[$key] = ['month_key'=>$key, 'month_label'=>$row['month_label'], 'income'=>0.0, 'fees'=>0.0, 'expenses'=>0.0];
            $monthly[$key]['expenses'] += (float)$row['total_amount'];
        }
        $records = array_merge($records, $res['records']);
    } else {
        $schemaError = trim($schemaError . ' The expense_transactions table was not found. Open the Expenses page first to initialise it, then reload this report.');
    }
} catch (Throwable $ex) {
    error_log('Profit & Loss report data error: ' . $ex->getMessage());
    $pageError = 'The report could not read one or more finance tables. Check that their columns match the working Income, Payments and Expenses pages; details have been written to the PHP error log.';
}

$totalIncome = $totals['other_income'] + $totals['fees'];
$netResult = $totalIncome - $totals['expenses'];
foreach ($monthly as &$m) {
    $m['total_income'] = $m['income'] + $m['fees'];
    $m['net'] = $m['total_income'] - $m['expenses'];
}
unset($m);
ksort($monthly);
usort($records, static function ($a, $b) {
    $ad = strtotime((string)($a['transaction_date'] ?? '')) ?: 0;
    $bd = strtotime((string)($b['transaction_date'] ?? '')) ?: 0;
    if ($ad === $bd) return ((int)$b['source_id']) <=> ((int)$a['source_id']);
    return $bd <=> $ad;
});
$recordCountForDisplay = array_sum([
    (int)($sourceResults['income']['summary']['record_count'] ?? 0),
    (int)($sourceResults['fees']['summary']['record_count'] ?? 0),
    (int)($sourceResults['expense']['summary']['record_count'] ?? 0),
]);

if ($exportCsv && $pageError === '') {
    while (ob_get_level() > 0) { @ob_end_clean(); }
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="profit-loss-' . ($dateFrom ?: 'all') . '-to-' . ($dateTo ?: 'all') . '.csv"');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    $out = fopen('php://output', 'w');
    fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));
    fputcsv($out, ['School Management System - Profit & Loss Report']);
    fputcsv($out, ['From', $dateFrom ?: 'All dates', 'To', $dateTo ?: 'All dates']);
    fputcsv($out, ['Student fee payments included', $includeFees ? 'Yes' : 'No']);
    fputcsv($out, ['Student fee payments', number_format($totals['fees'], 2, '.', '')]);
    fputcsv($out, ['Other income', number_format($totals['other_income'], 2, '.', '')]);
    fputcsv($out, ['Total income', number_format($totalIncome, 2, '.', '')]);
    fputcsv($out, ['Expenses', number_format($totals['expenses'], 2, '.', '')]);
    fputcsv($out, [$netResult >= 0 ? 'Net surplus' : 'Net deficit', number_format(abs($netResult), 2, '.', '')]);
    fputcsv($out, []);
    fputcsv($out, ['Date', 'Source', 'Transaction No.', 'Category', 'Payee', 'Description', 'Reference', 'Status', 'Amount (UGX)']);
    foreach ($records as $r) {
        fputcsv($out, [$r['transaction_date'] ?? '', $r['source'] ?? '', $r['transaction_no'] ?? '', $r['category_name'] ?? '', $r['payee_name'] ?? '', $r['description'] ?? '', $r['reference_no'] ?? '', $r['status'] ?? '', number_format((float)($r['amount'] ?? 0), 2, '.', '')]);
    }
    fclose($out);
    exit;
}

$fullName = (string)($_SESSION['full_name'] ?? 'Bursar');
$userRole = (string)($_SESSION['role'] ?? '');
$csvQuery = $_GET;
$csvQuery['export'] = 'csv';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Profit &amp; Loss | School Management System</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f6f9;font-family:Arial,Helvetica,sans-serif;color:#343a40}.sidebar{width:250px;position:fixed;inset:0 auto 0 0;background:#212529;color:#fff;overflow-y:auto;z-index:1050;transition:left .25s}.sidebar-header{padding:20px;background:#343a40;text-align:center}.sidebar-header h5{margin:0;font-weight:700}.sidebar-menu{padding:15px 10px}.sidebar-menu a{display:block;color:#ddd;padding:11px 15px;margin-bottom:4px;border-radius:6px;text-decoration:none;font-size:14px}.sidebar-menu a:hover,.sidebar-menu a.active{background:#007bff;color:#fff}.sidebar-menu i{width:25px}.main-content{margin-left:250px;padding:25px}.topbar,.page-header,.stat-card,.content-card{background:#fff;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,.05)}.topbar{padding:15px 20px;margin-bottom:22px}.page-header{padding:20px;margin-bottom:20px}.stat-card{padding:19px;margin-bottom:20px;height:100%}.stat-title{font-size:13px;color:#6c757d;margin-bottom:6px}.stat-value{font-size:22px;font-weight:700;overflow-wrap:anywhere}.stat-icon{width:46px;height:46px;display:flex;align-items:center;justify-content:center;border-radius:10px;background:#e9f5ff;color:#007bff;font-size:19px}.content-card{margin-bottom:24px}.content-card-header{padding:17px 20px;border-bottom:1px solid #eee}.content-card-body{padding:20px}.table thead th{background:#f8f9fa;border-top:none;white-space:nowrap;font-size:12px}.table td{vertical-align:middle;font-size:13px}.amount{font-weight:700;white-space:nowrap}.form-control,.custom-select,.btn{border-radius:6px}.form-control,.custom-select{min-height:40px}.mobile-menu{display:none}.badge{padding:7px 9px}.muted-small{font-size:12px;color:#6c757d}.bar-track{height:8px;background:#edf0f5;border-radius:99px;overflow:hidden}.bar-fill{height:100%;background:#2474d2;border-radius:99px}.empty{text-align:center;color:#718096;padding:30px 10px}.net-card{border-left:5px solid #28a745}.net-negative{border-left-color:#dc3545}.sidebar-overlay{display:none}@media(max-width:991px){.sidebar{left:-250px}.sidebar.show{left:0}.main-content{margin-left:0;padding:15px}.mobile-menu{display:inline-block}.sidebar-overlay.show{display:block;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:1040}}@media print{.sidebar,.topbar,.no-print,.sidebar-overlay{display:none!important}.main-content{margin:0;padding:0}.content-card,.stat-card,.page-header{box-shadow:none}body{background:#fff}}
</style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-header"><h5><i class="fas fa-school mr-1"></i> School Management</h5><small class="text-muted">Bursar Panel</small></div>
  <nav class="sidebar-menu">
    <a href="/admin/dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="/admin/bursar/students_fee_accounts.php"><i class="fas fa-user-graduate"></i> Student Fee Accounts</a>
    <a href="/admin/bursar/fee_structure.php"><i class="fas fa-list-alt"></i> Fee Structure</a>
    <a href="/admin/bursar/payments.php"><i class="fas fa-money-bill-wave"></i> Student Payments</a>
    <a href="/admin/bursar/income.php"><i class="fas fa-arrow-circle-down"></i> Other Income</a>
    <a href="/admin/bursar/expenses.php"><i class="fas fa-arrow-circle-up"></i> Expenses</a>
    <a href="/admin/bursar/suppliers.php"><i class="fas fa-truck"></i> Suppliers</a>
    <a href="/admin/bursar/supplier_payments.php"><i class="fas fa-file-invoice-dollar"></i> Supplier Payments</a>
    <a href="/admin/bursar/salaries.php"><i class="fas fa-users"></i> Staff Salaries</a>
    <a href="/admin/bursar/salary_payments.php"><i class="fas fa-money-check-alt"></i> Salary Payments</a>
    <a href="/admin/bursar/budgets.php"><i class="fas fa-wallet"></i> Budgets</a>
    <a href="/admin/bursar/cashbook.php"><i class="fas fa-book"></i> Cashbook</a>
    <a href="/admin/bursar/reports.php"><i class="fas fa-chart-bar"></i> Financial Reports</a>
    <a href="/admin/bursar/fees_report.php"><i class="fas fa-file-invoice-dollar"></i> Fees Report</a>
    <a href="/admin/bursar/expense_report.php"><i class="fas fa-file-alt"></i> Expense Report</a>
    <a href="/admin/bursar/profit_loss.php" class="active"><i class="fas fa-balance-scale"></i> Profit &amp; Loss</a>
    <hr class="bg-secondary"><a href="/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </nav>
</aside>
<main class="main-content">
  <div class="topbar d-flex align-items-center justify-content-between">
    <div><button type="button" class="btn btn-outline-primary mobile-menu mr-2" id="mobileMenuButton"><i class="fas fa-bars"></i></button><strong>Bursar Finance</strong></div>
    <div class="text-right"><strong><?= pl_h($fullName) ?></strong><br><small class="text-muted"><?= pl_h(ucwords(str_replace('_',' ',$userRole))) ?></small></div>
  </div>
  <div class="page-header d-flex flex-wrap justify-content-between align-items-center">
    <div><h3 class="mb-1"><i class="fas fa-balance-scale text-primary mr-2"></i>Profit &amp; Loss Statement</h3><p class="text-muted mb-0">Compare school income and expenses for a selected period.</p></div>
    <div class="mt-2 no-print"><a class="btn btn-success" href="?<?= pl_h(http_build_query($csvQuery)) ?>"><i class="fas fa-file-csv mr-1"></i> Export CSV</a> <button class="btn btn-secondary" type="button" onclick="window.print()"><i class="fas fa-print mr-1"></i> Print Statement</button></div>
  </div>

  <?php if ($schemaError !== ''): ?><div class="alert alert-warning"><strong>Database setup note:</strong> <?= pl_h($schemaError) ?></div><?php endif; ?>
  <?php if ($pageError !== ''): ?><div class="alert alert-danger"><strong>Report loading issue:</strong> <?= pl_h($pageError) ?></div><?php endif; ?>
  <?php if (isset($sourceResults['fees']) && $includeFees): ?><div class="alert alert-info"><i class="fas fa-info-circle mr-1"></i>Student fee payments are included as income. If your team also manually records the same fee receipts in Other Income, turn off “Include student fee payments” below to avoid counting them twice.</div><?php endif; ?>

  <section class="content-card no-print"><div class="content-card-header"><h5 class="mb-0"><i class="fas fa-filter mr-2"></i>Report filters</h5></div><div class="content-card-body">
    <form method="GET" action="profit_loss.php"><div class="form-row align-items-end">
      <div class="col-lg-3 col-md-6 form-group"><label for="date_from">From date</label><input id="date_from" class="form-control" type="date" name="date_from" value="<?= pl_h($dateFrom) ?>"></div>
      <div class="col-lg-3 col-md-6 form-group"><label for="date_to">To date</label><input id="date_to" class="form-control" type="date" name="date_to" value="<?= pl_h($dateTo) ?>"></div>
      <div class="col-lg-4 col-md-8 form-group"><label for="search">Search transactions</label><input id="search" class="form-control" type="search" name="search" value="<?= pl_h($search) ?>" placeholder="Transaction, category, payee or reference"></div>
      <div class="col-lg-2 col-md-4 form-group"><button class="btn btn-primary btn-block" type="submit"><i class="fas fa-search mr-1"></i> Apply</button></div>
    </div>
    <input type="hidden" name="include_fees" value="0"><div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="include_fees" name="include_fees" value="1" <?= $includeFees ? 'checked' : '' ?>><label class="custom-control-label" for="include_fees">Include student fee payments in income (when the fee_payments table exists)</label></div>
    <div class="muted-small mt-2">Only recorded transactions with a completed, paid or successful status are included in the statement. Cancelled and reversed records are excluded.</div>
    </form>
  </div></section>

  <div class="row">
    <div class="col-xl-3 col-md-6"><div class="stat-card"><div class="d-flex justify-content-between"><div><div class="stat-title">Student fee income</div><div class="stat-value text-primary">UGX <?= pl_money($totals['fees']) ?></div></div><div class="stat-icon"><i class="fas fa-user-graduate"></i></div></div><div class="muted-small mt-2"><?= number_format($totals['fees_count']) ?> completed payment(s)</div></div></div>
    <div class="col-xl-3 col-md-6"><div class="stat-card"><div class="d-flex justify-content-between"><div><div class="stat-title">Other income</div><div class="stat-value text-success">UGX <?= pl_money($totals['other_income']) ?></div></div><div class="stat-icon" style="background:#e9f8ef;color:#218838"><i class="fas fa-arrow-circle-down"></i></div></div><div class="muted-small mt-2"><?= number_format($totals['income_count']) ?> completed transaction(s)</div></div></div>
    <div class="col-xl-3 col-md-6"><div class="stat-card"><div class="d-flex justify-content-between"><div><div class="stat-title">Total expenses</div><div class="stat-value text-danger">UGX <?= pl_money($totals['expenses']) ?></div></div><div class="stat-icon" style="background:#fff0f0;color:#d64545"><i class="fas fa-arrow-circle-up"></i></div></div><div class="muted-small mt-2"><?= number_format($totals['expense_count']) ?> completed transaction(s)</div></div></div>
    <div class="col-xl-3 col-md-6"><div class="stat-card net-card <?= $netResult < 0 ? 'net-negative' : '' ?>"><div class="d-flex justify-content-between"><div><div class="stat-title"><?= $netResult >= 0 ? 'Net surplus' : 'Net deficit' ?></div><div class="stat-value <?= $netResult >= 0 ? 'text-success' : 'text-danger' ?>">UGX <?= pl_money(abs($netResult)) ?></div></div><div class="stat-icon" style="background:<?= $netResult >= 0 ? '#e9f8ef;color:#218838' : '#fff0f0;color:#d64545' ?>"><i class="fas fa-<?= $netResult >= 0 ? 'chart-line' : 'chart-area' ?>"></i></div></div><div class="muted-small mt-2">Total income minus expenses</div></div></div>
  </div>

  <section class="content-card"><div class="content-card-header d-flex flex-wrap justify-content-between align-items-center"><h5 class="mb-1"><i class="fas fa-file-invoice-dollar mr-2"></i>Profit &amp; loss summary</h5><span class="badge badge-primary"><?= pl_h($dateFrom ?: 'All dates') ?> to <?= pl_h($dateTo ?: 'All dates') ?></span></div><div class="table-responsive"><table class="table table-bordered mb-0"><tbody>
    <tr><th style="width:70%">Student fee payments</th><td class="text-right">UGX <?= pl_money($totals['fees']) ?></td></tr>
    <tr><th>Other income</th><td class="text-right">UGX <?= pl_money($totals['other_income']) ?></td></tr>
    <tr class="table-light"><th>Total income</th><th class="text-right text-success">UGX <?= pl_money($totalIncome) ?></th></tr>
    <tr><th>Less: expenses</th><td class="text-right text-danger">(UGX <?= pl_money($totals['expenses']) ?>)</td></tr>
    <tr class="<?= $netResult >= 0 ? 'table-success' : 'table-danger' ?>"><th><?= $netResult >= 0 ? 'NET SURPLUS' : 'NET DEFICIT' ?></th><th class="text-right">UGX <?= pl_money(abs($netResult)) ?></th></tr>
  </tbody></table></div><div class="content-card-body muted-small">This is a cash-received / cash-paid view based on recorded transactions for the selected dates. It is not an accrual accounting statement and does not include unpaid fee balances or unrecorded liabilities.</div></section>

  <div class="row">
    <div class="col-lg-6"><section class="content-card"><div class="content-card-header"><h5 class="mb-0"><i class="fas fa-tags text-success mr-2"></i>Income by category</h5></div><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Category</th><th>Records</th><th class="text-right">Amount (UGX)</th></tr></thead><tbody>
      <?php $allIncomeCats = $incomeCategories; if ($includeFees && isset($sourceResults['fees'])) $allIncomeCats[] = ['category_name'=>'Student Fees', 'record_count'=>$totals['fees_count'], 'total_amount'=>$totals['fees']]; ?>
      <?php if (!$allIncomeCats): ?><tr><td colspan="3" class="text-center text-muted py-4">No income records for this period.</td></tr><?php else: foreach ($allIncomeCats as $cat): ?><tr><td><?= pl_h($cat['category_name']) ?></td><td><?= number_format((int)$cat['record_count']) ?></td><td class="text-right text-success font-weight-bold"><?= pl_money($cat['total_amount']) ?></td></tr><?php endforeach; endif; ?>
    </tbody></table></div></section></div>
    <div class="col-lg-6"><section class="content-card"><div class="content-card-header"><h5 class="mb-0"><i class="fas fa-tags text-danger mr-2"></i>Expenses by category</h5></div><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Category</th><th>Records</th><th class="text-right">Amount (UGX)</th></tr></thead><tbody>
      <?php if (!$expenseCategories): ?><tr><td colspan="3" class="text-center text-muted py-4">No expense records for this period.</td></tr><?php else: foreach ($expenseCategories as $cat): ?><tr><td><?= pl_h($cat['category_name']) ?></td><td><?= number_format((int)$cat['record_count']) ?></td><td class="text-right text-danger font-weight-bold"><?= pl_money($cat['total_amount']) ?></td></tr><?php endforeach; endif; ?>
    </tbody></table></div></section></div>
  </div>

  <section class="content-card"><div class="content-card-header"><h5 class="mb-0"><i class="fas fa-calendar-alt mr-2"></i>Monthly income and expenses</h5></div><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Month</th><th class="text-right">Student fees (UGX)</th><th class="text-right">Other income (UGX)</th><th class="text-right">Total income (UGX)</th><th class="text-right">Expenses (UGX)</th><th class="text-right">Surplus / deficit (UGX)</th></tr></thead><tbody>
    <?php if (!$monthly): ?><tr><td colspan="6" class="text-center text-muted py-4">No completed transactions for the selected period.</td></tr><?php else: foreach ($monthly as $m): $monthNet = (float)$m['net']; ?><tr><td><?= pl_h($m['month_label']) ?></td><td class="text-right"><?= pl_money($m['fees']) ?></td><td class="text-right"><?= pl_money($m['income']) ?></td><td class="text-right text-success"><?= pl_money($m['total_income']) ?></td><td class="text-right text-danger"><?= pl_money($m['expenses']) ?></td><td class="text-right font-weight-bold <?= $monthNet >= 0 ? 'text-success' : 'text-danger' ?>"><?= $monthNet < 0 ? '( ' . pl_money(abs($monthNet)) . ' )' : pl_money($monthNet) ?></td></tr><?php endforeach; endif; ?>
  </tbody></table></div></section>

  <section class="content-card"><div class="content-card-header d-flex justify-content-between align-items-center flex-wrap"><h5 class="mb-1"><i class="fas fa-list mr-2"></i>Recorded transactions included</h5><span class="badge badge-primary"><?= number_format($recordCountForDisplay) ?> matched transaction(s)</span></div><div class="table-responsive"><table class="table table-hover table-bordered mb-0"><thead><tr><th>#</th><th>Date</th><th>Source</th><th>Transaction No.</th><th>Category</th><th>Payee / detail</th><th>Reference</th><th class="text-right">Amount (UGX)</th></tr></thead><tbody>
    <?php if (!$records): ?><tr><td colspan="8"><div class="empty"><i class="fas fa-receipt fa-2x mb-2"></i><h5>No transactions found</h5><div>Change the selected dates or search for another transaction.</div></div></td></tr><?php else: foreach (array_slice($records, 0, 500) as $i => $r): ?><tr><td><?= $i + 1 ?></td><td><?= !empty($r['transaction_date']) && strtotime((string)$r['transaction_date']) ? pl_h(date('d M Y', strtotime((string)$r['transaction_date']))) : '—' ?></td><td><span class="badge badge-<?= ($r['kind'] ?? '') === 'expense' ? 'danger' : 'success' ?>"><?= pl_h($r['source']) ?></span></td><td><strong><?= pl_h($r['transaction_no']) ?></strong></td><td><?= pl_h($r['category_name']) ?></td><td><?= pl_h($r['payee_name'] ?: ($r['description'] ?: '—')) ?></td><td><?= pl_h($r['reference_no'] ?: '—') ?></td><td class="text-right font-weight-bold <?= ($r['kind'] ?? '') === 'expense' ? 'text-danger' : 'text-success' ?>"><?= pl_money($r['amount']) ?></td></tr><?php endforeach; endif; ?>
  </tbody></table></div><div class="content-card-body muted-small">The on-screen register shows up to 500 records. Use Export CSV to download all matching rows for the selected period and filters.</div></section>
  <p class="muted-small text-center">School Management System &mdash; Bursar Profit &amp; Loss Report. Completed receipts and payments only.</p>
</main>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>(function(){const sidebar=document.getElementById('sidebar');const overlay=document.getElementById('sidebarOverlay');const button=document.getElementById('mobileMenuButton');function closeMenu(){sidebar.classList.remove('show');overlay.classList.remove('show');}if(button)button.addEventListener('click',function(){sidebar.classList.toggle('show');overlay.classList.toggle('show');});if(overlay)overlay.addEventListener('click',closeMenu);document.addEventListener('keydown',function(e){if(e.key==='Escape')closeMenu();});})();</script>
</body>
</html>
