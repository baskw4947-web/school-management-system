<?php
/**
 * School Management System - Bursar Expense Report
 * Suggested location: /admin/bursar/expense_report.php
 * Uses the expense_transactions / expense_categories schema from expenses.php.
 */
ob_start();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

set_exception_handler(function (Throwable $ex): void {
    error_log('Expense report uncaught error: ' . $ex->getMessage() . ' in ' . $ex->getFile() . ':' . $ex->getLine());
    if (!headers_sent()) http_response_code(500);
    while (ob_get_level() > 0) { @ob_end_clean(); }
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Expense Report Error</title><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"></head><body class="bg-light"><div class="container py-5"><div class="alert alert-danger"><h4>Expense report could not load</h4><p class="mb-0">A database or PHP error occurred. Technical details have been written to the hosting PHP error log. Check that the expense tables match your Expenses page.</p></div><a class="btn btn-primary" href="expense_report.php">Reload report</a></div></body></html>';
    exit;
});

require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator', 'bursar']);

$db = $conn ?? ($mysqli ?? ($connection ?? null));
if (!$db instanceof mysqli) {
    throw new RuntimeException('Database connection not found. Check config/database.php.');
}
$db->set_charset('utf8mb4');

function exr_h($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}
function exr_valid_date(string $value): bool {
    if ($value === '') return false;
    $date = DateTime::createFromFormat('!Y-m-d', $value);
    return $date !== false && $date->format('Y-m-d') === $value;
}
function exr_bind(mysqli_stmt $stmt, string $types, array &$params): void {
    if ($types === '') return;
    $args = [$types];
    foreach ($params as &$param) $args[] = &$param;
    unset($param);
    call_user_func_array([$stmt, 'bind_param'], $args);
}
function exr_table_exists(mysqli $db, string $table): bool {
    $safe = $db->real_escape_string($table);
    $result = $db->query("SHOW TABLES LIKE '{$safe}'");
    return $result && $result->num_rows > 0;
}
function exr_columns(mysqli $db, string $table): array {
    $columns = [];
    $safe = str_replace('`', '``', $table);
    $result = $db->query("SHOW COLUMNS FROM `{$safe}`");
    while ($row = $result->fetch_assoc()) $columns[$row['Field']] = $row;
    $result->free();
    return $columns;
}
function exr_col(array $columns, array $names): ?string {
    foreach ($names as $name) if (isset($columns[$name])) return $name;
    return null;
}
function exr_sql_col(string $alias, ?string $column, string $fallback = "''"): string {
    if (!$column) return $fallback;
    return $alias . '.`' . str_replace('`', '``', $column) . '`';
}
function exr_money($number): string {
    return number_format((float)$number, 2);
}
function exr_run_query(mysqli $db, string $sql, string $types, array &$params): mysqli_result {
    $stmt = $db->prepare($sql);
    exr_bind($stmt, $types, $params);
    $stmt->execute();
    $result = $stmt->get_result();
    // The result object remains readable after close for mysqlnd, but keep statement alive via result fetch here.
    return $result;
}

$pageError = '';
$schemaError = '';
$expenseColumns = $categoryColumns = $methodColumns = $userColumns = [];
$hasCategories = exr_table_exists($db, 'expense_categories');
$hasMethods = exr_table_exists($db, 'payment_methods');
$hasUsers = exr_table_exists($db, 'users');
if (!exr_table_exists($db, 'expense_transactions')) {
    $schemaError = 'The expense_transactions table was not found. Open the Expenses page first so its expense tables can be initialized.';
} else {
    $expenseColumns = exr_columns($db, 'expense_transactions');
    if ($hasCategories) $categoryColumns = exr_columns($db, 'expense_categories');
    if ($hasMethods) $methodColumns = exr_columns($db, 'payment_methods');
    if ($hasUsers) $userColumns = exr_columns($db, 'users');
    $required = ['id', 'amount', 'expense_date', 'status'];
    foreach ($required as $column) {
        if (!isset($expenseColumns[$column])) {
            $schemaError = "The expense_transactions table is missing the required '{$column}' column.";
            break;
        }
    }
}

$transactionCol = exr_col($expenseColumns, ['transaction_no', 'expense_no', 'reference_no']);
$categoryIdCol = exr_col($expenseColumns, ['category_id', 'expense_category_id']);
$methodIdCol = exr_col($expenseColumns, ['payment_method_id']);
$dateCol = exr_col($expenseColumns, ['expense_date', 'transaction_date', 'date']);
$amountCol = exr_col($expenseColumns, ['amount', 'expense_amount', 'total_amount']);
$statusCol = exr_col($expenseColumns, ['status', 'expense_status']);
$payeeCol = exr_col($expenseColumns, ['payee_name', 'supplier_name', 'payee', 'vendor_name']);
$referenceCol = exr_col($expenseColumns, ['reference_no', 'reference_number', 'receipt_no']);
$descriptionCol = exr_col($expenseColumns, ['description', 'details', 'narration', 'purpose']);
$createdByCol = exr_col($expenseColumns, ['created_by', 'recorded_by', 'user_id']);
$idCol = exr_col($expenseColumns, ['id', 'expense_id']);
$categoryNameCol = exr_col($categoryColumns, ['category_name', 'name', 'title']);
$methodNameCol = exr_col($methodColumns, ['method_name', 'name', 'payment_method']);
$userNameCol = exr_col($userColumns, ['full_name', 'name', 'username', 'email']);

$dateFrom = trim((string)($_GET['date_from'] ?? date('Y-m-01')));
$dateTo = trim((string)($_GET['date_to'] ?? date('Y-m-d')));
if (!exr_valid_date($dateFrom)) $dateFrom = '';
if (!exr_valid_date($dateTo)) $dateTo = '';
if ($dateFrom !== '' && $dateTo !== '' && $dateFrom > $dateTo) {
    $tmp = $dateFrom; $dateFrom = $dateTo; $dateTo = $tmp;
}
$search = trim((string)($_GET['search'] ?? ''));
$categoryFilter = (int)($_GET['category_id'] ?? 0);
$statusFilter = trim((string)($_GET['status'] ?? ''));
$validStatuses = ['completed', 'cancelled', 'reversed'];
if (!in_array($statusFilter, $validStatuses, true)) $statusFilter = '';
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 25;
$categories = [];
$rows = [];
$categorySummary = [];
$monthlySummary = [];
$summary = ['total_records' => 0, 'completed_amount' => 0.0, 'cancelled_amount' => 0.0, 'reversed_amount' => 0.0, 'average_amount' => 0.0];
$totalRecords = 0;
$totalPages = 1;
$offset = 0;
$export = (string)($_GET['export'] ?? '') === 'csv';

if ($schemaError === '') {
    try {
        if ($hasCategories && $categoryIdCol && $categoryNameCol) {
            $categoryResult = $db->query("SELECT `id`, `" . str_replace('`', '``', $categoryNameCol) . "` AS category_name FROM `expense_categories` ORDER BY `" . str_replace('`', '``', $categoryNameCol) . "`");
            while ($cat = $categoryResult->fetch_assoc()) $categories[] = $cat;
        }

        $joinSql = '';
        $categoryExpr = "'Uncategorised'";
        if ($hasCategories && $categoryIdCol && $categoryNameCol && isset($expenseColumns[$categoryIdCol], $categoryColumns['id'])) {
            $joinSql .= " LEFT JOIN expense_categories ec ON ec.`id` = et.`" . str_replace('`', '``', $categoryIdCol) . "` ";
            $categoryExpr = "COALESCE(ec.`" . str_replace('`', '``', $categoryNameCol) . "`, 'Uncategorised')";
        } elseif ($categoryIdCol) {
            $categoryExpr = "CONCAT('Category #', et.`" . str_replace('`', '``', $categoryIdCol) . "`)";
        }
        $methodExpr = "'Not specified'";
        if ($hasMethods && $methodIdCol && $methodNameCol && isset($methodColumns['id'])) {
            $joinSql .= " LEFT JOIN payment_methods pm ON pm.`id` = et.`" . str_replace('`', '``', $methodIdCol) . "` ";
            $methodExpr = "COALESCE(pm.`" . str_replace('`', '``', $methodNameCol) . "`, 'Not specified')";
        } elseif ($methodIdCol) {
            $methodExpr = "CONCAT('Method #', et.`" . str_replace('`', '``', $methodIdCol) . "`)";
        }
        $createdByExpr = "'Unknown'";
        if ($hasUsers && $createdByCol && $userNameCol && isset($userColumns['id'])) {
            $joinSql .= " LEFT JOIN users u ON u.`id` = et.`" . str_replace('`', '``', $createdByCol) . "` ";
            $createdByExpr = "COALESCE(u.`" . str_replace('`', '``', $userNameCol) . "`, 'Unknown')";
        }

        $selectTransaction = $transactionCol ? "COALESCE(et.`" . str_replace('`', '``', $transactionCol) . "`, CONCAT('EXP-', et.`" . str_replace('`', '``', $idCol) . "`))" : "CONCAT('EXP-', et.`" . str_replace('`', '``', $idCol) . "`)";
        $selectDate = "et.`" . str_replace('`', '``', $dateCol) . "`";
        $selectAmount = "et.`" . str_replace('`', '``', $amountCol) . "`";
        $selectStatus = "et.`" . str_replace('`', '``', $statusCol) . "`";
        $selectPayee = $payeeCol ? "COALESCE(et.`" . str_replace('`', '``', $payeeCol) . "`, '')" : "''";
        $selectRef = $referenceCol ? "COALESCE(et.`" . str_replace('`', '``', $referenceCol) . "`, '')" : "''";
        $selectDescription = $descriptionCol ? "COALESCE(et.`" . str_replace('`', '``', $descriptionCol) . "`, '')" : "''";

        $where = [];
        $params = [];
        $types = '';
        if ($dateFrom !== '') { $where[] = "DATE({$selectDate}) >= ?"; $params[] = $dateFrom; $types .= 's'; }
        if ($dateTo !== '') { $where[] = "DATE({$selectDate}) <= ?"; $params[] = $dateTo; $types .= 's'; }
        if ($statusFilter !== '') { $where[] = "{$selectStatus} = ?"; $params[] = $statusFilter; $types .= 's'; }
        if ($categoryFilter > 0 && $categoryIdCol) { $where[] = "et.`" . str_replace('`', '``', $categoryIdCol) . "` = ?"; $params[] = $categoryFilter; $types .= 'i'; }
        if ($search !== '') {
            $searchOr = [];
            $searchColumns = [$transactionCol, $payeeCol, $referenceCol, $descriptionCol];
            foreach ($searchColumns as $col) {
                if ($col) {
                    $searchOr[] = "et.`" . str_replace('`', '``', $col) . "` LIKE ?";
                    $params[] = '%' . $search . '%'; $types .= 's';
                }
            }
            if (strpos($categoryExpr, 'ec.') !== false) {
                $searchOr[] = $categoryExpr . ' LIKE ?'; $params[] = '%' . $search . '%'; $types .= 's';
            }
            if ($searchOr) $where[] = '(' . implode(' OR ', $searchOr) . ')';
        }
        $whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';
        $baseFrom = ' FROM expense_transactions et ' . $joinSql . $whereSql;

        $summarySql = "SELECT COUNT(*) AS total_records,
            COALESCE(SUM(CASE WHEN {$selectStatus} = 'completed' THEN {$selectAmount} ELSE 0 END),0) AS completed_amount,
            COALESCE(SUM(CASE WHEN {$selectStatus} = 'cancelled' THEN {$selectAmount} ELSE 0 END),0) AS cancelled_amount,
            COALESCE(SUM(CASE WHEN {$selectStatus} = 'reversed' THEN {$selectAmount} ELSE 0 END),0) AS reversed_amount,
            COALESCE(AVG(CASE WHEN {$selectStatus} = 'completed' THEN {$selectAmount} ELSE NULL END),0) AS average_amount" . $baseFrom;
        $sumParams = $params;
        $stmt = $db->prepare($summarySql);
        exr_bind($stmt, $types, $sumParams);
        $stmt->execute();
        $summary = $stmt->get_result()->fetch_assoc() ?: $summary;
        $stmt->close();

        $countSql = 'SELECT COUNT(*) AS total_records' . $baseFrom;
        $countParams = $params;
        $stmt = $db->prepare($countSql);
        exr_bind($stmt, $types, $countParams);
        $stmt->execute();
        $totalRecords = (int)($stmt->get_result()->fetch_assoc()['total_records'] ?? 0);
        $stmt->close();
        $totalPages = max(1, (int)ceil($totalRecords / $perPage));
        $page = min($page, $totalPages);
        $offset = ($page - 1) * $perPage;

        // Category breakdown uses the same search/date/status filters but groups by category name.
        $categorySql = "SELECT {$categoryExpr} AS category_name,
            COUNT(*) AS record_count,
            COALESCE(SUM(CASE WHEN {$selectStatus} = 'completed' THEN {$selectAmount} ELSE 0 END),0) AS completed_total" . $baseFrom .
            " GROUP BY category_name ORDER BY completed_total DESC, category_name ASC";
        $catParams = $params;
        $stmt = $db->prepare($categorySql);
        exr_bind($stmt, $types, $catParams);
        $stmt->execute();
        $rs = $stmt->get_result();
        while ($r = $rs->fetch_assoc()) $categorySummary[] = $r;
        $stmt->close();

        // Monthly trend for completed expense transactions in the filtered date range.
        $monthWhere = [];
        $monthParams = [];
        $monthTypes = '';
        if ($dateFrom !== '') { $monthWhere[] = "DATE({$selectDate}) >= ?"; $monthParams[] = $dateFrom; $monthTypes .= 's'; }
        if ($dateTo !== '') { $monthWhere[] = "DATE({$selectDate}) <= ?"; $monthParams[] = $dateTo; $monthTypes .= 's'; }
        $monthWhere[] = "{$selectStatus} = 'completed'";
        if ($categoryFilter > 0 && $categoryIdCol) { $monthWhere[] = "et.`" . str_replace('`', '``', $categoryIdCol) . "` = ?"; $monthParams[] = $categoryFilter; $monthTypes .= 'i'; }
        // Apply search to the month report too, matching the transaction filter.
        if ($search !== '') {
            $monthSearchOr = [];
            foreach ([$transactionCol, $payeeCol, $referenceCol, $descriptionCol] as $col) {
                if ($col) { $monthSearchOr[] = "et.`" . str_replace('`', '``', $col) . "` LIKE ?"; $monthParams[] = '%' . $search . '%'; $monthTypes .= 's'; }
            }
            if (strpos($categoryExpr, 'ec.') !== false) { $monthSearchOr[] = $categoryExpr . ' LIKE ?'; $monthParams[] = '%' . $search . '%'; $monthTypes .= 's'; }
            if ($monthSearchOr) $monthWhere[] = '(' . implode(' OR ', $monthSearchOr) . ')';
        }
        $monthWhereSql = ' WHERE ' . implode(' AND ', $monthWhere);
        $monthSql = "SELECT DATE_FORMAT({$selectDate}, '%Y-%m') AS month_key,
            DATE_FORMAT({$selectDate}, '%b %Y') AS month_label,
            COUNT(*) AS record_count, COALESCE(SUM({$selectAmount}),0) AS total_amount
            FROM expense_transactions et {$joinSql} {$monthWhereSql}
            GROUP BY month_key, month_label ORDER BY month_key DESC LIMIT 12";
        $stmt = $db->prepare($monthSql);
        exr_bind($stmt, $monthTypes, $monthParams);
        $stmt->execute();
        $rs = $stmt->get_result();
        while ($r = $rs->fetch_assoc()) $monthlySummary[] = $r;
        $stmt->close();

        $selectList = "SELECT et.`" . str_replace('`', '``', $idCol) . "` AS id,
            {$selectTransaction} AS transaction_no, {$categoryExpr} AS category_name,
            {$selectPayee} AS payee_name, {$selectAmount} AS amount,
            {$selectDate} AS expense_date, {$methodExpr} AS payment_method,
            {$selectRef} AS reference_no, {$selectDescription} AS description,
            {$createdByExpr} AS created_by_name, {$selectStatus} AS status";
        $orderCol = $dateCol ? "et.`" . str_replace('`', '``', $dateCol) . "`" : "et.`" . str_replace('`', '``', $idCol) . "`";
        $listSql = $selectList . $baseFrom . " ORDER BY {$orderCol} DESC, et.`" . str_replace('`', '``', $idCol) . "` DESC";

        if ($export) {
            $stmt = $db->prepare($listSql);
            $exportParams = $params;
            exr_bind($stmt, $types, $exportParams);
            $stmt->execute();
            $rs = $stmt->get_result();
            while ($r = $rs->fetch_assoc()) $rows[] = $r;
            $stmt->close();
            while (ob_get_level() > 0) { @ob_end_clean(); }
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="school-expense-report-' . date('Y-m-d') . '.csv"');
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF");
            fputcsv($out, ['Transaction No.', 'Category', 'Payee / Supplier', 'Amount (UGX)', 'Expense Date', 'Payment Method', 'Reference', 'Description', 'Recorded By', 'Status']);
            foreach ($rows as $r) fputcsv($out, [$r['transaction_no'], $r['category_name'], $r['payee_name'], $r['amount'], $r['expense_date'], $r['payment_method'], $r['reference_no'], $r['description'], $r['created_by_name'], $r['status']]);
            fclose($out);
            exit;
        }

        $listSql .= ' LIMIT ? OFFSET ?';
        $listParams = $params;
        $listTypes = $types . 'ii';
        $listParams[] = $perPage;
        $listParams[] = $offset;
        $stmt = $db->prepare($listSql);
        exr_bind($stmt, $listTypes, $listParams);
        $stmt->execute();
        $rs = $stmt->get_result();
        while ($r = $rs->fetch_assoc()) $rows[] = $r;
        $stmt->close();
    } catch (Throwable $ex) {
        error_log('Expense report data error: ' . $ex->getMessage());
        $pageError = 'The expense report could not load its data. Check the expense table structure and hosting PHP error log.';
    }
}

$fullName = (string)($_SESSION['full_name'] ?? 'Bursar');
$userRole = (string)($_SESSION['role'] ?? '');
$queryKeep = $_GET;
unset($queryKeep['export']);
$csvQuery = $queryKeep;
$csvQuery['export'] = 'csv';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Expense Report | School Management System</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f6f9;font-family:Arial,Helvetica,sans-serif;color:#343a40}.sidebar{width:250px;position:fixed;inset:0 auto 0 0;background:#212529;color:#fff;overflow-y:auto;z-index:1050;transition:left .25s}.sidebar-header{padding:20px;background:#343a40;text-align:center}.sidebar-header h5{margin:0;font-weight:700}.sidebar-menu{padding:15px 10px}.sidebar-menu a{display:block;color:#ddd;padding:11px 15px;margin-bottom:4px;border-radius:6px;text-decoration:none;font-size:14px}.sidebar-menu a:hover,.sidebar-menu a.active{background:#007bff;color:#fff}.sidebar-menu i{width:25px}.main-content{margin-left:250px;padding:25px}.topbar,.page-header,.stat-card,.content-card{background:#fff;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,.05)}.topbar{padding:15px 20px;margin-bottom:22px}.page-header{padding:20px;margin-bottom:20px}.stat-card{padding:19px;margin-bottom:20px;height:100%}.stat-title{font-size:13px;color:#6c757d;margin-bottom:6px}.stat-value{font-size:22px;font-weight:700;overflow-wrap:anywhere}.stat-icon{width:46px;height:46px;display:flex;align-items:center;justify-content:center;border-radius:10px;background:#e9f5ff;color:#007bff;font-size:19px}.content-card{margin-bottom:24px}.content-card-header{padding:17px 20px;border-bottom:1px solid #eee}.content-card-body{padding:20px}.table thead th{background:#f8f9fa;border-top:none;white-space:nowrap;font-size:12px}.table td{vertical-align:middle;font-size:13px}.amount{font-weight:700;white-space:nowrap}.form-control,.custom-select,.btn{border-radius:6px}.form-control,.custom-select{min-height:40px}.mobile-menu{display:none}.badge{padding:7px 9px}.muted-small{font-size:12px;color:#6c757d}.sidebar-overlay{display:none}.bar-track{height:8px;background:#edf0f5;border-radius:99px;overflow:hidden;min-width:65px}.bar-fill{height:100%;background:#2474d2;border-radius:99px}.empty{text-align:center;color:#718096;padding:35px 10px}@media(max-width:991px){.sidebar{left:-250px}.sidebar.show{left:0}.main-content{margin-left:0;padding:15px}.mobile-menu{display:inline-block}.sidebar-overlay.show{display:block;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:1040}}@media print{.sidebar,.topbar,.no-print,.sidebar-overlay{display:none!important}.main-content{margin:0;padding:0}.content-card,.stat-card,.page-header{box-shadow:none}body{background:#fff}}
</style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-header"><h5><i class="fas fa-school mr-1"></i> School Management</h5><small class="text-muted">Bursar Panel</small></div>
  <nav class="sidebar-menu">
    <a href="/admin/dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="/admin/bursar/students_fees.php"><i class="fas fa-user-graduate"></i> Student Fees</a>
    <a href="/admin/bursar/fee_structure.php"><i class="fas fa-money-check-alt"></i> Fee Structure</a>
    <a href="/admin/bursar/payments.php"><i class="fas fa-money-bill-wave"></i> Student Payments</a>
    <a href="/admin/bursar/outstanding_fees.php"><i class="fas fa-exclamation-circle"></i> Outstanding Fees</a>
    <a href="/admin/bursar/income.php"><i class="fas fa-arrow-circle-down"></i> Income</a>
    <a href="/admin/bursar/expenses.php"><i class="fas fa-arrow-circle-up"></i> Expenses</a>
    <a href="/admin/bursar/suppliers.php"><i class="fas fa-truck"></i> Suppliers</a>
    <a href="/admin/bursar/supplier_payments.php"><i class="fas fa-file-invoice-dollar"></i> Supplier Payments</a>
    <a href="/admin/bursar/salaries.php"><i class="fas fa-users"></i> Salaries</a>
    <a href="/admin/bursar/budgets.php"><i class="fas fa-wallet"></i> Budgets</a>
    <a href="/admin/bursar/cashbook.php"><i class="fas fa-book"></i> Cashbook</a>
    <a href="/admin/bursar/reports.php"><i class="fas fa-chart-bar"></i> Financial Reports</a>
    <a href="/admin/bursar/fees_report.php"><i class="fas fa-file-invoice-dollar"></i> Fees Report</a>
    <a href="/admin/bursar/expense_report.php" class="active"><i class="fas fa-file-alt"></i> Expense Report</a>
    <hr class="bg-secondary"><a href="/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </nav>
</aside>
<main class="main-content">
  <div class="topbar d-flex align-items-center justify-content-between">
    <div><button type="button" class="btn btn-outline-primary mobile-menu mr-2" id="mobileMenuButton"><i class="fas fa-bars"></i></button><strong>Bursar Finance</strong></div>
    <div class="text-right"><strong><?= exr_h($fullName) ?></strong><br><small class="text-muted"><?= exr_h(ucwords(str_replace('_',' ',$userRole))) ?></small></div>
  </div>
  <div class="page-header d-flex flex-wrap justify-content-between align-items-center">
    <div><h3 class="mb-1"><i class="fas fa-file-invoice-dollar text-danger mr-2"></i>Expense Report</h3><p class="text-muted mb-0">Review, analyse and export school expenditure recorded by the bursar.</p></div>
    <div class="mt-2 no-print"><a class="btn btn-success" href="?<?= exr_h(http_build_query($csvQuery)) ?>"><i class="fas fa-file-csv mr-1"></i> Export CSV</a> <button class="btn btn-secondary" type="button" onclick="window.print()"><i class="fas fa-print mr-1"></i> Print Report</button></div>
  </div>

  <?php if ($schemaError !== ''): ?><div class="alert alert-danger"><h5><i class="fas fa-exclamation-triangle mr-1"></i>Database / page configuration error</h5><?= exr_h($schemaError) ?><div class="small mt-2">No records were changed. Open the Expenses page to initialize missing tables, then reload this report.</div></div><?php endif; ?>
  <?php if ($pageError !== ''): ?><div class="alert alert-warning"><strong>Report loading issue:</strong> <?= exr_h($pageError) ?></div><?php endif; ?>

  <section class="content-card no-print"><div class="content-card-header"><h5 class="mb-0"><i class="fas fa-filter mr-2"></i>Filter expense records</h5></div><div class="content-card-body">
    <form method="GET" action="expense_report.php"><div class="form-row">
      <div class="col-lg-2 col-md-4 form-group"><label>From date</label><input class="form-control" type="date" name="date_from" value="<?= exr_h($dateFrom) ?>"></div>
      <div class="col-lg-2 col-md-4 form-group"><label>To date</label><input class="form-control" type="date" name="date_to" value="<?= exr_h($dateTo) ?>"></div>
      <div class="col-lg-3 col-md-4 form-group"><label>Category</label><select class="form-control" name="category_id"><option value="0">All categories</option><?php foreach ($categories as $cat): ?><option value="<?= (int)$cat['id'] ?>" <?= $categoryFilter === (int)$cat['id'] ? 'selected' : '' ?>><?= exr_h($cat['category_name']) ?></option><?php endforeach; ?></select></div>
      <div class="col-lg-2 col-md-4 form-group"><label>Status</label><select class="form-control" name="status"><option value="">All statuses</option><?php foreach (['completed'=>'Completed','cancelled'=>'Cancelled','reversed'=>'Reversed'] as $s => $label): ?><option value="<?= exr_h($s) ?>" <?= $statusFilter === $s ? 'selected' : '' ?>><?= exr_h($label) ?></option><?php endforeach; ?></select></div>
      <div class="col-lg-3 col-md-8 form-group"><label>Search transactions</label><input class="form-control" type="search" name="search" value="<?= exr_h($search) ?>" placeholder="Transaction, payee, category or reference"></div>
    </div><button class="btn btn-primary" type="submit"><i class="fas fa-search mr-1"></i> Apply Filters</button> <a class="btn btn-light" href="expense_report.php">Reset</a></form>
  </div></section>

  <div class="row">
    <div class="col-xl-3 col-md-6"><div class="stat-card"><div class="d-flex justify-content-between"><div><div class="stat-title">Completed expenses</div><div class="stat-value text-danger">UGX <?= exr_money($summary['completed_amount'] ?? 0) ?></div></div><div class="stat-icon" style="background:#fff0f0;color:#d64545"><i class="fas fa-arrow-circle-up"></i></div></div><div class="muted-small mt-2">For the selected filters</div></div></div>
    <div class="col-xl-3 col-md-6"><div class="stat-card"><div class="d-flex justify-content-between"><div><div class="stat-title">Matching records</div><div class="stat-value"><?= number_format((int)($summary['total_records'] ?? 0)) ?></div></div><div class="stat-icon"><i class="fas fa-receipt"></i></div></div><div class="muted-small mt-2">Current filtered results</div></div></div>
    <div class="col-xl-3 col-md-6"><div class="stat-card"><div class="d-flex justify-content-between"><div><div class="stat-title">Cancelled amount</div><div class="stat-value text-secondary">UGX <?= exr_money($summary['cancelled_amount'] ?? 0) ?></div></div><div class="stat-icon" style="background:#f0f1f3;color:#657184"><i class="fas fa-ban"></i></div></div><div class="muted-small mt-2">Not included in completed expenses</div></div></div>
    <div class="col-xl-3 col-md-6"><div class="stat-card"><div class="d-flex justify-content-between"><div><div class="stat-title">Reversed amount</div><div class="stat-value text-warning">UGX <?= exr_money($summary['reversed_amount'] ?? 0) ?></div></div><div class="stat-icon" style="background:#fff6e5;color:#be8317"><i class="fas fa-undo"></i></div></div><div class="muted-small mt-2">Reversed entries retained for audit</div></div></div>
  </div>

  <section class="content-card"><div class="content-card-header d-flex justify-content-between align-items-center flex-wrap"><h5 class="mb-1"><i class="fas fa-list-alt mr-2"></i>Expense transaction register</h5><span class="badge badge-primary"><?= number_format($totalRecords) ?> record(s)</span></div>
    <div class="table-responsive"><table class="table table-hover table-bordered mb-0"><thead><tr><th>#</th><th>Transaction No.</th><th>Category / Purpose</th><th>Payee / Supplier</th><th>Payment Date</th><th>Payment Method</th><th>Reference</th><th>Recorded By</th><th>Status</th><th class="text-right">Amount (UGX)</th></tr></thead><tbody>
    <?php if (!$rows): ?><tr><td colspan="10"><div class="empty"><i class="fas fa-file-invoice-dollar fa-2x mb-2"></i><h5>No expense records found</h5><div>Change the selected filters or record an expense on the Expenses page.</div></div></td></tr><?php else: $rowNo = $offset + 1; foreach ($rows as $row): $rowStatus = strtolower((string)($row['status'] ?? '')); $badge = $rowStatus === 'completed' ? 'success' : ($rowStatus === 'cancelled' ? 'secondary' : 'warning'); ?>
      <tr><td><?= $rowNo++ ?></td><td><strong><?= exr_h($row['transaction_no']) ?></strong></td><td><strong><?= exr_h($row['category_name']) ?></strong><?php if (trim((string)$row['description']) !== ''): ?><br><small class="text-muted"><?= exr_h(function_exists('mb_strimwidth') ? mb_strimwidth((string)$row['description'], 0, 90, '…') : substr((string)$row['description'], 0, 90)) ?></small><?php endif; ?></td><td><?= exr_h($row['payee_name'] ?: '—') ?></td><td><?= !empty($row['expense_date']) && strtotime((string)$row['expense_date']) ? exr_h(date('d M Y H:i', strtotime((string)$row['expense_date']))) : '—' ?></td><td><?= exr_h($row['payment_method']) ?></td><td><?= exr_h($row['reference_no'] ?: '—') ?></td><td><?= exr_h($row['created_by_name']) ?></td><td><span class="badge badge-<?= exr_h($badge) ?>"><?= exr_h(ucfirst($rowStatus ?: 'unknown')) ?></span></td><td class="text-right amount <?= $rowStatus === 'completed' ? 'text-danger' : 'text-muted' ?>"><?= $rowStatus === 'completed' ? '' : '— ' ?><?= exr_money($row['amount']) ?></td></tr>
    <?php endforeach; endif; ?></tbody></table></div>
    <?php if ($totalPages > 1): ?><div class="p-3 no-print"><nav aria-label="Expense report pages"><ul class="pagination mb-0 flex-wrap"><?php $pageQuery = $_GET; $pageQuery['page'] = max(1, $page - 1); ?><li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="?<?= exr_h(http_build_query($pageQuery)) ?>">Previous</a></li><?php for ($p = max(1, $page - 2); $p <= min($totalPages, $page + 2); $p++): $pageQuery['page'] = $p; ?><li class="page-item <?= $p === $page ? 'active' : '' ?>"><a class="page-link" href="?<?= exr_h(http_build_query($pageQuery)) ?>"><?= $p ?></a></li><?php endfor; ?><?php $pageQuery['page'] = min($totalPages, $page + 1); ?><li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>"><a class="page-link" href="?<?= exr_h(http_build_query($pageQuery)) ?>">Next</a></li></ul></nav></div><?php endif; ?>
  </section>

  <div class="row">
    <div class="col-lg-6"><section class="content-card"><div class="content-card-header"><h5 class="mb-0"><i class="fas fa-tags mr-2"></i>Expense breakdown by category</h5></div><div class="content-card-body">
      <?php if (!$categorySummary): ?><div class="empty">No category summary for these filters.</div><?php else: $maxCat = 0.0; foreach ($categorySummary as $cr) $maxCat = max($maxCat, (float)$cr['completed_total']); foreach ($categorySummary as $cr): $pct = $maxCat > 0 ? ((float)$cr['completed_total'] / $maxCat) * 100 : 0; ?><div class="mb-3"><div class="d-flex justify-content-between mb-1"><strong><?= exr_h($cr['category_name']) ?></strong><span class="text-danger font-weight-bold">UGX <?= exr_money($cr['completed_total']) ?></span></div><div class="bar-track"><div class="bar-fill" style="width:<?= number_format($pct, 2, '.', '') ?>%"></div></div><small class="text-muted"><?= number_format((int)$cr['record_count']) ?> record(s)</small></div><?php endforeach; endif; ?>
    </div></section></div>
    <div class="col-lg-6"><section class="content-card"><div class="content-card-header"><h5 class="mb-0"><i class="fas fa-calendar-alt mr-2"></i>Monthly completed expenses</h5></div><div class="table-responsive"><table class="table table-sm table-hover mb-0"><thead><tr><th>Month</th><th>Transactions</th><th class="text-right">Total (UGX)</th></tr></thead><tbody><?php if (!$monthlySummary): ?><tr><td colspan="3" class="text-center text-muted py-4">No completed expenses for the selected date range.</td></tr><?php else: foreach ($monthlySummary as $m): ?><tr><td><?= exr_h($m['month_label']) ?></td><td><?= number_format((int)$m['record_count']) ?></td><td class="text-right font-weight-bold text-danger"><?= exr_money($m['total_amount']) ?></td></tr><?php endforeach; endif; ?></tbody></table></div></section></div>
  </div>
  <p class="muted-small text-center">School Management System &mdash; Bursar Expense Report. Completed amounts exclude cancelled and reversed entries.</p>
</main>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function(){const sidebar=document.getElementById('sidebar');const overlay=document.getElementById('sidebarOverlay');const button=document.getElementById('mobileMenuButton');function closeMenu(){sidebar.classList.remove('show');overlay.classList.remove('show');}if(button)button.addEventListener('click',function(){sidebar.classList.toggle('show');overlay.classList.toggle('show');});if(overlay)overlay.addEventListener('click',closeMenu);document.addEventListener('keydown',function(e){if(e.key==='Escape')closeMenu();});})();
</script>
</body>
</html>
