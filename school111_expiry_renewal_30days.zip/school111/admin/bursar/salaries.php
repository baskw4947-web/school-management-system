<?php
/**
 * School staff salary management page.
 * Complete page with responsive bursar sidebar and dynamic staff/salary schema support.
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator', 'bursar']);

if (!isset($conn) || !($conn instanceof mysqli)) {
    http_response_code(500);
    exit('Database connection is unavailable. Please check config/database.php.');
}
$conn->set_charset('utf8mb4');
if (session_status() === PHP_SESSION_NONE) session_start();

function salE($value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8'); }
function salFlash(string $type, string $message): void { $_SESSION['salaries_flash'] = ['type' => $type, 'message' => $message]; }
function salRedirect(string $url = 'salaries.php'): void { header('Location: ' . $url); exit; }
function salUserId(): int {
    if (isset($_SESSION['user_id']) && is_numeric($_SESSION['user_id'])) return (int)$_SESSION['user_id'];
    if (isset($_SESSION['id']) && is_numeric($_SESSION['id'])) return (int)$_SESSION['id'];
    if (isset($_SESSION['user']['id']) && is_numeric($_SESSION['user']['id'])) return (int)$_SESSION['user']['id'];
    return 0;
}
function salIdent(string $name): string { return '`' . str_replace('`', '``', $name) . '`'; }
function salFirstColumn(array $columns, array $candidates): ?string {
    foreach ($candidates as $candidate) if (isset($columns[$candidate])) return $candidate;
    return null;
}
function salEnumValues(string $type): array {
    if (stripos($type, 'enum(') !== 0) return [];
    preg_match_all("/'((?:[^'\\\\]|\\\\.)*)'/", $type, $matches);
    return array_map(static fn($v) => stripcslashes($v), $matches[1] ?? []);
}
function salTableColumns(mysqli $conn, string $table): array {
    $columns = [];
    $result = $conn->query('SHOW COLUMNS FROM ' . salIdent($table));
    while ($row = $result->fetch_assoc()) $columns[$row['Field']] = $row;
    $result->free();
    return $columns;
}
function salBindExecute(mysqli_stmt $stmt, string $types, array &$values): void {
    if ($types !== '') {
        $params = [$types];
        foreach ($values as $key => &$value) $params[] = &$value;
        call_user_func_array([$stmt, 'bind_param'], $params);
    }
    $stmt->execute();
}
function salGenerateNumber(mysqli $conn, string $column, string $prefix = 'SAL-'): string {
    for ($i = 0; $i < 12; $i++) {
        $candidate = $prefix . date('Ymd-His') . '-' . strtoupper(bin2hex(random_bytes(2)));
        $stmt = $conn->prepare('SELECT 1 FROM `salaries` WHERE ' . salIdent($column) . ' = ? LIMIT 1');
        $stmt->bind_param('s', $candidate);
        $stmt->execute();
        $found = (bool)$stmt->get_result()->fetch_row();
        $stmt->close();
        if (!$found) return $candidate;
    }
    throw new RuntimeException('A unique salary number could not be generated. Please try again.');
}
function salHumanSource(string $table): string {
    $labels = ['employees'=>'Employee','staff'=>'Staff member','school_staff'=>'School staff','teachers'=>'Teacher','non_teaching_staff'=>'Non-teaching staff','admin_staff'=>'Administrative staff','users'=>'User account'];
    return $labels[$table] ?? ucwords(str_replace('_', ' ', $table));
}
function salIsActiveStatus(string $status): bool { return !in_array(strtolower($status), ['inactive','cancelled','canceled','reversed','disabled','terminated','deleted'], true); }
function salRowDisplayName(array $row, array $map, array $peopleByKey): string {
    if (!empty($map['name']) && trim((string)($row[$map['name']] ?? '')) !== '') return trim((string)$row[$map['name']]);
    $idColumn = $map['person_id'] ?? null;
    if ($idColumn && !empty($row[$idColumn])) {
        $source = $map['person_source'] ? (string)($row[$map['person_source']] ?? '') : '';
        if ($source !== '' && isset($peopleByKey[$source . ':' . (int)$row[$idColumn]])) return $peopleByKey[$source . ':' . (int)$row[$idColumn]]['person_name'];
        $matches = [];
        foreach ($peopleByKey as $person) if ((int)$person['person_id'] === (int)$row[$idColumn]) $matches[] = $person['person_name'];
        if (count($matches) === 1) return $matches[0];
        return 'Personnel #' . (int)$row[$idColumn];
    }
    return 'Name not available';
}
function salRowAmount(array $row, ?string $column): float { return $column ? (float)($row[$column] ?? 0) : 0.0; }
function salRowNet(array $row, array $map): float {
    if (!empty($map['net']) && isset($row[$map['net']])) return (float)$row[$map['net']];
    return salRowAmount($row, $map['basic']) + salRowAmount($row, $map['allowances']) - salRowAmount($row, $map['deductions']);
}

if (empty($_SESSION['salaries_csrf'])) $_SESSION['salaries_csrf'] = bin2hex(random_bytes(32));
$csrfToken = (string)$_SESSION['salaries_csrf'];
$flash = $_SESSION['salaries_flash'] ?? null;
unset($_SESSION['salaries_flash']);
$pageError = '';
$schemaError = '';
$staffPeople = [];
$staffSources = [];
$salaryRows = [];
$salaryColumns = [];
$createdDefaultTable = false;
$staffSourceNote = '';

try {
    $tableResult = $conn->query('SHOW TABLES');
    $tableNames = [];
    while ($row = $tableResult->fetch_row()) $tableNames[] = (string)$row[0];
    $tableResult->free();

    if (!in_array('salaries', $tableNames, true)) {
        $conn->query("CREATE TABLE `salaries` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `salary_no` VARCHAR(50) NOT NULL,
            `person_source` VARCHAR(60) DEFAULT NULL,
            `person_id` INT(11) DEFAULT NULL,
            `person_name` VARCHAR(150) NOT NULL,
            `person_role` VARCHAR(100) DEFAULT NULL,
            `basic_salary` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            `allowances` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            `deductions` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            `net_salary` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            `pay_frequency` VARCHAR(30) NOT NULL DEFAULT 'monthly',
            `effective_date` DATE DEFAULT NULL,
            `status` VARCHAR(20) NOT NULL DEFAULT 'active',
            `created_by` INT(11) DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`), UNIQUE KEY `uq_salaries_salary_no` (`salary_no`),
            KEY `idx_salaries_person` (`person_source`,`person_id`), KEY `idx_salaries_status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $createdDefaultTable = true;
        $tableNames[] = 'salaries';
    }
    $salaryColumns = salTableColumns($conn, 'salaries');

    $sourceSpecs = [
        'employees'=>['id'=>['id','employee_id'],'name'=>['employee_name','full_name','name','staff_name'],'first'=>['first_name'],'last'=>['last_name','surname'],'role'=>['job_title','position','designation','role','department'],'email'=>['email','email_address'],'phone'=>['phone','phone_number','mobile'],'status'=>['status','is_active','active']],
        'staff'=>['id'=>['id','staff_id'],'name'=>['staff_name','full_name','name','employee_name'],'first'=>['first_name'],'last'=>['last_name','surname'],'role'=>['job_title','position','designation','staff_type','role'],'email'=>['email','email_address'],'phone'=>['phone','phone_number','mobile'],'status'=>['status','is_active','active']],
        'school_staff'=>['id'=>['id','staff_id','person_id'],'name'=>['staff_name','full_name','name','employee_name'],'first'=>['first_name'],'last'=>['last_name','surname'],'role'=>['job_title','position','designation','staff_type','role'],'email'=>['email','email_address'],'phone'=>['phone','phone_number','mobile'],'status'=>['status','is_active','active']],
        'teachers'=>['id'=>['id','teacher_id'],'name'=>['teacher_name','full_name','name','staff_name'],'first'=>['first_name'],'last'=>['last_name','surname'],'role'=>['job_title','position','designation','subject','role'],'email'=>['email','email_address'],'phone'=>['phone','phone_number','mobile'],'status'=>['status','is_active','active']],
        'non_teaching_staff'=>['id'=>['id','staff_id'],'name'=>['staff_name','full_name','name','employee_name'],'first'=>['first_name'],'last'=>['last_name','surname'],'role'=>['job_title','position','designation','role'],'email'=>['email','email_address'],'phone'=>['phone','phone_number','mobile'],'status'=>['status','is_active','active']],
        'admin_staff'=>['id'=>['id','staff_id','employee_id'],'name'=>['full_name','staff_name','employee_name','name'],'first'=>['first_name'],'last'=>['last_name','surname'],'role'=>['job_title','position','designation','role'],'email'=>['email','email_address'],'phone'=>['phone','phone_number','mobile'],'status'=>['status','is_active','active']],
        'users'=>['id'=>['id','user_id'],'name'=>['full_name','name','staff_name','username'],'first'=>['first_name'],'last'=>['last_name','surname'],'role'=>['role','user_role','user_type','account_type','position'],'email'=>['email','email_address'],'phone'=>['phone','phone_number','mobile'],'status'=>['status','is_active','active']],
    ];
    $dedicatedFound = false;
    foreach (['employees','staff','school_staff','teachers','non_teaching_staff','admin_staff'] as $t) if (in_array($t, $tableNames, true)) $dedicatedFound = true;

    foreach ($sourceSpecs as $sourceTable => $spec) {
        if (!in_array($sourceTable, $tableNames, true)) continue;
        if ($sourceTable === 'users' && $dedicatedFound) continue;
        $cols = salTableColumns($conn, $sourceTable);
        $idCol = salFirstColumn($cols, $spec['id']);
        $nameCol = salFirstColumn($cols, $spec['name']);
        $firstCol = salFirstColumn($cols, $spec['first']);
        $lastCol = salFirstColumn($cols, $spec['last']);
        if (!$idCol || (!$nameCol && !$firstCol)) continue;
        $roleCol = salFirstColumn($cols, $spec['role']);
        $emailCol = salFirstColumn($cols, $spec['email']);
        $phoneCol = salFirstColumn($cols, $spec['phone']);
        $statusCol = salFirstColumn($cols, $spec['status']);
        $select = salIdent($idCol) . ' AS _person_id';
        if ($nameCol) $select .= ', ' . salIdent($nameCol) . ' AS _person_name';
        else {
            $parts = [salIdent($firstCol)];
            if ($lastCol) $parts[] = salIdent($lastCol);
            $select .= ", CONCAT_WS(' ', " . implode(', ', $parts) . ') AS _person_name';
        }
        $select .= $roleCol ? ', ' . salIdent($roleCol) . ' AS _person_role' : ", '' AS _person_role";
        $select .= $emailCol ? ', ' . salIdent($emailCol) . ' AS _person_email' : ", '' AS _person_email";
        $select .= $phoneCol ? ', ' . salIdent($phoneCol) . ' AS _person_phone' : ", '' AS _person_phone";
        $select .= $statusCol ? ', ' . salIdent($statusCol) . ' AS _person_status' : ", 'active' AS _person_status";
        $res = $conn->query('SELECT ' . $select . ' FROM ' . salIdent($sourceTable) . ' ORDER BY _person_name');
        $count = 0;
        while ($person = $res->fetch_assoc()) {
            $name = trim((string)$person['_person_name']);
            if ($name === '') continue;
            $role = trim((string)$person['_person_role']);
            if ($sourceTable === 'users') {
                $lowerRole = strtolower($role);
                if (preg_match('/student|parent|guardian|pupil|learner/', $lowerRole)) continue;
                if ($lowerRole !== '' && !preg_match('/teacher|admin|bursar|staff|employee|head.?teacher|accountant|librarian|secretary|director|principal|finance|support|warden|cook|security|driver|nurse|matron|caretaker|registrar|deputy|manager/', $lowerRole)) continue;
            }
            $staffPeople[] = [
                'source_table'=>$sourceTable, 'source_label'=>salHumanSource($sourceTable),
                'person_id'=>(int)$person['_person_id'], 'person_name'=>$name,
                'person_role'=>$role !== '' ? $role : salHumanSource($sourceTable),
                'person_email'=>trim((string)$person['_person_email']), 'person_phone'=>trim((string)$person['_person_phone']),
                'person_status'=>(string)$person['_person_status']
            ];
            $count++;
        }
        $res->free();
        if ($count) $staffSources[] = $sourceTable;
    }
    $seenEmail = $seenName = $deduped = [];
    foreach ($staffPeople as $person) {
        $email = strtolower(trim($person['person_email']));
        $name = strtolower(trim($person['person_name']));
        if (($email !== '' && isset($seenEmail[$email])) || ($name !== '' && isset($seenName[$name]))) continue;
        if ($email !== '') $seenEmail[$email] = true;
        if ($name !== '') $seenName[$name] = true;
        $deduped[] = $person;
    }
    $staffPeople = $deduped;
    if (!$staffPeople) $staffSourceNote = 'No staff directory was detected. You can still enter a person manually if the salaries table contains a name column.';
} catch (Throwable $e) {
    error_log('salaries.php initialisation error: ' . $e->getMessage());
    $schemaError = 'The page could not load the salary or personnel database structure. Check your database tables and PHP error log.';
}

$map = [
    'id'=>salFirstColumn($salaryColumns,['id','salary_id']),
    'number'=>salFirstColumn($salaryColumns,['salary_no','salary_number','record_no','salary_code']),
    'person_source'=>salFirstColumn($salaryColumns,['person_source','source_table','staff_source']),
    'person_id'=>salFirstColumn($salaryColumns,['person_id','staff_id','employee_id','teacher_id','user_id','personnel_id']),
    'name'=>salFirstColumn($salaryColumns,['person_name','employee_name','staff_name','teacher_name','full_name','name']),
    'role'=>salFirstColumn($salaryColumns,['person_role','job_title','position','designation','staff_role','role']),
    'basic'=>salFirstColumn($salaryColumns,['basic_salary','base_salary','salary_amount','monthly_salary','salary','gross_salary','basic_pay','amount']),
    'allowances'=>salFirstColumn($salaryColumns,['allowances','allowance','total_allowances']),
    'deductions'=>salFirstColumn($salaryColumns,['deductions','deduction','total_deductions']),
    'net'=>salFirstColumn($salaryColumns,['net_salary','net_pay','take_home_pay','take_home']),
    'frequency'=>salFirstColumn($salaryColumns,['pay_frequency','salary_frequency','frequency','payment_frequency']),
    'effective'=>salFirstColumn($salaryColumns,['effective_date','start_date','date_effective','salary_date']),
    'status'=>salFirstColumn($salaryColumns,['status','salary_status']),
    'created_by'=>salFirstColumn($salaryColumns,['created_by','recorded_by','user_id_created']),
    'created_at'=>salFirstColumn($salaryColumns,['created_at','date_created']),
    'updated_at'=>salFirstColumn($salaryColumns,['updated_at','modified_at'])
];
$peopleByKey = [];
foreach ($staffPeople as $person) $peopleByKey[$person['source_table'] . ':' . $person['person_id']] = $person;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $schemaError === '') {
    if (!hash_equals($csrfToken, (string)($_POST['csrf_token'] ?? ''))) {
        salFlash('danger', 'Your form session expired. Refresh the page and try again.');
        salRedirect();
    }
    $action = (string)($_POST['action'] ?? '');
    try {
        if (in_array($action, ['save_salary','update_salary'], true)) {
            if (!$map['id'] || (!$map['basic'] && !$map['net'])) throw new RuntimeException('The salaries table needs an ID column and a salary amount column.');
            $editId = (int)($_POST['salary_id'] ?? 0);
            $personKey = trim((string)($_POST['person_key'] ?? ''));
            $person = null;
            if ($personKey === '__manual__') {
                if (!$map['name']) throw new RuntimeException('Your salaries table does not contain a name column for manual staff entries.');
                $manualName = trim((string)($_POST['manual_name'] ?? ''));
                if ($manualName === '') throw new RuntimeException('Enter the staff member’s full name.');
                $person = ['source_table'=>'manual','person_id'=>0,'person_name'=>$manualName,'person_role'=>trim((string)($_POST['manual_role'] ?? '')) ?: 'School staff'];
            } else {
                $parts = explode(':', $personKey, 2);
                if (count($parts) === 2 && ctype_digit($parts[1])) $person = $peopleByKey[$parts[0] . ':' . (int)$parts[1]] ?? null;
                if (!$person) throw new RuntimeException('Select a valid staff member or choose Person not listed.');
            }
            $basic = filter_var($_POST['basic_salary'] ?? null, FILTER_VALIDATE_FLOAT);
            $allowances = filter_var($_POST['allowances'] ?? '0', FILTER_VALIDATE_FLOAT);
            $deductions = filter_var($_POST['deductions'] ?? '0', FILTER_VALIDATE_FLOAT);
            $effectiveInput = trim((string)($_POST['effective_date'] ?? date('Y-m-d')));
            $effectiveDate = DateTime::createFromFormat('!Y-m-d', $effectiveInput);
            $frequency = trim((string)($_POST['pay_frequency'] ?? 'monthly'));
            $status = trim((string)($_POST['status'] ?? 'active'));
            if ($basic === false || !is_finite((float)$basic) || $basic < 0) throw new RuntimeException('Enter a valid basic salary amount.');
            if ($allowances === false || !is_finite((float)$allowances) || $allowances < 0) throw new RuntimeException('Enter a valid allowances amount.');
            if ($deductions === false || !is_finite((float)$deductions) || $deductions < 0) throw new RuntimeException('Enter a valid deductions amount.');
            $netSalary = (float)$basic + (float)$allowances - (float)$deductions;
            if ($netSalary < 0) throw new RuntimeException('Deductions cannot be greater than basic salary plus allowances.');
            if (!$effectiveDate || $effectiveDate->format('Y-m-d') !== $effectiveInput) throw new RuntimeException('Choose a valid effective date.');
            $freqEnum = $map['frequency'] ? salEnumValues((string)$salaryColumns[$map['frequency']]['Type']) : [];
            if ($freqEnum && !in_array($frequency, $freqEnum, true)) $frequency = in_array('monthly',$freqEnum,true) ? 'monthly' : $freqEnum[0];
            $statusEnum = $map['status'] ? salEnumValues((string)$salaryColumns[$map['status']]['Type']) : [];
            if ($statusEnum && !in_array($status,$statusEnum,true)) $status = in_array('active',$statusEnum,true) ? 'active' : $statusEnum[0];

            $values = []; $types = '';
            $put = static function (?string $column, $value, string $type) use (&$values,&$types,$salaryColumns): void {
                if ($column && isset($salaryColumns[$column])) { $values[$column] = $value; $types .= $type; }
            };
            if ($map['person_source']) $put($map['person_source'],$person['source_table'],'s');
            if ($map['person_id']) {
                $linkColumn = $map['person_id'];
                if ($person['source_table'] !== 'manual') {
                    if (in_array($linkColumn,['teacher_id'],true) && $person['source_table'] !== 'teachers') {
                        if (!$map['name']) throw new RuntimeException('The salary table only links teachers. Select a teacher or add a compatible name column.');
                    } elseif (in_array($linkColumn,['employee_id'],true) && $person['source_table'] !== 'employees') {
                        if (!$map['name']) throw new RuntimeException('The salary table only links employees. Select an employee or add a compatible name column.');
                    } elseif (in_array($linkColumn,['staff_id','personnel_id'],true) && !in_array($person['source_table'],['staff','school_staff','non_teaching_staff','admin_staff'],true)) {
                        if (!$map['name']) throw new RuntimeException('The salary table does not have a compatible personnel ID for the selected source.');
                    } else $put($linkColumn,(int)$person['person_id'],'i');
                } elseif ($linkColumn === 'person_id') $put($linkColumn,null,'i');
                elseif (!$map['name']) throw new RuntimeException('Select staff from the directory; this table requires a personnel ID.');
            }
            if ($map['name']) $put($map['name'],$person['person_name'],'s');
            if ($map['role']) $put($map['role'],$person['person_role'],'s');
            if ($map['basic']) $put($map['basic'],(float)$basic,'d');
            if ($map['allowances']) $put($map['allowances'],(float)$allowances,'d');
            if ($map['deductions']) $put($map['deductions'],(float)$deductions,'d');
            if ($map['net'] && $map['net'] !== $map['basic']) $put($map['net'],$netSalary,'d');
            if ($map['frequency']) $put($map['frequency'],$frequency,'s');
            if ($map['effective']) {
                $dateType = strtolower((string)$salaryColumns[$map['effective']]['Type']);
                $put($map['effective'],(strpos($dateType,'datetime') !== false || strpos($dateType,'timestamp') !== false) ? $effectiveInput . ' ' . date('H:i:s') : $effectiveInput,'s');
            }
            if ($map['status']) $put($map['status'],$status,'s');
            if ($map['updated_at']) $put($map['updated_at'],date('Y-m-d H:i:s'),'s');
            if ($action === 'save_salary') {
                if ($map['number']) $put($map['number'],salGenerateNumber($conn,$map['number']),'s');
                if ($map['created_by'] && salUserId() > 0) $put($map['created_by'],salUserId(),'i');
                if (!$values) throw new RuntimeException('No compatible salary columns were found.');
                $cols = array_keys($values);
                $sql = 'INSERT INTO `salaries` (' . implode(',',array_map('salIdent',$cols)) . ') VALUES (' . implode(',',array_fill(0,count($cols),'?')) . ')';
                $stmt = $conn->prepare($sql); $insertValues = array_values($values); salBindExecute($stmt,$types,$insertValues); $stmt->close();
                salFlash('success','Salary record saved for ' . $person['person_name'] . '. Net salary: UGX ' . number_format($netSalary,2) . '.');
            } else {
                if ($editId < 1) throw new RuntimeException('Invalid salary record selected for updating.');
                $sets = []; foreach (array_keys($values) as $col) $sets[] = salIdent($col) . ' = ?';
                $updateValues = array_values($values); $updateTypes = $types . 'i'; $updateValues[] = $editId;
                $stmt = $conn->prepare('UPDATE `salaries` SET ' . implode(',',$sets) . ' WHERE ' . salIdent($map['id']) . ' = ?');
                salBindExecute($stmt,$updateTypes,$updateValues); $stmt->close();
                salFlash('success','Salary record updated for ' . $person['person_name'] . '.');
            }
            salRedirect();
        }
        if ($action === 'toggle_status') {
            $salaryId = (int)($_POST['salary_id'] ?? 0); $newStatus = trim((string)($_POST['new_status'] ?? 'inactive'));
            if (!$map['id'] || !$map['status'] || $salaryId < 1) throw new RuntimeException('This salary table does not support status changes.');
            $allowed = salEnumValues((string)$salaryColumns[$map['status']]['Type']);
            if ($allowed && !in_array($newStatus,$allowed,true)) throw new RuntimeException('Invalid salary status selected.');
            if (!$allowed && !in_array($newStatus,['active','inactive'],true)) throw new RuntimeException('Invalid salary status selected.');
            $sql = 'UPDATE `salaries` SET ' . salIdent($map['status']) . ' = ?';
            if ($map['updated_at']) $sql .= ', ' . salIdent($map['updated_at']) . ' = NOW()';
            $sql .= ' WHERE ' . salIdent($map['id']) . ' = ?';
            $stmt = $conn->prepare($sql); $stmt->bind_param('si',$newStatus,$salaryId); $stmt->execute(); $stmt->close();
            salFlash('success','Salary record status changed to ' . $newStatus . '.'); salRedirect();
        }
    } catch (Throwable $e) {
        error_log('salaries.php form error: ' . $e->getMessage());
        salFlash('danger',$e instanceof RuntimeException ? $e->getMessage() : 'The salary record could not be saved. Check the salary table structure and PHP error log.');
        salRedirect();
    }
}

$editRow = null;
$editId = (int)($_GET['edit'] ?? 0);
if ($editId > 0 && $map['id'] && $schemaError === '') {
    try {
        $stmt = $conn->prepare('SELECT * FROM `salaries` WHERE ' . salIdent($map['id']) . ' = ? LIMIT 1');
        $stmt->bind_param('i',$editId); $stmt->execute(); $editRow = $stmt->get_result()->fetch_assoc() ?: null; $stmt->close();
        if (!$editRow) { salFlash('warning','That salary record was not found.'); salRedirect(); }
    } catch (Throwable $e) { error_log('salaries.php edit error: ' . $e->getMessage()); $pageError = 'The selected salary record could not be loaded.'; }
}
if ($schemaError === '' && $map['id']) {
    try {
        $res = $conn->query('SELECT * FROM `salaries` ORDER BY ' . salIdent($map['id']) . ' DESC');
        while ($row = $res->fetch_assoc()) $salaryRows[] = $row;
        $res->free();
    } catch (Throwable $e) { error_log('salaries.php list error: ' . $e->getMessage()); $pageError = 'Salary records could not be loaded. Check your database table structure.'; }
}
$search = trim((string)($_GET['q'] ?? ''));
$statusFilter = trim((string)($_GET['status'] ?? ''));
$filteredRows = []; $activeCount = 0; $activeNetTotal = 0.0;
foreach ($salaryRows as $row) {
    $displayName = salRowDisplayName($row,$map,$peopleByKey);
    $rowStatus = $map['status'] ? (string)($row[$map['status']] ?? 'active') : 'active';
    $role = $map['role'] ? trim((string)($row[$map['role']] ?? '')) : '';
    $number = $map['number'] ? (string)($row[$map['number']] ?? '') : ('SAL-' . (int)($row[$map['id']] ?? 0));
    $net = salRowNet($row,$map);
    if (salIsActiveStatus($rowStatus)) { $activeCount++; $activeNetTotal += $net; }
    $haystack = strtolower($displayName . ' ' . $role . ' ' . $number . ' ' . $rowStatus . ' ' . ($map['person_source'] ? (string)($row[$map['person_source']] ?? '') : ''));
    if ($search !== '' && strpos($haystack,strtolower($search)) === false) continue;
    if ($statusFilter !== '' && strtolower($rowStatus) !== strtolower($statusFilter)) continue;
    $row['_display_name'] = $displayName; $row['_display_role'] = $role; $row['_display_number'] = $number; $row['_display_status'] = $rowStatus; $row['_display_net'] = $net;
    $filteredRows[] = $row;
}
$page = max(1,(int)($_GET['page'] ?? 1)); $perPage = 10; $totalRows = count($filteredRows); $totalPages = max(1,(int)ceil($totalRows/$perPage));
if ($page > $totalPages) $page = $totalPages;
$visibleRows = array_slice($filteredRows,($page-1)*$perPage,$perPage);
$frequencyOptions = $map['frequency'] ? salEnumValues((string)($salaryColumns[$map['frequency']]['Type'] ?? '')) : [];
if (!$frequencyOptions) $frequencyOptions = ['monthly','weekly','fortnightly','daily','termly'];
$statusOptions = $map['status'] ? salEnumValues((string)($salaryColumns[$map['status']]['Type'] ?? '')) : [];
if (!$statusOptions) $statusOptions = ['active','inactive'];
$editPersonKey = ''; $editManualName = ''; $editManualRole = '';
if ($editRow) {
    $source = $map['person_source'] ? (string)($editRow[$map['person_source']] ?? '') : '';
    $personId = $map['person_id'] ? (int)($editRow[$map['person_id']] ?? 0) : 0;
    if ($source !== '' && $personId > 0 && isset($peopleByKey[$source . ':' . $personId])) $editPersonKey = $source . ':' . $personId;
    elseif ($map['name'] && trim((string)($editRow[$map['name']] ?? '')) !== '') { $editPersonKey = '__manual__'; $editManualName = (string)$editRow[$map['name']]; $editManualRole = $map['role'] ? (string)($editRow[$map['role']] ?? '') : ''; }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Staff Salaries | School Management System</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
:root{--navy:#212529;--navy2:#343a40;--accent:#dc3545;--bg:#f4f6fa;--ink:#202b3c;--muted:#6c7788;--line:#e5eaf2}
*{box-sizing:border-box}body{background:#f5f6fa;color:var(--ink);font-family:Arial,Helvetica,sans-serif;font-size:14px;margin:0}
.sidebar{position:fixed;top:0;left:0;bottom:0;width:250px;background:#212529;color:#fff;z-index:1030;overflow-y:auto;transition:transform .2s;padding:0}
.sidebar-header{padding:20px 15px;color:#fff;font-weight:700;border-bottom:1px solid rgba(255,255,255,.1)}
.sidebar-menu{padding:15px 10px}
.sidebar-section{color:#6c757d;font-size:11px;text-transform:uppercase;padding:12px 10px 6px}
.sidebar a{display:block;color:#ced4da;padding:12px 15px;margin-bottom:3px;text-decoration:none;border-radius:6px;font-size:13px;line-height:1.35}
.sidebar a:hover{background:#343a40;color:#fff}
.sidebar a.active{background:#dc3545;color:#fff}
.sidebar i{width:25px;text-align:center;margin-right:5px}
.sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:1025}.sidebar-overlay.show{display:block}
.main{margin-left:250px;padding:26px;min-width:0}.topline{display:flex;justify-content:space-between;align-items:center;gap:14px;margin-bottom:24px}.eyebrow{color:var(--muted);text-transform:uppercase;letter-spacing:.08em;font-size:11px;font-weight:700}.page-title{font-size:27px;font-weight:700;margin:2px 0 0}.subtitle{color:var(--muted);margin-top:5px}
.card{border:1px solid var(--line);border-radius:12px;box-shadow:0 4px 18px rgba(24,42,77,.035);margin-bottom:20px}.card-header{background:#fff;border-bottom:1px solid var(--line);font-weight:700;padding:15px 18px;border-radius:12px 12px 0 0!important}.card-body{padding:19px}
.stat-card{display:flex;align-items:center;gap:14px;min-height:108px}.stat-icon{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;justify-content:center;background:#e9f2ff;color:#2f80ed;font-size:19px}.stat-label{color:var(--muted);font-size:12px}.stat-value{font-size:22px;font-weight:700;margin-top:4px;line-height:1.2;word-break:break-word}
.form-control{border-color:#dce3ee;border-radius:7px;height:40px;font-size:13px}.form-control:focus{border-color:#dc3545;box-shadow:0 0 0 .15rem rgba(220,53,69,.12)}textarea.form-control{height:auto}.btn{border-radius:7px;font-size:13px;font-weight:600}.btn-primary{background:var(--accent);border-color:var(--accent)}.table{font-size:12.5px;margin-bottom:0}.table thead th{border-top:0;background:#f8faff;color:#536077;font-size:11px;text-transform:uppercase;letter-spacing:.04em;white-space:nowrap}.table td,.table th{vertical-align:middle;padding:12px 10px;border-color:#edf0f5}.person-name{font-weight:700;color:#263750}.meta{font-size:11px;color:#7b8698;margin-top:3px}.money{font-weight:700;white-space:nowrap}.badge-status{display:inline-block;padding:5px 9px;border-radius:20px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.03em}.badge-active{background:#e2f7ed;color:#17764c}.badge-inactive{background:#edf0f4;color:#697586}.badge-other{background:#fff0d8;color:#895600}.required{color:#dc3545}.hint{font-size:11px;color:var(--muted)}.empty-state{padding:38px 15px;text-align:center;color:var(--muted)}.empty-state i{font-size:32px;margin-bottom:12px;color:#c5cfdd}
.mobile-menu{display:none}
@media(max-width:991px){.sidebar{transform:translateX(-100%)}.sidebar.show{transform:translateX(0)}.main{margin-left:0;padding:18px}.mobile-menu{display:inline-block}.page-title{font-size:23px}}
@media print{.sidebar,.sidebar-overlay,.no-print,.topline button,.form-card,.pagination{display:none!important}.main{margin:0;padding:0}.card{box-shadow:none;border:0}.table{font-size:10px}body{background:#fff}}
</style>    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<div id="sidebarOverlay" class="sidebar-overlay no-print"></div>
<aside id="sidebar" class="sidebar no-print">
    <div class="sidebar-header">
        <i class="fas fa-university"></i>
        <span>Bursar</span>
    </div>
    <div class="sidebar-menu">
        <a href="/admin/bursar/index.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a>

        <div class="sidebar-section">Students &amp; Fees</div>
        <a href="/admin/bursar/students_fees.php"><i class="fas fa-file-invoice-dollar"></i>Student Fees</a>
        <a href="/admin/bursar/students_fee_accounts.php"><i class="fas fa-file-invoice-dollar"></i>Student Fee Accounts</a>
        <a href="/admin/bursar/fee_structure.php"><i class="fas fa-list-alt"></i>Fee Structure</a>
        <a href="/admin/bursar/payments.php"><i class="fas fa-money-bill-wave"></i>Receive Payment</a>
        <a href="/admin/bursar/outstanding_fees.php"><i class="fas fa-exclamation-circle"></i>Outstanding Fees</a>

        <div class="sidebar-section">Finance</div>
        <a href="/admin/bursar/income.php"><i class="fas fa-arrow-circle-down"></i>Income</a>
        <a href="/admin/bursar/expenses.php"><i class="fas fa-arrow-circle-up"></i>Expenses</a>
        <a href="/admin/bursar/suppliers.php"><i class="fas fa-truck"></i>Suppliers</a>
        <a href="/admin/bursar/supplier_payments.php"><i class="fas fa-hand-holding-usd"></i>Supplier Payments</a>

        <div class="sidebar-section">Payroll &amp; Budget</div>
        <a href="/admin/bursar/salaries.php" class="active" aria-current="page"><i class="fas fa-users"></i>Salaries</a>
        <a href="/admin/bursar/salary_payments.php"><i class="fas fa-money-check-alt"></i>Salary Payments</a>
        <a href="/admin/bursar/budgets.php"><i class="fas fa-chart-pie"></i>Budgets</a>

        <div class="sidebar-section">Reports</div>
        <a href="/admin/bursar/cashbook.php"><i class="fas fa-book"></i>Cashbook</a>
        <a href="/admin/bursar/financial_reports.php"><i class="fas fa-chart-line"></i>Financial Reports</a>
        <a href="/admin/bursar/income_report.php"><i class="fas fa-file-invoice"></i>Income Report</a>
        <a href="/admin/bursar/expense_report.php"><i class="fas fa-receipt"></i>Expense Report</a>
        <a href="/admin/bursar/fees_report.php"><i class="fas fa-file-alt"></i>Fees Report</a>
        <a href="/admin/bursar/profit_loss.php"><i class="fas fa-balance-scale"></i>Profit &amp; Loss</a>

        <div class="sidebar-section">System</div>
        <a href="/admin/dashboard.php"><i class="fas fa-user-shield"></i>Admin Dashboard</a>
        <a href="/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
    </div>
</aside>

<main class="main">
 <div class="topline"><div class="d-flex align-items-start"><button id="mobileMenuBtn" class="btn btn-outline-secondary mr-3 mobile-menu" type="button" aria-label="Open navigation"><i class="fas fa-bars"></i></button><div><div class="eyebrow">Human resources / payroll</div><h1 class="page-title">Staff Salaries</h1><div class="subtitle">Manage salary structures for teaching and non-teaching personnel across the school.</div></div></div><button type="button" class="btn btn-outline-primary no-print" onclick="window.print()"><i class="fas fa-print mr-1"></i>Print</button></div>
 <?php if ($flash): ?><div class="alert alert-<?= salE($flash['type'] ?? 'info') ?> alert-dismissible fade show" role="alert"><?= salE($flash['message'] ?? '') ?><button type="button" class="close" data-dismiss="alert"><span>&times;</span></button></div><?php endif; ?>
 <?php if ($createdDefaultTable): ?><div class="alert alert-info"><i class="fas fa-info-circle mr-1"></i>A <code>salaries</code> table was created because none existed. Personnel are loaded from the staff directory tables available in your database.</div><?php endif; ?>
 <?php if ($schemaError !== ''): ?><div class="alert alert-danger"><strong>Database setup problem:</strong> <?= salE($schemaError) ?></div><?php endif; ?>
 <?php if ($pageError !== ''): ?><div class="alert alert-danger"><?= salE($pageError) ?></div><?php endif; ?>
 <?php if ($staffSourceNote !== ''): ?><div class="alert alert-warning"><i class="fas fa-exclamation-triangle mr-1"></i><?= salE($staffSourceNote) ?></div><?php endif; ?>
 <?php if ($staffSources): ?><div class="small text-muted mb-3"><i class="fas fa-users mr-1"></i>Personnel sources detected: <?= salE(implode(', ',array_map('salHumanSource',array_values(array_unique($staffSources)))) ) ?>. Duplicate names/emails are combined in the staff selector.</div><?php endif; ?>
 <div class="row">
  <div class="col-md-6 col-xl-4"><div class="card"><div class="card-body stat-card"><div class="stat-icon"><i class="fas fa-user-tie"></i></div><div><div class="stat-label">Salary records</div><div class="stat-value"><?= number_format(count($salaryRows)) ?></div></div></div></div></div>
  <div class="col-md-6 col-xl-4"><div class="card"><div class="card-body stat-card"><div class="stat-icon" style="background:#e1f7ef;color:#15945e"><i class="fas fa-user-check"></i></div><div><div class="stat-label">Active salary records</div><div class="stat-value"><?= number_format($activeCount) ?></div></div></div></div></div>
  <div class="col-md-12 col-xl-4"><div class="card"><div class="card-body stat-card"><div class="stat-icon" style="background:#fff1dd;color:#b77516"><i class="fas fa-wallet"></i></div><div><div class="stat-label">Active net salary total (per pay period)</div><div class="stat-value" style="font-size:20px">UGX <?= number_format($activeNetTotal,2) ?></div></div></div></div></div>
 </div>
 <section class="card form-card" id="salaryForm">
  <div class="card-header d-flex justify-content-between align-items-center"><span><i class="fas fa-<?= $editRow ? 'edit' : 'plus-circle' ?> mr-2 text-danger"></i><?= $editRow ? 'Edit Salary Record' : 'Add Salary Record' ?></span><?php if ($editRow): ?><a href="salaries.php" class="btn btn-sm btn-outline-secondary">Cancel editing</a><?php endif; ?></div>
  <div class="card-body">
   <?php if (!$map['id'] || (!$map['basic'] && !$map['net'])): ?><div class="alert alert-warning mb-0">Your existing <code>salaries</code> table does not have the minimum columns this page needs. At minimum it must contain an ID column and a salary amount column such as <code>id</code> and <code>basic_salary</code>.</div><?php else: ?>
   <form method="post" action="salaries.php<?= $editRow ? '?edit=' . (int)$editRow[$map['id']] . '#salaryForm' : '#salaryForm' ?>" id="salaryFormElement">
    <input type="hidden" name="csrf_token" value="<?= salE($csrfToken) ?>"><input type="hidden" name="action" value="<?= $editRow ? 'update_salary' : 'save_salary' ?>">
    <?php if ($editRow): ?><input type="hidden" name="salary_id" value="<?= (int)$editRow[$map['id']] ?>"><?php endif; ?>
    <div class="form-row">
     <div class="form-group col-md-6 col-xl-5"><label for="person_key">Staff member <span class="required">*</span></label><select class="form-control" name="person_key" id="person_key" required><option value="">Select a teacher or staff member</option><?php foreach ($staffPeople as $person): $key=$person['source_table'].':'.$person['person_id']; ?><option value="<?= salE($key) ?>" <?= $editPersonKey === $key ? 'selected' : '' ?>><?= salE($person['person_name']) ?> — <?= salE($person['person_role']) ?></option><?php endforeach; ?><?php if ($map['name']): ?><option value="__manual__" <?= $editPersonKey === '__manual__' ? 'selected' : '' ?>>Person not listed — enter name manually</option><?php endif; ?></select><?php if (!$staffPeople): ?><small class="hint">No staff records were found in the available staff/personnel tables.</small><?php endif; ?></div>
     <div class="form-group col-md-6 col-xl-4 manual-person-field" style="display:<?= $editPersonKey === '__manual__' ? 'block' : 'none' ?>"><label for="manual_name">Full name <span class="required">*</span></label><input type="text" class="form-control" name="manual_name" id="manual_name" maxlength="150" value="<?= salE($editManualName) ?>" placeholder="Enter staff member's full name"></div>
     <div class="form-group col-md-6 col-xl-3 manual-person-field" style="display:<?= $editPersonKey === '__manual__' ? 'block' : 'none' ?>"><label for="manual_role">Job title / role</label><input type="text" class="form-control" name="manual_role" id="manual_role" maxlength="100" value="<?= salE($editManualRole) ?>" placeholder="e.g. Cleaner, Teacher"></div>
     <div class="form-group col-md-4 col-xl-3"><label for="basic_salary">Basic salary (UGX) <span class="required">*</span></label><input type="number" class="form-control salary-calc" id="basic_salary" name="basic_salary" min="0" step="0.01" required value="<?= $editRow ? salE(salRowAmount($editRow,$map['basic'])) : '' ?>" placeholder="0.00"></div>
     <div class="form-group col-md-4 col-xl-3"><label for="allowances">Allowances (UGX)</label><input type="number" class="form-control salary-calc" id="allowances" name="allowances" min="0" step="0.01" value="<?= $editRow ? salE(salRowAmount($editRow,$map['allowances'])) : '0.00' ?>"></div>
     <div class="form-group col-md-4 col-xl-3"><label for="deductions">Deductions (UGX)</label><input type="number" class="form-control salary-calc" id="deductions" name="deductions" min="0" step="0.01" value="<?= $editRow ? salE(salRowAmount($editRow,$map['deductions'])) : '0.00' ?>"></div>
     <div class="form-group col-md-6 col-xl-3"><label>Calculated net salary</label><div class="form-control bg-light font-weight-bold" id="netSalaryPreview" aria-live="polite">UGX 0.00</div><small class="hint">Basic + allowances − deductions</small></div>
     <div class="form-group col-md-6 col-xl-3"><label for="pay_frequency">Pay frequency</label><select name="pay_frequency" id="pay_frequency" class="form-control"><?php foreach ($frequencyOptions as $option): ?><option value="<?= salE($option) ?>" <?= (($editRow && $map['frequency'] && (string)($editRow[$map['frequency']] ?? '') === $option) || (!$editRow && strtolower($option)==='monthly') || ($editRow && !$map['frequency'] && strtolower($option)==='monthly')) ? 'selected' : '' ?>><?= salE(ucwords(str_replace('_',' ',$option))) ?></option><?php endforeach; ?></select></div>
     <div class="form-group col-md-6 col-xl-3"><label for="effective_date">Effective date</label><?php $dateValue=date('Y-m-d'); if ($editRow && $map['effective'] && !empty($editRow[$map['effective']])) $dateValue=substr((string)$editRow[$map['effective']],0,10); ?><input type="date" class="form-control" id="effective_date" name="effective_date" required value="<?= salE($dateValue) ?>"></div>
     <div class="form-group col-md-6 col-xl-3"><label for="status">Record status</label><select name="status" id="status" class="form-control"><?php foreach ($statusOptions as $option): ?><option value="<?= salE($option) ?>" <?= (($editRow && $map['status'] && (string)($editRow[$map['status']] ?? '') === $option) || (!$editRow && strtolower($option)==='active')) ? 'selected' : '' ?>><?= salE(ucwords(str_replace('_',' ',$option))) ?></option><?php endforeach; ?></select></div>
    </div>
    <div class="d-flex flex-wrap align-items-center justify-content-between mt-2"><div class="hint mb-2"><i class="fas fa-info-circle mr-1"></i>This page manages salary amounts and status. Record actual disbursements under <a href="salary_payments.php">Salary Payments</a>.</div><button type="submit" id="saveSalaryButton" class="btn btn-primary px-4"><i class="fas fa-save mr-1"></i><?= $editRow ? 'Update Salary' : 'Save Salary Record' ?></button></div>
   </form><?php endif; ?>
  </div>
 </section>
 <section class="card">
  <div class="card-header d-flex flex-wrap align-items-center justify-content-between"><span><i class="fas fa-list mr-2 text-danger"></i>Salary Records</span><span class="text-muted small"><?= number_format($totalRows) ?> record(s) found</span></div>
  <div class="card-body pb-0 no-print"><form method="get" action="salaries.php" class="form-row align-items-end"><div class="form-group col-md-6"><label for="q">Search</label><input type="search" class="form-control" id="q" name="q" value="<?= salE($search) ?>" placeholder="Name, staff role, salary number..."></div><div class="form-group col-md-3"><label for="statusFilter">Status</label><select class="form-control" id="statusFilter" name="status"><option value="">All statuses</option><?php foreach ($statusOptions as $option): ?><option value="<?= salE($option) ?>" <?= strtolower($statusFilter) === strtolower($option) ? 'selected' : '' ?>><?= salE(ucwords(str_replace('_',' ',$option))) ?></option><?php endforeach; ?></select></div><div class="form-group col-md-3"><button class="btn btn-primary mr-1" type="submit"><i class="fas fa-search mr-1"></i>Search</button><a class="btn btn-outline-secondary" href="salaries.php">Reset</a></div></form></div>
  <div class="table-responsive"><table class="table table-hover"><thead><tr><th>Salary No.</th><th>Staff member</th><th>Basic salary</th><th>Allowances</th><th>Deductions</th><th>Net salary</th><th>Frequency</th><th>Effective date</th><th>Status</th><th class="no-print">Actions</th></tr></thead><tbody>
  <?php if (!$visibleRows): ?><tr><td colspan="10"><div class="empty-state"><i class="fas fa-users d-block"></i><strong>No salary records found</strong><div class="mt-1">Use the form above to create a salary record for a teacher or staff member.</div></div></td></tr><?php else: foreach ($visibleRows as $row):
      $rowStatus=(string)$row['_display_status']; $statusClass=(strtolower($rowStatus)==='active'||strtolower($rowStatus)==='paid')?'badge-active':((strtolower($rowStatus)==='inactive')?'badge-inactive':'badge-other');
      $rowBasic=salRowAmount($row,$map['basic']); $rowAllowances=salRowAmount($row,$map['allowances']); $rowDeductions=salRowAmount($row,$map['deductions']);
      $rowFrequency=$map['frequency']?(string)($row[$map['frequency']] ?? 'Monthly'):'Monthly'; $rowDate=$map['effective']?(string)($row[$map['effective']] ?? ''):'';
  ?><tr><td><span class="font-weight-bold"><?= salE($row['_display_number']) ?></span></td><td><div class="person-name"><?= salE($row['_display_name']) ?></div><?php if ($row['_display_role']!==''): ?><div class="meta"><?= salE($row['_display_role']) ?></div><?php endif; ?></td><td class="money">UGX <?= number_format($rowBasic,2) ?></td><td class="money">UGX <?= number_format($rowAllowances,2) ?></td><td class="money">UGX <?= number_format($rowDeductions,2) ?></td><td class="money text-success">UGX <?= number_format((float)$row['_display_net'],2) ?></td><td><?= salE(ucwords(str_replace('_',' ',$rowFrequency))) ?></td><td><?= salE($rowDate!==''?substr($rowDate,0,10):'—') ?></td><td><span class="badge-status <?= $statusClass ?>"><?= salE($rowStatus) ?></span></td><td class="no-print text-nowrap"><?php if ($map['id']): ?><a href="salaries.php?edit=<?= (int)$row[$map['id']] ?>#salaryForm" class="btn btn-sm btn-outline-primary mb-1" title="Edit salary"><i class="fas fa-edit"></i></a><?php endif; ?><?php if ($map['status'] && in_array(strtolower($rowStatus),['active','inactive'],true)): ?><form method="post" action="salaries.php" class="d-inline" onsubmit="return confirm('Change this salary record status?');"><input type="hidden" name="csrf_token" value="<?= salE($csrfToken) ?>"><input type="hidden" name="action" value="toggle_status"><input type="hidden" name="salary_id" value="<?= (int)$row[$map['id']] ?>"><input type="hidden" name="new_status" value="<?= strtolower($rowStatus)==='active'?'inactive':'active' ?>"><button class="btn btn-sm <?= strtolower($rowStatus)==='active'?'btn-outline-secondary':'btn-outline-success' ?> mb-1" type="submit" title="<?= strtolower($rowStatus)==='active'?'Deactivate':'Activate' ?>"><i class="fas <?= strtolower($rowStatus)==='active'?'fa-ban':'fa-check' ?>"></i></button></form><?php endif; ?></td></tr><?php endforeach; endif; ?>
  </tbody></table></div>
  <?php if ($totalPages>1): $pageQuery=$_GET; ?><div class="card-body no-print"><nav aria-label="Salary record pages"><ul class="pagination flex-wrap mb-0"><?php $pageQuery['page']=max(1,$page-1); ?><li class="page-item <?= $page<=1?'disabled':'' ?>"><a class="page-link" href="?<?= salE(http_build_query($pageQuery)) ?>">Previous</a></li><?php for($p=max(1,$page-2);$p<=min($totalPages,$page+2);$p++): $pageQuery['page']=$p; ?><li class="page-item <?= $p===$page?'active':'' ?>"><a class="page-link" href="?<?= salE(http_build_query($pageQuery)) ?>"><?= $p ?></a></li><?php endfor; $pageQuery['page']=min($totalPages,$page+1); ?><li class="page-item <?= $page>=$totalPages?'disabled':'' ?>"><a class="page-link" href="?<?= salE(http_build_query($pageQuery)) ?>">Next</a></li></ul></nav></div><?php endif; ?>
 </section>
 <p class="text-center text-muted small">School Management System &mdash; Staff Salary Management</p>
</main>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function(){
 var sidebar=document.getElementById('sidebar'),overlay=document.getElementById('sidebarOverlay'),menuButton=document.getElementById('mobileMenuBtn');
 function closeMenu(){if(sidebar)sidebar.classList.remove('show');if(overlay)overlay.classList.remove('show');}
 if(menuButton&&sidebar)menuButton.addEventListener('click',function(){sidebar.classList.toggle('show');if(overlay)overlay.classList.toggle('show',sidebar.classList.contains('show'));});
 if(overlay)overlay.addEventListener('click',closeMenu);
 document.addEventListener('click',function(event){if(window.innerWidth<=991&&sidebar&&sidebar.classList.contains('show')&&!sidebar.contains(event.target)&&menuButton&&!menuButton.contains(event.target))closeMenu();});
 var personSelect=document.getElementById('person_key'),manualFields=document.querySelectorAll('.manual-person-field'),manualName=document.getElementById('manual_name');
 function updateManualFields(){var manual=personSelect&&personSelect.value==='__manual__';manualFields.forEach(function(el){el.style.display=manual?'block':'none';});if(manualName)manualName.required=!!manual;}
 if(personSelect){personSelect.addEventListener('change',updateManualFields);updateManualFields();}
 var basic=document.getElementById('basic_salary'),allowances=document.getElementById('allowances'),deductions=document.getElementById('deductions'),preview=document.getElementById('netSalaryPreview');
 function updateNet(){if(!preview)return;var b=parseFloat(basic&&basic.value)||0,a=parseFloat(allowances&&allowances.value)||0,d=parseFloat(deductions&&deductions.value)||0,n=b+a-d;preview.textContent='UGX '+n.toLocaleString('en-UG',{minimumFractionDigits:2,maximumFractionDigits:2});preview.classList.toggle('text-danger',n<0);preview.classList.toggle('text-success',n>=0);}
 [basic,allowances,deductions].forEach(function(el){if(el)el.addEventListener('input',updateNet);});updateNet();
 var form=document.getElementById('salaryFormElement');if(form)form.addEventListener('submit',function(){var button=document.getElementById('saveSalaryButton');if(button){button.disabled=true;button.innerHTML='<i class="fas fa-spinner fa-spin mr-1"></i>Saving...';}});
})();
</script>
</body></html>

