<?php
/**
 * School Management System - Bursar Cashbook
 * Updated to use the shared Bursar sidebar and CSS design from budgets.php.
 * Save as UTF-8 without BOM. Keep this opening PHP tag as the first bytes.
 */
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator', 'bursar']);

if (!isset($conn) || !($conn instanceof mysqli)) {
    http_response_code(500);
    exit('Database connection is unavailable. Please check config/database.php.');
}
$conn->set_charset('utf8mb4');

function sseru_cashbook_h($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}
function sseru_cashbook_ident(string $name): string {
    return '`' . str_replace('`', '``', $name) . '`';
}
function sseru_cashbook_columns(mysqli $db, string $table): array {
    $columns = [];
    $result = $db->query('SHOW COLUMNS FROM ' . sseru_cashbook_ident($table));
    while ($row = $result->fetch_assoc()) $columns[strtolower((string)$row['Field'])] = (string)$row['Field'];
    $result->free();
    return $columns;
}
function sseru_cashbook_pick(array $columns, array $candidates): ?string {
    foreach ($candidates as $candidate) {
        $key = strtolower((string)$candidate);
        if (isset($columns[$key])) return $columns[$key];
    }
    return null;
}
function sseru_cashbook_table(array $tables, array $candidates): ?string {
    foreach ($candidates as $candidate) {
        if (isset($tables[strtolower($candidate)])) return $tables[strtolower($candidate)];
    }
    return null;
}
function sseru_cashbook_date(array $row, array $columns): ?int {
    foreach ($columns as $column) {
        if (!$column || !isset($row[$column]) || trim((string)$row[$column]) === '') continue;
        $raw = trim((string)$row[$column]);
        if ($raw === '0000-00-00' || $raw === '0000-00-00 00:00:00') continue;
        $time = strtotime($raw);
        if ($time !== false) return $time;
    }
    return null;
}
function sseru_cashbook_status_effective(string $status): bool {
    $status = strtolower(trim($status));
    if ($status === '') return true;
    return in_array($status, ['completed','complete','paid','success','successful','confirmed','approved','posted','received','settled','processed','done','1'], true);
}
function sseru_cashbook_money($amount): string {
    return number_format((float)$amount, 2);
}
function sseru_cashbook_lookup_names(mysqli $db, ?string $table, array $idCandidates, array $nameCandidates): array {
    if (!$table) return [];
    try {
        $columns = sseru_cashbook_columns($db, $table);
        $idCol = sseru_cashbook_pick($columns, $idCandidates);
        $nameCol = sseru_cashbook_pick($columns, $nameCandidates);
        if (!$idCol) return [];
        if ($nameCol) {
            $sql = 'SELECT ' . sseru_cashbook_ident($idCol) . ' AS lookup_id, ' . sseru_cashbook_ident($nameCol) . ' AS lookup_name FROM ' . sseru_cashbook_ident($table);
        } else {
            $first = sseru_cashbook_pick($columns, ['first_name']);
            $last = sseru_cashbook_pick($columns, ['last_name']);
            if (!$first && !$last) return [];
            $a = $first ? 'NULLIF(TRIM(CAST(' . sseru_cashbook_ident($first) . ' AS CHAR)), \'\')' : "''";
            $b = $last ? 'NULLIF(TRIM(CAST(' . sseru_cashbook_ident($last) . ' AS CHAR)), \'\')' : "''";
            $sql = 'SELECT ' . sseru_cashbook_ident($idCol) . ' AS lookup_id, CONCAT_WS(\' \',' . $a . ',' . $b . ') AS lookup_name FROM ' . sseru_cashbook_ident($table);
        }
        $result = $db->query($sql);
        $map = [];
        while ($row = $result->fetch_assoc()) {
            $id = (string)($row['lookup_id'] ?? '');
            $name = trim((string)($row['lookup_name'] ?? ''));
            if ($id !== '' && $name !== '') $map[$id] = $name;
        }
        $result->free();
        return $map;
    } catch (Throwable $e) {
        error_log('Cashbook lookup error for ' . $table . ': ' . $e->getMessage());
        return [];
    }
}

$today = date('Y-m-d');
$defaultFrom = date('Y-m-01');
$from = trim((string)($_GET['from'] ?? $defaultFrom));
$to = trim((string)($_GET['to'] ?? $today));
$q = trim((string)($_GET['q'] ?? ''));
$typeFilter = trim((string)($_GET['type'] ?? ''));
$statusFilter = trim((string)($_GET['status'] ?? ''));
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 25;
$errors = [];
$validFrom = DateTime::createFromFormat('!Y-m-d', $from);
$validTo = DateTime::createFromFormat('!Y-m-d', $to);
if (!$validFrom || $validFrom->format('Y-m-d') !== $from || !$validTo || $validTo->format('Y-m-d') !== $to) {
    $errors[] = 'Please select valid From and To dates.';
    $from = $defaultFrom;
    $to = $today;
}
if ($from > $to) {
    $errors[] = 'The From date cannot be later than the To date.';
    $from = $defaultFrom;
    $to = $today;
}
if (!in_array($typeFilter, ['', 'in', 'out'], true)) $typeFilter = '';

$tableMap = [];
$columnCache = [];
$studentNames = [];
$supplierNames = [];
$teacherNames = [];
$staffNames = [];
$paymentMethods = [];
$incomeCategories = [];
$expenseCategories = [];
$accountStudentMap = [];
$rows = [];
$matchingRows = [];
$openingBalance = 0.0;
$totalCashIn = 0.0;
$totalCashOut = 0.0;
$closingBalance = 0.0;
$loadWarnings = [];
$recordsRead = 0;

try {
    $tablesResult = $conn->query('SHOW TABLES');
    while ($tableRow = $tablesResult->fetch_row()) $tableMap[strtolower((string)$tableRow[0])] = (string)$tableRow[0];
    $tablesResult->free();
    foreach ($tableMap as $tableName) {
        try { $columnCache[strtolower($tableName)] = sseru_cashbook_columns($conn, $tableName); }
        catch (Throwable $e) { error_log('Cashbook column read error: ' . $e->getMessage()); }
    }

    $studentsTable = sseru_cashbook_table($tableMap, ['students']);
    $suppliersTable = sseru_cashbook_table($tableMap, ['suppliers']);
    $teachersTable = sseru_cashbook_table($tableMap, ['teachers', 'teacher']);
    $staffTable = sseru_cashbook_table($tableMap, ['other_staff', 'staff_members', 'non_teaching_staff', 'employees', 'staff']);
    $accountsTable = sseru_cashbook_table($tableMap, ['student_fee_accounts']);
    $methodsTable = sseru_cashbook_table($tableMap, ['payment_methods']);
    $incomeCatTable = sseru_cashbook_table($tableMap, ['income_categories']);
    $expenseCatTable = sseru_cashbook_table($tableMap, ['expense_categories']);

    $studentNames = sseru_cashbook_lookup_names($conn, $studentsTable, ['id','student_id'], ['full_name','student_name']);
    $studentIdentifiers = [];
    if ($studentsTable) {
        try {
            $studentIdCol = sseru_cashbook_pick($columnCache[strtolower($studentsTable)] ?? [], ['id','student_id']);
            $studentLinCol = sseru_cashbook_pick($columnCache[strtolower($studentsTable)] ?? [], ['lin_no']);
            $studentPaymentCol = sseru_cashbook_pick($columnCache[strtolower($studentsTable)] ?? [], ['student_payment_code']);
            $studentSectionCol = sseru_cashbook_pick($columnCache[strtolower($studentsTable)] ?? [], ['student_section']);
            if ($studentIdCol) {
                $select = [sseru_cashbook_ident($studentIdCol) . ' AS sid'];
                $select[] = $studentLinCol ? sseru_cashbook_ident($studentLinCol) . ' AS lin_no' : "'' AS lin_no";
                $select[] = $studentPaymentCol ? sseru_cashbook_ident($studentPaymentCol) . ' AS payment_code' : "'' AS payment_code";
                $select[] = $studentSectionCol ? sseru_cashbook_ident($studentSectionCol) . ' AS student_section' : "'Day' AS student_section";
                $identifierResult = $conn->query('SELECT ' . implode(', ', $select) . ' FROM ' . sseru_cashbook_ident($studentsTable));
                while ($identifierRow = $identifierResult->fetch_assoc()) $studentIdentifiers[(string)$identifierRow['sid']] = $identifierRow;
                $identifierResult->free();
            }
        } catch (Throwable $e) { error_log('Cashbook student identifier lookup: ' . $e->getMessage()); }
    }
    $supplierNames = sseru_cashbook_lookup_names($conn, $suppliersTable, ['id','supplier_id'], ['supplier_name','name','company_name']);
    $teacherNames = sseru_cashbook_lookup_names($conn, $teachersTable, ['id','teacher_id'], ['full_name','teacher_name','name']);
    $staffNames = sseru_cashbook_lookup_names($conn, $staffTable, ['id','staff_id','employee_id'], ['full_name','staff_name','employee_name','name']);
    $paymentMethods = sseru_cashbook_lookup_names($conn, $methodsTable, ['id','payment_method_id'], ['method_name','name','payment_method','title']);
    $incomeCategories = sseru_cashbook_lookup_names($conn, $incomeCatTable, ['id','category_id'], ['category_name','name','title']);
    $expenseCategories = sseru_cashbook_lookup_names($conn, $expenseCatTable, ['id','category_id'], ['category_name','name','title']);

    if ($accountsTable) {
        $ac = $columnCache[strtolower($accountsTable)] ?? [];
        $aid = sseru_cashbook_pick($ac, ['id','account_id']);
        $asid = sseru_cashbook_pick($ac, ['student_id']);
        if ($aid && $asid) {
            $ar = $conn->query('SELECT ' . sseru_cashbook_ident($aid) . ' AS aid, ' . sseru_cashbook_ident($asid) . ' AS sid FROM ' . sseru_cashbook_ident($accountsTable));
            while ($a = $ar->fetch_assoc()) $accountStudentMap[(string)$a['aid']] = (string)$a['sid'];
            $ar->free();
        }
    }

    // These are read-only sources: existing financial records are consolidated into the cashbook.
    $sources = [
        ['table'=>'fee_payments','direction'=>'in','kind'=>'Student fees','date'=>['payment_date','paid_date','transaction_date','created_at'],'amount'=>['amount','paid_amount','payment_amount'],'number'=>['receipt_no','payment_no','transaction_no','receipt_number'],'status'=>['status','payment_status'],'method_id'=>['payment_method_id'],'method_text'=>['payment_method','method','payment_type'],'ref'=>['reference_no','reference_number','transaction_reference'],'notes'=>['description','notes','remarks','narration'],'category'=>'Student fees'],
        ['table'=>'income_transactions','direction'=>'in','kind'=>'Other income','date'=>['income_date','transaction_date','date','created_at'],'amount'=>['amount','income_amount','total_amount'],'number'=>['transaction_no','income_no','receipt_no','reference_no'],'status'=>['status','payment_status'],'method_id'=>['payment_method_id'],'method_text'=>['payment_method','method'],'ref'=>['reference_no','reference_number'],'notes'=>['description','notes','remarks'],'category_id'=>['category_id'],'category'=>'Other income'],
        ['table'=>'expense_transactions','direction'=>'out','kind'=>'Expense','date'=>['expense_date','transaction_date','date','created_at'],'amount'=>['amount','expense_amount','total_amount'],'number'=>['transaction_no','expense_no','reference_no'],'status'=>['status','payment_status'],'method_id'=>['payment_method_id'],'method_text'=>['payment_method','method'],'ref'=>['reference_no','reference_number'],'notes'=>['description','notes','remarks'],'category_id'=>['category_id'],'payee'=>['payee_name','supplier_name','payee','supplier'],'category'=>'Expense'],
        ['table'=>'supplier_payments','direction'=>'out','kind'=>'Supplier payment','date'=>['payment_date','paid_date','transaction_date','date','created_at'],'amount'=>['amount','paid_amount','payment_amount','total_amount'],'number'=>['payment_no','transaction_no','receipt_no','reference_no'],'status'=>['status','payment_status'],'method_id'=>['payment_method_id'],'method_text'=>['payment_method','method','payment_type'],'ref'=>['reference_no','reference_number','transaction_reference'],'notes'=>['description','notes','remarks','narration'],'payee'=>['supplier_name','payee_name','supplier','payee'],'supplier_id'=>['supplier_id'],'category'=>'Supplier payment'],
        ['table'=>'salary_payments','direction'=>'out','kind'=>'Salary payment','date'=>['payment_date','paid_date','transaction_date','created_at'],'amount'=>['net_salary','amount','paid_amount','payment_amount','net_amount'],'number'=>['payment_no','transaction_no','receipt_no'],'status'=>['status','payment_status'],'method_id'=>['payment_method_id'],'method_text'=>['payment_method','method','payment_type'],'ref'=>['reference_no','reference_number','transaction_reference'],'notes'=>['notes','description','remarks','narration'],'category'=>'Staff salaries','salary_employee'=>true],
    ];

    $startTs = strtotime($from . ' 00:00:00');
    $endTs = strtotime($to . ' 23:59:59');
    foreach ($sources as $source) {
        $table = sseru_cashbook_table($tableMap, [$source['table']]);
        if (!$table) continue;
        $columns = $columnCache[strtolower($table)] ?? sseru_cashbook_columns($conn, $table);
        $dateCol = sseru_cashbook_pick($columns, $source['date']);
        $amountCol = sseru_cashbook_pick($columns, $source['amount']);
        if (!$dateCol || !$amountCol) {
            $loadWarnings[] = $table . ' was skipped because a date or amount column could not be identified.';
            continue;
        }
        try {
            $orderCol = sseru_cashbook_pick($columns, ['id']) ?: $dateCol;
            $result = $conn->query('SELECT * FROM ' . sseru_cashbook_ident($table) . ' ORDER BY ' . sseru_cashbook_ident($orderCol) . ' DESC');
            while ($raw = $result->fetch_assoc()) {
                $recordsRead++;
                $dateCandidates = [$dateCol];
                foreach (['paid_date','income_date','expense_date','transaction_date','created_at','date'] as $fallback) {
                    if (isset($columns[$fallback]) && !in_array($columns[$fallback], $dateCandidates, true)) $dateCandidates[] = $columns[$fallback];
                }
                $dateTs = sseru_cashbook_date($raw, $dateCandidates);
                if ($dateTs === null) continue;
                $statusCol = sseru_cashbook_pick($columns, $source['status']);
                $status = $statusCol ? trim((string)($raw[$statusCol] ?? '')) : 'completed';
                if ($status === '') $status = 'completed';
                $amount = abs((float)($raw[$amountCol] ?? 0));
                $effective = sseru_cashbook_status_effective($status);
                if ($dateTs < $startTs) {
                    if ($effective) $openingBalance += ($source['direction'] === 'in' ? $amount : -$amount);
                    continue;
                }
                if ($dateTs > $endTs) continue;

                $numberCol = sseru_cashbook_pick($columns, $source['number']);
                $methodIdCol = sseru_cashbook_pick($columns, $source['method_id'] ?? ['payment_method_id']);
                $methodTextCol = sseru_cashbook_pick($columns, $source['method_text'] ?? ['payment_method','method']);
                $referenceCol = sseru_cashbook_pick($columns, $source['ref']);
                $notesCol = sseru_cashbook_pick($columns, $source['notes']);
                $category = (string)$source['category'];
                if (isset($source['category_id'])) {
                    $catIdCol = sseru_cashbook_pick($columns, $source['category_id']);
                    $catId = $catIdCol ? (string)($raw[$catIdCol] ?? '') : '';
                    $catMap = $source['direction'] === 'in' ? $incomeCategories : $expenseCategories;
                    if ($catId !== '' && isset($catMap[$catId])) $category = $catMap[$catId];
                }
                $studentIdentifierLabel = '';
                $person = '';
                if (!empty($source['payee'])) {
                    $personCol = sseru_cashbook_pick($columns, $source['payee']);
                    if ($personCol) $person = trim((string)($raw[$personCol] ?? ''));
                }
                if (isset($source['supplier_id']) && $person === '') {
                    $sidCol = sseru_cashbook_pick($columns, $source['supplier_id']);
                    $sid = $sidCol ? (string)($raw[$sidCol] ?? '') : '';
                    if ($sid !== '' && isset($supplierNames[$sid])) $person = $supplierNames[$sid];
                }
                if ($source['table'] === 'fee_payments') {
                    $studentIdCol = sseru_cashbook_pick($columns, ['student_id']);
                    $studentId = $studentIdCol ? (string)($raw[$studentIdCol] ?? '') : '';
                    if ($studentId === '') {
                        $accountCol = sseru_cashbook_pick($columns, ['student_fee_account_id','account_id','fee_account_id']);
                        $accountId = $accountCol ? (string)($raw[$accountCol] ?? '') : '';
                        $studentId = $accountStudentMap[$accountId] ?? '';
                    }
                    if ($studentId !== '' && isset($studentNames[$studentId])) $person = $studentNames[$studentId];
                    if ($person === '') $person = 'Student fee account';
                    if ($studentId !== '' && isset($studentIdentifiers[$studentId])) {
                        $identifier = $studentIdentifiers[$studentId];
                        $studentIdentifierLabel = 'LIN: ' . (trim((string)($identifier['lin_no'] ?? '')) ?: '—')
                            . ' | Payment Code: ' . (trim((string)($identifier['payment_code'] ?? '')) ?: '—')
                            . ' | ' . (trim((string)($identifier['student_section'] ?? 'Day')) ?: 'Day');
                    }
                }
                if (!empty($source['salary_employee']) && $person === '') {
                    $person = trim((string)($raw['person_name'] ?? $raw['employee_name'] ?? $raw['staff_name'] ?? $raw['teacher_name'] ?? $raw['full_name'] ?? ''));
                    if ($person === '') {
                        $teacherId = (string)($raw['teacher_id'] ?? '');
                        $staffId = (string)($raw['staff_id'] ?? $raw['employee_id'] ?? '');
                        if ($teacherId !== '' && isset($teacherNames[$teacherId])) $person = $teacherNames[$teacherId];
                        elseif ($staffId !== '' && isset($staffNames[$staffId])) $person = $staffNames[$staffId];
                        elseif ($teacherId !== '') $person = 'Teacher #' . $teacherId;
                        elseif ($staffId !== '') $person = 'Staff member #' . $staffId;
                    }
                    if ($person === '') $person = 'Staff salary';
                }
                $method = $methodTextCol ? trim((string)($raw[$methodTextCol] ?? '')) : '';
                if ($method === '' && $methodIdCol) {
                    $methodId = (string)($raw[$methodIdCol] ?? '');
                    $method = $methodId !== '' ? ($paymentMethods[$methodId] ?? ('Method ID ' . $methodId)) : '';
                }
                $number = $numberCol ? trim((string)($raw[$numberCol] ?? '')) : '';
                if ($number === '') $number = strtoupper(substr($table, 0, 3)) . '-' . (string)($raw['id'] ?? '');
                $rows[] = [
                    'date_ts'=>$dateTs,
                    'date'=>date('Y-m-d H:i:s', $dateTs),
                    'date_label'=>date('d M Y', $dateTs),
                    'source'=>$source['kind'], 'table'=>$table, 'row_id'=>(int)($raw['id'] ?? 0),
                    'number'=>$number, 'direction'=>$source['direction'], 'category'=>$category,
                    'person'=>$person, 'student_identifiers'=>$studentIdentifierLabel, 'method'=>$method,
                    'reference'=>$referenceCol ? trim((string)($raw[$referenceCol] ?? '')) : '',
                    'notes'=>$notesCol ? trim((string)($raw[$notesCol] ?? '')) : '',
                    'status'=>$status, 'amount'=>$amount, 'effective'=>$effective,
                ];
                if ($effective) {
                    if ($source['direction'] === 'in') $totalCashIn += $amount;
                    else $totalCashOut += $amount;
                }
            }
            $result->free();
        } catch (Throwable $e) {
            $loadWarnings[] = 'Could not read ' . $table . '. Its transactions were not included.';
            error_log('Cashbook source error (' . $table . '): ' . $e->getMessage());
        }
    }
} catch (Throwable $e) {
    $errors[] = 'Cashbook could not read the database. Check the database connection and hosting PHP error log.';
    error_log('cashbook.php setup error: ' . $e->getMessage());
}

$closingBalance = $openingBalance + $totalCashIn - $totalCashOut;
usort($rows, static function ($a, $b) {
    return $a['date_ts'] === $b['date_ts'] ? ($b['row_id'] <=> $a['row_id']) : ($b['date_ts'] <=> $a['date_ts']);
});
foreach ($rows as $row) {
    if ($typeFilter !== '' && $row['direction'] !== $typeFilter) continue;
    if ($statusFilter !== '' && strtolower($row['status']) !== strtolower($statusFilter)) continue;
    if ($q !== '') {
        $haystack = strtolower(implode(' ', [$row['date'],$row['source'],$row['number'],$row['category'],$row['person'],$row['student_identifiers'],$row['method'],$row['reference'],$row['notes'],$row['status']]));
        if (strpos($haystack, strtolower($q)) === false) continue;
    }
    $matchingRows[] = $row;
}
$totalMatching = count($matchingRows);
$totalPages = max(1, (int)ceil($totalMatching / $perPage));
if ($page > $totalPages) $page = $totalPages;
$displayRows = array_slice($matchingRows, ($page - 1) * $perPage, $perPage);

if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="cashbook_' . $from . '_to_' . $to . '.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Date','Transaction No.','Source','Direction','Category','Staff / Student / Payee','Student Identifiers','Payment Method','Reference','Status','Cash In (UGX)','Cash Out (UGX)','Description']);
    foreach ($matchingRows as $row) {
        fputcsv($out, [$row['date'],$row['number'],$row['source'],$row['direction'] === 'in' ? 'Cash in' : 'Cash out',$row['category'],$row['person'],$row['student_identifiers'],$row['method'],$row['reference'],$row['status'],$row['direction'] === 'in' && $row['effective'] ? number_format($row['amount'], 2, '.', '') : '0.00',$row['direction'] === 'out' && $row['effective'] ? number_format($row['amount'], 2, '.', '') : '0.00',$row['notes']]);
    }
    fclose($out);
    exit;
}
$statusOptions = [];
foreach ($rows as $row) $statusOptions[$row['status']] = true;
ksort($statusOptions);
$exportQuery = $_GET;
$exportQuery['export'] = 'csv';
unset($exportQuery['page']);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Cashbook | School Management System</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f6f9;font-family:Arial,Helvetica,sans-serif;color:#343a40}.sidebar{position:fixed;top:0;bottom:0;left:0;width:250px;background:#212529;overflow-y:auto;z-index:1050}.sidebar-header{padding:22px 18px;background:#171a1d;color:#fff;font-weight:700;font-size:18px;border-bottom:1px solid rgba(255,255,255,.1)}.sidebar-header small{font-size:12px}.sidebar a{display:block;color:#ced4da;padding:11px 16px;text-decoration:none;border-left:4px solid transparent;font-size:14px}.sidebar a:hover,.sidebar a.active{background:#343a40;color:#fff;border-left-color:#28a745}.sidebar a i{width:24px;text-align:center;margin-right:5px}.sidebar-section{padding:15px 16px 6px;color:#868e96;font-size:11px;text-transform:uppercase;font-weight:bold;letter-spacing:.5px}.main{margin-left:250px;min-height:100vh;padding:0}.topbar{padding:17px 25px;background:#fff;border-bottom:1px solid #e5e5e5;display:flex;align-items:center;justify-content:space-between;gap:12px}.content{padding:24px}.page-head,.panel,.stat-card{background:#fff;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,.05)}.page-head{padding:21px;margin-bottom:20px}.panel{padding:21px;margin-bottom:22px}.stat-card{padding:18px;margin-bottom:18px;height:calc(100% - 18px)}.stat-title,.stat-card .label{color:#6c757d;font-size:13px}.stat-number,.stat-card .value{font-size:22px;font-weight:700;overflow-wrap:anywhere}.form-control,.custom-select,.btn{border-radius:6px}.form-control,.custom-select{min-height:40px}label{font-size:13px;font-weight:600}.table th{background:#f8f9fa;white-space:nowrap;font-size:12px}.table td{vertical-align:middle;font-size:13px}.badge{padding:7px 9px}.progress{height:7px;min-width:75px}.amount-in{color:#16845b;font-weight:700;white-space:nowrap}.amount-out{color:#c33d4b;font-weight:700;white-space:nowrap}.direction-pill{display:inline-block;padding:4px 7px;border-radius:5px;font-size:10px;font-weight:700}.direction-in{background:#e1f7ef;color:#11784f}.direction-out{background:#fff0f1;color:#b42334}.detail-cell{min-width:180px;max-width:280px;overflow-wrap:anywhere}.number-cell{min-width:115px}.muted-small,.small-muted{font-size:11px;color:#89929c}.empty-state{padding:35px 10px;text-align:center;color:#8290a4}.empty-state i{font-size:30px;margin-bottom:12px;color:#bec8d7}.footer-note{text-align:center;color:#97a1b1;font-size:11px;padding:7px 0 0}.mobile-menu{display:none}.alert{font-size:13px}.balance{color:#243754}.symbol{float:right;width:38px;height:38px;line-height:38px;text-align:center;border-radius:9px;background:#eef4ff;color:#326bd1}.subheading{color:#6c757d;font-size:13px;margin-top:5px}.panel-title{font-size:17px;font-weight:700;margin-bottom:17px;color:#1d2d44}.btn{font-size:12px}.btn-primary{background:#2865cf;border-color:#2865cf}.amount-in,.amount-out{white-space:nowrap}@media(max-width:991px){.sidebar{left:-250px;transition:left .25s}.sidebar.show{left:0}.main{margin-left:0}.mobile-menu{display:inline-block}.content{padding:15px}.topbar{padding:12px 15px}.topbar h2{font-size:22px}.panel{padding:16px}}@media print{.sidebar,.topbar .no-print,.no-print,.mobile-menu,.footer-note{display:none!important}.main{margin:0}.content{padding:0}body{background:#fff}.panel,.stat-card,.page-head{box-shadow:none}.topbar{padding:0;border:0}}
</style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<aside class="sidebar no-print" id="sidebar">
 <div class="sidebar-header"><i class="fas fa-school mr-2"></i>School Management<br><small class="text-muted">Bursar Panel</small></div>
 <div class="sidebar-section">Main</div>
 <a href="/admin/dashboard.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
 <a href="/admin/bursar/index.php"><i class="fas fa-chart-line"></i>Bursar Dashboard</a>
 <div class="sidebar-section">Students &amp; Fees</div>
 <a href="/admin/bursar/students_fee_accounts.php"><i class="fas fa-user-graduate"></i>Student Fee Accounts</a>
 <a href="/admin/bursar/fee_structure.php"><i class="fas fa-list-alt"></i>Fee Structure</a>
 <a href="/admin/bursar/payments.php"><i class="fas fa-money-bill-wave"></i>Student Payments</a>
 <a href="/admin/bursar/outstanding_fees.php"><i class="fas fa-exclamation-circle"></i>Outstanding Fees</a>
 <div class="sidebar-section">Finance</div>
 <a href="/admin/bursar/income.php"><i class="fas fa-arrow-circle-down"></i>Other Income</a>
 <a href="/admin/bursar/expenses.php"><i class="fas fa-arrow-circle-up"></i>Expenses</a>
 <a href="/admin/bursar/suppliers.php"><i class="fas fa-truck"></i>Suppliers</a>
 <a href="/admin/bursar/supplier_payments.php"><i class="fas fa-file-invoice-dollar"></i>Supplier Payments</a>
 <div class="sidebar-section">Payroll &amp; Budget</div>
 <a href="/admin/bursar/salaries.php"><i class="fas fa-users"></i>Salaries</a>
 <a href="/admin/bursar/salary_payments.php"><i class="fas fa-money-check-alt"></i>Salary Payments</a>
 <a href="/admin/bursar/budgets.php"><i class="fas fa-wallet"></i>Budgets</a>
 <a href="/admin/bursar/cashbook.php" class="active"><i class="fas fa-book"></i>Cashbook</a>
 <div class="sidebar-section">Reports</div>
 <a href="/admin/bursar/financial_reports.php"><i class="fas fa-chart-line"></i>Financial Reports</a>
 <a href="/admin/bursar/income_report.php"><i class="fas fa-file-invoice"></i>Income Report</a>
 <a href="/admin/bursar/expense_report.php"><i class="fas fa-receipt"></i>Expense Report</a>
 <a href="/admin/bursar/fees_report.php"><i class="fas fa-file-alt"></i>Fees Report</a>
 <a href="/admin/bursar/profit_loss.php"><i class="fas fa-balance-scale"></i>Profit &amp; Loss</a>
 <div class="sidebar-section">System</div>
 <a href="/admin/dashboard.php"><i class="fas fa-user-shield"></i>Admin Dashboard</a>
 <a href="/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
</aside>
<main class="main">
 <div class="topbar">
  <div class="d-flex align-items-start"><button type="button" id="mobileMenuBtn" class="btn btn-dark mobile-menu mr-3" aria-label="Open navigation"><i class="fas fa-bars"></i></button><div><div class="text-uppercase text-success small font-weight-bold">Finance / Reports</div><h3 class="mb-1 font-weight-bold">Cashbook</h3><div class="subheading">A consolidated record of cash received and cash paid by the school.</div></div></div>
  <div class="no-print d-flex flex-wrap" style="gap:8px"><button type="button" onclick="window.print()" class="btn btn-outline-secondary"><i class="fas fa-print mr-1"></i>Print</button><a class="btn btn-outline-success" href="?<?= sseru_cashbook_h(http_build_query($exportQuery)) ?>"><i class="fas fa-file-csv mr-1"></i>Export CSV</a></div>
 </div>
 <div class="content">
 <?php if ($errors): ?><div class="alert alert-danger"><strong>Cashbook issue:</strong><br><?= sseru_cashbook_h(implode(' ', $errors)) ?></div><?php endif; ?>
 <?php foreach ($loadWarnings as $warning): ?><div class="alert alert-warning py-2"><i class="fas fa-exclamation-triangle mr-1"></i><?= sseru_cashbook_h($warning) ?></div><?php endforeach; ?>
 <div class="page-head d-flex justify-content-between align-items-center flex-wrap"><div><h4 class="mb-1"><i class="fas fa-book text-success mr-2"></i>Cashbook Overview</h4><div class="text-muted">Review school income, expenses, supplier payments and payroll disbursements.</div></div><div class="small text-muted mt-2">Currency: UGX</div></div>
 <section class="panel no-print"><div class="panel-title"><i class="fas fa-filter text-success mr-2"></i>Filter Cashbook</div><form method="get" action="cashbook.php" class="form-row align-items-end">
  <div class="form-group col-xl-2 col-md-4"><label for="from">From date</label><input class="form-control" type="date" name="from" id="from" value="<?= sseru_cashbook_h($from) ?>" required></div>
  <div class="form-group col-xl-2 col-md-4"><label for="to">To date</label><input class="form-control" type="date" name="to" id="to" value="<?= sseru_cashbook_h($to) ?>" required></div>
  <div class="form-group col-xl-3 col-md-4"><label for="q">Search transaction or payee</label><input class="form-control" type="search" name="q" id="q" value="<?= sseru_cashbook_h($q) ?>" placeholder="Receipt, supplier, staff..."></div>
  <div class="form-group col-xl-2 col-md-4"><label for="type">Transaction type</label><select class="form-control" name="type" id="type"><option value="">All transactions</option><option value="in" <?= $typeFilter === 'in' ? 'selected' : '' ?>>Cash received</option><option value="out" <?= $typeFilter === 'out' ? 'selected' : '' ?>>Cash paid</option></select></div>
  <div class="form-group col-xl-2 col-md-4"><label for="status">Status</label><select class="form-control" name="status" id="status"><option value="">All statuses</option><?php foreach (array_keys($statusOptions) as $statusOption): ?><option value="<?= sseru_cashbook_h($statusOption) ?>" <?= strtolower($statusFilter) === strtolower($statusOption) ? 'selected' : '' ?>><?= sseru_cashbook_h(ucwords(str_replace('_', ' ', $statusOption))) ?></option><?php endforeach; ?></select></div>
  <div class="form-group col-xl-1 col-md-4"><button type="submit" class="btn btn-success btn-block"><i class="fas fa-search"></i></button></div>
 </form><div class="small text-muted">Only completed/paid transactions affect cash balances. Pending, cancelled and reversed entries remain visible without changing the balance.</div></section>
 <div class="row mb-2">
  <div class="col-sm-6 col-xl-3 mb-3"><div class="stat-card"><span class="symbol"><i class="fas fa-wallet"></i></span><div class="stat-title">Opening Balance</div><div class="stat-number">UGX <?= sseru_cashbook_money($openingBalance) ?></div><div class="muted-small">Before <?= sseru_cashbook_h($from) ?></div></div></div>
  <div class="col-sm-6 col-xl-3 mb-3"><div class="stat-card"><span class="symbol" style="background:#e1f7ef;color:#16845b"><i class="fas fa-arrow-down"></i></span><div class="stat-title">Cash Received</div><div class="stat-number text-success">UGX <?= sseru_cashbook_money($totalCashIn) ?></div><div class="muted-small">For selected dates</div></div></div>
  <div class="col-sm-6 col-xl-3 mb-3"><div class="stat-card"><span class="symbol" style="background:#fff0f1;color:#c33d4b"><i class="fas fa-arrow-up"></i></span><div class="stat-title">Cash Paid</div><div class="stat-number text-danger">UGX <?= sseru_cashbook_money($totalCashOut) ?></div><div class="muted-small">For selected dates</div></div></div>
  <div class="col-sm-6 col-xl-3 mb-3"><div class="stat-card"><span class="symbol" style="background:#e6f4ff;color:#196ba5"><i class="fas fa-balance-scale"></i></span><div class="stat-title">Closing Balance</div><div class="stat-number balance">UGX <?= sseru_cashbook_money($closingBalance) ?></div><div class="muted-small">Opening + received − paid</div></div></div>
 </div>
 <section class="panel"><div class="d-flex flex-wrap justify-content-between align-items-center mb-3"><div><div class="panel-title mb-1"><i class="fas fa-list-alt text-success mr-2"></i>Cashbook Entries</div><div class="small text-muted"><?= number_format($totalMatching) ?> matching record(s) | <?= sseru_cashbook_h($from) ?> to <?= sseru_cashbook_h($to) ?></div></div><div class="small text-muted">Currency: UGX</div></div>
  <div class="table-responsive"><table class="table table-bordered table-hover mb-0"><thead><tr><th>Date</th><th>Transaction No.</th><th>Details</th><th>Source</th><th>Method / Reference</th><th>Status</th><th class="text-right">Cash In (UGX)</th><th class="text-right">Cash Out (UGX)</th></tr></thead><tbody>
  <?php if (!$displayRows): ?><tr><td colspan="8"><div class="empty-state"><i class="fas fa-book-open d-block"></i><strong>No cashbook entries found</strong><div class="small mt-1">Try a different date range or remove some filters.</div></div></td></tr><?php else: foreach ($displayRows as $entry): $statusLower = strtolower($entry['status']); $effective = $entry['effective']; $isIn = $entry['direction'] === 'in'; $isStatusBad = in_array($statusLower, ['cancelled','canceled','reversed','refunded','failed','void'], true); ?><tr>
   <td class="text-nowrap"><?= sseru_cashbook_h($entry['date_label']) ?><div class="muted-small"><?= sseru_cashbook_h(date('H:i', $entry['date_ts'])) ?></div></td>
   <td class="number-cell"><strong><?= sseru_cashbook_h($entry['number']) ?></strong><div class="muted-small"><?= sseru_cashbook_h($entry['table']) ?><?= $entry['row_id'] ? ' #' . (int)$entry['row_id'] : '' ?></div></td>
   <td class="detail-cell"><strong><?= sseru_cashbook_h($entry['category']) ?></strong><?php if ($entry['person'] !== ''): ?><div><?= sseru_cashbook_h($entry['person']) ?></div><?php if (!empty($entry['student_identifiers'])): ?><div class="muted-small"><?= sseru_cashbook_h($entry['student_identifiers']) ?></div><?php endif; ?><?php endif; ?><?php if ($entry['notes'] !== ''): ?><div class="muted-small"><?= sseru_cashbook_h($entry['notes']) ?></div><?php endif; ?></td>
   <td><span class="direction-pill <?= $isIn ? 'direction-in' : 'direction-out' ?>"><?= $isIn ? 'CASH IN' : 'CASH OUT' ?></span><div class="muted-small mt-1"><?= sseru_cashbook_h($entry['source']) ?></div></td>
   <td><?= $entry['method'] !== '' ? sseru_cashbook_h($entry['method']) : '—' ?><?php if ($entry['reference'] !== ''): ?><div class="muted-small">Ref: <?= sseru_cashbook_h($entry['reference']) ?></div><?php endif; ?></td>
   <td><span class="badge badge-<?= $effective ? 'success' : ($isStatusBad ? 'danger' : 'secondary') ?>"><?= sseru_cashbook_h(ucwords(str_replace('_', ' ', $entry['status']))) ?></span></td>
   <td class="text-right amount-in"><?= $isIn && $effective ? sseru_cashbook_money($entry['amount']) : '—' ?></td><td class="text-right amount-out"><?= !$isIn && $effective ? sseru_cashbook_money($entry['amount']) : '—' ?></td>
  </tr><?php endforeach; endif; ?>
  </tbody></table></div>
  <?php if ($totalPages > 1): $pageQuery = $_GET; unset($pageQuery['export']); ?><nav class="no-print mt-3" aria-label="Cashbook pages"><ul class="pagination flex-wrap mb-0"><?php $pageQuery['page'] = max(1, $page - 1); ?><li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="?<?= sseru_cashbook_h(http_build_query($pageQuery)) ?>">Previous</a></li><?php for ($p = max(1, $page - 2); $p <= min($totalPages, $page + 2); $p++): $pageQuery['page'] = $p; ?><li class="page-item <?= $p === $page ? 'active' : '' ?>"><a class="page-link" href="?<?= sseru_cashbook_h(http_build_query($pageQuery)) ?>"><?= $p ?></a></li><?php endfor; ?><?php $pageQuery['page'] = min($totalPages, $page + 1); ?><li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>"><a class="page-link" href="?<?= sseru_cashbook_h(http_build_query($pageQuery)) ?>">Next</a></li></ul></nav><?php endif; ?>
 </section>
 <div class="footer-note">School Management System &mdash; Bursar Cashbook. Balances are calculated from recorded completed transactions.</div>
 </div>
</main>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>(function(){var sidebar=document.getElementById('sidebar'),button=document.getElementById('mobileMenuBtn');if(button&&sidebar)button.addEventListener('click',function(){sidebar.classList.toggle('show');});document.addEventListener('click',function(e){if(window.innerWidth<=991&&sidebar&&sidebar.classList.contains('show')&&!sidebar.contains(e.target)&&button&&!button.contains(e.target))sidebar.classList.remove('show');});})();</script>
</body>
</html>

