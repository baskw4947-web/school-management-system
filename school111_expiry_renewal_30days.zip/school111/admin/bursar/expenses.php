<?php
/**
 * School Management System - Bursar Expense Management
 * Suggested path: /admin/bursar/expenses.php
 */
ob_start();
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

set_exception_handler(function (Throwable $ex) {
    error_log('Expenses page error: ' . $ex->getMessage() . ' in ' . $ex->getFile() . ':' . $ex->getLine());
    if (!headers_sent()) {
        http_response_code(500);
    }
    while (ob_get_level() > 0) { @ob_end_clean(); }
    $detail = htmlspecialchars($ex->getMessage(), ENT_QUOTES, 'UTF-8');
    $location = htmlspecialchars(basename($ex->getFile()) . ':' . $ex->getLine(), ENT_QUOTES, 'UTF-8');
    $isSignedIn = isset($_SESSION['user_id']) && in_array(($_SESSION['role'] ?? ''), ['administrator', 'assistant_administrator', 'bursar'], true);
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Expenses - Error</title><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"></head><body class="bg-light"><div class="container py-5"><div class="alert alert-danger"><h4>Expenses page could not load</h4><p class="mb-2">A database or PHP error occurred.</p>' . ($isSignedIn ? '<p><strong>Technical error:</strong> ' . $detail . '<br><strong>Location:</strong> ' . $location . '</p>' : '<p>Sign in with an authorized school account to view the diagnostic details.</p>') . '<p class="mb-0">The full details were also written to the hosting PHP error log.</p></div><a class="btn btn-primary" href="expenses.php">Reload page</a></div></body></html>';
    exit;
});

require_once '../../config/database.php';
require_once '../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator', 'bursar']);

$db = $conn ?? ($mysqli ?? ($connection ?? null));
if (!$db instanceof mysqli) {
    throw new RuntimeException('Database connection was not found. Check config/database.php.');
}
$db->set_charset('utf8mb4');
$userId = (int)($_SESSION['user_id'] ?? $_SESSION['id'] ?? 0);

function ex_h($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}
function ex_redirect(string $message, string $type = 'success'): void {
    $_SESSION['expense_flash'] = $message;
    $_SESSION['expense_flash_type'] = $type;
    header('Location: expenses.php');
    exit;
}
function ex_valid_date(string $value): bool {
    if ($value === '') return false;
    $date = DateTime::createFromFormat('!Y-m-d', $value);
    return $date !== false && $date->format('Y-m-d') === $value;
}
function ex_bind(mysqli_stmt $stmt, string $types, array &$params): void {
    if ($types === '') return;
    $args = [$types];
    foreach ($params as &$param) $args[] = &$param;
    unset($param);
    call_user_func_array([$stmt, 'bind_param'], $args);
}
function ex_money($amount): string {
    return number_format((float)$amount, 2);
}
function ex_make_transaction_no(mysqli $db, string $date): string {
    $prefix = 'EXP-' . date('Ymd', strtotime($date)) . '-';
    for ($i = 0; $i < 10; $i++) {
        $number = $prefix . strtoupper(bin2hex(random_bytes(3)));
        $stmt = $db->prepare('SELECT id FROM expense_transactions WHERE transaction_no = ? LIMIT 1');
        $stmt->bind_param('s', $number);
        $stmt->execute();
        $exists = $stmt->get_result()->num_rows > 0;
        $stmt->close();
        if (!$exists) return $number;
    }
    throw new RuntimeException('Unable to generate a unique expense transaction number. Please try again.');
}

/* Create the tables this module needs if they do not exist. */
$db->query("CREATE TABLE IF NOT EXISTS expense_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL,
    description VARCHAR(255) DEFAULT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_expense_category_name (category_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$db->query("CREATE TABLE IF NOT EXISTS payment_methods (
    id INT AUTO_INCREMENT PRIMARY KEY,
    method_name VARCHAR(50) NOT NULL,
    description VARCHAR(255) DEFAULT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_payment_method_name (method_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$db->query("CREATE TABLE IF NOT EXISTS expense_transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transaction_no VARCHAR(50) NOT NULL,
    category_id INT NOT NULL,
    amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
    expense_date DATETIME NOT NULL,
    payment_method_id INT DEFAULT NULL,
    reference_no VARCHAR(100) DEFAULT NULL,
    payee_name VARCHAR(150) DEFAULT NULL,
    description TEXT DEFAULT NULL,
    created_by INT DEFAULT NULL,
    status ENUM('completed','cancelled','reversed') NOT NULL DEFAULT 'completed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_expense_transaction_no (transaction_no),
    INDEX idx_expense_date (expense_date),
    INDEX idx_expense_category (category_id),
    INDEX idx_expense_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

/*
 * Compatibility migration: older versions of the school system may already
 * have created one of these tables with fewer columns. CREATE TABLE IF NOT
 * EXISTS does not update an existing table, so add any columns this page uses.
 */
function ex_has_column(mysqli $db, string $table, string $column): bool {
    $tableSafe = str_replace('`', '``', $table);
    $columnEscaped = $db->real_escape_string($column);
    $result = $db->query("SHOW COLUMNS FROM `$tableSafe` LIKE '$columnEscaped'");
    return $result && $result->num_rows > 0;
}

function ex_ensure_column(mysqli $db, string $table, string $column, string $definition): void {
    if (!ex_has_column($db, $table, $column)) {
        $tableSafe = str_replace('`', '``', $table);
        $columnSafe = str_replace('`', '``', $column);
        $db->query("ALTER TABLE `$tableSafe` ADD COLUMN `$columnSafe` $definition");
    }
}

function ex_copy_legacy_column(mysqli $db, string $table, string $destination, array $sources): void {
    if (!ex_has_column($db, $table, $destination)) return;
    $tableSafe = str_replace('`', '``', $table);
    $destinationSafe = str_replace('`', '``', $destination);
    foreach ($sources as $source) {
        if (ex_has_column($db, $table, $source)) {
            $sourceSafe = str_replace('`', '``', $source);
            $db->query("UPDATE `$tableSafe` SET `$destinationSafe` = `$sourceSafe` WHERE (`$destinationSafe` IS NULL OR `$destinationSafe` = '' OR `$destinationSafe` = 'Other') AND `$sourceSafe` IS NOT NULL AND `$sourceSafe` <> ''");
            break;
        }
    }
}

// Make category and payment-method columns compatible with older tables.
ex_ensure_column($db, 'expense_categories', 'category_name', "VARCHAR(100) NOT NULL DEFAULT 'Other'");
ex_ensure_column($db, 'expense_categories', 'description', 'VARCHAR(255) NULL DEFAULT NULL');
ex_ensure_column($db, 'expense_categories', 'status', "ENUM('active','inactive') NOT NULL DEFAULT 'active'");
ex_ensure_column($db, 'expense_categories', 'created_at', 'TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP');
ex_copy_legacy_column($db, 'expense_categories', 'category_name', ['name', 'category', 'title']);

ex_ensure_column($db, 'payment_methods', 'method_name', "VARCHAR(50) NOT NULL DEFAULT 'Other'");
ex_ensure_column($db, 'payment_methods', 'description', 'VARCHAR(255) NULL DEFAULT NULL');
ex_ensure_column($db, 'payment_methods', 'status', "ENUM('active','inactive') NOT NULL DEFAULT 'active'");
ex_ensure_column($db, 'payment_methods', 'created_at', 'TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP');
ex_copy_legacy_column($db, 'payment_methods', 'method_name', ['name', 'method', 'payment_method']);

// Ensure all columns referenced by the form, list and summary queries exist.
ex_ensure_column($db, 'expense_transactions', 'transaction_no', "VARCHAR(50) NOT NULL DEFAULT ''");
ex_ensure_column($db, 'expense_transactions', 'category_id', 'INT NOT NULL DEFAULT 1');
ex_ensure_column($db, 'expense_transactions', 'amount', 'DECIMAL(14,2) NOT NULL DEFAULT 0.00');
ex_ensure_column($db, 'expense_transactions', 'expense_date', 'DATETIME NULL DEFAULT NULL');
ex_ensure_column($db, 'expense_transactions', 'payment_method_id', 'INT NULL DEFAULT NULL');
ex_ensure_column($db, 'expense_transactions', 'reference_no', 'VARCHAR(100) NULL DEFAULT NULL');
ex_ensure_column($db, 'expense_transactions', 'payee_name', 'VARCHAR(150) NULL DEFAULT NULL');
ex_ensure_column($db, 'expense_transactions', 'description', 'TEXT NULL DEFAULT NULL');
ex_ensure_column($db, 'expense_transactions', 'created_by', 'INT NULL DEFAULT NULL');
ex_ensure_column($db, 'expense_transactions', 'status', "VARCHAR(20) NOT NULL DEFAULT 'completed'");
ex_ensure_column($db, 'expense_transactions', 'created_at', 'TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP');
ex_ensure_column($db, 'expense_transactions', 'updated_at', 'TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP');
ex_copy_legacy_column($db, 'expense_transactions', 'transaction_no', ['expense_no', 'reference_no']);
ex_copy_legacy_column($db, 'expense_transactions', 'expense_date', ['transaction_date', 'date', 'created_at']);
ex_copy_legacy_column($db, 'expense_transactions', 'payee_name', ['supplier_name', 'payee', 'supplier']);

// Some older schemas used a limited ENUM for status. Widen it so this page
// can safely set completed, cancelled and reversed values.
$statusColumnResult = $db->query("SHOW COLUMNS FROM expense_transactions LIKE 'status'");
if ($statusColumnResult && ($statusColumn = $statusColumnResult->fetch_assoc())) {
    if (stripos((string)$statusColumn['Type'], 'enum(') === 0) {
        $db->query("ALTER TABLE expense_transactions MODIFY COLUMN status VARCHAR(20) NOT NULL DEFAULT 'completed'");
    }
}

$defaultCategories = [
    'Salaries and Wages', 'Utilities', 'Teaching Materials', 'School Supplies',
    'Repairs and Maintenance', 'Transport', 'Supplier Payments', 'Cleaning',
    'ICT and Equipment', 'School Projects', 'Administration', 'Bank Charges', 'Other'
];
$catInsert = $db->prepare("INSERT IGNORE INTO expense_categories (category_name) VALUES (?)");
foreach ($defaultCategories as $catName) {
    $catInsert->bind_param('s', $catName);
    $catInsert->execute();
}
$catInsert->close();

$defaultMethods = [
    ['Cash', 'Cash payment'],
    ['Mobile Money', 'Mobile money payment'],
    ['Bank', 'Bank payment or transfer'],
    ['Cheque', 'Cheque payment'],
    ['Other', 'Other payment method']
];
$methodInsert = $db->prepare("INSERT IGNORE INTO payment_methods (method_name, description) VALUES (?, ?)");
foreach ($defaultMethods as $methodData) {
    $methodInsert->bind_param('ss', $methodData[0], $methodData[1]);
    $methodInsert->execute();
}
$methodInsert->close();

if (empty($_SESSION['expense_csrf'])) {
    $_SESSION['expense_csrf'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['expense_csrf'];

/* Handle all forms using POST/Redirect/GET. */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postedToken = (string)($_POST['csrf_token'] ?? '');
    if ($postedToken === '' || !hash_equals($csrf, $postedToken)) {
        ex_redirect('Your session security token has expired. Please try again.', 'danger');
    }
    $action = (string)($_POST['action'] ?? '');

    if ($action === 'save_expense') {
        $id = filter_var($_POST['transaction_id'] ?? 0, FILTER_VALIDATE_INT);
        $id = $id && $id > 0 ? $id : 0;
        $categoryId = (int)($_POST['category_id'] ?? 0);
        $amountInput = trim((string)($_POST['amount'] ?? ''));
        $expenseDate = trim((string)($_POST['expense_date'] ?? ''));
        $methodId = (int)($_POST['payment_method_id'] ?? 0);
        $reference = trim((string)($_POST['reference_no'] ?? ''));
        $payee = trim((string)($_POST['payee_name'] ?? ''));
        $description = trim((string)($_POST['description'] ?? ''));
        $errors = [];

        if ($categoryId <= 0) $errors[] = 'Please select an expense category.';
        if ($amountInput === '' || !is_numeric($amountInput) || (float)$amountInput <= 0 || (float)$amountInput > 999999999999.99) $errors[] = 'Enter a valid amount greater than zero.';
        if ($expenseDate === '') $errors[] = 'Please select the expense date and time.';
        else {
            $parsed = DateTime::createFromFormat('Y-m-d\TH:i', $expenseDate);
            if (!$parsed || $parsed->format('Y-m-d\TH:i') !== $expenseDate) $errors[] = 'The expense date is invalid.';
        }
        if (strlen($reference) > 100) $errors[] = 'Reference number must be 100 characters or fewer.';
        if (strlen($payee) > 150) $errors[] = 'Payee name must be 150 characters or fewer.';
        if ($methodId < 0) $errors[] = 'Invalid payment method.';

        if ($categoryId > 0) {
            $check = $db->prepare("SELECT id FROM expense_categories WHERE id = ? AND status = 'active' LIMIT 1");
            $check->bind_param('i', $categoryId);
            $check->execute();
            if ($check->get_result()->num_rows === 0) $errors[] = 'The selected expense category is not active.';
            $check->close();
        }
        if ($methodId > 0) {
            $check = $db->prepare("SELECT id FROM payment_methods WHERE id = ? AND status = 'active' LIMIT 1");
            $check->bind_param('i', $methodId);
            $check->execute();
            if ($check->get_result()->num_rows === 0) $errors[] = 'The selected payment method is invalid or inactive.';
            $check->close();
        }

        if ($errors) {
            ex_redirect(implode(' ', $errors), 'danger');
        }
        $amount = round((float)$amountInput, 2);
        $expenseDateDb = str_replace('T', ' ', $expenseDate) . ':00';
        $methodId = max(0, $methodId);
        $referenceDb = $reference;
        $payeeDb = $payee;
        $descriptionDb = $description;

        try {
            if ($id > 0) {
                $check = $db->prepare("SELECT status FROM expense_transactions WHERE id = ? LIMIT 1");
                $check->bind_param('i', $id);
                $check->execute();
                $existing = $check->get_result()->fetch_assoc();
                $check->close();
                if (!$existing) ex_redirect('Expense transaction was not found.', 'danger');
                if ($existing['status'] !== 'completed') ex_redirect('Only completed expense transactions can be edited.', 'warning');

                $stmt = $db->prepare("UPDATE expense_transactions
                    SET category_id = ?, amount = ?, expense_date = ?,
                        payment_method_id = NULLIF(?, 0), reference_no = NULLIF(?, ''),
                        payee_name = NULLIF(?, ''), description = NULLIF(?, '')
                    WHERE id = ? AND status = 'completed'");
                $stmt->bind_param('idsisssi', $categoryId, $amount, $expenseDateDb, $methodId, $referenceDb, $payeeDb, $descriptionDb, $id);
                $stmt->execute();
                $changed = $stmt->affected_rows;
                $stmt->close();
                ex_redirect($changed >= 0 ? 'Expense transaction updated successfully.' : 'No expense transaction was updated.', 'success');
            } else {
                $transactionNo = ex_make_transaction_no($db, $expenseDateDb);
                $stmt = $db->prepare("INSERT INTO expense_transactions
                    (transaction_no, category_id, amount, expense_date, payment_method_id, reference_no, payee_name, description, created_by, status)
                    VALUES (?, ?, ?, ?, NULLIF(?, 0), NULLIF(?, ''), NULLIF(?, ''), NULLIF(?, ''), ?, 'completed')");
                $stmt->bind_param('sidsisssi', $transactionNo, $categoryId, $amount, $expenseDateDb, $methodId, $referenceDb, $payeeDb, $descriptionDb, $userId);
                $stmt->execute();
                $stmt->close();
                ex_redirect('Expense recorded successfully. Transaction number: ' . $transactionNo);
            }
        } catch (mysqli_sql_exception $ex) {
            error_log('Expense save SQL error: ' . $ex->getMessage());
            ex_redirect('Unable to save the expense. Please check your database structure and PHP error log.', 'danger');
        }
    }

    if ($action === 'cancel_expense' || $action === 'reverse_expense') {
        $id = filter_var($_POST['transaction_id'] ?? 0, FILTER_VALIDATE_INT);
        if (!$id || $id < 1) ex_redirect('Invalid expense transaction.', 'danger');
        $newStatus = $action === 'cancel_expense' ? 'cancelled' : 'reversed';
        $stmt = $db->prepare("UPDATE expense_transactions SET status = ? WHERE id = ? AND status = 'completed'");
        $stmt->bind_param('si', $newStatus, $id);
        $stmt->execute();
        $changed = $stmt->affected_rows;
        $stmt->close();
        ex_redirect($changed > 0 ? 'Expense transaction ' . $newStatus . ' successfully.' : 'Transaction was not found or is no longer completed.', $changed > 0 ? 'success' : 'warning');
    }
    ex_redirect('Invalid expense request.', 'danger');
}

$flash = (string)($_SESSION['expense_flash'] ?? '');
$flashType = (string)($_SESSION['expense_flash_type'] ?? 'success');
unset($_SESSION['expense_flash'], $_SESSION['expense_flash_type']);
if (!in_array($flashType, ['success','danger','warning','info'], true)) $flashType = 'info';

/* Edit form */
$editId = filter_input(INPUT_GET, 'edit', FILTER_VALIDATE_INT);
$editEntry = null;
if ($editId && $editId > 0) {
    $stmt = $db->prepare('SELECT * FROM expense_transactions WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $editId);
    $stmt->execute();
    $editEntry = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$editEntry) { $flash = 'Expense transaction was not found.'; $flashType = 'warning'; }
    elseif ($editEntry['status'] !== 'completed') { $flash = 'Only completed expense transactions can be edited.'; $flashType = 'warning'; $editEntry = null; }
}

/* Categories and payment methods */
$categories = [];
$result = $db->query("SELECT id, category_name FROM expense_categories WHERE status = 'active' ORDER BY category_name");
while ($row = $result->fetch_assoc()) $categories[] = $row;
$paymentMethods = [];
$result = $db->query("SELECT id, method_name FROM payment_methods WHERE status = 'active' ORDER BY method_name");
while ($row = $result->fetch_assoc()) $paymentMethods[] = $row;

/* Filters */
$search = trim((string)($_GET['search'] ?? ''));
$categoryFilter = (int)($_GET['category_id'] ?? 0);
$dateFrom = trim((string)($_GET['date_from'] ?? ''));
$dateTo = trim((string)($_GET['date_to'] ?? ''));
$statusFilter = trim((string)($_GET['status'] ?? 'completed'));
$validStatuses = ['completed','cancelled','reversed'];
if (!in_array($statusFilter, $validStatuses, true)) $statusFilter = '';
if ($dateFrom !== '' && !ex_valid_date($dateFrom)) $dateFrom = '';
if ($dateTo !== '' && !ex_valid_date($dateTo)) $dateTo = '';

$where = [];
$params = [];
$types = '';
if ($search !== '') {
    $where[] = '(et.transaction_no LIKE ? OR et.reference_no LIKE ? OR et.description LIKE ? OR et.payee_name LIKE ? OR ec.category_name LIKE ?)';
    $like = '%' . $search . '%';
    for ($i = 0; $i < 5; $i++) { $params[] = $like; $types .= 's'; }
}
if ($categoryFilter > 0) { $where[] = 'et.category_id = ?'; $params[] = $categoryFilter; $types .= 'i'; }
if ($dateFrom !== '') { $where[] = 'DATE(et.expense_date) >= ?'; $params[] = $dateFrom; $types .= 's'; }
if ($dateTo !== '') { $where[] = 'DATE(et.expense_date) <= ?'; $params[] = $dateTo; $types .= 's'; }
if ($statusFilter !== '') { $where[] = 'et.status = ?'; $params[] = $statusFilter; $types .= 's'; }
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$joins = ' FROM expense_transactions et LEFT JOIN expense_categories ec ON ec.id = et.category_id LEFT JOIN payment_methods pm ON pm.id = et.payment_method_id LEFT JOIN users u ON u.id = et.created_by ';

/* Filtered summary */
$summarySql = "SELECT COUNT(*) AS count_records,
    COALESCE(SUM(CASE WHEN et.status = 'completed' THEN et.amount ELSE 0 END), 0) AS filtered_expenses,
    COALESCE(SUM(CASE WHEN et.status = 'completed' AND DATE(et.expense_date) = CURDATE() THEN et.amount ELSE 0 END), 0) AS filtered_today
    $joins $whereSql";
$stmt = $db->prepare($summarySql);
$summaryParams = $params;
ex_bind($stmt, $types, $summaryParams);
$stmt->execute();
$summary = $stmt->get_result()->fetch_assoc();
$stmt->close();

/* All-time today and month totals use completed expenses only. */
$todayResult = $db->query("SELECT COALESCE(SUM(amount),0) AS total FROM expense_transactions WHERE status='completed' AND DATE(expense_date)=CURDATE()");
$todayExpense = (float)$todayResult->fetch_assoc()['total'];
$monthResult = $db->query("SELECT COALESCE(SUM(amount),0) AS total FROM expense_transactions WHERE status='completed' AND YEAR(expense_date)=YEAR(CURDATE()) AND MONTH(expense_date)=MONTH(CURDATE())");
$monthExpense = (float)$monthResult->fetch_assoc()['total'];
$allTimeResult = $db->query("SELECT COALESCE(SUM(CASE WHEN status='completed' THEN amount ELSE 0 END),0) AS total FROM expense_transactions");
$allTimeExpense = (float)$allTimeResult->fetch_assoc()['total'];

/* Transactions list */
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 15;
$countSql = "SELECT COUNT(*) AS total $joins $whereSql";
$stmt = $db->prepare($countSql);
$countParams = $params;
ex_bind($stmt, $types, $countParams);
$stmt->execute();
$totalRecords = (int)$stmt->get_result()->fetch_assoc()['total'];
$stmt->close();
$totalPages = max(1, (int)ceil($totalRecords / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;
$listSql = "SELECT et.id, et.transaction_no, et.category_id, et.amount, et.expense_date,
    et.payment_method_id, et.reference_no, et.payee_name, et.description, et.created_by,
    et.status, et.created_at, ec.category_name, pm.method_name AS payment_method,
    u.full_name AS created_by_name $joins $whereSql
    ORDER BY et.expense_date DESC, et.id DESC LIMIT ? OFFSET ?";
$stmt = $db->prepare($listSql);
$listTypes = $types . 'ii';
$listParams = $params;
$listParams[] = $perPage;
$listParams[] = $offset;
ex_bind($stmt, $listTypes, $listParams);
$stmt->execute();
$transactions = $stmt->get_result();
$stmt->close();

$fullName = (string)($_SESSION['full_name'] ?? 'User');
$userRole = (string)($_SESSION['role'] ?? '');
$formDate = $editEntry ? date('Y-m-d\TH:i', strtotime($editEntry['expense_date'])) : date('Y-m-d\TH:i');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Expenses | School Management System</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
*{box-sizing:border-box}
body{margin:0;background:#f5f6fa;font-family:Arial,Helvetica,sans-serif;color:#343a40}
.sidebar{position:fixed;top:0;left:0;bottom:0;width:250px;background:#212529;color:#fff;z-index:1050;overflow-y:auto;transition:left .25s}
.sidebar-header{padding:20px 15px;color:#fff;font-weight:700;border-bottom:1px solid rgba(255,255,255,.1);font-size:18px}
.sidebar-menu{padding:15px 10px}
.sidebar-section{color:#6c757d;font-size:11px;text-transform:uppercase;padding:12px 10px 6px;letter-spacing:1px;font-weight:700}
.sidebar-menu a{display:block;color:#ced4da;padding:12px 15px;margin-bottom:3px;text-decoration:none;border-radius:6px;font-size:14px;transition:background .2s,color .2s}
.sidebar-menu a:hover{background:#343a40;color:#fff}
.sidebar-menu a.active{background:#dc3545;color:#fff}
.sidebar-menu i{width:25px;text-align:center;margin-right:5px}
.main-content{margin-left:250px;padding:25px;min-height:100vh}
.topbar,.page-header,.stat-card,.content-card{background:#fff;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,.05)}
.topbar{padding:15px 20px;margin-bottom:22px}
.page-header{padding:20px;margin-bottom:20px}
.stat-card{padding:19px;margin-bottom:20px;height:100%}
.stat-title{font-size:13px;color:#6c757d;margin-bottom:4px}
.stat-value{font-size:23px;font-weight:700;overflow-wrap:anywhere}
.stat-icon{width:48px;height:48px;display:flex;align-items:center;justify-content:center;border-radius:10px;background:#e9f5ff;color:#007bff;font-size:20px}
.content-card{margin-bottom:24px}
.content-card-header{padding:17px 20px;border-bottom:1px solid #eee}
.content-card-body{padding:20px}
.table thead th{background:#f8f9fa;border-top:none;white-space:nowrap;font-size:13px}
.table td{vertical-align:middle;font-size:14px}
.transaction-number{font-weight:700;color:#007bff}
.amount{font-weight:700;white-space:nowrap}
.form-control,.custom-select,.btn{border-radius:6px}
.form-control,.custom-select{min-height:40px}
.mobile-menu{display:none}
.badge{padding:7px 9px}
.muted-small{font-size:13px;color:#6c757d}
.sidebar-overlay{display:none}
@media(max-width:991px){.sidebar{left:-250px}.sidebar.show{left:0}.main-content{margin-left:0;padding:15px}.mobile-menu{display:inline-block}.sidebar-overlay.show{display:block;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:1040}}
@media print{.sidebar,.topbar,.no-print,.sidebar-overlay{display:none!important}.main-content{margin:0;padding:0}.content-card,.stat-card,.page-header{box-shadow:none}body{background:#fff}}
</style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-header"><i class="fas fa-university mr-1"></i> <span>Bursar</span></div>
  <nav class="sidebar-menu">
    <a href="/admin/bursar/index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>

    <div class="sidebar-section">Students &amp; Fees</div>
    <a href="/admin/bursar/students_fees.php"><i class="fas fa-file-invoice-dollar"></i> Student Fees</a>
    <a href="/admin/bursar/students_fee_accounts.php"><i class="fas fa-file-invoice-dollar"></i> Student Fee Accounts</a>
    <a href="/admin/bursar/fee_structure.php"><i class="fas fa-list-alt"></i> Fee Structure</a>
    <a href="/admin/bursar/payments.php"><i class="fas fa-money-bill-wave"></i> Receive Payment</a>
    <a href="/admin/bursar/outstanding_fees.php"><i class="fas fa-exclamation-circle"></i> Outstanding Fees</a>

    <div class="sidebar-section">Finance</div>
    <a href="/admin/bursar/income.php"><i class="fas fa-arrow-circle-down"></i> Income</a>
    <a href="/admin/bursar/expenses.php" class="active"><i class="fas fa-arrow-circle-up"></i> Expenses</a>
    <a href="/admin/bursar/suppliers.php"><i class="fas fa-truck"></i> Suppliers</a>
    <a href="/admin/bursar/supplier_payments.php"><i class="fas fa-hand-holding-usd"></i> Supplier Payments</a>

    <div class="sidebar-section">Payroll &amp; Budget</div>
    <a href="/admin/bursar/salaries.php"><i class="fas fa-users"></i> Salaries</a>
    <a href="/admin/bursar/salary_payments.php"><i class="fas fa-money-check-alt"></i> Salary Payments</a>
    <a href="/admin/bursar/budgets.php"><i class="fas fa-chart-pie"></i> Budgets</a>

    <div class="sidebar-section">Reports</div>
    <a href="/admin/bursar/cashbook.php"><i class="fas fa-book"></i> Cashbook</a>
    <a href="/admin/bursar/reports.php"><i class="fas fa-chart-line"></i> Financial Reports</a>
    <a href="/admin/bursar/income_report.php"><i class="fas fa-file-invoice"></i> Income Report</a>
    <a href="/admin/bursar/expense_report.php"><i class="fas fa-receipt"></i> Expense Report</a>
    <a href="/admin/bursar/fees_report.php"><i class="fas fa-file-alt"></i> Fees Report</a>
    <a href="/admin/bursar/profit_loss.php"><i class="fas fa-balance-scale"></i> Profit &amp; Loss</a>

    <div class="sidebar-section">System</div>
    <a href="/admin/dashboard.php"><i class="fas fa-user-shield"></i> Admin Dashboard</a>
    <a href="/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </nav>
</aside>
<main class="main-content">
  <div class="topbar d-flex align-items-center justify-content-between">
    <div><button type="button" class="btn btn-outline-primary mobile-menu mr-2" id="mobileMenuButton"><i class="fas fa-bars"></i></button><strong>Expense Management</strong></div>
    <div class="text-right"><strong><?= ex_h($fullName) ?></strong><br><small class="text-muted"><?= ex_h(ucwords(str_replace('_',' ',$userRole))) ?></small></div>
  </div>
  <div class="page-header d-flex flex-wrap justify-content-between align-items-center">
    <div><h3 class="mb-1"><i class="fas fa-arrow-circle-up text-danger mr-1"></i> School Expenses</h3><p class="text-muted mb-0">Record, search, and manage school expenditure.</p></div>
    <div class="mt-2 no-print"><button class="btn btn-danger" type="button" data-toggle="collapse" data-target="#expenseForm"><i class="fas fa-plus-circle mr-1"></i><?= $editEntry ? 'Edit Expense' : 'Add Expense' ?></button> <button class="btn btn-secondary" type="button" onclick="window.print()"><i class="fas fa-print mr-1"></i> Print</button></div>
  </div>
  <?php if ($flash !== ''): ?><div class="alert alert-<?= ex_h($flashType) ?> alert-dismissible fade show" role="alert"><?= ex_h($flash) ?><button type="button" class="close" data-dismiss="alert"><span>&times;</span></button></div><?php endif; ?>
  <div class="row mb-1">
    <div class="col-md-6 col-xl-3 mb-3"><div class="stat-card"><div class="d-flex align-items-center"><div class="stat-icon mr-3"><i class="fas fa-receipt"></i></div><div><div class="stat-title">Filtered Transactions</div><div class="stat-value"><?= number_format((int)$summary['count_records']) ?></div></div></div></div></div>
    <div class="col-md-6 col-xl-3 mb-3"><div class="stat-card"><div class="d-flex align-items-center"><div class="stat-icon mr-3 text-danger" style="background:#fdebed"><i class="fas fa-money-bill-wave"></i></div><div><div class="stat-title">Filtered Completed Expenses</div><div class="stat-value">UGX <?= ex_money($summary['filtered_expenses']) ?></div></div></div></div></div>
    <div class="col-md-6 col-xl-3 mb-3"><div class="stat-card"><div class="d-flex align-items-center"><div class="stat-icon mr-3" style="background:#e8f8ee;color:#218838"><i class="fas fa-calendar-day"></i></div><div><div class="stat-title">Today's Expenses</div><div class="stat-value">UGX <?= ex_money($todayExpense) ?></div></div></div></div></div>
    <div class="col-md-6 col-xl-3 mb-3"><div class="stat-card"><div class="d-flex align-items-center"><div class="stat-icon mr-3" style="background:#fff3cd;color:#856404"><i class="fas fa-calendar-alt"></i></div><div><div class="stat-title">This Month</div><div class="stat-value">UGX <?= ex_money($monthExpense) ?></div></div></div></div></div>
  </div>

  <section class="content-card collapse <?= $editEntry ? 'show' : '' ?> no-print" id="expenseForm">
    <div class="content-card-header"><h5 class="mb-0"><i class="fas fa-edit text-primary mr-2"></i><?= $editEntry ? 'Edit Expense Transaction' : 'Record New Expense' ?></h5></div>
    <div class="content-card-body">
      <form method="POST" action="expenses.php">
        <input type="hidden" name="csrf_token" value="<?= ex_h($csrf) ?>"><input type="hidden" name="action" value="save_expense">
        <?php if ($editEntry): ?><input type="hidden" name="transaction_id" value="<?= (int)$editEntry['id'] ?>"><?php endif; ?>
        <div class="row">
          <div class="col-md-6 col-lg-3 form-group"><label>Transaction No.</label><input type="text" class="form-control" readonly value="<?= ex_h($editEntry['transaction_no'] ?? 'Generated when saved') ?>"></div>
          <div class="col-md-6 col-lg-3 form-group"><label>Expense Category <span class="text-danger">*</span></label><select name="category_id" class="form-control" required><option value="">-- Select Category --</option><?php foreach ($categories as $category): ?><option value="<?= (int)$category['id'] ?>" <?= (int)($editEntry['category_id'] ?? 0) === (int)$category['id'] ? 'selected' : '' ?>><?= ex_h($category['category_name']) ?></option><?php endforeach; ?></select></div>
          <div class="col-md-6 col-lg-3 form-group"><label>Amount (UGX) <span class="text-danger">*</span></label><input type="number" name="amount" class="form-control" min="0.01" max="999999999999.99" step="0.01" required placeholder="0.00" value="<?= ex_h($editEntry['amount'] ?? '') ?>"></div>
          <div class="col-md-6 col-lg-3 form-group"><label>Expense Date &amp; Time <span class="text-danger">*</span></label><input type="datetime-local" name="expense_date" class="form-control" required value="<?= ex_h($formDate) ?>"></div>
          <div class="col-md-6 form-group"><label>Payee / Supplier</label><input type="text" name="payee_name" class="form-control" maxlength="150" placeholder="Person or company paid" value="<?= ex_h($editEntry['payee_name'] ?? '') ?>"></div>
          <div class="col-md-6 form-group"><label>Payment Method</label><select name="payment_method_id" class="form-control"><option value="0">-- Not specified --</option><?php foreach ($paymentMethods as $method): ?><option value="<?= (int)$method['id'] ?>" <?= (int)($editEntry['payment_method_id'] ?? 0) === (int)$method['id'] ? 'selected' : '' ?>><?= ex_h($method['method_name']) ?></option><?php endforeach; ?></select></div>
          <div class="col-md-6 form-group"><label>Receipt / Reference No.</label><input type="text" name="reference_no" maxlength="100" class="form-control" placeholder="Optional receipt, cheque or transfer reference" value="<?= ex_h($editEntry['reference_no'] ?? '') ?>"></div>
          <div class="col-md-6 form-group"><label>Description / Purpose</label><textarea name="description" class="form-control" rows="2" placeholder="Explain what this expense was for"><?= ex_h($editEntry['description'] ?? '') ?></textarea></div>
        </div>
        <button type="submit" class="btn btn-danger"><i class="fas fa-save mr-1"></i><?= $editEntry ? 'Update Expense' : 'Save Expense' ?></button>
        <?php if ($editEntry): ?> <a href="expenses.php" class="btn btn-light">Cancel Edit</a><?php endif; ?>
      </form>
    </div>
  </section>

  <section class="content-card no-print">
    <div class="content-card-header"><h5 class="mb-0"><i class="fas fa-filter mr-2"></i>Search &amp; Filter Expenses</h5></div>
    <div class="content-card-body">
      <form method="GET" action="expenses.php"><div class="row">
        <div class="col-lg-4 col-md-6 form-group"><label>Search</label><input type="text" name="search" class="form-control" placeholder="Transaction, payee, category, reference" value="<?= ex_h($search) ?>"></div>
        <div class="col-lg-2 col-md-6 form-group"><label>Category</label><select name="category_id" class="form-control"><option value="0">All categories</option><?php foreach ($categories as $category): ?><option value="<?= (int)$category['id'] ?>" <?= $categoryFilter === (int)$category['id'] ? 'selected' : '' ?>><?= ex_h($category['category_name']) ?></option><?php endforeach; ?></select></div>
        <div class="col-lg-2 col-md-6 form-group"><label>From Date</label><input type="date" name="date_from" class="form-control" value="<?= ex_h($dateFrom) ?>"></div>
        <div class="col-lg-2 col-md-6 form-group"><label>To Date</label><input type="date" name="date_to" class="form-control" value="<?= ex_h($dateTo) ?>"></div>
        <div class="col-lg-2 col-md-6 form-group"><label>Status</label><select name="status" class="form-control"><option value="">All statuses</option><option value="completed" <?= $statusFilter === 'completed' ? 'selected' : '' ?>>Completed</option><option value="cancelled" <?= $statusFilter === 'cancelled' ? 'selected' : '' ?>>Cancelled</option><option value="reversed" <?= $statusFilter === 'reversed' ? 'selected' : '' ?>>Reversed</option></select></div>
      </div><button class="btn btn-primary" type="submit"><i class="fas fa-search mr-1"></i>Apply Filters</button> <a href="expenses.php" class="btn btn-light">Clear Filters</a></form>
    </div>
  </section>

  <section class="content-card">
    <div class="content-card-header d-flex justify-content-between align-items-center flex-wrap"><h5 class="mb-1"><i class="fas fa-list mr-2"></i>Expense Transactions</h5><span class="badge badge-primary"><?= number_format($totalRecords) ?> Records</span></div>
    <div class="table-responsive"><table class="table table-hover table-bordered mb-0">
      <thead><tr><th>#</th><th>Transaction No.</th><th>Category / Description</th><th>Payee</th><th>Amount (UGX)</th><th>Date</th><th>Payment</th><th>Reference</th><th>Recorded By</th><th>Status</th><th class="no-print">Actions</th></tr></thead>
      <tbody>
      <?php if ($transactions->num_rows === 0): ?><tr><td colspan="11" class="text-center text-muted py-5"><i class="fas fa-receipt fa-3x mb-3"></i><h5>No expense transactions found</h5><p class="mb-0">Change the filters or record a new expense.</p></td></tr>
      <?php else: $rowNo = $offset + 1; while ($row = $transactions->fetch_assoc()): ?>
        <tr>
          <td><?= $rowNo++ ?></td><td><span class="transaction-number"><?= ex_h($row['transaction_no']) ?></span></td>
          <td><strong><?= ex_h($row['category_name'] ?: 'Unknown Category') ?></strong><?php if (!empty($row['description'])): ?><br><small class="text-muted"><?= ex_h(function_exists('mb_strimwidth') ? mb_strimwidth($row['description'], 0, 80, '…') : (strlen($row['description']) > 80 ? substr($row['description'], 0, 77) . '...' : $row['description'])) ?></small><?php endif; ?></td>
          <td><?= ex_h($row['payee_name'] ?: '—') ?></td><td class="amount text-danger"><?= ex_money($row['amount']) ?></td>
          <td><?= ex_h(date('d M Y', strtotime($row['expense_date']))) ?><br><small class="text-muted"><?= ex_h(date('H:i', strtotime($row['expense_date']))) ?></small></td>
          <td><?= ex_h($row['payment_method'] ?: 'Not specified') ?></td><td><?= ex_h($row['reference_no'] ?: '—') ?></td><td><?= ex_h($row['created_by_name'] ?: 'Unknown') ?></td>
          <td><?php if ($row['status'] === 'completed'): ?><span class="badge badge-success">Completed</span><?php elseif ($row['status'] === 'cancelled'): ?><span class="badge badge-danger">Cancelled</span><?php else: ?><span class="badge badge-warning">Reversed</span><?php endif; ?></td>
          <td class="no-print text-nowrap"><?php if ($row['status'] === 'completed'): ?>
            <a href="expenses.php?edit=<?= (int)$row['id'] ?>#expenseForm" class="btn btn-sm btn-outline-primary" title="Edit"><i class="fas fa-edit"></i></a>
            <form method="POST" action="expenses.php" class="d-inline" onsubmit="return confirm('Reverse this expense record?');"><input type="hidden" name="csrf_token" value="<?= ex_h($csrf) ?>"><input type="hidden" name="action" value="reverse_expense"><input type="hidden" name="transaction_id" value="<?= (int)$row['id'] ?>"><button class="btn btn-sm btn-outline-warning" title="Reverse"><i class="fas fa-undo"></i></button></form>
            <form method="POST" action="expenses.php" class="d-inline" onsubmit="return confirm('Cancel this expense record?');"><input type="hidden" name="csrf_token" value="<?= ex_h($csrf) ?>"><input type="hidden" name="action" value="cancel_expense"><input type="hidden" name="transaction_id" value="<?= (int)$row['id'] ?>"><button class="btn btn-sm btn-outline-danger" title="Cancel"><i class="fas fa-ban"></i></button></form>
          <?php else: ?><span class="text-muted">—</span><?php endif; ?></td>
        </tr>
      <?php endwhile; endif; ?>
      </tbody>
    </table></div>
    <?php if ($totalPages > 1): ?><div class="p-3 no-print"><nav><ul class="pagination mb-0 flex-wrap">
      <?php $pageQuery = $_GET; $pageQuery['page'] = max(1, $page - 1); ?><li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="?<?= ex_h(http_build_query($pageQuery)) ?>">Previous</a></li>
      <?php for ($p = max(1, $page - 2); $p <= min($totalPages, $page + 2); $p++): $pageQuery['page'] = $p; ?><li class="page-item <?= $p === $page ? 'active' : '' ?>"><a class="page-link" href="?<?= ex_h(http_build_query($pageQuery)) ?>"><?= $p ?></a></li><?php endfor; ?>
      <?php $pageQuery['page'] = min($totalPages, $page + 1); ?><li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>"><a class="page-link" href="?<?= ex_h(http_build_query($pageQuery)) ?>">Next</a></li>
    </ul></nav></div><?php endif; ?>
  </section>
  <p class="muted-small text-center">School Management System — Bursar Expense Module</p>
</main>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function(){
  const sidebar=document.getElementById('sidebar');
  const overlay=document.getElementById('sidebarOverlay');
  const button=document.getElementById('mobileMenuButton');
  function closeMenu(){sidebar.classList.remove('show');overlay.classList.remove('show');}
  if(button) button.addEventListener('click',function(){sidebar.classList.toggle('show');overlay.classList.toggle('show');});
  overlay.addEventListener('click',closeMenu);
  document.addEventListener('keydown',function(event){if(event.key==='Escape')closeMenu();});
})();
</script>
</body>
</html>


