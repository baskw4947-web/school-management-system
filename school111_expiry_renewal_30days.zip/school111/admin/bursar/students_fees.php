<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once "../../config/database.php";
require_once "../../includes/auth.php";

requireRole([
    'administrator',
    'assistant_administrator',
    'bursar'
]);

/*
|--------------------------------------------------------------------------
| Helper Functions
|--------------------------------------------------------------------------
*/

function tableExists($conn, $table)
{
    $table = $conn->real_escape_string($table);

    $result = $conn->query("
        SELECT COUNT(*) AS total
        FROM information_schema.tables
        WHERE table_schema = DATABASE()
        AND table_name = '$table'
    ");

    if (!$result) {
        return false;
    }

    $row = $result->fetch_assoc();

    return ((int)$row['total'] > 0);
}

function money($amount)
{
    return number_format((float)$amount, 2);
}

function e($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}


/*
|--------------------------------------------------------------------------
| Variables
|--------------------------------------------------------------------------
*/

$students = [];
$years = [];
$terms = [];

$search = trim($_GET['search'] ?? '');
$academicYear = trim($_GET['academic_year'] ?? '');
$term = trim($_GET['term'] ?? '');
$status = trim($_GET['status'] ?? '');

$viewAccountId = isset($_GET['account_id'])
    ? (int)$_GET['account_id']
    : 0;

$accountDetails = null;
$accountPayments = [];

$totalAccounts = 0;
$totalExpected = 0;
$totalPaid = 0;
$totalBalance = 0;


/*
|--------------------------------------------------------------------------
| Check Required Tables
|--------------------------------------------------------------------------
*/

$hasStudents = tableExists($conn, 'students');
$hasAccounts = tableExists($conn, 'student_fee_accounts');
$hasPayments = tableExists($conn, 'fee_payments');
$hasPaymentMethods = tableExists($conn, 'payment_methods');


/*
|--------------------------------------------------------------------------
| Get Academic Years
|--------------------------------------------------------------------------
*/

if ($hasAccounts) {

    $yearResult = $conn->query("
        SELECT DISTINCT academic_year
        FROM student_fee_accounts
        WHERE academic_year IS NOT NULL
        AND academic_year <> ''
        ORDER BY academic_year DESC
    ");

    if ($yearResult) {

        while ($row = $yearResult->fetch_assoc()) {
            $years[] = $row['academic_year'];
        }
    }
}


/*
|--------------------------------------------------------------------------
| Get Terms
|--------------------------------------------------------------------------
*/

if ($hasAccounts) {

    $termResult = $conn->query("
        SELECT DISTINCT term
        FROM student_fee_accounts
        WHERE term IS NOT NULL
        AND term <> ''
        ORDER BY
            CASE term
                WHEN 'Term 1' THEN 1
                WHEN 'Term 2' THEN 2
                WHEN 'Term 3' THEN 3
                ELSE 4
            END
    ");

    if ($termResult) {

        while ($row = $termResult->fetch_assoc()) {
            $terms[] = $row['term'];
        }
    }
}


/*
|--------------------------------------------------------------------------
| Load Student Fee Accounts
|--------------------------------------------------------------------------
*/

if ($hasStudents && $hasAccounts) {

    $where = [];
    $params = [];
    $types = '';

    /*
    | Search
    */

    if ($search !== '') {

        $where[] = "
            (
                CONCAT(s.first_name, ' ', s.last_name) LIKE ?
                OR s.admission_no LIKE ?
                OR s.lin_no LIKE ?
                OR s.student_payment_code LIKE ?
            )
        ";

        $searchValue = '%' . $search . '%';

        $params[] = $searchValue;
        $params[] = $searchValue;
        $params[] = $searchValue;
        $params[] = $searchValue;

        $types .= 'ssss';
    }


    /*
    | Academic Year
    */

    if ($academicYear !== '') {

        $where[] = "sfa.academic_year = ?";

        $params[] = $academicYear;

        $types .= 's';
    }


    /*
    | Term
    */

    if ($term !== '') {

        $where[] = "sfa.term = ?";

        $params[] = $term;

        $types .= 's';
    }


    /*
    | Status
    */

    if ($status !== '') {

        $where[] = "sfa.status = ?";

        $params[] = $status;

        $types .= 's';
    }


    $whereSQL = '';

    if (!empty($where)) {
        $whereSQL = 'WHERE ' . implode(' AND ', $where);
    }


    $sql = "
        SELECT
            sfa.id AS account_id,
            sfa.student_id,
            sfa.academic_year,
            sfa.term,
            sfa.total_amount,
            sfa.total_paid,
            sfa.discount_amount,
            sfa.amount_paid,
            sfa.balance,
            sfa.status,
            sfa.created_at,
            sfa.updated_at,

            s.admission_no,
            s.lin_no,
            s.student_payment_code,
            s.student_section,
            s.first_name,
            s.last_name,

            CONCAT(
                s.first_name,
                ' ',
                s.last_name
            ) AS student_name

        FROM student_fee_accounts sfa

        INNER JOIN students s
            ON sfa.student_id = s.id

        $whereSQL

        ORDER BY
            CASE sfa.status
                WHEN 'overdue' THEN 1
                WHEN 'partial' THEN 2
                WHEN 'pending' THEN 3
                WHEN 'paid' THEN 4
                ELSE 5
            END,
            s.first_name ASC,
            s.last_name ASC
    ";


    $stmt = $conn->prepare($sql);

    if ($stmt) {

        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }

        $stmt->execute();

        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {

            $students[] = $row;

            $totalAccounts++;

            $totalExpected += (float)$row['total_amount'];

            /*
            | Prefer amount_paid when populated,
            | otherwise use total_paid.
            */

            $paidAmount = (float)$row['amount_paid'];

            if ($paidAmount <= 0 && (float)$row['total_paid'] > 0) {
                $paidAmount = (float)$row['total_paid'];
            }

            $totalPaid += $paidAmount;

            $totalBalance += (float)$row['balance'];
        }

        $stmt->close();
    }
}


/*
|--------------------------------------------------------------------------
| View Single Fee Account
|--------------------------------------------------------------------------
*/

if ($viewAccountId > 0 && $hasStudents && $hasAccounts) {

    $stmt = $conn->prepare("
        SELECT
            sfa.id AS account_id,
            sfa.student_id,
            sfa.academic_year,
            sfa.term,
            sfa.total_amount,
            sfa.total_paid,
            sfa.discount_amount,
            sfa.amount_paid,
            sfa.balance,
            sfa.status,
            sfa.created_at,
            sfa.updated_at,

            s.admission_no,
            s.lin_no,
            s.student_payment_code,
            s.student_section,
            s.first_name,
            s.last_name,

            CONCAT(
                s.first_name,
                ' ',
                s.last_name
            ) AS student_name

        FROM student_fee_accounts sfa

        INNER JOIN students s
            ON sfa.student_id = s.id

        WHERE sfa.id = ?

        LIMIT 1
    ");

    if ($stmt) {

        $stmt->bind_param('i', $viewAccountId);

        $stmt->execute();

        $result = $stmt->get_result();

        $accountDetails = $result->fetch_assoc();

        $stmt->close();
    }


    /*
    | Payment History
    */

    if ($accountDetails && $hasPayments) {

        if ($hasPaymentMethods) {

            $stmt = $conn->prepare("
                SELECT
                    fp.id,
                    fp.receipt_no,
                    fp.amount,
                    fp.payment_date,
                    fp.reference_no,
                    fp.description,
                    fp.status,
                    pm.method_name

                FROM fee_payments fp

                LEFT JOIN payment_methods pm
                    ON fp.payment_method_id = pm.id

                WHERE fp.account_id = ?

                ORDER BY fp.payment_date DESC

            ");

        } else {

            $stmt = $conn->prepare("
                SELECT
                    fp.id,
                    fp.receipt_no,
                    fp.amount,
                    fp.payment_date,
                    fp.reference_no,
                    fp.description,
                    fp.status,
                    NULL AS method_name

                FROM fee_payments fp

                WHERE fp.account_id = ?

                ORDER BY fp.payment_date DESC
            ");
        }


        if ($stmt) {

            $stmt->bind_param('i', $viewAccountId);

            $stmt->execute();

            $result = $stmt->get_result();

            while ($row = $result->fetch_assoc()) {
                $accountPayments[] = $row;
            }

            $stmt->close();
        }
    }
}


/*
|--------------------------------------------------------------------------
| Current User
|--------------------------------------------------------------------------
*/

$fullName = $_SESSION['full_name'] ?? 'Bursar';
$role = $_SESSION['role'] ?? '';

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
   content="width=device-width, initial-scale=1.0">

<title>Student Fees - Bursar</title>

<link rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

<link rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<style>

body {
    margin: 0;
    background: #f4f6f9;
    font-family: Arial, Helvetica, sans-serif;
}


/* Sidebar */

.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 250px;
    height: 100vh;
    background: #343a40;
    color: #fff;
    z-index: 1050;
    transition: all 0.3s ease;
    overflow-y: auto;
}

.sidebar-header {
    height: 70px;
    display: flex;
    align-items: center;
    padding: 0 20px;
    background: #212529;
    font-size: 19px;
    font-weight: bold;
}

.sidebar-header i {
    margin-right: 10px;
}

.sidebar-menu {
    padding: 15px 0;
}

.sidebar-menu a {
    display: flex;
    align-items: center;
    color: #ced4da;
    text-decoration: none;
    padding: 13px 20px;
    font-size: 15px;
    transition: 0.2s;
}

.sidebar-menu a i {
    width: 30px;
    font-size: 16px;
}

.sidebar-menu a:hover,
.sidebar-menu a.active {
    background: #007bff;
    color: #fff;
}

.sidebar-section {
    padding: 15px 20px 7px;
    font-size: 11px;
    color: #868e96;
    text-transform: uppercase;
    letter-spacing: 1px;
}


/* Main */

.main-content {
    margin-left: 250px;
    min-height: 100vh;
}


/* Topbar */

.topbar {
    height: 70px;
    background: #fff;
    border-bottom: 1px solid #dee2e6;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 25px;
}

.menu-btn {
    border: none;
    background: transparent;
    font-size: 22px;
    color: #343a40;
    cursor: pointer;
}

.user-info {
    display: flex;
    align-items: center;
}

.user-avatar {
    width: 38px;
    height: 38px;
    border-radius: 50%;
    background: #007bff;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 10px;
}


/* Page */

.page-content {
    padding: 25px;
}

.page-title {
    font-weight: 600;
    color: #343a40;
    margin-bottom: 5px;
}

.page-subtitle {
    color: #6c757d;
    margin-bottom: 25px;
}


/* Cards */

.stat-card,
.content-card {
    background: #fff;
    border: none;
    border-radius: 10px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    margin-bottom: 25px;
}

.stat-card {
    padding: 20px;
}

.stat-title {
    color: #6c757d;
    font-size: 13px;
    margin-bottom: 5px;
}

.stat-value {
    font-size: 23px;
    font-weight: bold;
    color: #343a40;
}


/* Filters */

.filter-card {
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    padding: 20px;
    margin-bottom: 25px;
}


/* Table */

.content-card .card-header {
    background: #fff;
    border-bottom: 1px solid #eee;
    padding: 17px 20px;
    font-weight: 600;
}

.table th {
    border-top: none;
    font-size: 12px;
    color: #6c757d;
    white-space: nowrap;
}

.table td {
    vertical-align: middle;
    font-size: 13px;
}

.student-name {
    font-weight: 600;
    color: #343a40;
}

.admission {
    color: #6c757d;
    font-size: 12px;
}

.amount {
    font-weight: 600;
    white-space: nowrap;
}

.balance-danger {
    color: #dc3545;
}

.balance-success {
    color: #28a745;
}


/* Status */

.status-badge {
    padding: 6px 9px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
}

.status-paid {
    background: #d4edda;
    color: #155724;
}

.status-partial {
    background: #fff3cd;
    color: #856404;
}

.status-pending {
    background: #e2e3e5;
    color: #383d41;
}

.status-overdue {
    background: #f8d7da;
    color: #721c24;
}


/* Account */

.account-summary {
    border-radius: 10px;
    padding: 18px;
    background: #f8f9fa;
    border: 1px solid #e9ecef;
}

.account-number {
    font-size: 12px;
    color: #6c757d;
}


/* Overlay */

.overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 1040;
}


/* Mobile */

@media (max-width: 768px) {

    .sidebar {
        left: -250px;
    }

    .sidebar.show {
        left: 0;
    }

    .main-content {
        margin-left: 0;
    }

    .overlay.show {
        display: block;
    }

    .page-content {
        padding: 15px;
    }

    .topbar {
        padding: 0 15px;
    }

    .user-info .user-name {
        display: none;
    }

}

</style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>

<body>

<!-- ============================================================
     SIDEBAR
============================================================ -->

<div class="sidebar" id="sidebar">


<div class="sidebar-header">
    <i class="fas fa-university"></i>
    <span>Bursar</span>
</div>

<div class="sidebar-menu">

    <a href="/admin/bursar/index.php">
        <i class="fas fa-tachometer-alt"></i>
        <span>Dashboard</span>
    </a>

    <div class="sidebar-section">
        Fees
    </div>

    <a href="/admin/bursar/students_fees.php" class="active">
        <i class="fas fa-user-graduate"></i>
        <span>Student Fees</span>
    </a>
    <a href="/admin/bursar/students_fee_accounts.php" >
        <i class="fas fa-user-graduate"></i>
        <span>Student Fee Accounts</span>
    </a>

    <a href="/admin/bursar/fee_structure.php">
        <i class="fas fa-list-alt"></i>
        <span>Fee Structure</span>
    </a>

    <a href="/admin/bursar/payments.php">
        <i class="fas fa-money-bill-wave"></i>
        <span>Receive Payment</span>
    </a>

    <a href="/admin/bursar/outstanding_fees.php">
        <i class="fas fa-exclamation-circle"></i>
        <span>Outstanding Fees</span>
    </a>

    <div class="sidebar-section">
        Finance
    </div>

    <a href="/admin/bursar/income.php">
        <i class="fas fa-arrow-circle-down"></i>
        <span>Income</span>
    </a>

    <a href="/admin/bursar/expenses.php">
        <i class="fas fa-arrow-circle-up"></i>
        <span>Expenses</span>
    </a>

    <a href="/admin/bursar/suppliers.php">
        <i class="fas fa-truck"></i>
        <span>Suppliers</span>
    </a>

    <a href="/admin/bursar/supplier_payments.php">
        <i class="fas fa-hand-holding-usd"></i>
        <span>Supplier Payments</span>
    </a>

    <div class="sidebar-section">
        Payroll & Budget
    </div>

    <a href="/admin/bursar/salaries.php">
        <i class="fas fa-users"></i>
        <span>Salaries</span>
    </a>

    <a href="/admin/bursar/salary_payments.php">
        <i class="fas fa-money-check-alt"></i>
        <span>Salary Payments</span>
    </a>

    <a href="/admin/bursar/budgets.php">
        <i class="fas fa-chart-pie"></i>
        <span>Budgets</span>
    </a>

    <div class="sidebar-section">
        Reports
    </div>

    <a href="/admin/bursar/cashbook.php">
        <i class="fas fa-book"></i>
        <span>Cashbook</span>
    </a>

    <a href="/admin/bursar/reports.php">
        <i class="fas fa-chart-line"></i>
        <span>Financial Reports</span>
    </a>

    <a href="/admin/bursar/income_report.php">
        <i class="fas fa-file-invoice-dollar"></i>
        <span>Income Report</span>
    </a>

    <a href="/admin/bursar/expense_report.php">
        <i class="fas fa-file-invoice"></i>
        <span>Expense Report</span>
    </a>

    <a href="/admin/bursar/fees_report.php">
        <i class="fas fa-file-alt"></i>
        <span>Fees Report</span>
    </a>

    <a href="/admin/bursar/profit_loss.php">
        <i class="fas fa-balance-scale"></i>
        <span>Profit & Loss</span>
    </a>

    <div class="sidebar-section">
        System
    </div>

    <a href="/admin/dashboard.php">
        <i class="fas fa-home"></i>
        <span>Admin Dashboard</span>
    </a>

    <a href="/logout.php">
        <i class="fas fa-sign-out-alt"></i>
        <span>Logout</span>
    </a>

</div>


</div>

<div class="overlay" id="overlay"></div>

<!-- ============================================================
     MAIN
============================================================ -->

<div class="main-content">


<!-- TOPBAR -->

<div class="topbar">

    <button class="menu-btn" id="menuBtn">
        <i class="fas fa-bars"></i>
    </button>

    <div class="user-info">

        <div class="user-avatar">
            <i class="fas fa-user"></i>
        </div>

        <div class="user-name">

            <strong>
                <?php echo e($fullName); ?>
            </strong>

            <br>

            <small class="text-muted">
                <?php
                echo e(
                    ucwords(
                        str_replace('_', ' ', $role)
                    )
                );
                ?>
            </small>

        </div>

    </div>

</div>


<!-- PAGE -->

<div class="page-content">

    <h2 class="page-title">
        Student Fees
    </h2>

    <p class="page-subtitle">
        View student fee accounts, payments and outstanding balances.
    </p>


    <!-- ====================================================
         SUMMARY
    ===================================================== -->

    <div class="row">

        <div class="col-xl-3 col-md-6">

            <div class="stat-card">

                <div class="stat-title">
                    Fee Accounts
                </div>

                <div class="stat-value">
                    <?php echo number_format($totalAccounts); ?>
                </div>

            </div>

        </div>


        <div class="col-xl-3 col-md-6">

            <div class="stat-card">

                <div class="stat-title">
                    Total Expected
                </div>

                <div class="stat-value">
                    <?php echo money($totalExpected); ?>
                </div>

            </div>

        </div>


        <div class="col-xl-3 col-md-6">

            <div class="stat-card">

                <div class="stat-title">
                    Total Paid
                </div>

                <div class="stat-value text-success">
                    <?php echo money($totalPaid); ?>
                </div>

            </div>

        </div>


        <div class="col-xl-3 col-md-6">

            <div class="stat-card">

                <div class="stat-title">
                    Outstanding Balance
                </div>

                <div class="stat-value text-danger">
                    <?php echo money($totalBalance); ?>
                </div>

            </div>

        </div>

    </div>


    <!-- ====================================================
         FILTERS
    ===================================================== -->

    <div class="filter-card">

        <form method="GET"
              action="students_fees.php">

            <div class="row">


                <div class="col-lg-4 mb-3">

                    <label>
                        Search Student
                    </label>

                    <div class="input-group">

                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fas fa-search"></i>
                            </span>
                        </div>

                        <input
                            type="text"
                            name="search"
                            class="form-control"
                            placeholder="Name or admission number"
                            value="<?php echo e($search); ?>"
                        >

                    </div>

                </div>


                <div class="col-lg-2 mb-3">

                    <label>
                        Academic Year
                    </label>

                    <select
                        name="academic_year"
                        class="form-control"
                    >

                        <option value="">
                            All Years
                        </option>

                        <?php foreach ($years as $year): ?>

                            <option
                                value="<?php echo e($year); ?>"
                                <?php echo $academicYear === $year ? 'selected' : ''; ?>
                            >
                                <?php echo e($year); ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <div class="col-lg-2 mb-3">

                    <label>
                        Term
                    </label>

                    <select
                        name="term"
                        class="form-control"
                    >

                        <option value="">
                            All Terms
                        </option>

                        <?php foreach ($terms as $item): ?>

                            <option
                                value="<?php echo e($item); ?>"
                                <?php echo $term === $item ? 'selected' : ''; ?>
                            >
                                <?php echo e($item); ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <div class="col-lg-2 mb-3">

                    <label>
                        Status
                    </label>

                    <select
                        name="status"
                        class="form-control"
                    >

                        <option value="">
                            All Status
                        </option>

                        <option
                            value="pending"
                            <?php echo $status === 'pending' ? 'selected' : ''; ?>
                        >
                            Pending
                        </option>

                        <option
                            value="partial"
                            <?php echo $status === 'partial' ? 'selected' : ''; ?>
                        >
                            Partial
                        </option>

                        <option
                            value="paid"
                            <?php echo $status === 'paid' ? 'selected' : ''; ?>
                        >
                            Paid
                        </option>

                        <option
                            value="overdue"
                            <?php echo $status === 'overdue' ? 'selected' : ''; ?>
                        >
                            Overdue
                        </option>

                    </select>

                </div>


                <div class="col-lg-2 mb-3">

                    <label>
                        &nbsp;
                    </label>

                    <div>

                        <button
                            type="submit"
                            class="btn btn-primary"
                        >

                            <i class="fas fa-filter"></i>
                            Filter

                        </button>

                        <a
                            href="students_fees.php"
                            class="btn btn-light"
                        >

                            <i class="fas fa-redo"></i>

                        </a>

                    </div>

                </div>

            </div>

        </form>

    </div>


    <!-- ====================================================
         ACCOUNT DETAILS
    ===================================================== -->

    <?php if ($viewAccountId > 0): ?>

        <?php if ($accountDetails): ?>

            <div class="content-card">

                <div class="card-header d-flex justify-content-between align-items-center">

                    <span>
                        <i class="fas fa-file-invoice-dollar text-primary"></i>
                        Fee Account Details
                    </span>

                    <a
                        href="students_fees.php"
                        class="btn btn-sm btn-outline-secondary"
                    >
                        <i class="fas fa-times"></i>
                        Close
                    </a>

                </div>


                <div class="card-body">

                    <div class="row">

                        <div class="col-lg-4 mb-3">

                            <div class="account-summary">

                                <div class="account-number">
                                    STUDENT
                                </div>

                                <h5 class="mb-1">

                                    <?php
                                    echo e(
                                        $accountDetails['student_name']
                                    );
                                    ?>

                                </h5>

                                <small class="text-muted d-block">
                                    Admission No: <?= e($accountDetails['admission_no']) ?>
                                </small>
                                <small class="text-muted d-block">
                                    LIN: <?= e($accountDetails['lin_no'] ?: '—') ?>
                                    | Payment Code: <?= e($accountDetails['student_payment_code'] ?: '—') ?>
                                    | Section: <?= e($accountDetails['student_section'] ?: 'Day') ?>
                                </small>

                            </div>

                        </div>


                        <div class="col-lg-2 mb-3">

                            <div class="account-summary">

                                <div class="account-number">
                                    ACADEMIC YEAR
                                </div>

                                <strong>
                                    <?php
                                    echo e(
                                        $accountDetails['academic_year']
                                    );
                                    ?>
                                </strong>

                            </div>

                        </div>


                        <div class="col-lg-2 mb-3">

                            <div class="account-summary">

                                <div class="account-number">
                                    TERM
                                </div>

                                <strong>
                                    <?php
                                    echo e(
                                        $accountDetails['term']
                                    );
                                    ?>
                                </strong>

                            </div>

                        </div>


                        <div class="col-lg-2 mb-3">

                            <div class="account-summary">

                                <div class="account-number">
                                    TOTAL FEES
                                </div>

                                <strong>
                                    <?php
                                    echo money(
                                        $accountDetails['total_amount']
                                    );
                                    ?>
                                </strong>

                            </div>

                        </div>


                        <div class="col-lg-2 mb-3">

                            <div class="account-summary">

                                <div class="account-number">
                                    BALANCE
                                </div>

                                <strong class="text-danger">

                                    <?php
                                    echo money(
                                        $accountDetails['balance']
                                    );
                                    ?>

                                </strong>

                            </div>

                        </div>

                    </div>


                    <div class="row">

                        <div class="col-md-3">

                            <strong>
                                Total Expected
                            </strong>

                            <br>

                            <?php
                            echo money(
                                $accountDetails['total_amount']
                            );
                            ?>

                        </div>


                        <div class="col-md-3">

                            <strong>
                                Discount
                            </strong>

                            <br>

                            <?php
                            echo money(
                                $accountDetails['discount_amount']
                            );
                            ?>

                        </div>


                        <div class="col-md-3">

                            <strong>
                                Amount Paid
                            </strong>

                            <br>

                            <span class="text-success">

                                <?php
                                $displayPaid =
                                    (float)$accountDetails['amount_paid'];

                                if (
                                    $displayPaid <= 0 &&
                                    (float)$accountDetails['total_paid'] > 0
                                ) {
                                    $displayPaid =
                                        (float)$accountDetails['total_paid'];
                                }

                                echo money($displayPaid);
                                ?>

                            </span>

                        </div>


                        <div class="col-md-3">

                            <strong>
                                Status
                            </strong>

                            <br>

                            <?php

                            $accountStatus =
                                strtolower(
                                    $accountDetails['status']
                                );

                            $statusClass =
                                'status-' . $accountStatus;

                            ?>

                            <span
                                class="status-badge <?php echo e($statusClass); ?>"
                            >
                                <?php
                                echo e(
                                    ucfirst(
                                        $accountStatus
                                    )
                                );
                                ?>
                            </span>

                        </div>

                    </div>


                    <hr>


                    <div class="d-flex justify-content-between align-items-center mb-3">

                        <h5 class="mb-0">
                            <i class="fas fa-history"></i>
                            Payment History
                        </h5>

                        <a
                            href="payments.php?account_id=<?php echo (int)$accountDetails['account_id']; ?>"
                            class="btn btn-success btn-sm"
                        >

                            <i class="fas fa-plus"></i>
                            Receive Payment

                        </a>

                    </div>


                    <?php if (!empty($accountPayments)): ?>

                        <div class="table-responsive">

                            <table class="table table-hover">

                                <thead>

                                    <tr>

                                        <th>
                                            Receipt
                                        </th>

                                        <th>
                                            Date
                                        </th>

                                        <th>
                                            Method
                                        </th>

                                        <th>
                                            Reference
                                        </th>

                                        <th>
                                            Status
                                        </th>

                                        <th class="text-right">
                                            Amount
                                        </th>

                                    </tr>

                                </thead>


                                <tbody>

                                <?php foreach ($accountPayments as $payment): ?>

                                    <tr>

                                        <td>

                                            <a
                                                href="payment_receipt.php?id=<?php echo (int)$payment['id']; ?>"
                                            >

                                                <?php
                                                echo e(
                                                    $payment['receipt_no']
                                                );
                                                ?>

                                            </a>

                                        </td>


                                        <td>

                                            <?php
                                            echo date(
                                                'd M Y H:i',
                                                strtotime(
                                                    $payment['payment_date']
                                                )
                                            );
                                            ?>

                                        </td>


                                        <td>

                                            <?php
                                            echo e(
                                                $payment['method_name']
                                                ?: 'N/A'
                                            );
                                            ?>

                                        </td>


                                        <td>

                                            <?php
                                            echo e(
                                                $payment['reference_no']
                                                ?: '-'
                                            );
                                            ?>

                                        </td>


                                        <td>

                                            <?php

                                            $paymentStatus =
                                                strtolower(
                                                    $payment['status']
                                                );

                                            ?>

                                            <span
                                                class="badge badge-<?php
                                                echo $paymentStatus === 'completed'
                                                    ? 'success'
                                                    : 'secondary';
                                                ?>"
                                            >

                                                <?php
                                                echo e(
                                                    ucfirst(
                                                        $paymentStatus
                                                    )
                                                );
                                                ?>

                                            </span>

                                        </td>


                                        <td class="text-right font-weight-bold text-success">

                                            <?php
                                            echo money(
                                                $payment['amount']
                                            );
                                            ?>

                                        </td>

                                    </tr>

                                <?php endforeach; ?>

                                </tbody>

                            </table>

                        </div>

                    <?php else: ?>

                        <div class="text-center py-4">

                            <i
                                class="fas fa-receipt fa-2x text-muted mb-2"
                            ></i>

                            <p class="text-muted mb-0">
                                No payments have been recorded
                                for this fee account.
                            </p>

                        </div>

                    <?php endif; ?>

                </div>

            </div>

        <?php else: ?>

            <div class="alert alert-warning">

                <i class="fas fa-exclamation-triangle"></i>

                The requested fee account could not be found.

            </div>

        <?php endif; ?>

    <?php endif; ?>


    <!-- ====================================================
         STUDENT FEE ACCOUNTS
    ===================================================== -->

    <div class="content-card">

        <div class="card-header d-flex justify-content-between align-items-center">

            <span>
                <i class="fas fa-users text-primary"></i>
                Student Fee Accounts
            </span>

            <span class="badge badge-primary">
                <?php echo number_format(count($students)); ?>
                accounts
            </span>

        </div>


        <div class="card-body p-0">

            <?php if (!empty($students)): ?>

                <div class="table-responsive">

                    <table class="table table-hover mb-0">

                        <thead>

                            <tr>

                                <th>
                                    Student
                                </th>

                                <th>
                                    Academic Year
                                </th>

                                <th>
                                    Term
                                </th>

                                <th>
                                    Expected
                                </th>

                                <th>
                                    Paid
                                </th>

                                <th>
                                    Balance
                                </th>

                                <th>
                                    Status
                                </th>

                                <th class="text-right">
                                    Actions
                                </th>

                            </tr>

                        </thead>


                        <tbody>

                        <?php foreach ($students as $student): ?>

                            <?php

                            $studentPaid =
                                (float)$student['amount_paid'];

                            if (
                                $studentPaid <= 0 &&
                                (float)$student['total_paid'] > 0
                            ) {
                                $studentPaid =
                                    (float)$student['total_paid'];
                            }

                            $studentStatus =
                                strtolower(
                                    $student['status']
                                );

                            ?>

                            <tr>


                                <td>

                                    <div class="student-name">

                                        <?php
                                        echo e(
                                            $student['student_name']
                                        );
                                        ?>

                                    </div>

                                    <div class="admission">
                                        Admission: <?= e($student['admission_no']) ?>
                                    </div>
                                    <div class="admission">
                                        LIN: <?= e($student['lin_no'] ?: '—') ?>
                                        | Payment Code: <?= e($student['student_payment_code'] ?: '—') ?>
                                        | <?= e($student['student_section'] ?: 'Day') ?>
                                    </div>

                                </td>


                                <td>

                                    <?php
                                    echo e(
                                        $student['academic_year']
                                    );
                                    ?>

                                </td>


                                <td>

                                    <span class="badge badge-light">

                                        <?php
                                        echo e(
                                            $student['term']
                                        );
                                        ?>

                                    </span>

                                </td>


                                <td class="amount">

                                    <?php
                                    echo money(
                                        $student['total_amount']
                                    );
                                    ?>

                                </td>


                                <td class="amount text-success">

                                    <?php
                                    echo money($studentPaid);
                                    ?>

                                </td>


                                <td class="amount
                                    <?php
                                    echo (float)$student['balance'] > 0
                                        ? 'balance-danger'
                                        : 'balance-success';
                                    ?>"
                                >

                                    <?php
                                    echo money(
                                        $student['balance']
                                    );
                                    ?>

                                </td>


                                <td>

                                    <span
                                        class="status-badge status-<?php
                                        echo e($studentStatus);
                                        ?>"
                                    >

                                        <?php
                                        echo e(
                                            ucfirst(
                                                $studentStatus
                                            )
                                        );
                                        ?>

                                    </span>

                                </td>


                                <td class="text-right">

                                    <a
                                        href="students_fees.php?account_id=<?php echo (int)$student['account_id']; ?>"
                                        class="btn btn-sm btn-outline-primary"
                                        title="View Account"
                                    >

                                        <i class="fas fa-eye"></i>

                                    </a>


                                    <a
                                        href="payments.php?account_id=<?php echo (int)$student['account_id']; ?>"
                                        class="btn btn-sm btn-success"
                                        title="Receive Payment"
                                    >

                                        <i class="fas fa-money-bill-wave"></i>

                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php else: ?>

                <div class="text-center py-5">

                    <i
                        class="fas fa-user-graduate fa-3x text-muted mb-3"
                    ></i>

                    <h5>
                        No fee accounts found
                    </h5>

                    <p class="text-muted">

                        No student fee accounts match
                        your current filters.

                    </p>

                    <a
                        href="students_fees.php"
                        class="btn btn-primary"
                    >

                        <i class="fas fa-redo"></i>
                        Clear Filters

                    </a>

                </div>

            <?php endif; ?>

        </div>

    </div>


    <!-- FOOTER -->

    <div class="text-center text-muted py-3">

        <small>

            School Management System &copy;
            <?php echo date('Y'); ?>
            — Bursar Module

        </small>

    </div>

</div>


</div>

<script>

const menuBtn =
    document.getElementById('menuBtn');

const sidebar =
    document.getElementById('sidebar');

const overlay =
    document.getElementById('overlay');


menuBtn.addEventListener(
    'click',
    function () {

        sidebar.classList.toggle('show');

        overlay.classList.toggle('show');

    }
);


overlay.addEventListener(
    'click',
    function () {

        sidebar.classList.remove('show');

        overlay.classList.remove('show');

    }
);


document.addEventListener(
    'keydown',
    function (event) {

        if (event.key === 'Escape') {

            sidebar.classList.remove('show');

            overlay.classList.remove('show');

        }

    }
);

</script>

</body>

</html>
