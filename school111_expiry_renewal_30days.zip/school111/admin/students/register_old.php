<?php
/**
 * Legacy student registration URL.
 * Redirect to the current student registration form, which includes
 * LIN No., Student Payment Code, and Day/Boarding selection.
 */
require_once __DIR__ . '/../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator']);
header('Location: register.php');
exit;
