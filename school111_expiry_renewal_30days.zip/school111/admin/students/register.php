<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once "../../includes/auth.php";
require_once "../../config/database.php";

requireRole([
    'administrator',
    'assistant_administrator'
]);

/*
|--------------------------------------------------------------------------
| CSRF TOKEN
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrf_token = $_SESSION['csrf_token'];


/*
|--------------------------------------------------------------------------
| Helper
|--------------------------------------------------------------------------
*/

function e($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}


/*
|--------------------------------------------------------------------------
| Variables
|--------------------------------------------------------------------------
*/

$error = '';
$success = '';

$admission_no = '';
$lin_no = '';
$student_payment_code = '';
$student_section = 'Day';

$first_name = '';
$last_name = '';
$other_names = '';
$gender = '';
$date_of_birth = '';
$class_id = '';

$guardian_name = '';
$guardian_relationship = '';
$guardian_phone = '';
$guardian_nin = '';
$guardian_email = '';
$guardian_address = '';


/*
|--------------------------------------------------------------------------
| Load Classes
|--------------------------------------------------------------------------
*/

$classes = [];

$classQuery = $conn->query("
    SELECT
        id,
        class_name,
        section,
        academic_year
    FROM classes
    WHERE status = 'active'
    ORDER BY class_name, section
");

if (!$classQuery) {
    die("Unable to load classes: " . $conn->error);
}

while ($row = $classQuery->fetch_assoc()) {
    $classes[] = $row;
}


/*
|--------------------------------------------------------------------------
| Process Form
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /*
    |--------------------------------------------------------------------------
    | CSRF
    |--------------------------------------------------------------------------
    */

    $postedToken = $_POST['csrf_token'] ?? '';

    if (
        empty($postedToken) ||
        !hash_equals($_SESSION['csrf_token'], $postedToken)
    ) {
        $error = "Invalid security token. Please refresh the page and try again.";
    }


    /*
    |--------------------------------------------------------------------------
    | Get Form Data
    |--------------------------------------------------------------------------
    */

    if ($error === '') {

        $admission_no = trim($_POST['admission_no'] ?? '');
        $lin_no = trim($_POST['lin_no'] ?? '');
        $student_payment_code = trim($_POST['student_payment_code'] ?? '');
        $student_section = trim($_POST['student_section'] ?? 'Day');

        $first_name = trim($_POST['first_name'] ?? '');
        $last_name = trim($_POST['last_name'] ?? '');
        $other_names = trim($_POST['other_names'] ?? '');

        $gender = trim($_POST['gender'] ?? '');
        $date_of_birth = trim($_POST['date_of_birth'] ?? '');

        $class_id = (int)($_POST['class_id'] ?? 0);

        $guardian_name = trim($_POST['guardian_name'] ?? '');
        $guardian_relationship = trim($_POST['guardian_relationship'] ?? '');
        $guardian_phone = trim($_POST['guardian_phone'] ?? '');
        $guardian_nin = trim($_POST['guardian_nin'] ?? '');
        $guardian_email = trim($_POST['guardian_email'] ?? '');
        $guardian_address = trim($_POST['guardian_address'] ?? '');


        /*
        |--------------------------------------------------------------------------
        | Validation
        |--------------------------------------------------------------------------
        */

        if ($admission_no === '') {

            $error = "Admission number is required.";

        } elseif (
            !preg_match(
                '/^[A-Za-z0-9\/-]{2,50}$/',
                $admission_no
            )
        ) {

            $error = "Invalid admission number.";

        } elseif ($lin_no === '') {

            $error = "LIN number is required.";

        } elseif (
            !preg_match(
                '/^[A-Za-z0-9\/-]{2,50}$/',
                $lin_no
            )
        ) {

            $error = "Invalid LIN number.";

        } elseif ($student_payment_code === '') {

            $error = "Student Payment Code is required.";

        } elseif (!preg_match('/^[A-Za-z0-9\/-]{2,50}$/', $student_payment_code)) {

            $error = "Invalid Student Payment Code.";

        } elseif (!in_array($student_section, ['Day', 'Boarding'], true)) {

            $error = "Please select Day or Boarding for the student.";

        } elseif ($first_name === '') {

            $error = "First name is required.";

        } elseif ($last_name === '') {

            $error = "Last name is required.";

        } elseif (
            !in_array(
                $gender,
                ['Male', 'Female'],
                true
            )
        ) {

            $error = "Please select a valid gender.";

        } elseif ($class_id <= 0) {

            $error = "Please select a class.";

        } elseif ($guardian_name === '') {

            $error = "Guardian name is required.";

        } elseif ($guardian_relationship === '') {

            $error = "Guardian relationship is required.";

        } elseif ($guardian_phone === '') {

            $error = "Guardian phone number is required.";

        } elseif ($guardian_nin === '') {

            $error = "Guardian NIN number is required.";

        } elseif (
            !preg_match(
                '/^[A-Za-z0-9-]{5,30}$/',
                $guardian_nin
            )
        ) {

            $error = "Invalid guardian NIN number.";

        } elseif (
            $guardian_email !== '' &&
            !filter_var(
                $guardian_email,
                FILTER_VALIDATE_EMAIL
            )
        ) {

            $error = "Please enter a valid guardian email address.";
        }


        /*
        |--------------------------------------------------------------------------
        | Check Admission Number
        |--------------------------------------------------------------------------
        */

        if ($error === '') {

            $stmt = $conn->prepare("
                SELECT id
                FROM students
                WHERE admission_no = ?
                LIMIT 1
            ");

            if (!$stmt) {

                $error = "Database error: " . $conn->error;

            } else {

                $stmt->bind_param(
                    "s",
                    $admission_no
                );

                $stmt->execute();
                $stmt->store_result();

                if ($stmt->num_rows > 0) {

                    $error =
                        "This admission number already exists.";
                }

                $stmt->close();
            }
        }


        /*
        |--------------------------------------------------------------------------
        | Check LIN Number
        |--------------------------------------------------------------------------
        */

        if ($error === '') {

            $stmt = $conn->prepare("
                SELECT id
                FROM students
                WHERE lin_no = ?
                LIMIT 1
            ");

            if (!$stmt) {

                $error = "Database error: " . $conn->error;

            } else {

                $stmt->bind_param(
                    "s",
                    $lin_no
                );

                $stmt->execute();
                $stmt->store_result();

                if ($stmt->num_rows > 0) {

                    $error =
                        "This LIN number already exists.";
                }

                $stmt->close();
            }
        }


        /*
        |--------------------------------------------------------------------------
        | Check Student Payment Code
        |--------------------------------------------------------------------------
        */

        if ($error === '') {

            $stmt = $conn->prepare("SELECT id FROM students WHERE student_payment_code = ? LIMIT 1");
            if (!$stmt) {
                $error = "Database error: " . $conn->error;
            } else {
                $stmt->bind_param("s", $student_payment_code);
                $stmt->execute();
                $stmt->store_result();
                if ($stmt->num_rows > 0) {
                    $error = "This Student Payment Code already exists.";
                }
                $stmt->close();
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Check Class
        |--------------------------------------------------------------------------
        */

        if ($error === '') {

            $stmt = $conn->prepare("
                SELECT id
                FROM classes
                WHERE id = ?
                AND status = 'active'
                LIMIT 1
            ");

            if (!$stmt) {

                $error = "Database error: " . $conn->error;

            } else {

                $stmt->bind_param(
                    "i",
                    $class_id
                );

                $stmt->execute();
                $stmt->store_result();

                if ($stmt->num_rows === 0) {

                    $error =
                        "Selected class does not exist or is inactive.";
                }

                $stmt->close();
            }
        }


        /*
        |--------------------------------------------------------------------------
        | Photo Upload
        |--------------------------------------------------------------------------
        */

        $photoName = null;

        if (
            $error === '' &&
            isset($_FILES['photo']) &&
            $_FILES['photo']['error'] !== UPLOAD_ERR_NO_FILE
        ) {

            if (
                $_FILES['photo']['error']
                !== UPLOAD_ERR_OK
            ) {

                $error =
                    "There was a problem uploading the photo.";

            } elseif (
                $_FILES['photo']['size']
                > 2 * 1024 * 1024
            ) {

                $error =
                    "Student photo must not exceed 2 MB.";

            } else {

                $tmpName =
                    $_FILES['photo']['tmp_name'];

                $finfo =
                    finfo_open(FILEINFO_MIME_TYPE);

                $mimeType =
                    finfo_file(
                        $finfo,
                        $tmpName
                    );

                finfo_close($finfo);

                $allowedTypes = [
                    'image/jpeg' => 'jpg',
                    'image/png'  => 'png',
                    'image/webp' => 'webp'
                ];

                if (
                    !isset(
                        $allowedTypes[$mimeType]
                    )
                ) {

                    $error =
                        "Only JPG, PNG and WEBP photos are allowed.";

                } else {

                    $uploadDirectory =
                        __DIR__
                        . "/../../uploads/students/";

                    if (!is_dir($uploadDirectory)) {

                        if (
                            !mkdir(
                                $uploadDirectory,
                                0755,
                                true
                            )
                        ) {

                            $error =
                                "Unable to create photo upload directory.";
                        }
                    }

                    if ($error === '') {

                        $photoName =
                            bin2hex(
                                random_bytes(16)
                            )
                            . '.'
                            . $allowedTypes[$mimeType];

                        $destination =
                            $uploadDirectory
                            . $photoName;

                        if (
                            !move_uploaded_file(
                                $tmpName,
                                $destination
                            )
                        ) {

                            $error =
                                "Unable to save the student photo.";

                            $photoName = null;
                        }
                    }
                }
            }
        }


        /*
        |--------------------------------------------------------------------------
        | Save Student
        |--------------------------------------------------------------------------
        */

        if ($error === '') {

            $conn->begin_transaction();

            try {

                /*
                |--------------------------------------------------------------------------
                | Insert Guardian
                |--------------------------------------------------------------------------
                */

                $stmt = $conn->prepare("
                    INSERT INTO guardians
                    (
                        full_name,
                        relationship,
                        phone,
                        nin_no,
                        email,
                        address
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                ");

                if (!$stmt) {

                    throw new Exception(
                        "Guardian database error: "
                        . $conn->error
                    );
                }

                $stmt->bind_param(
                    "ssssss",
                    $guardian_name,
                    $guardian_relationship,
                    $guardian_phone,
                    $guardian_nin,
                    $guardian_email,
                    $guardian_address
                );

                if (!$stmt->execute()) {

                    throw new Exception(
                        "Unable to save guardian: "
                        . $stmt->error
                    );
                }

                $guardianId =
                    $stmt->insert_id;

                $stmt->close();


                /*
                |--------------------------------------------------------------------------
                | Insert Student
                |--------------------------------------------------------------------------
                */

                $userId =
                    (int)$_SESSION['user_id'];

                $stmt = $conn->prepare("
                    INSERT INTO students
                    (
                        admission_no,
                        lin_no,
                        student_payment_code,
                        student_section,
                        first_name,
                        last_name,
                        other_names,
                        gender,
                        date_of_birth,
                        class_id,
                        guardian_id,
                        photo,
                        registered_by
                    )
                    VALUES (
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        NULLIF(?, ''),
                        ?,
                        ?,
                        ?,
                        ?
                    )
                ");

                if (!$stmt) {

                    throw new Exception(
                        "Student database error: "
                        . $conn->error
                    );
                }

                $stmt->bind_param(
                    "sssssssssiisi",
                    $admission_no,
                    $lin_no,
                    $student_payment_code,
                    $student_section,
                    $first_name,
                    $last_name,
                    $other_names,
                    $gender,
                    $date_of_birth,
                    $class_id,
                    $guardianId,
                    $photoName,
                    $userId
                );

                if (!$stmt->execute()) {

                    throw new Exception(
                        "Unable to save student: "
                        . $stmt->error
                    );
                }

                $stmt->close();

                $conn->commit();


                /*
                |--------------------------------------------------------------------------
                | Success
                |--------------------------------------------------------------------------
                */

                $success =
                    "Student registered successfully.";

                $admission_no = '';
                $lin_no = '';
                $student_payment_code = '';
                $student_section = 'Day';

                $first_name = '';
                $last_name = '';
                $other_names = '';
                $gender = '';
                $date_of_birth = '';
                $class_id = '';

                $guardian_name = '';
                $guardian_relationship = '';
                $guardian_phone = '';
                $guardian_nin = '';
                $guardian_email = '';
                $guardian_address = '';

                $_SESSION['csrf_token'] =
                    bin2hex(random_bytes(32));

                $csrf_token =
                    $_SESSION['csrf_token'];

            } catch (Exception $e) {

                $conn->rollback();

                if (!empty($photoName)) {

                    $photoPath =
                        __DIR__
                        . "/../../uploads/students/"
                        . $photoName;

                    if (file_exists($photoPath)) {

                        unlink($photoPath);
                    }
                }

                $error =
                    $e->getMessage();
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Register Student - School Management System</title>

    <!-- Bootstrap 4 -->
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
    >

    <!-- Font Awesome -->
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
    >

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;

            background: #f4f6f9;

            font-family: Arial, sans-serif;
        }


        /* =========================================================
           SIDEBAR
        ========================================================= */

        .sidebar {
            position: fixed;

            top: 0;
            left: 0;
            bottom: 0;

            width: 250px;

            background: #343a40;

            color: white;

            overflow-y: auto;
            overflow-x: hidden;

            z-index: 1050;

            transition:
                width 0.3s ease,
                transform 0.3s ease;
        }


        .sidebar-header {
            height: 70px;

            display: flex;

            align-items: center;

            justify-content: space-between;

            padding: 0 18px;

            background: #212529;

            border-bottom:
                1px solid rgba(255,255,255,0.08);
        }


        .sidebar-brand {
            display: flex;

            align-items: center;

            color: white;

            text-decoration: none;

            white-space: nowrap;

            font-size: 18px;

            font-weight: 600;
        }


        .sidebar-brand:hover {
            color: white;

            text-decoration: none;
        }


        .sidebar-brand i {
            font-size: 22px;

            min-width: 35px;
        }


        .sidebar-toggle {
            border: none;

            background: transparent;

            color: #fff;

            font-size: 18px;

            cursor: pointer;

            width: 35px;

            height: 35px;

            border-radius: 5px;
        }


        .sidebar-toggle:hover {
            background:
                rgba(255,255,255,0.1);
        }


        .sidebar-menu {
            padding: 15px 10px 30px;
        }


        .menu-title {
            color: #adb5bd;

            font-size: 11px;

            font-weight: 600;

            text-transform: uppercase;

            padding: 15px 12px 8px;

            white-space: nowrap;
        }


        .sidebar-menu a {
            display: flex;

            align-items: center;

            color: #ced4da;

            padding: 12px 14px;

            margin-bottom: 4px;

            border-radius: 6px;

            text-decoration: none;

            transition:
                all 0.2s ease;

            white-space: nowrap;
        }


        .sidebar-menu a:hover {
            background: #007bff;

            color: #fff;

            text-decoration: none;
        }


        .sidebar-menu a.active {
            background: #007bff;

            color: #fff;
        }


        .sidebar-menu a i {
            width: 25px;

            min-width: 25px;

            margin-right: 10px;

            text-align: center;
        }


        /* =========================================================
           COLLAPSED SIDEBAR
        ========================================================= */

        body.sidebar-collapsed .sidebar {
            width: 75px;
        }


        body.sidebar-collapsed .main-content {
            margin-left: 75px;
        }


        body.sidebar-collapsed
        .sidebar-brand span,

        body.sidebar-collapsed
        .menu-title,

        body.sidebar-collapsed
        .sidebar-menu a span {
            display: none;
        }


        body.sidebar-collapsed
        .sidebar-header {
            justify-content: center;

            padding: 0;
        }


        body.sidebar-collapsed
        .sidebar-toggle {
            position: absolute;

            right: 4px;

            top: 18px;

            width: 28px;
        }


        body.sidebar-collapsed
        .sidebar-brand {
            justify-content: center;
        }


        body.sidebar-collapsed
        .sidebar-menu a {
            justify-content: center;

            padding: 13px 5px;
        }


        body.sidebar-collapsed
        .sidebar-menu a i {
            margin-right: 0;
        }


        /* =========================================================
           MOBILE MENU
        ========================================================= */

        .mobile-menu-btn {
            display: none;

            border: none;

            background: #343a40;

            color: white;

            width: 42px;

            height: 42px;

            border-radius: 5px;

            font-size: 18px;

            cursor: pointer;

            align-items: center;

            justify-content: center;
        }


        .mobile-menu-btn:hover {
            background: #007bff;
        }


        .sidebar-overlay {
            display: none;

            position: fixed;

            top: 0;
            left: 0;
            right: 0;
            bottom: 0;

            background:
                rgba(0,0,0,0.5);

            z-index: 1040;
        }


        /* =========================================================
           MAIN CONTENT
        ========================================================= */

        .main-content {
            min-height: 100vh;

            margin-left: 250px;

            transition:
                margin-left 0.3s ease;
        }


        /* =========================================================
           TOPBAR
        ========================================================= */

        .topbar {
            min-height: 70px;

            background: #fff;

            padding: 12px 25px;

            box-shadow:
                0 2px 8px
                rgba(0,0,0,0.08);

            display: flex;

            align-items: center;

            justify-content: space-between;
        }


        .topbar-left {
            display: flex;

            align-items: center;
        }


        .topbar h4 {
            margin: 0 0 0 15px;

            font-weight: 600;
        }


        .user-info {
            display: flex;

            align-items: center;
        }


        /* =========================================================
           PAGE HEADER
        ========================================================= */

        .page-header {
            background: white;

            padding: 20px;

            border-radius: 9px;

            box-shadow:
                0 3px 12px
                rgba(0,0,0,0.06);
        }


        /* =========================================================
           CARDS
        ========================================================= */

        .card {
            border: none;

            border-radius: 9px;

            box-shadow:
                0 3px 12px
                rgba(0,0,0,0.06);
        }


        .card-header {
            background: white;

            border-bottom:
                1px solid #eee;

            padding: 15px 20px;
        }


        /* =========================================================
           FORM
        ========================================================= */

        .form-control {
            border-radius: 6px;
        }


        .btn {
            border-radius: 6px;
        }


        /* =========================================================
           DESKTOP
        ========================================================= */

        @media (min-width: 769px) {

            body.sidebar-collapsed
            .sidebar-brand span {
                display: none;
            }

            body.sidebar-collapsed
            .sidebar-menu a span {
                display: none;
            }

            body.sidebar-collapsed
            .menu-title {
                display: none;
            }

        }


        /* =========================================================
           MOBILE
        ========================================================= */

        @media (max-width: 768px) {

            .sidebar {
                width: 250px;

                transform:
                    translateX(-100%);

                box-shadow:
                    4px 0 15px
                    rgba(0,0,0,0.2);
            }


            .sidebar.mobile-open {
                transform:
                    translateX(0);
            }


            .main-content {
                margin-left: 0;
            }


            .mobile-menu-btn {
                display: inline-flex;
            }


            .sidebar-overlay.active {
                display: block;
            }


            body.sidebar-collapsed
            .sidebar {
                width: 250px;
            }


            body.sidebar-collapsed
            .sidebar-brand span,

            body.sidebar-collapsed
            .menu-title,

            body.sidebar-collapsed
            .sidebar-menu a span {
                display: inline;
            }


            body.sidebar-collapsed
            .sidebar-header {
                justify-content: space-between;

                padding: 0 18px;
            }


            body.sidebar-collapsed
            .sidebar-menu a {
                justify-content: flex-start;

                padding: 12px 14px;
            }


            body.sidebar-collapsed
            .sidebar-menu a i {
                margin-right: 10px;
            }


            .topbar {
                padding: 12px 15px;
            }


            .topbar h4 {
                font-size: 17px;
            }


            .user-info .user-name {
                display: none;
            }


            .container-fluid {
                padding: 15px !important;
            }

        }


        @media (max-width: 576px) {

            .topbar-right
            .logout-text {
                display: none;
            }


            .topbar-right .btn {
                padding: 7px 10px;
            }


            .page-header
            .header-content {
                flex-direction: column;

                align-items: flex-start !important;
            }


            .page-header
            .student-list-btn {
                margin-top: 15px;
            }


            .form-row
            .form-group {
                margin-bottom: 15px;
            }

        }

    </style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>


<body>


<!-- =========================================================
     SIDEBAR OVERLAY
========================================================= -->

<div
    class="sidebar-overlay"
    id="sidebarOverlay"
></div>


<!-- =========================================================
     SIDEBAR
========================================================= -->

<div
    class="sidebar"
    id="sidebar"
>


    <div class="sidebar-header">


        <a
            href="/admin/dashboard.php"
            class="sidebar-brand"
        >

            <i class="fas fa-school"></i>

            <span>
                School Management
            </span>

        </a>


        <button
            type="button"
            class="sidebar-toggle"
            id="sidebarToggle"
            title="Collapse Sidebar"
        >

            <i class="fas fa-bars"></i>

        </button>


    </div>


    <div class="sidebar-menu">


        <!-- MAIN -->

        <div class="menu-title">
            Main
        </div>


        <a href="/admin/dashboard.php">

            <i class="fas fa-tachometer-alt"></i>

            <span>
                Dashboard
            </span>

        </a>


        <!-- ACADEMIC -->

        <div class="menu-title">
            Academic
        </div>


        <a href="/admin/classes/index.php">

            <i class="fas fa-chalkboard"></i>

            <span>
                Classes
            </span>

        </a>


        <a
            href="/admin/students/list.php"
            class="active"
        >

            <i class="fas fa-user-graduate"></i>

            <span>
                Students
            </span>

        </a>


        <a href="/admin/teachers/index.php">

            <i class="fas fa-chalkboard-teacher"></i>

            <span>
                Teachers
            </span>

        </a>


        <!-- FINANCE -->

        <div class="menu-title">
            Finance
        </div>


        <a href="/admin/bursar/index.php">

            <i class="fas fa-money-bill-wave"></i>

            <span>
                Bursar
            </span>

        </a>


        <!-- SCHOOL MANAGEMENT -->

        <div class="menu-title">
            School Management
        </div>


        <a href="/admin/assets/index.php">

            <i class="fas fa-boxes"></i>

            <span>
                Assets
            </span>

        </a>


        <a href="/admin/staff/index.php">

            <i class="fas fa-users"></i>

            <span>
                Other Staff Members
            </span>

        </a>


        <a href="/admin/projects/index.php">

            <i class="fas fa-project-diagram"></i>

            <span>
                School Projects
            </span>

        </a>


        <!-- ADMINISTRATION -->

        <div class="menu-title">
            Administration
        </div>


        <a href="/admin/users/index.php">

            <i class="fas fa-users-cog"></i>

            <span>
                Users
            </span>

        </a>


        <a href="/logout.php">

            <i class="fas fa-sign-out-alt"></i>

            <span>
                Logout
            </span>

        </a>


    </div>

</div>


<!-- =========================================================
     MAIN CONTENT
========================================================= -->

<div class="main-content">


    <!-- TOPBAR -->

    <div class="topbar">


        <div class="topbar-left">


            <button
                type="button"
                class="mobile-menu-btn"
                id="mobileMenuBtn"
                title="Open Menu"
            >

                <i class="fas fa-bars"></i>

            </button>


            <h4>
                Register Student
            </h4>


        </div>


        <div class="topbar-right">


            <div class="user-info">


                <span class="mr-3 user-name">

                    <i class="fas fa-user-circle"></i>

                    <?= e($_SESSION['full_name']) ?>

                </span>


                <a
                    href="../../logout.php"
                    class="btn btn-outline-danger btn-sm"
                >

                    <i class="fas fa-sign-out-alt"></i>

                    <span class="logout-text">
                        Logout
                    </span>

                </a>


            </div>


        </div>


    </div>


    <!-- =====================================================
         PAGE CONTENT
    ====================================================== -->

    <div class="container-fluid p-4">


        <!-- PAGE HEADER -->

        <div class="page-header mb-4">


            <div
                class="header-content d-flex
                       justify-content-between
                       align-items-center"
            >


                <div>


                    <h2 class="mb-1">

                        <i
                            class="fas fa-user-plus text-primary"
                        ></i>

                        Register Student

                    </h2>


                    <p class="text-muted mb-0">

                        Add a new student to the school

                    </p>


                </div>


                <div class="student-list-btn">


                    <a
                        href="list.php"
                        class="btn btn-secondary"
                    >

                        <i class="fas fa-list"></i>

                        Student List

                    </a>


                </div>


            </div>


        </div>


        <!-- SUCCESS -->

        <?php if ($success !== ''): ?>

            <div class="alert alert-success">

                <i class="fas fa-check-circle"></i>

                <?= e($success) ?>

                <br>

                <a href="list.php">

                    View Student List

                </a>

            </div>

        <?php endif; ?>


        <!-- ERROR -->

        <?php if ($error !== ''): ?>

            <div class="alert alert-danger">

                <i class="fas fa-exclamation-circle"></i>

                <?= e($error) ?>

            </div>

        <?php endif; ?>


        <!-- =================================================
             FORM
        ================================================== -->

        <form
            method="POST"
            enctype="multipart/form-data"
        >


            <input
                type="hidden"
                name="csrf_token"
                value="<?= e($csrf_token) ?>"
            >


            <!-- =================================================
                 STUDENT INFORMATION
            ================================================== -->

            <div class="card mb-4">


                <div class="card-header">


                    <strong>

                        <i
                            class="fas fa-user-graduate text-primary"
                        ></i>

                        Student Information

                    </strong>


                </div>


                <div class="card-body">


                    <!-- Admission / LIN / First Name -->

                    <div class="form-row">


                        <div class="form-group col-md-4">

                            <label>
                                Admission Number
                            </label>


                            <input
                                type="text"
                                name="admission_no"
                                class="form-control"
                                placeholder="e.g. ADM001"
                                value="<?= e($admission_no) ?>"
                                required
                            >

                        </div>


                        <div class="form-group col-md-4">

                            <label>
                                LIN Number
                            </label>


                            <input
                                type="text"
                                name="lin_no"
                                class="form-control"
                                placeholder="Enter LIN number"
                                value="<?= e($lin_no) ?>"
                                required
                            >

                        </div>

                        <div class="form-group col-md-4">
                            <label for="student_payment_code">Student Payment Code</label>
                            <input type="text" name="student_payment_code" id="student_payment_code" class="form-control" maxlength="50" placeholder="Enter Student Payment Code" value="<?= e($student_payment_code) ?>" required>
                        </div>

                        <div class="form-group col-md-4">
                            <label for="student_section">Student Section</label>
                            <select name="student_section" id="student_section" class="custom-select" required>
                                <option value="Day" <?= $student_section === 'Day' ? 'selected' : '' ?>>Day</option>
                                <option value="Boarding" <?= $student_section === 'Boarding' ? 'selected' : '' ?>>Boarding</option>
                            </select>
                        </div>

                        <div class="form-group col-md-4">

                            <label>
                                First Name
                            </label>


                            <input
                                type="text"
                                name="first_name"
                                class="form-control"
                                value="<?= e($first_name) ?>"
                                required
                            >

                        </div>


                    </div>


                    <!-- Names / Gender -->

                    <div class="form-row">


                        <div class="form-group col-md-4">

                            <label>
                                Last Name
                            </label>


                            <input
                                type="text"
                                name="last_name"
                                class="form-control"
                                value="<?= e($last_name) ?>"
                                required
                            >

                        </div>


                        <div class="form-group col-md-4">

                            <label>
                                Other Names
                            </label>


                            <input
                                type="text"
                                name="other_names"
                                class="form-control"
                                value="<?= e($other_names) ?>"
                            >

                        </div>


                        <div class="form-group col-md-4">

                            <label>
                                Gender
                            </label>


                            <select
                                name="gender"
                                class="form-control"
                                required
                            >

                                <option value="">
                                    Select Gender
                                </option>


                                <option
                                    value="Male"
                                    <?= $gender === 'Male'
                                        ? 'selected'
                                        : '' ?>
                                >
                                    Male
                                </option>


                                <option
                                    value="Female"
                                    <?= $gender === 'Female'
                                        ? 'selected'
                                        : '' ?>
                                >
                                    Female
                                </option>


                            </select>


                        </div>


                    </div>


                    <!-- DOB / Class / Photo -->

                    <div class="form-row">


                        <div class="form-group col-md-4">

                            <label>
                                Date of Birth
                            </label>


                            <input
                                type="date"
                                name="date_of_birth"
                                class="form-control"
                                value="<?= e($date_of_birth) ?>"
                            >

                        </div>


                        <div class="form-group col-md-4">

                            <label>
                                Class
                            </label>


                            <select
                                name="class_id"
                                class="form-control"
                                required
                            >

                                <option value="">
                                    Select Class
                                </option>


                                <?php foreach (
                                    $classes as $class
                                ): ?>


                                    <option
                                        value="<?= (int)$class['id'] ?>"
                                        <?= (int)$class_id ===
                                            (int)$class['id']
                                            ? 'selected'
                                            : '' ?>
                                    >

                                        <?= e(
                                            $class['class_name']
                                        ) ?>


                                        <?php if (
                                            !empty(
                                                $class['section']
                                            )
                                        ): ?>

                                            -
                                            <?= e(
                                                $class['section']
                                            ) ?>

                                        <?php endif; ?>


                                        (
                                        <?= e(
                                            $class['academic_year']
                                        ) ?>
                                        )

                                    </option>


                                <?php endforeach; ?>


                            </select>

                        </div>


                        <div class="form-group col-md-4">

                            <label>
                                Student Photo
                            </label>


                            <input
                                type="file"
                                name="photo"
                                class="form-control-file"
                                accept="image/jpeg,image/png,image/webp"
                            >


                            <small
                                class="form-text text-muted"
                            >

                                JPG, PNG or WEBP.
                                Maximum 2 MB.

                            </small>


                        </div>


                    </div>


                </div>

            </div>


            <!-- =================================================
                 GUARDIAN INFORMATION
            ================================================== -->

            <div class="card mb-4">


                <div class="card-header">


                    <strong>

                        <i
                            class="fas fa-user-shield text-success"
                        ></i>

                        Guardian Information

                    </strong>


                </div>


                <div class="card-body">


                    <!-- Name / Relationship -->

                    <div class="form-row">


                        <div class="form-group col-md-6">

                            <label>
                                Guardian Full Name
                            </label>


                            <input
                                type="text"
                                name="guardian_name"
                                class="form-control"
                                value="<?= e($guardian_name) ?>"
                                required
                            >

                        </div>


                        <div class="form-group col-md-6">

                            <label>
                                Relationship
                            </label>


                            <input
                                type="text"
                                name="guardian_relationship"
                                class="form-control"
                                placeholder="Father, Mother, Uncle, etc."
                                value="<?= e(
                                    $guardian_relationship
                                ) ?>"
                                required
                            >

                        </div>


                    </div>


                    <!-- Phone / NIN / Email -->

                    <div class="form-row">


                        <div class="form-group col-md-4">

                            <label>
                                Phone Number
                            </label>


                            <input
                                type="text"
                                name="guardian_phone"
                                class="form-control"
                                placeholder="e.g. 0700000000"
                                value="<?= e(
                                    $guardian_phone
                                ) ?>"
                                required
                            >

                        </div>


                        <div class="form-group col-md-4">

                            <label>
                                NIN Number
                            </label>


                            <input
                                type="text"
                                name="guardian_nin"
                                class="form-control"
                                placeholder="Guardian NIN"
                                value="<?= e(
                                    $guardian_nin
                                ) ?>"
                                required
                            >

                        </div>


                        <div class="form-group col-md-4">

                            <label>
                                Email
                            </label>


                            <input
                                type="email"
                                name="guardian_email"
                                class="form-control"
                                value="<?= e(
                                    $guardian_email
                                ) ?>"
                            >

                        </div>


                    </div>


                    <!-- Address -->

                    <div class="form-group">

                        <label>
                            Address
                        </label>


                        <textarea
                            name="guardian_address"
                            class="form-control"
                            rows="2"
                        ><?= e(
                            $guardian_address
                        ) ?></textarea>


                    </div>


                </div>

            </div>


            <!-- =================================================
                 BUTTONS
            ================================================== -->

            <div class="text-right mb-5">


                <button
                    type="reset"
                    class="btn btn-secondary"
                >

                    <i class="fas fa-undo"></i>

                    Clear

                </button>


                <button
                    type="submit"
                    class="btn btn-primary"
                >

                    <i class="fas fa-save"></i>

                    Register Student

                </button>


            </div>


        </form>


        <!-- FOOTER -->

        <div
            class="text-center text-muted mt-4 mb-3"
        >

            <small>

                School Management System &copy;

                <?= date('Y') ?>

            </small>

        </div>


    </div>

</div>


<!-- =========================================================
     JAVASCRIPT
========================================================= -->

<script
    src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
></script>


<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
></script>


<script>

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const sidebar =
            document.getElementById("sidebar");

        const sidebarToggle =
            document.getElementById("sidebarToggle");

        const mobileMenuBtn =
            document.getElementById("mobileMenuBtn");

        const sidebarOverlay =
            document.getElementById("sidebarOverlay");

        const sidebarLinks =
            document.querySelectorAll(
                ".sidebar-menu a"
            );


        /*
        |--------------------------------------------------------------------------
        | Desktop Collapse / Mobile Close
        |--------------------------------------------------------------------------
        */

        sidebarToggle.addEventListener(
            "click",
            function () {

                if (window.innerWidth <= 768) {

                    sidebar.classList.remove(
                        "mobile-open"
                    );

                    sidebarOverlay.classList.remove(
                        "active"
                    );

                } else {

                    document.body.classList.toggle(
                        "sidebar-collapsed"
                    );

                }

            }
        );


        /*
        |--------------------------------------------------------------------------
        | Open Mobile Sidebar
        |--------------------------------------------------------------------------
        */

        mobileMenuBtn.addEventListener(
            "click",
            function () {

                sidebar.classList.add(
                    "mobile-open"
                );

                sidebarOverlay.classList.add(
                    "active"
                );

            }
        );


        /*
        |--------------------------------------------------------------------------
        | Overlay Close
        |--------------------------------------------------------------------------
        */

        sidebarOverlay.addEventListener(
            "click",
            function () {

                sidebar.classList.remove(
                    "mobile-open"
                );

                sidebarOverlay.classList.remove(
                    "active"
                );

            }
        );


        /*
        |--------------------------------------------------------------------------
        | Close After Link Click
        |--------------------------------------------------------------------------
        */

        sidebarLinks.forEach(
            function (link) {

                link.addEventListener(
                    "click",
                    function () {

                        if (
                            window.innerWidth <= 768
                        ) {

                            sidebar.classList.remove(
                                "mobile-open"
                            );

                            sidebarOverlay.classList.remove(
                                "active"
                            );

                        }

                    }
                );

            }
        );


        /*
        |--------------------------------------------------------------------------
        | Escape Key
        |--------------------------------------------------------------------------
        */

        document.addEventListener(
            "keydown",
            function (event) {

                if (event.key === "Escape") {

                    sidebar.classList.remove(
                        "mobile-open"
                    );

                    sidebarOverlay.classList.remove(
                        "active"
                    );

                }

            }
        );


        /*
        |--------------------------------------------------------------------------
        | Window Resize
        |--------------------------------------------------------------------------
        */

        window.addEventListener(
            "resize",
            function () {

                if (window.innerWidth > 768) {

                    sidebar.classList.remove(
                        "mobile-open"
                    );

                    sidebarOverlay.classList.remove(
                        "active"
                    );

                }

            }
        );

    }
);

</script>


</body>

</html>