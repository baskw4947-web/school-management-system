<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once "../../includes/auth.php";
require_once "../../config/database.php";

requireRole([
    'administrator',
    'assistant_administrator'
]);

/*
|--------------------------------------------------------------------------
| Helper
|--------------------------------------------------------------------------
*/

function e($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}


/*
|--------------------------------------------------------------------------
| Get Student ID
|--------------------------------------------------------------------------
*/

$student_id = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$student_id || $student_id <= 0) {
    http_response_code(400);
    exit("Invalid student ID.");
}


/*
|--------------------------------------------------------------------------
| Get Student
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        s.id,
        s.admission_no,
        s.lin_no,
        s.student_payment_code,
        s.student_section,
        s.first_name,
        s.last_name,
        s.other_names,
        s.gender,
        s.date_of_birth,
        s.photo,
        s.status,
        s.created_at,

        c.class_name,
        c.section,
        c.academic_year,

        g.full_name AS guardian_name,
        g.relationship AS guardian_relationship,
        g.phone AS guardian_phone,
        g.nin_no AS guardian_nin,
        g.email AS guardian_email,
        g.address AS guardian_address,

        u.full_name AS registered_by_name

    FROM students s

    INNER JOIN classes c
        ON s.class_id = c.id

    INNER JOIN guardians g
        ON s.guardian_id = g.id

    LEFT JOIN users u
        ON s.registered_by = u.id

    WHERE s.id = ?

    LIMIT 1
";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Database prepare error: " . $conn->error);
}

$stmt->bind_param(
    "i",
    $student_id
);

$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {
    http_response_code(404);
    exit("Student not found.");
}

$student = $result->fetch_assoc();

$stmt->close();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Student Profile - <?= e($student['first_name']) ?>
    </title>

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
    >

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
    >

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: #f5f6f8;
            font-family: Arial, Helvetica, sans-serif;
        }

        /* =====================================================
           SIDEBAR
        ===================================================== */

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100vh;
            background: #343a40;
            color: #fff;
            z-index: 1050;
            transition: all 0.3s ease;
            overflow-y: auto;
        }

        .sidebar-header {
            height: 65px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 18px;
            background: #212529;
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }

        .sidebar-header h5 {
            margin: 0;
            font-size: 18px;
            font-weight: 600;
            white-space: nowrap;
        }

        .sidebar-header small {
            display: block;
            color: #adb5bd;
            font-size: 11px;
        }

        .sidebar-menu {
            padding: 15px 10px;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            color: #ced4da;
            text-decoration: none;
            padding: 12px 14px;
            margin-bottom: 5px;
            border-radius: 6px;
            transition: all 0.2s ease;
            font-size: 14px;
        }

        .sidebar-menu a i {
            width: 25px;
            min-width: 25px;
            text-align: center;
            margin-right: 12px;
            font-size: 16px;
        }

        .sidebar-menu a:hover {
            background: #495057;
            color: #fff;
        }

        .sidebar-menu a.active {
            background: #007bff;
            color: #fff;
        }

        .sidebar-divider {
            border-top: 1px solid rgba(255,255,255,0.1);
            margin: 15px 5px;
        }

        /* =====================================================
           COLLAPSED SIDEBAR
        ===================================================== */

        body.sidebar-collapsed .sidebar {
            width: 75px;
        }

        body.sidebar-collapsed .sidebar-header {
            justify-content: center;
            padding: 0;
        }

        body.sidebar-collapsed .sidebar-header h5,
        body.sidebar-collapsed .sidebar-header small,
        body.sidebar-collapsed .sidebar-menu a span {
            display: none;
        }

        body.sidebar-collapsed .sidebar-menu a {
            justify-content: center;
            padding: 13px 8px;
        }

        body.sidebar-collapsed .sidebar-menu a i {
            margin-right: 0;
        }

        /* =====================================================
           MAIN CONTENT
        ===================================================== */

        .main-content {
            margin-left: 250px;
            min-height: 100vh;
            transition: all 0.3s ease;
            padding: 25px;
        }

        body.sidebar-collapsed .main-content {
            margin-left: 75px;
        }

        /* =====================================================
           DESKTOP TOPBAR
        ===================================================== */

        .desktop-topbar {
            height: 55px;
            background: #fff;
            border-radius: 8px;
            margin-bottom: 25px;
            padding: 0 15px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }

        .sidebar-toggle {
            border: none;
            background: transparent;
            font-size: 20px;
            color: #343a40;
            cursor: pointer;
            outline: none !important;
        }

        /* =====================================================
           MOBILE TOPBAR
        ===================================================== */

        .mobile-topbar {
            display: none;
            background: #212529;
            color: #fff;
            height: 60px;
            align-items: center;
            padding: 0 15px;
            justify-content: space-between;
        }

        .mobile-menu-btn {
            background: transparent;
            border: none;
            color: #fff;
            font-size: 22px;
            cursor: pointer;
        }

        .sidebar-close {
            display: none;
            background: transparent;
            border: none;
            color: #fff;
            font-size: 20px;
            cursor: pointer;
        }

        /* =====================================================
           OVERLAY
        ===================================================== */

        .sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.5);
            z-index: 1040;
        }

        .sidebar-overlay.show {
            display: block;
        }

        /* =====================================================
           PROFILE
        ===================================================== */

        .student-photo {
            width: 180px;
            height: 180px;
            object-fit: cover;
            border-radius: 10px;
            border: 1px solid #ddd;
        }

        .no-photo {
            width: 180px;
            height: 180px;
            background: #e9ecef;
            border-radius: 10px;

            display: flex;
            align-items: center;
            justify-content: center;

            color: #777;
            margin: auto;
        }

        .profile-card {
            border: none;
            border-radius: 10px;
        }

        .section-title {
            font-weight: 600;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }

        .info-label {
            font-size: 13px;
            color: #777;
            margin-bottom: 3px;
        }

        .info-value {
            font-weight: 500;
            margin-bottom: 15px;
            word-break: break-word;
        }

        .identity-box {
            background: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }

        .identity-number {
            font-size: 18px;
            font-weight: 600;
        }

        .page-title {
            font-weight: 600;
        }

        /* =====================================================
           MOBILE
        ===================================================== */

        @media (max-width: 767px) {

            .sidebar {
                width: 250px;
                transform: translateX(-100%);
                box-shadow: 5px 0 20px rgba(0,0,0,0.15);
            }

            .sidebar.mobile-open {
                transform: translateX(0);
            }

            .sidebar-close {
                display: block;
            }

            .main-content,
            body.sidebar-collapsed .main-content {
                margin-left: 0;
                padding: 15px;
            }

            .desktop-topbar {
                display: none;
            }

            .mobile-topbar {
                display: flex;
            }

            .header-buttons {
                margin-top: 15px;
            }

            .header-buttons .btn {
                margin-bottom: 5px;
            }

            .student-photo,
            .no-photo {
                width: 150px;
                height: 150px;
            }

            .page-header {
                margin-top: 20px;
            }
        }

    </style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>

<body>


<!-- =========================================================
     SIDEBAR
========================================================= -->

<div class="sidebar" id="sidebar">

    <div class="sidebar-header">

        <div>
            <h5>
                <i class="fas fa-school mr-1"></i>
                <span>School System</span>
            </h5>

            <small>
                Administration
            </small>
        </div>

        <button
            type="button"
            class="sidebar-close"
            id="sidebarClose"
        >
            <i class="fas fa-times"></i>
        </button>

    </div>


    <div class="sidebar-menu">

        <a href="/admin/dashboard.php">
            <i class="fas fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>


        <a href="/admin/classes/index.php">
            <i class="fas fa-chalkboard"></i>
            <span>Classes</span>
        </a>


        <a
            href="/admin/students/list.php"
            class="active"
        >
            <i class="fas fa-user-graduate"></i>
            <span>Students</span>
        </a>


        <a href="/admin/teachers/index.php">
            <i class="fas fa-chalkboard-teacher"></i>
            <span>Teachers</span>
        </a>


        <a href="/admin/bursar/index.php">
            <i class="fas fa-money-bill-wave"></i>
            <span>Bursar</span>
        </a>


        <a href="/admin/assets/index.php">
            <i class="fas fa-boxes"></i>
            <span>Assets</span>
        </a>


        <a href="/admin/staff/index.php">
            <i class="fas fa-users"></i>
            <span>Other Staff</span>
        </a>


        <a href="/admin/projects/index.php">
            <i class="fas fa-project-diagram"></i>
            <span>School Projects</span>
        </a>


        <a href="/admin/users/index.php">
            <i class="fas fa-user-cog"></i>
            <span>Users</span>
        </a>


        <div class="sidebar-divider"></div>


        <a href="/logout.php">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>

    </div>

</div>


<!-- Sidebar Overlay -->

<div
    class="sidebar-overlay"
    id="sidebarOverlay"
></div>


<!-- =========================================================
     MOBILE TOPBAR
========================================================= -->

<div class="mobile-topbar">

    <div>
        <strong>
            <i class="fas fa-school mr-1"></i>
            School System
        </strong>
    </div>

    <button
        type="button"
        class="mobile-menu-btn"
        id="menuToggle"
    >
        <i class="fas fa-bars"></i>
    </button>

</div>


<!-- =========================================================
     MAIN CONTENT
========================================================= -->

<div class="main-content">


    <!-- Desktop Topbar -->

    <div class="desktop-topbar">

        <button
            type="button"
            class="sidebar-toggle"
            id="desktopSidebarToggle"
            title="Toggle Sidebar"
        >
            <i class="fas fa-bars"></i>
        </button>

        <div class="text-muted">
            <i class="fas fa-user-graduate mr-1"></i>
            Student Profile
        </div>

    </div>


    <div class="container-fluid">


        <!-- =================================================
             HEADER
        ================================================== -->

        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap page-header">

            <div>

                <h2 class="mb-1 page-title">
                    Student Profile
                </h2>

                <p class="text-muted mb-0">
                    Student information and guardian details
                </p>

            </div>


            <div class="header-buttons">

                <a
                    href="list.php"
                    class="btn btn-secondary"
                >
                    <i class="fas fa-arrow-left mr-1"></i>
                    Student List
                </a>


                <a
                    href="edit.php?id=<?= (int)$student['id'] ?>"
                    class="btn btn-warning"
                >
                    <i class="fas fa-edit mr-1"></i>
                    Edit Student
                </a>

            </div>

        </div>


        <!-- =================================================
             STUDENT PROFILE
        ================================================== -->

        <div class="card profile-card shadow-sm mb-4">

            <div class="card-body">

                <div class="row">


                    <!-- Photo -->

                    <div class="col-md-3 text-center mb-4 mb-md-0">

                        <?php if (!empty($student['photo'])): ?>

                            <img
                                src="/uploads/students/<?= e($student['photo']) ?>"
                                alt="Student Photo"
                                class="student-photo"
                            >

                        <?php else: ?>

                            <div class="no-photo">
                                <div>
                                    <i class="fas fa-user fa-2x mb-2"></i>
                                    <br>
                                    No Photo
                                </div>
                            </div>

                        <?php endif; ?>

                    </div>


                    <!-- Basic Information -->

                    <div class="col-md-9">

                        <h3 class="mb-3">

                            <?= e($student['first_name']) ?>

                            <?php if (!empty($student['other_names'])): ?>

                                <?= e($student['other_names']) ?>

                            <?php endif; ?>

                            <?= e($student['last_name']) ?>

                        </h3>


                        <!-- Student Identification -->

                        <div class="row">

                            <div class="col-md-6">

                                <div class="identity-box">

                                    <div class="info-label">
                                        Admission Number
                                    </div>

                                    <div class="identity-number">
                                        <?= e($student['admission_no']) ?>
                                    </div>

                                </div>

                            </div>


                            <div class="col-md-4">

                                <div class="identity-box">

                                    <div class="info-label">
                                        LIN Number
                                    </div>

                                    <div class="identity-number">

                                        <?php if (!empty($student['lin_no'])): ?>

                                            <?= e($student['lin_no']) ?>

                                        <?php else: ?>

                                            <span class="text-muted">
                                                Not provided
                                            </span>

                                        <?php endif; ?>

                                    </div>

                                </div>

                            </div>

                            <div class="col-md-4">
                                <div class="identity-box">
                                    <div class="info-label">Student Payment Code</div>
                                    <div class="identity-number">
                                        <?= !empty($student['student_payment_code']) ? e($student['student_payment_code']) : '<span class="text-muted">Not provided</span>' ?>
                                    </div>
                                </div>
                            </div>

                        </div>


                        <!-- Other Student Information -->

                        <div class="row">

                            <div class="col-md-4">

                                <div class="info-label">
                                    Gender
                                </div>

                                <div class="info-value">
                                    <?= e($student['gender']) ?>
                                </div>

                            </div>


                            <div class="col-md-4">

                                <div class="info-label">
                                    Date of Birth
                                </div>

                                <div class="info-value">

                                    <?php if (!empty($student['date_of_birth'])): ?>

                                        <?= e($student['date_of_birth']) ?>

                                    <?php else: ?>

                                        <span class="text-muted">
                                            Not provided
                                        </span>

                                    <?php endif; ?>

                                </div>

                            </div>


                            <div class="col-md-4">

                                <div class="info-label">
                                    Status
                                </div>

                                <div class="info-value">

                                    <?php if ($student['status'] === 'active'): ?>

                                        <span class="badge badge-success">
                                            Active
                                        </span>

                                    <?php else: ?>

                                        <span class="badge badge-secondary">
                                            Inactive
                                        </span>

                                    <?php endif; ?>

                                </div>

                            </div>


                            <div class="col-md-4">

                                <div class="info-label">
                                    Class
                                </div>

                                <div class="info-value">

                                    <?= e($student['class_name']) ?>

                                    <?php if (!empty($student['section'])): ?>

                                        - <?= e($student['section']) ?>

                                    <?php endif; ?>

                                </div>

                            </div>


                            <div class="col-md-4">

                                <div class="info-label">
                                    Student Section
                                </div>

                                <div class="info-value">
                                    <span class="badge badge-<?= ($student['student_section'] ?? 'Day') === 'Boarding' ? 'info' : 'secondary' ?>">
                                        <?= e($student['student_section'] ?? 'Day') ?>
                                    </span>
                                </div>

                            </div>


                            <div class="col-md-4">

                                <div class="info-label">
                                    Academic Year
                                </div>

                                <div class="info-value">
                                    <?= e($student['academic_year']) ?>
                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- =================================================
             GUARDIAN INFORMATION
        ================================================== -->

        <div class="card profile-card shadow-sm mb-4">

            <div class="card-body">

                <h5 class="section-title">
                    <i class="fas fa-user-shield mr-2"></i>
                    Guardian Information
                </h5>


                <div class="row">

                    <div class="col-md-4">

                        <div class="info-label">
                            Guardian Name
                        </div>

                        <div class="info-value">
                            <?= e($student['guardian_name']) ?>
                        </div>

                    </div>


                    <div class="col-md-4">

                        <div class="info-label">
                            Relationship
                        </div>

                        <div class="info-value">
                            <?= e($student['guardian_relationship']) ?>
                        </div>

                    </div>


                    <div class="col-md-4">

                        <div class="info-label">
                            Phone
                        </div>

                        <div class="info-value">
                            <?= e($student['guardian_phone']) ?>
                        </div>

                    </div>


                    <!-- Guardian NIN -->

                    <div class="col-md-4">

                        <div class="info-label">
                            Guardian NIN Number
                        </div>

                        <div class="info-value">

                            <?php if (!empty($student['guardian_nin'])): ?>

                                <?= e($student['guardian_nin']) ?>

                            <?php else: ?>

                                <span class="text-muted">
                                    Not provided
                                </span>

                            <?php endif; ?>

                        </div>

                    </div>


                    <div class="col-md-4">

                        <div class="info-label">
                            Email
                        </div>

                        <div class="info-value">

                            <?php if (!empty($student['guardian_email'])): ?>

                                <?= e($student['guardian_email']) ?>

                            <?php else: ?>

                                <span class="text-muted">
                                    Not provided
                                </span>

                            <?php endif; ?>

                        </div>

                    </div>


                    <div class="col-md-4">

                        <div class="info-label">
                            Address
                        </div>

                        <div class="info-value">

                            <?php if (!empty($student['guardian_address'])): ?>

                                <?= e($student['guardian_address']) ?>

                            <?php else: ?>

                                <span class="text-muted">
                                    Not provided
                                </span>

                            <?php endif; ?>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- =================================================
             REGISTRATION INFORMATION
        ================================================== -->

        <div class="card profile-card shadow-sm">

            <div class="card-body">

                <h5 class="section-title">
                    <i class="fas fa-info-circle mr-2"></i>
                    Registration Information
                </h5>


                <div class="row">

                    <div class="col-md-6">

                        <div class="info-label">
                            Registered By
                        </div>

                        <div class="info-value">

                            <?= e(
                                $student['registered_by_name']
                                ?: 'Unknown'
                            ) ?>

                        </div>

                    </div>


                    <div class="col-md-6">

                        <div class="info-label">
                            Registration Date
                        </div>

                        <div class="info-value">

                            <?= e($student['created_at']) ?>

                        </div>

                    </div>

                </div>

            </div>

        </div>


    </div>

</div>


<!-- =========================================================
     JAVASCRIPT
========================================================= -->

<script>

    const sidebar = document.getElementById('sidebar');

    const menuToggle = document.getElementById('menuToggle');

    const sidebarClose = document.getElementById('sidebarClose');

    const sidebarOverlay = document.getElementById('sidebarOverlay');

    const desktopSidebarToggle =
        document.getElementById('desktopSidebarToggle');


    /*
    |--------------------------------------------------------------------------
    | Desktop Sidebar Toggle
    |--------------------------------------------------------------------------
    */

    if (desktopSidebarToggle) {

        desktopSidebarToggle.addEventListener('click', function () {

            document.body.classList.toggle('sidebar-collapsed');

        });

    }


    /*
    |--------------------------------------------------------------------------
    | Mobile Sidebar Open
    |--------------------------------------------------------------------------
    */

    if (menuToggle) {

        menuToggle.addEventListener('click', function () {

            sidebar.classList.add('mobile-open');

            sidebarOverlay.classList.add('show');

        });

    }


    /*
    |--------------------------------------------------------------------------
    | Mobile Sidebar Close
    |--------------------------------------------------------------------------
    */

    function closeMobileSidebar() {

        sidebar.classList.remove('mobile-open');

        sidebarOverlay.classList.remove('show');

    }


    if (sidebarClose) {

        sidebarClose.addEventListener(
            'click',
            closeMobileSidebar
        );

    }


    if (sidebarOverlay) {

        sidebarOverlay.addEventListener(
            'click',
            closeMobileSidebar
        );

    }


    /*
    |--------------------------------------------------------------------------
    | Close Sidebar With ESC
    |--------------------------------------------------------------------------
    */

    document.addEventListener('keydown', function (event) {

        if (event.key === 'Escape') {

            closeMobileSidebar();

        }

    });


    /*
    |--------------------------------------------------------------------------
    | Close Mobile Sidebar After Clicking Link
    |--------------------------------------------------------------------------
    */

    const sidebarLinks =
        document.querySelectorAll('.sidebar-menu a');

    sidebarLinks.forEach(function (link) {

        link.addEventListener('click', function () {

            if (window.innerWidth <= 767) {

                closeMobileSidebar();

            }

        });

    });

</script>


</body>

</html>