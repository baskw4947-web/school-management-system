<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once "../../includes/auth.php";
require_once "../../config/database.php";

requireRole([
    'administrator',
    'assistant_administrator'
]);

/*
|--------------------------------------------------------------------------
| CSRF TOKEN
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrf_token = $_SESSION['csrf_token'];


/*
|--------------------------------------------------------------------------
| HELPER
|--------------------------------------------------------------------------
*/

function e($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}


/*
|--------------------------------------------------------------------------
| GET STUDENT ID
|--------------------------------------------------------------------------
*/

$student_id = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$student_id || $student_id <= 0) {
    exit("Invalid student ID.");
}


/*
|--------------------------------------------------------------------------
| VARIABLES
|--------------------------------------------------------------------------
*/

$error = '';
$success = '';

$admission_no = '';
$lin_no = '';
$student_payment_code = '';
$student_section = 'Day';

$first_name = '';
$last_name = '';
$other_names = '';
$gender = '';
$date_of_birth = '';
$class_id = '';
$status = 'active';

$guardian_id = '';
$guardian_name = '';
$guardian_relationship = '';
$guardian_phone = '';
$guardian_nin = '';
$guardian_email = '';
$guardian_address = '';

$current_photo = '';


/*
|--------------------------------------------------------------------------
| LOAD STUDENT
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT
        s.id,
        s.admission_no,
        s.lin_no,
        s.student_payment_code,
        s.student_section,
        s.first_name,
        s.last_name,
        s.other_names,
        s.gender,
        s.date_of_birth,
        s.class_id,
        s.guardian_id,
        s.photo,
        s.status,

        g.full_name AS guardian_name,
        g.relationship AS guardian_relationship,
        g.phone AS guardian_phone,
        g.nin_no AS guardian_nin,
        g.email AS guardian_email,
        g.address AS guardian_address

    FROM students s

    INNER JOIN guardians g
        ON s.guardian_id = g.id

    WHERE s.id = ?

    LIMIT 1
");

if (!$stmt) {
    die("Database error: " . $conn->error);
}

$stmt->bind_param(
    "i",
    $student_id
);

$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {
    exit("Student not found.");
}

$student = $result->fetch_assoc();

$stmt->close();


/*
|--------------------------------------------------------------------------
| POPULATE VARIABLES
|--------------------------------------------------------------------------
*/

$admission_no =
    $student['admission_no'] ?? '';

$lin_no =
    $student['lin_no'] ?? '';

$student_payment_code =
    $student['student_payment_code'] ?? '';

$student_section =
    $student['student_section'] ?? 'Day';

$first_name =
    $student['first_name'] ?? '';

$last_name =
    $student['last_name'] ?? '';

$other_names =
    $student['other_names'] ?? '';

$gender =
    $student['gender'] ?? '';

$date_of_birth =
    $student['date_of_birth'] ?? '';

$class_id =
    $student['class_id'] ?? '';

$status =
    $student['status'] ?? 'active';

$guardian_id =
    $student['guardian_id'] ?? '';

$guardian_name =
    $student['guardian_name'] ?? '';

$guardian_relationship =
    $student['guardian_relationship'] ?? '';

$guardian_phone =
    $student['guardian_phone'] ?? '';

$guardian_nin =
    $student['guardian_nin'] ?? '';

$guardian_email =
    $student['guardian_email'] ?? '';

$guardian_address =
    $student['guardian_address'] ?? '';

$current_photo =
    $student['photo'] ?? '';


/*
|--------------------------------------------------------------------------
| LOAD ACTIVE CLASSES
|--------------------------------------------------------------------------
*/

$classes = [];

$classQuery = $conn->query("
    SELECT
        id,
        class_name,
        section,
        academic_year
    FROM classes
    WHERE status = 'active'
    ORDER BY class_name, section
");

if (!$classQuery) {
    die(
        "Unable to load classes: "
        . $conn->error
    );
}

while ($row = $classQuery->fetch_assoc()) {
    $classes[] = $row;
}


/*
|--------------------------------------------------------------------------
| PROCESS FORM
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /*
    |--------------------------------------------------------------------------
    | CSRF
    |--------------------------------------------------------------------------
    */

    $postedToken =
        $_POST['csrf_token'] ?? '';

    if (
        empty($postedToken) ||
        !hash_equals(
            $_SESSION['csrf_token'],
            $postedToken
        )
    ) {
        $error =
            "Invalid security token. Please refresh the page and try again.";
    }


    /*
    |--------------------------------------------------------------------------
    | GET FORM DATA
    |--------------------------------------------------------------------------
    */

    if ($error === '') {

        $admission_no =
            trim($_POST['admission_no'] ?? '');

        $lin_no =
            trim($_POST['lin_no'] ?? '');

        $student_payment_code =
            trim($_POST['student_payment_code'] ?? '');

        $student_section =
            trim($_POST['student_section'] ?? 'Day');

        $first_name =
            trim($_POST['first_name'] ?? '');

        $last_name =
            trim($_POST['last_name'] ?? '');

        $other_names =
            trim($_POST['other_names'] ?? '');

        $gender =
            trim($_POST['gender'] ?? '');

        $date_of_birth =
            trim($_POST['date_of_birth'] ?? '');

        $class_id =
            (int)($_POST['class_id'] ?? 0);

        $status =
            trim($_POST['status'] ?? 'active');

        $guardian_name =
            trim($_POST['guardian_name'] ?? '');

        $guardian_relationship =
            trim($_POST['guardian_relationship'] ?? '');

        $guardian_phone =
            trim($_POST['guardian_phone'] ?? '');

        $guardian_nin =
            trim($_POST['guardian_nin'] ?? '');

        $guardian_email =
            trim($_POST['guardian_email'] ?? '');

        $guardian_address =
            trim($_POST['guardian_address'] ?? '');


        /*
        |--------------------------------------------------------------------------
        | VALIDATION
        |--------------------------------------------------------------------------
        */

        if ($admission_no === '') {

            $error =
                "Admission number is required.";

        } elseif (
            !preg_match(
                '/^[A-Za-z0-9\/-]{2,50}$/',
                $admission_no
            )
        ) {

            $error =
                "Invalid admission number.";

        } elseif ($lin_no === '') {

            $error =
                "LIN number is required.";

        } elseif (
            !preg_match(
                '/^[A-Za-z0-9\/-]{2,50}$/',
                $lin_no
            )
        ) {

            $error =
                "Invalid LIN number.";

        } elseif ($student_payment_code === '') {

            $error = "Student Payment Code is required.";

        } elseif (!preg_match('/^[A-Za-z0-9\/-]{2,50}$/', $student_payment_code)) {

            $error = "Invalid Student Payment Code.";

        } elseif (!in_array($student_section, ['Day', 'Boarding'], true)) {

            $error = "Please select Day or Boarding for the student.";

        } elseif ($first_name === '') {

            $error =
                "First name is required.";

        } elseif ($last_name === '') {

            $error =
                "Last name is required.";

        } elseif (
            !in_array(
                $gender,
                [
                    'Male',
                    'Female',
                    'Other'
                ],
                true
            )
        ) {

            $error =
                "Please select a valid gender.";

        } elseif ($class_id <= 0) {

            $error =
                "Please select a class.";

        } elseif (
            !in_array(
                $status,
                [
                    'active',
                    'inactive'
                ],
                true
            )
        ) {

            $error =
                "Invalid student status.";

        } elseif ($guardian_name === '') {

            $error =
                "Guardian name is required.";

        } elseif ($guardian_relationship === '') {

            $error =
                "Guardian relationship is required.";

        } elseif ($guardian_phone === '') {

            $error =
                "Guardian phone number is required.";

        } elseif ($guardian_nin === '') {

            $error =
                "Guardian NIN number is required.";

        } elseif (
            !preg_match(
                '/^[A-Za-z0-9-]{5,30}$/',
                $guardian_nin
            )
        ) {

            $error =
                "Invalid guardian NIN number.";

        } elseif (
            $guardian_email !== '' &&
            !filter_var(
                $guardian_email,
                FILTER_VALIDATE_EMAIL
            )
        ) {

            $error =
                "Please enter a valid guardian email address.";
        }


        /*
        |--------------------------------------------------------------------------
        | CHECK ADMISSION NUMBER
        |--------------------------------------------------------------------------
        */

        if ($error === '') {

            $stmt = $conn->prepare("
                SELECT id
                FROM students
                WHERE admission_no = ?
                AND id != ?
                LIMIT 1
            ");

            if (!$stmt) {

                $error =
                    "Database error: "
                    . $conn->error;

            } else {

                $stmt->bind_param(
                    "si",
                    $admission_no,
                    $student_id
                );

                $stmt->execute();
                $stmt->store_result();

                if ($stmt->num_rows > 0) {

                    $error =
                        "This admission number already belongs to another student.";
                }

                $stmt->close();
            }
        }


        /*
        |--------------------------------------------------------------------------
        | CHECK LIN NUMBER
        |--------------------------------------------------------------------------
        */

        if ($error === '') {

            $stmt = $conn->prepare("
                SELECT id
                FROM students
                WHERE lin_no = ?
                AND id != ?
                LIMIT 1
            ");

            if (!$stmt) {

                $error =
                    "Database error: "
                    . $conn->error;

            } else {

                $stmt->bind_param(
                    "si",
                    $lin_no,
                    $student_id
                );

                $stmt->execute();
                $stmt->store_result();

                if ($stmt->num_rows > 0) {

                    $error =
                        "This LIN number already belongs to another student.";
                }

                $stmt->close();
            }
        }


        /*
        |--------------------------------------------------------------------------
        | CHECK STUDENT PAYMENT CODE
        |--------------------------------------------------------------------------
        */

        if ($error === '') {
            $stmt = $conn->prepare("SELECT id FROM students WHERE student_payment_code = ? AND id != ? LIMIT 1");
            if (!$stmt) {
                $error = "Database error: " . $conn->error;
            } else {
                $stmt->bind_param("si", $student_payment_code, $student_id);
                $stmt->execute();
                $stmt->store_result();
                if ($stmt->num_rows > 0) {
                    $error = "This Student Payment Code already belongs to another student.";
                }
                $stmt->close();
            }
        }

        /*
        |--------------------------------------------------------------------------
        | CHECK CLASS
        |--------------------------------------------------------------------------
        */

        if ($error === '') {

            $stmt = $conn->prepare("
                SELECT id
                FROM classes
                WHERE id = ?
                AND status = 'active'
                LIMIT 1
            ");

            if (!$stmt) {

                $error =
                    "Database error: "
                    . $conn->error;

            } else {

                $stmt->bind_param(
                    "i",
                    $class_id
                );

                $stmt->execute();
                $stmt->store_result();

                if ($stmt->num_rows === 0) {

                    $error =
                        "Selected class does not exist or is inactive.";
                }

                $stmt->close();
            }
        }


        /*
        |--------------------------------------------------------------------------
        | PHOTO UPLOAD
        |--------------------------------------------------------------------------
        */

        $newPhoto =
            $current_photo;

        $uploadedNewPhoto = false;

        if (
            $error === '' &&
            isset($_FILES['photo']) &&
            $_FILES['photo']['error']
                !== UPLOAD_ERR_NO_FILE
        ) {

            if (
                $_FILES['photo']['error']
                !== UPLOAD_ERR_OK
            ) {

                $error =
                    "There was a problem uploading the photo.";

            } elseif (
                $_FILES['photo']['size']
                > 2 * 1024 * 1024
            ) {

                $error =
                    "Student photo must not exceed 2 MB.";

            } else {

                $tmpName =
                    $_FILES['photo']['tmp_name'];

                $finfo =
                    finfo_open(
                        FILEINFO_MIME_TYPE
                    );

                $mimeType =
                    finfo_file(
                        $finfo,
                        $tmpName
                    );

                finfo_close($finfo);

                $allowedTypes = [
                    'image/jpeg' => 'jpg',
                    'image/png'  => 'png',
                    'image/webp' => 'webp'
                ];

                if (
                    !isset(
                        $allowedTypes[$mimeType]
                    )
                ) {

                    $error =
                        "Only JPG, PNG and WEBP photos are allowed.";

                } else {

                    $uploadDirectory =
                        __DIR__
                        . "/../../uploads/students/";

                    if (!is_dir($uploadDirectory)) {

                        if (
                            !mkdir(
                                $uploadDirectory,
                                0755,
                                true
                            )
                        ) {

                            $error =
                                "Unable to create photo upload directory.";
                        }
                    }

                    if ($error === '') {

                        /*
                        | IMPORTANT:
                        | Store the extension in the database.
                        */

                        $newPhoto =
                            bin2hex(
                                random_bytes(16)
                            )
                            . '.'
                            . $allowedTypes[$mimeType];

                        $destination =
                            $uploadDirectory
                            . $newPhoto;

                        if (
                            !move_uploaded_file(
                                $tmpName,
                                $destination
                            )
                        ) {

                            $error =
                                "Unable to save the student photo.";

                            $newPhoto =
                                $current_photo;

                        } else {

                            $uploadedNewPhoto =
                                true;
                        }
                    }
                }
            }
        }


        /*
        |--------------------------------------------------------------------------
        | UPDATE DATABASE
        |--------------------------------------------------------------------------
        */

        if ($error === '') {

            $conn->begin_transaction();

            try {

                /*
                |--------------------------------------------------------------------------
                | UPDATE GUARDIAN
                |--------------------------------------------------------------------------
                */

                $stmt = $conn->prepare("
                    UPDATE guardians
                    SET
                        full_name = ?,
                        relationship = ?,
                        phone = ?,
                        nin_no = ?,
                        email = ?,
                        address = ?
                    WHERE id = ?
                ");

                if (!$stmt) {

                    throw new Exception(
                        "Guardian database error: "
                        . $conn->error
                    );
                }

                $stmt->bind_param(
                    "ssssssi",
                    $guardian_name,
                    $guardian_relationship,
                    $guardian_phone,
                    $guardian_nin,
                    $guardian_email,
                    $guardian_address,
                    $guardian_id
                );

                if (!$stmt->execute()) {

                    throw new Exception(
                        "Unable to update guardian: "
                        . $stmt->error
                    );
                }

                $stmt->close();


                /*
                |--------------------------------------------------------------------------
                | UPDATE STUDENT
                |--------------------------------------------------------------------------
                */

                $stmt = $conn->prepare("
                    UPDATE students
                    SET
                        admission_no = ?,
                        lin_no = ?,
                        student_payment_code = ?,
                        student_section = ?,
                        first_name = ?,
                        last_name = ?,
                        other_names = ?,
                        gender = ?,
                        date_of_birth = NULLIF(?, ''),
                        class_id = ?,
                        photo = ?,
                        status = ?
                    WHERE id = ?
                ");

                if (!$stmt) {

                    throw new Exception(
                        "Student database error: "
                        . $conn->error
                    );
                }

                /*
                | 11 variables:
                | s s s s s s s i s s i
                |
                | Correct string:
                | sssssssissi
                */

                $stmt->bind_param(
                    "sssssssssissi",
                    $admission_no,
                    $lin_no,
                    $student_payment_code,
                    $student_section,
                    $first_name,
                    $last_name,
                    $other_names,
                    $gender,
                    $date_of_birth,
                    $class_id,
                    $newPhoto,
                    $status,
                    $student_id
                );

                if (!$stmt->execute()) {

                    throw new Exception(
                        "Unable to update student: "
                        . $stmt->error
                    );
                }

                $stmt->close();

                $conn->commit();


                /*
                |--------------------------------------------------------------------------
                | DELETE OLD PHOTO
                |--------------------------------------------------------------------------
                */

                if (
                    $uploadedNewPhoto &&
                    !empty($current_photo) &&
                    $current_photo !== $newPhoto
                ) {

                    $oldPhotoPath =
                        __DIR__
                        . "/../../uploads/students/"
                        . $current_photo;

                    if (
                        file_exists(
                            $oldPhotoPath
                        )
                    ) {

                        unlink(
                            $oldPhotoPath
                        );
                    }
                }


                /*
                |--------------------------------------------------------------------------
                | SUCCESS
                |--------------------------------------------------------------------------
                */

                $current_photo =
                    $newPhoto;

                $success =
                    "Student information updated successfully.";

                $_SESSION['csrf_token'] =
                    bin2hex(random_bytes(32));

                $csrf_token =
                    $_SESSION['csrf_token'];

            } catch (Exception $e) {

                $conn->rollback();


                /*
                | Remove newly uploaded photo
                | if database update failed.
                */

                if (
                    $uploadedNewPhoto &&
                    !empty($newPhoto)
                ) {

                    $newPhotoPath =
                        __DIR__
                        . "/../../uploads/students/"
                        . $newPhoto;

                    if (
                        file_exists(
                            $newPhotoPath
                        )
                    ) {

                        unlink(
                            $newPhotoPath
                        );
                    }
                }

                $error =
                    $e->getMessage();
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Edit Student</title>

    <!-- Bootstrap 4 -->
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
    >

    <!-- Font Awesome -->
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
    >

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: #f4f6f9;
            font-family: Arial, Helvetica, sans-serif;
        }

        /*
        |--------------------------------------------------------------------------
        | SIDEBAR
        |--------------------------------------------------------------------------
        */

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;

            width: 250px;
            height: 100vh;

            background: #343a40;
            color: #fff;

            z-index: 1050;

            transition: all 0.3s ease;

            overflow-y: auto;
        }

        .sidebar-header {
            height: 65px;

            display: flex;
            align-items: center;
            justify-content: space-between;

            padding: 0 18px;

            background: #212529;

            border-bottom: 1px solid #495057;
        }

        .sidebar-header h4 {
            margin: 0;

            font-size: 20px;
            font-weight: 600;

            white-space: nowrap;
        }

        .sidebar-header button {
            border: none;
            background: transparent;
            color: #fff;

            font-size: 20px;

            cursor: pointer;
        }

        .sidebar-menu {
            padding: 15px 0;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;

            color: #ddd;

            text-decoration: none;

            padding: 13px 20px;

            font-size: 15px;

            transition: 0.2s;
        }

        .sidebar-menu a i {
            width: 25px;
            margin-right: 12px;

            text-align: center;

            font-size: 16px;
        }

        .sidebar-menu a:hover {
            background: #495057;
            color: #fff;
        }

        .sidebar-menu a.active {
            background: #007bff;
            color: #fff;
        }

        .sidebar-divider {
            border-top: 1px solid #495057;
            margin: 10px 15px;
        }


        /*
        |--------------------------------------------------------------------------
        | COLLAPSED SIDEBAR
        |--------------------------------------------------------------------------
        */

        body.sidebar-collapsed .sidebar {
            width: 75px;
        }

        body.sidebar-collapsed .sidebar-header h4 {
            display: none;
        }

        body.sidebar-collapsed .sidebar-menu a {
            justify-content: center;
            padding-left: 0;
            padding-right: 0;
        }

        body.sidebar-collapsed .sidebar-menu a i {
            margin-right: 0;
        }

        body.sidebar-collapsed .sidebar-menu a span {
            display: none;
        }


        /*
        |--------------------------------------------------------------------------
        | MAIN CONTENT
        |--------------------------------------------------------------------------
        */

        .main-content {
            margin-left: 250px;

            min-height: 100vh;

            transition: all 0.3s ease;
        }

        body.sidebar-collapsed .main-content {
            margin-left: 75px;
        }


        /*
        |--------------------------------------------------------------------------
        | TOP BAR
        |--------------------------------------------------------------------------
        */

        .topbar {
            height: 65px;

            background: #fff;

            border-bottom: 1px solid #ddd;

            display: flex;
            align-items: center;

            padding: 0 25px;

            justify-content: space-between;

            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }

        .topbar-left {
            display: flex;
            align-items: center;
        }

        .topbar-left button {
            border: none;

            background: transparent;

            font-size: 21px;

            color: #343a40;

            cursor: pointer;

            margin-right: 15px;
        }

        .page-title {
            font-size: 20px;
            font-weight: 600;

            color: #343a40;
        }

        .topbar-user {
            color: #6c757d;
            font-size: 14px;
        }


        /*
        |--------------------------------------------------------------------------
        | CONTENT AREA
        |--------------------------------------------------------------------------
        */

        .content-wrapper {
            padding: 25px;
        }

        .page-header {
            background: #fff;

            border-radius: 8px;

            padding: 20px;

            margin-bottom: 20px;

            box-shadow: 0 2px 5px rgba(0,0,0,0.05);

            display: flex;

            justify-content: space-between;

            align-items: center;
        }

        .page-header h2 {
            margin: 0;

            font-size: 25px;

            color: #343a40;
        }

        .page-header p {
            margin: 5px 0 0;

            color: #6c757d;
        }


        /*
        |--------------------------------------------------------------------------
        | CARDS
        |--------------------------------------------------------------------------
        */

        .card {
            border: none;

            border-radius: 8px;

            box-shadow: 0 2px 8px rgba(0,0,0,0.06);

            margin-bottom: 20px;
        }

        .card-header {
            background: #fff;

            border-bottom: 1px solid #eee;

            padding: 15px 20px;

            font-size: 16px;
        }

        .card-body {
            padding: 20px;
        }


        /*
        |--------------------------------------------------------------------------
        | PHOTO
        |--------------------------------------------------------------------------
        */

        .student-photo {
            width: 150px;
            height: 150px;

            object-fit: cover;

            border-radius: 8px;

            border: 1px solid #ddd;

            background: #f8f9fa;
        }


        /*
        |--------------------------------------------------------------------------
        | FORM
        |--------------------------------------------------------------------------
        */

        .form-control {
            border-radius: 5px;
        }

        .form-control:focus {
            box-shadow: 0 0 0 0.15rem rgba(0,123,255,.15);
        }

        label {
            font-weight: 600;

            color: #495057;
        }


        /*
        |--------------------------------------------------------------------------
        | MOBILE
        |--------------------------------------------------------------------------
        */

        .mobile-topbar {
            display: none;
        }

        .sidebar-overlay {
            display: none;
        }


        @media (max-width: 767.98px) {

            .sidebar {
                width: 250px;

                transform: translateX(-100%);
            }

            .sidebar.mobile-open {
                transform: translateX(0);
            }

            body.sidebar-collapsed .sidebar {
                width: 250px;
            }

            body.sidebar-collapsed .sidebar-header h4 {
                display: block;
            }

            body.sidebar-collapsed .sidebar-menu a {
                justify-content: flex-start;

                padding-left: 20px;
                padding-right: 20px;
            }

            body.sidebar-collapsed .sidebar-menu a i {
                margin-right: 12px;
            }

            body.sidebar-collapsed .sidebar-menu a span {
                display: inline;
            }

            .main-content,
            body.sidebar-collapsed .main-content {
                margin-left: 0;
            }

            .topbar {
                display: none;
            }

            .mobile-topbar {
                display: flex;

                height: 60px;

                background: #212529;

                color: #fff;

                align-items: center;

                justify-content: space-between;

                padding: 0 15px;

                position: sticky;

                top: 0;

                z-index: 1000;
            }

            .mobile-topbar button {
                background: transparent;

                border: none;

                color: #fff;

                font-size: 22px;
            }

            .mobile-topbar-title {
                font-size: 17px;

                font-weight: 600;
            }

            .content-wrapper {
                padding: 15px;
            }

            .page-header {
                display: block;
            }

            .page-header .header-buttons {
                margin-top: 15px;
            }

            .page-header .header-buttons .btn {
                margin-bottom: 5px;
            }

            .sidebar-overlay {
                position: fixed;

                top: 0;
                left: 0;

                width: 100%;
                height: 100%;

                background: rgba(0,0,0,0.45);

                z-index: 1040;
            }

            .sidebar-overlay.show {
                display: block;
            }

            .student-photo {
                width: 120px;
                height: 120px;
            }
        }

    </style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>


<body>


<!-- ==========================================================
     SIDEBAR
=========================================================== -->

<div
    class="sidebar"
    id="sidebar"
>

    <div class="sidebar-header">

        <h4>
            School Admin
        </h4>

        <button
            type="button"
            id="sidebarClose"
            class="d-md-none"
        >
            <i class="fas fa-times"></i>
        </button>

    </div>


    <div class="sidebar-menu">

        <a
            href="/admin/dashboard.php"
        >
            <i class="fas fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>


        <a
            href="/admin/classes/index.php"
        >
            <i class="fas fa-chalkboard"></i>
            <span>Classes</span>
        </a>


        <a
            href="/admin/students/list.php"
            class="active"
        >
            <i class="fas fa-user-graduate"></i>
            <span>Students</span>
        </a>


        <a
            href="/admin/teachers/index.php"
        >
            <i class="fas fa-chalkboard-teacher"></i>
            <span>Teachers</span>
        </a>


        <a
            href="/admin/bursar/index.php"
        >
            <i class="fas fa-money-bill-wave"></i>
            <span>Bursar</span>
        </a>


        <a
            href="/admin/assets/index.php"
        >
            <i class="fas fa-boxes"></i>
            <span>Assets</span>
        </a>


        <a
            href="/admin/staff/index.php"
        >
            <i class="fas fa-users"></i>
            <span>Other Staff</span>
        </a>


        <a
            href="/admin/projects/index.php"
        >
            <i class="fas fa-project-diagram"></i>
            <span>School Projects</span>
        </a>


        <a
            href="/admin/users/index.php"
        >
            <i class="fas fa-user-cog"></i>
            <span>Users</span>
        </a>


        <div class="sidebar-divider"></div>


        <a
            href="/logout.php"
        >
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>

    </div>

</div>


<!-- ==========================================================
     SIDEBAR OVERLAY
=========================================================== -->

<div
    class="sidebar-overlay"
    id="sidebarOverlay"
></div>


<!-- ==========================================================
     MAIN CONTENT
=========================================================== -->

<div class="main-content">


    <!-- DESKTOP TOPBAR -->

    <div class="topbar">

        <div class="topbar-left">

            <button
                type="button"
                id="sidebarToggle"
                title="Toggle Sidebar"
            >
                <i class="fas fa-bars"></i>
            </button>

            <div class="page-title">
                Edit Student
            </div>

        </div>


        <div class="topbar-user">

            <i class="fas fa-user-circle"></i>

            <?= e($_SESSION['full_name'] ?? $_SESSION['username'] ?? 'User') ?>

        </div>

    </div>


    <!-- MOBILE TOPBAR -->

    <div class="mobile-topbar">

        <button
            type="button"
            id="menuToggle"
        >
            <i class="fas fa-bars"></i>
        </button>

        <div class="mobile-topbar-title">
            Edit Student
        </div>

        <div style="width:25px;"></div>

    </div>


    <!-- CONTENT -->

    <div class="content-wrapper">


        <!-- PAGE HEADER -->

        <div class="page-header">

            <div>

                <h2>
                    <i class="fas fa-user-edit text-primary"></i>
                    Edit Student
                </h2>

                <p>
                    Update student and guardian information
                </p>

            </div>


            <div class="header-buttons">

                <a
                    href="view.php?id=<?= (int)$student_id ?>"
                    class="btn btn-info"
                >
                    <i class="fas fa-eye"></i>
                    View Student
                </a>


                <a
                    href="list.php"
                    class="btn btn-secondary"
                >
                    <i class="fas fa-list"></i>
                    Student List
                </a>

            </div>

        </div>


        <!-- SUCCESS MESSAGE -->

        <?php if ($success !== ''): ?>

            <div class="alert alert-success">

                <i class="fas fa-check-circle"></i>

                <?= e($success) ?>

            </div>

        <?php endif; ?>


        <!-- ERROR MESSAGE -->

        <?php if ($error !== ''): ?>

            <div class="alert alert-danger">

                <i class="fas fa-exclamation-circle"></i>

                <?= e($error) ?>

            </div>

        <?php endif; ?>


        <!-- =====================================================
             FORM
        ====================================================== -->

        <form
            method="POST"
            enctype="multipart/form-data"
        >

            <input
                type="hidden"
                name="csrf_token"
                value="<?= e($csrf_token) ?>"
            >


            <!-- =================================================
                 STUDENT INFORMATION
            ================================================== -->

            <div class="card">

                <div class="card-header">

                    <strong>
                        <i class="fas fa-user-graduate text-primary"></i>
                        Student Information
                    </strong>

                </div>


                <div class="card-body">


                    <!-- Admission / LIN / First Name -->

                    <div class="form-row">

                        <div class="form-group col-md-4">

                            <label>
                                Admission Number
                            </label>

                            <input
                                type="text"
                                name="admission_no"
                                class="form-control"
                                value="<?= e($admission_no) ?>"
                                required
                            >

                        </div>


                        <div class="form-group col-md-4">

                            <label>
                                LIN Number
                            </label>

                            <input
                                type="text"
                                name="lin_no"
                                class="form-control"
                                value="<?= e($lin_no) ?>"
                                required
                            >

                        </div>

                        <div class="form-group col-md-4">
                            <label for="student_payment_code">Student Payment Code</label>
                            <input type="text" name="student_payment_code" id="student_payment_code" class="form-control" maxlength="50" value="<?= e($student_payment_code) ?>" required>
                        </div>

                        <div class="form-group col-md-4">
                            <label for="student_section">Student Section</label>
                            <select name="student_section" id="student_section" class="custom-select" required>
                                <option value="Day" <?= $student_section === 'Day' ? 'selected' : '' ?>>Day</option>
                                <option value="Boarding" <?= $student_section === 'Boarding' ? 'selected' : '' ?>>Boarding</option>
                            </select>
                        </div>

                        <div class="form-group col-md-4">

                            <label>
                                First Name
                            </label>

                            <input
                                type="text"
                                name="first_name"
                                class="form-control"
                                value="<?= e($first_name) ?>"
                                required
                            >

                        </div>

                    </div>


                    <!-- Last / Other / Gender -->

                    <div class="form-row">

                        <div class="form-group col-md-4">

                            <label>
                                Last Name
                            </label>

                            <input
                                type="text"
                                name="last_name"
                                class="form-control"
                                value="<?= e($last_name) ?>"
                                required
                            >

                        </div>


                        <div class="form-group col-md-4">

                            <label>
                                Other Names
                            </label>

                            <input
                                type="text"
                                name="other_names"
                                class="form-control"
                                value="<?= e($other_names) ?>"
                            >

                        </div>


                        <div class="form-group col-md-4">

                            <label>
                                Gender
                            </label>

                            <select
                                name="gender"
                                class="form-control"
                                required
                            >

                                <option value="">
                                    Select Gender
                                </option>


                                <option
                                    value="Male"
                                    <?= $gender === 'Male'
                                        ? 'selected'
                                        : '' ?>
                                >
                                    Male
                                </option>


                                <option
                                    value="Female"
                                    <?= $gender === 'Female'
                                        ? 'selected'
                                        : '' ?>
                                >
                                    Female
                                </option>


                                <option
                                    value="Other"
                                    <?= $gender === 'Other'
                                        ? 'selected'
                                        : '' ?>
                                >
                                    Other
                                </option>

                            </select>

                        </div>

                    </div>


                    <!-- DOB / Class / Status -->

                    <div class="form-row">

                        <div class="form-group col-md-4">

                            <label>
                                Date of Birth
                            </label>

                            <input
                                type="date"
                                name="date_of_birth"
                                class="form-control"
                                value="<?= e($date_of_birth) ?>"
                            >

                        </div>


                        <div class="form-group col-md-4">

                            <label>
                                Class
                            </label>

                            <select
                                name="class_id"
                                class="form-control"
                                required
                            >

                                <option value="">
                                    Select Class
                                </option>


                                <?php foreach ($classes as $class): ?>

                                    <option
                                        value="<?= (int)$class['id'] ?>"
                                        <?= (int)$class_id === (int)$class['id']
                                            ? 'selected'
                                            : '' ?>
                                    >

                                        <?= e($class['class_name']) ?>

                                        <?php if (!empty($class['section'])): ?>

                                            -
                                            <?= e($class['section']) ?>

                                        <?php endif; ?>

                                        (
                                        <?= e($class['academic_year']) ?>
                                        )

                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>


                        <div class="form-group col-md-4">

                            <label>
                                Status
                            </label>

                            <select
                                name="status"
                                class="form-control"
                                required
                            >

                                <option
                                    value="active"
                                    <?= $status === 'active'
                                        ? 'selected'
                                        : '' ?>
                                >
                                    Active
                                </option>


                                <option
                                    value="inactive"
                                    <?= $status === 'inactive'
                                        ? 'selected'
                                        : '' ?>
                                >
                                    Inactive
                                </option>

                            </select>

                        </div>

                    </div>


                    <!-- PHOTO -->

                    <div class="form-row">

                        <div class="form-group col-md-6">

                            <label>
                                <i class="fas fa-camera"></i>
                                Change Student Photo
                            </label>

                            <input
                                type="file"
                                name="photo"
                                class="form-control-file"
                                accept="image/jpeg,image/png,image/webp"
                            >

                            <small class="form-text text-muted">

                                JPG, PNG or WEBP.
                                Maximum 2 MB.

                            </small>

                        </div>


                        <div class="form-group col-md-6">

                            <?php if (!empty($current_photo)): ?>

                                <label>
                                    Current Photo
                                </label>

                                <br>

                                <img
                                    src="/uploads/students/<?= e($current_photo) ?>"
                                    class="student-photo"
                                    alt="Student Photo"
                                >

                            <?php else: ?>

                                <p class="text-muted">

                                    <i class="fas fa-image"></i>

                                    No student photo uploaded.

                                </p>

                            <?php endif; ?>

                        </div>

                    </div>

                </div>

            </div>


            <!-- =================================================
                 GUARDIAN INFORMATION
            ================================================== -->

            <div class="card">

                <div class="card-header">

                    <strong>
                        <i class="fas fa-user-shield text-primary"></i>
                        Guardian Information
                    </strong>

                </div>


                <div class="card-body">


                    <!-- Name / Relationship -->

                    <div class="form-row">

                        <div class="form-group col-md-6">

                            <label>
                                Guardian Full Name
                            </label>

                            <input
                                type="text"
                                name="guardian_name"
                                class="form-control"
                                value="<?= e($guardian_name) ?>"
                                required
                            >

                        </div>


                        <div class="form-group col-md-6">

                            <label>
                                Relationship
                            </label>

                            <input
                                type="text"
                                name="guardian_relationship"
                                class="form-control"
                                placeholder="Father, Mother, Uncle, etc."
                                value="<?= e($guardian_relationship) ?>"
                                required
                            >

                        </div>

                    </div>


                    <!-- Phone / NIN / Email -->

                    <div class="form-row">

                        <div class="form-group col-md-4">

                            <label>
                                Phone Number
                            </label>

                            <input
                                type="text"
                                name="guardian_phone"
                                class="form-control"
                                value="<?= e($guardian_phone) ?>"
                                required
                            >

                        </div>


                        <div class="form-group col-md-4">

                            <label>
                                NIN Number
                            </label>

                            <input
                                type="text"
                                name="guardian_nin"
                                class="form-control"
                                value="<?= e($guardian_nin) ?>"
                                required
                            >

                        </div>


                        <div class="form-group col-md-4">

                            <label>
                                Email
                            </label>

                            <input
                                type="email"
                                name="guardian_email"
                                class="form-control"
                                value="<?= e($guardian_email) ?>"
                            >

                        </div>

                    </div>


                    <!-- ADDRESS -->

                    <div class="form-group">

                        <label>
                            Address
                        </label>

                        <textarea
                            name="guardian_address"
                            class="form-control"
                            rows="3"
                        ><?= e($guardian_address) ?></textarea>

                    </div>

                </div>

            </div>


            <!-- =================================================
                 BUTTONS
            ================================================== -->

            <div class="d-flex justify-content-end mb-5">

                <a
                    href="view.php?id=<?= (int)$student_id ?>"
                    class="btn btn-secondary mr-2"
                >
                    <i class="fas fa-times"></i>
                    Cancel
                </a>


                <button
                    type="submit"
                    class="btn btn-primary"
                >
                    <i class="fas fa-save"></i>
                    Update Student
                </button>

            </div>


        </form>

    </div>

</div>


<!-- ==========================================================
     JAVASCRIPT
=========================================================== -->

<script>

    const sidebar =
        document.getElementById('sidebar');

    const sidebarToggle =
        document.getElementById('sidebarToggle');

    const menuToggle =
        document.getElementById('menuToggle');

    const sidebarClose =
        document.getElementById('sidebarClose');

    const sidebarOverlay =
        document.getElementById('sidebarOverlay');


    /*
    |--------------------------------------------------------------------------
    | DESKTOP SIDEBAR TOGGLE
    |--------------------------------------------------------------------------
    */

    if (sidebarToggle) {

        sidebarToggle.addEventListener(
            'click',
            function () {

                document.body.classList.toggle(
                    'sidebar-collapsed'
                );

            }
        );

    }


    /*
    |--------------------------------------------------------------------------
    | MOBILE MENU OPEN
    |--------------------------------------------------------------------------
    */

    if (menuToggle) {

        menuToggle.addEventListener(
            'click',
            function () {

                sidebar.classList.add(
                    'mobile-open'
                );

                sidebarOverlay.classList.add(
                    'show'
                );

            }
        );

    }


    /*
    |--------------------------------------------------------------------------
    | MOBILE MENU CLOSE
    |--------------------------------------------------------------------------
    */

    function closeMobileSidebar() {

        sidebar.classList.remove(
            'mobile-open'
        );

        sidebarOverlay.classList.remove(
            'show'
        );

    }


    if (sidebarClose) {

        sidebarClose.addEventListener(
            'click',
            closeMobileSidebar
        );

    }


    if (sidebarOverlay) {

        sidebarOverlay.addEventListener(
            'click',
            closeMobileSidebar
        );

    }


    /*
    |--------------------------------------------------------------------------
    | CLOSE ON ESCAPE
    |--------------------------------------------------------------------------
    */

    document.addEventListener(
        'keydown',
        function (event) {

            if (event.key === 'Escape') {

                closeMobileSidebar();

            }

        }
    );


    /*
    |--------------------------------------------------------------------------
    | CLOSE MOBILE MENU AFTER CLICKING LINK
    |--------------------------------------------------------------------------
    */

    document
        .querySelectorAll('.sidebar-menu a')
        .forEach(function (link) {

            link.addEventListener(
                'click',
                function () {

                    closeMobileSidebar();

                }
            );

        });

</script>


</body>
</html>