
<?php
/**
 * Delete Student
 * Path: /admin/students/delete.php
 */
error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
ini_set('log_errors', '1');
/*
*error_reporting(E_ALL);
*ini_set('display_errors', '0');
*ini_set('log_errors', '1');
*/
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Load authentication and database before producing any HTML.
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../config/database.php';

requireRole(['administrator', 'assistant_administrator']);

if (!isset($conn) || !($conn instanceof mysqli)) {
    http_response_code(500);
    exit('Database connection is unavailable.');
}

$conn->set_charset('utf8mb4');

// Escape output.
function studentDeleteEscape($value): string
{
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

// Create CSRF token.
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['csrf_token'];

$error = '';
$student = null;

// Accept student ID from GET or POST.
$studentId = filter_var(
    $_POST['id'] ?? $_GET['id'] ?? null,
    FILTER_VALIDATE_INT
);

if (!$studentId || $studentId <= 0) {
    http_response_code(400);
    exit('Invalid student ID.');
}

// Load student.
try {
    $stmt = $conn->prepare("
        SELECT
            id,
            admission_no,
            lin_no,
            student_payment_code,
            student_section,
            first_name,
            last_name,
            other_names,
            photo
        FROM students
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->bind_param("i", $studentId);
    $stmt->execute();

    $result = $stmt->get_result();
    $student = $result->fetch_assoc();

    $stmt->close();

    if (!$student) {
        http_response_code(404);
        exit('Student not found.');
    }

} catch (Throwable $ex) {
    error_log('Student delete load error: ' . $ex->getMessage());
    http_response_code(500);
    exit('Unable to load student information.');
}

// Process confirmed deletion.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $postedToken = $_POST['csrf_token'] ?? '';

    if (
        empty($postedToken) ||
        !hash_equals($csrfToken, $postedToken)
    ) {
        $error = 'Invalid security token. Refresh the page and try again.';

    } else {

        try {
            $conn->begin_transaction();

            $stmt = $conn->prepare("
                DELETE FROM students
                WHERE id = ?
                LIMIT 1
            ");

            $stmt->bind_param("i", $studentId);
            $stmt->execute();

            if ($stmt->affected_rows !== 1) {
                throw new RuntimeException(
                    'The student record could not be deleted.'
                );
            }

            $stmt->close();

            $conn->commit();

            // Delete photo only after successful database deletion.
            $photo = basename((string)($student['photo'] ?? ''));

            if ($photo !== '') {
                $photoPath = __DIR__
                    . '/../../uploads/students/'
                    . $photo;

                if (is_file($photoPath)) {
                    if (!unlink($photoPath)) {
                        error_log(
                            'Could not delete student photo: ' . $photoPath
                        );
                    }
                }
            }

            // Generate a fresh CSRF token.
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

            header('Location: list.php?deleted=1');
            exit;

        } catch (Throwable $ex) {

            try {
                $conn->rollback();
            } catch (Throwable $rollbackError) {
                error_log('Student delete rollback error: ' . $rollbackError->getMessage());
            }

            error_log('Student delete error: ' . $ex->getMessage());

            // Do not expose internal database details.
            $error = 'The student could not be deleted. This student may have '
                   . 'linked records, such as fee accounts or payment history. '
                   . 'Check the related records before trying again.';
        }
    }
}

$studentName = trim(
    ($student['first_name'] ?? '') . ' ' .
    ($student['other_names'] ?? '') . ' ' .
    ($student['last_name'] ?? '')
);

$photo = basename((string)($student['photo'] ?? ''));

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Delete Student | School Management System</title>

    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>
        body {
            background: #f4f6f9;
            font-family: Arial, sans-serif;
        }

        .main-content {
            max-width: 650px;
            margin: 70px auto;
            padding: 15px;
        }

        .delete-card {
            background: #fff;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 3px 15px rgba(0,0,0,.08);
        }

        .warning-icon {
            width: 75px;
            height: 75px;
            border-radius: 50%;
            background: #f8d7da;
            color: #dc3545;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 32px;
            margin: 0 auto 20px;
        }

        .student-photo {
            width: 75px;
            height: 75px;
            border-radius: 50%;
            object-fit: cover;
        }

        .student-details {
            background: #f8f9fa;
            padding: 18px;
            border-radius: 8px;
            margin: 20px 0;
        }
    </style>
</head>

<body>

<div class="main-content">

    <div class="delete-card">

        <div class="text-center">

            <div class="warning-icon">
                <i class="fas fa-trash-alt"></i>
            </div>

            <h3 class="text-danger font-weight-bold">
                Delete Student
            </h3>

            <p class="text-muted">
                Are you sure you want to permanently delete this student?
            </p>

        </div>

        <?php if ($error !== ''): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle mr-2"></i>
                <?= studentDeleteEscape($error) ?>
            </div>
        <?php endif; ?>

        <div class="student-details">

            <div class="d-flex align-items-center">

                <?php if ($photo !== ''): ?>
                    <img
                        src="/uploads/students/<?= rawurlencode($photo) ?>"
                        class="student-photo mr-3"
                        alt="Student photo"
                    >
                <?php else: ?>
                    <div class="student-photo mr-3 bg-secondary text-white d-flex align-items-center justify-content-center">
                        <i class="fas fa-user fa-2x"></i>
                    </div>
                <?php endif; ?>

                <div>
                    <h5 class="mb-1">
                        <?= studentDeleteEscape($studentName) ?>
                    </h5>

                    <div class="text-muted">
                        Admission No:
                        <strong><?= studentDeleteEscape($student['admission_no']) ?></strong>
                    </div>
                    <div class="text-muted">
                        LIN No.: <strong><?= studentDeleteEscape($student['lin_no'] ?? '—') ?></strong>
                        &nbsp; | &nbsp; Payment Code: <strong><?= studentDeleteEscape($student['student_payment_code'] ?? '—') ?></strong>
                        &nbsp; | &nbsp; Section: <strong><?= studentDeleteEscape($student['student_section'] ?? 'Day') ?></strong>
                    </div>
                    <div class="text-muted">
                        Student ID: <?= (int)$student['id'] ?>
                    </div>
                </div>

            </div>

        </div>

        <div class="alert alert-warning">
            <strong>Warning:</strong>
            Deleting this student may be blocked if financial or other
            records are linked to the student. Guardian records are
            not deleted by this page.
        </div>

        <form method="POST" action="delete.php?id=<?= (int)$studentId ?>">

            <input type="hidden" name="id"
                   value="<?= (int)$studentId ?>">

            <input type="hidden" name="csrf_token"
                   value="<?= studentDeleteEscape($csrfToken) ?>">

            <div class="d-flex justify-content-between flex-wrap">

                <a href="list.php" class="btn btn-secondary mb-2">
                    <i class="fas fa-arrow-left mr-1"></i>
                    Cancel
                </a>

                <button
                    type="submit"
                    class="btn btn-danger mb-2"
                    onclick="return confirm('Are you absolutely sure you want to delete this student?');"
                >
                    <i class="fas fa-trash-alt mr-1"></i>
                    Confirm Delete
                </button>

            </div>

        </form>

    </div>

    <div class="text-center text-muted mt-3 small">
        School Management System
    </div>

</div>

</body>
</html>
