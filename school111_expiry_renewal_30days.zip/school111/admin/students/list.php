<?php

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../config/database.php';

requireRole(['administrator', 'assistant_administrator']);

if (!isset($conn) || !($conn instanceof mysqli)) {
    die("ERROR: The database connection variable \$conn is missing or is not MySQLi.");
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    http_response_code(500);
    exit('Database connection is unavailable.');
}

$conn->set_charset('utf8mb4');

function e($value): string
{
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

/**
 * Get actual column names from a database table.
 */
function getTableColumns(mysqli $db, string $table): array
{
    $allowedTables = ['students', 'classes', 'guardians'];

    if (!in_array($table, $allowedTables, true)) {
        return [];
    }

    $columns = [];
    $result = $db->query("SHOW COLUMNS FROM `$table`");

    while ($row = $result->fetch_assoc()) {
        $columns[strtolower($row['Field'])] = $row['Field'];
    }

    $result->free();

    return $columns;
}

/**
 * Safely bind a dynamic number of parameters.
 */
function bindDynamic(mysqli_stmt $stmt, string $types, array $params): void
{
    if ($types === '' || !$params) {
        return;
    }

    $references = [];
    $references[] = &$types;

    foreach ($params as $key => $value) {
        $references[] = &$params[$key];
    }

    call_user_func_array([$stmt, 'bind_param'], $references);
}

$students = [];
$pageError = '';
$search = trim((string)($_GET['search'] ?? ''));

try {
    $studentColumns = getTableColumns($conn, 'students');
    $classColumns = getTableColumns($conn, 'classes');

    // Detect the actual guardian column names.
    $guardianColumns = [];

    try {
        $guardianColumns = getTableColumns($conn, 'guardians');
    } catch (Throwable $e) {
        error_log('Student list guardian schema: ' . $e->getMessage());
    }

    // Required student columns.
    $requiredStudentColumns = [
        'id',
        'admission_no',
        'first_name',
        'last_name',
        'class_id'
    ];

    foreach ($requiredStudentColumns as $column) {
        if (!isset($studentColumns[$column])) {
            throw new RuntimeException(
                "The students table is missing the required column: $column"
            );
        }
    }

    // Determine guardian name and phone columns.
    $guardianNameColumn = null;
    $guardianPhoneColumn = null;

    foreach (['guardian_name', 'full_name', 'name'] as $candidate) {
        if (isset($guardianColumns[$candidate])) {
            $guardianNameColumn = $guardianColumns[$candidate];
            break;
        }
    }

    foreach (['guardian_phone', 'phone', 'phone_number', 'telephone'] as $candidate) {
        if (isset($guardianColumns[$candidate])) {
            $guardianPhoneColumn = $guardianColumns[$candidate];
            break;
        }
    }

    $hasGuardianId = isset($studentColumns['guardian_id'])
        && isset($guardianColumns['id']);

    $guardianJoin = '';
    $guardianNameSelect = "''";
    $guardianPhoneSelect = "''";

    if ($hasGuardianId) {
        $guardianJoin = ' LEFT JOIN guardians g ON g.id = s.guardian_id ';

        if ($guardianNameColumn) {
            $guardianNameSelect = "COALESCE(g.`$guardianNameColumn`, '')";
        }

        if ($guardianPhoneColumn) {
            $guardianPhoneSelect = "COALESCE(g.`$guardianPhoneColumn`, '')";
        }
    }

    // Class information.
    $classJoin = '';
    $classNameSelect = "'Not assigned'";
    $sectionSelect = "''";
    $academicYearSelect = "''";

    if (isset($classColumns['id'])) {
        $classJoin = ' LEFT JOIN classes c ON c.id = s.class_id ';

        if (isset($classColumns['class_name'])) {
            $classNameSelect = "COALESCE(c.class_name, 'Not assigned')";
        }

        if (isset($classColumns['section'])) {
            $sectionSelect = "COALESCE(c.section, '')";
        }

        if (isset($classColumns['academic_year'])) {
            $academicYearSelect = "COALESCE(c.academic_year, '')";
        }
    }

    // Optional student fields.
    $linSelect = isset($studentColumns['lin_no'])
        ? "COALESCE(s.lin_no, '')"
        : "''";

    $paymentCodeSelect = isset($studentColumns['student_payment_code'])
        ? "COALESCE(s.student_payment_code, '')"
        : "''";

    $studentSectionSelect = isset($studentColumns['student_section'])
        ? "COALESCE(s.student_section, 'Day')"
        : "'Day'";

    $genderSelect = isset($studentColumns['gender'])
        ? "COALESCE(s.gender, '')"
        : "''";

    $photoSelect = isset($studentColumns['photo'])
        ? "COALESCE(s.photo, '')"
        : "''";

    $statusSelect = isset($studentColumns['status'])
        ? "COALESCE(s.status, 'active')"
        : "'active'";

    $otherNamesSelect = isset($studentColumns['other_names'])
        ? "COALESCE(s.other_names, '')"
        : "''";

    // Build search conditions.
    $searchConditions = [];
    $params = [];
    $types = '';

    if ($search !== '') {
        $searchableColumns = [
            'admission_no' => 's.admission_no',
            'lin_no' => isset($studentColumns['lin_no']) ? 's.lin_no' : null,
            'student_payment_code' => isset($studentColumns['student_payment_code']) ? 's.student_payment_code' : null,
            'first_name' => 's.first_name',
            'last_name' => 's.last_name',
            'other_names' => isset($studentColumns['other_names'])
                ? 's.other_names'
                : null
        ];

        foreach ($searchableColumns as $column => $expression) {
            if ($expression !== null) {
                $searchConditions[] = "$expression LIKE ?";
                $params[] = '%' . $search . '%';
                $types .= 's';
            }
        }

        if ($hasGuardianId && $guardianNameColumn) {
            $searchConditions[] = "g.`$guardianNameColumn` LIKE ?";
            $params[] = '%' . $search . '%';
            $types .= 's';
        }
    }

    $whereSql = '';

    if ($searchConditions) {
        $whereSql = ' WHERE (' . implode(' OR ', $searchConditions) . ')';
    }

    $sql = "
        SELECT
            s.id,
            s.admission_no,
            $linSelect AS lin_no,
            $paymentCodeSelect AS student_payment_code,
            $studentSectionSelect AS student_section,
            s.first_name,
            s.last_name,
            $otherNamesSelect AS other_names,
            $genderSelect AS gender,
            $photoSelect AS photo,
            $statusSelect AS status,
            $classNameSelect AS class_name,
            $sectionSelect AS section,
            $academicYearSelect AS academic_year,
            $guardianNameSelect AS guardian_name,
            $guardianPhoneSelect AS guardian_phone

        FROM students s

        $classJoin
        $guardianJoin

        $whereSql

        ORDER BY s.id DESC
    ";

    $stmt = $conn->prepare($sql);

    bindDynamic($stmt, $types, $params);

    $stmt->execute();

    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $students[] = $row;
    }

    $stmt->close();

} catch (Throwable $ex) {
    $pageError = 'Unable to load student records. Please check the database structure and PHP error log.';
    error_log('Student list error: ' . $ex->getMessage());
}

$fullName = $_SESSION['full_name']
    ?? $_SESSION['username']
    ?? 'Administrator';

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Students | School Management System</title>

<link rel="stylesheet"
href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: #f4f6f9;
    font-family: Arial, Helvetica, sans-serif;
    color: #343a40;
}

.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    width: 250px;
    background: #212529;
    color: #fff;
    overflow-y: auto;
    z-index: 1050;
    transition: left .25s ease;
}

.sidebar-header {
    padding: 22px 15px;
    background: #171a1d;
    text-align: center;
    font-weight: bold;
    font-size: 17px;
}

.sidebar-section {
    padding: 17px 15px 7px;
    color: #89929b;
    font-size: 11px;
    text-transform: uppercase;
    font-weight: bold;
}

.sidebar a {
    display: block;
    color: #ced4da;
    padding: 12px 17px;
    margin: 3px 10px;
    border-radius: 6px;
    text-decoration: none;
    font-size: 14px;
}

.sidebar a i {
    width: 23px;
}

.sidebar a:hover,
.sidebar a.active {
    background: #dc3545;
    color: #fff;
}

.main {
    margin-left: 250px;
    min-height: 100vh;
}

.topbar {
    background: #fff;
    min-height: 65px;
    padding: 15px 25px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-shadow: 0 2px 8px rgba(0,0,0,.06);
}

.content {
    padding: 25px;
}

.page-heading {
    margin-bottom: 22px;
}

.page-heading h3 {
    font-weight: 700;
    color: #343a40;
}

.panel {
    background: #fff;
    padding: 22px;
    border-radius: 9px;
    box-shadow: 0 2px 12px rgba(0,0,0,.05);
    margin-bottom: 22px;
}

.student-photo {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid #e9ecef;
}

.photo-placeholder {
    width: 42px;
    height: 42px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background: #e9ecef;
    color: #6c757d;
}

.table td,
.table th {
    vertical-align: middle;
    font-size: 13px;
}

.table thead th {
    background: #f8f9fa;
    white-space: nowrap;
}

.mobile-menu {
    display: none;
}

.sidebar-overlay {
    display: none;
}

@media(max-width: 991px) {
    .sidebar {
        left: -260px;
    }

    .sidebar.show {
        left: 0;
    }

    .main {
        margin-left: 0;
    }

    .mobile-menu {
        display: inline-block;
    }

    .content {
        padding: 15px;
    }

    .topbar {
        padding: 12px 15px;
    }

    .sidebar-overlay.show {
        display: block;
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,.45);
        z-index: 1040;
    }
}

@media print {
    .sidebar,
    .topbar,
    .no-print {
        display: none !important;
    }

    .main {
        margin: 0;
    }

    .content {
        padding: 0;
    }

    body {
        background: #fff;
    }
}
</style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>

<body>

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<!-- SIDEBAR -->
<aside class="sidebar" id="sidebar">

    <div class="sidebar-header">
        <i class="fas fa-school mr-2"></i>
        School Management
        <br>
        <small class="text-muted">Administration Panel</small>
    </div>

    <div class="sidebar-section">Main</div>

    <a href="/admin/dashboard.php">
        <i class="fas fa-tachometer-alt"></i> Dashboard
    </a>

    <div class="sidebar-section">School Management</div>

    <a href="/admin/classes/index.php">
        <i class="fas fa-chalkboard"></i> Classes
    </a>

    <a href="/admin/students/list.php" class="active">
        <i class="fas fa-user-graduate"></i> Students
    </a>

    <a href="/admin/teachers/index.php">
        <i class="fas fa-chalkboard-teacher"></i> Teachers
    </a>

    <a href="/admin/staff/index.php">
        <i class="fas fa-users"></i> Other Staff Members
    </a>

    <a href="/admin/assets/index.php">
        <i class="fas fa-boxes"></i> Assets
    </a>

    <a href="/admin/projects/index.php">
        <i class="fas fa-project-diagram"></i> School Projects
    </a>

    <div class="sidebar-section">Finance</div>

    <a href="/bursar/dashboard.php">
        <i class="fas fa-wallet"></i> Bursar
    </a>

    <div class="sidebar-section">System</div>

    <a href="/admin/users/index.php">
        <i class="fas fa-user-cog"></i> Users
    </a>

    <a href="/logout.php">
        <i class="fas fa-sign-out-alt"></i> Logout
    </a>

</aside>

<!-- MAIN CONTENT -->
<main class="main">

    <div class="topbar">

        <div>
            <button
                type="button"
                class="btn btn-dark mobile-menu mr-2"
                id="mobileMenuBtn"
                aria-label="Open menu">

                <i class="fas fa-bars"></i>

            </button>

            <strong>
                <i class="fas fa-user-graduate text-danger mr-2"></i>
                Student Management
            </strong>
        </div>

        <div class="text-muted small">
            <i class="fas fa-user-circle mr-1"></i>
            <?= e($fullName) ?>
        </div>

    </div>

    <div class="content">

        <div class="page-heading d-flex justify-content-between align-items-center flex-wrap">

            <div>
                <h3>
                    <i class="fas fa-users text-danger mr-2"></i>
                    Students
                </h3>

                <div class="text-muted">
                    Register, view, search and manage student records.
                </div>
            </div>

            <div class="mt-2 no-print">

                <a href="register.php" class="btn btn-danger">
                    <i class="fas fa-plus-circle mr-1"></i>
                    Register Student
                </a>

            </div>

        </div>

        <?php if ($pageError !== ''): ?>

            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle mr-2"></i>
                <?= e($pageError) ?>
            </div>

        <?php endif; ?>

        <?php if (isset($_GET['deleted']) && $_GET['deleted'] === '1'): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle mr-2"></i>
                Student record deleted successfully.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <section class="panel">

            <div class="d-flex justify-content-between align-items-center flex-wrap mb-3">

                <h5 class="mb-2">
                    <i class="fas fa-list text-danger mr-2"></i>
                    Student Records
                </h5>

                <span class="badge badge-primary p-2">
                    <?= count($students) ?> Students Found
                </span>

            </div>

            <!-- SEARCH -->
            <form method="GET" action="list.php" class="form-row align-items-end no-print">

                <div class="form-group col-md-6">

                    <label for="search">
                        Search Students
                    </label>

                    <input
                        type="search"
                        name="search"
                        id="search"
                        class="form-control"
                        value="<?= e($search) ?>"
                        placeholder="Admission No., LIN No., Student Payment Code, name or guardian..."
                    >

                </div>

                <div class="form-group col-md-3">

                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search mr-1"></i>
                        Search
                    </button>

                    <a href="list.php" class="btn btn-outline-secondary">
                        Reset
                    </a>

                </div>

                <div class="form-group col-md-3 text-md-right">

                    <button
                        type="button"
                        onclick="window.print()"
                        class="btn btn-outline-dark">

                        <i class="fas fa-print mr-1"></i>
                        Print List

                    </button>

                </div>

            </form>

            <div class="table-responsive">

                <table class="table table-bordered table-hover">

                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Photo</th>
                            <th>Admission No.</th>
                            <th>LIN No.</th>
                            <th>Student Payment Code</th>
                            <th>Student Section</th>
                            <th>Student Name</th>
                            <th>Gender</th>
                            <th>Class</th>
                            <th>Academic Year</th>
                            <th>Guardian</th>
                            <th>Guardian Phone</th>
                            <th>Status</th>
                            <th class="no-print">Actions</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php if (!$students): ?>

                        <tr>
                            <td colspan="14" class="text-center text-muted py-4">

                                <i class="fas fa-user-graduate fa-2x mb-2"></i>

                                <br>

                                <?php if ($search !== ''): ?>
                                    No students matched your search.
                                <?php else: ?>
                                    No student records found.
                                <?php endif; ?>

                            </td>
                        </tr>

                    <?php else: ?>

                        <?php foreach ($students as $index => $student): ?>

                            <?php
                            $photo = trim((string)$student['photo']);

                            // Only allow a filename, not a path supplied by the database.
                            $photo = basename($photo);

                            $photoPath = '../../uploads/students/' . rawurlencode($photo);

                            $studentName = trim(
                                $student['first_name'] . ' ' .
                                $student['other_names'] . ' ' .
                                $student['last_name']
                            );

                            $status = strtolower(trim((string)$student['status']));
                            ?>

                            <tr>

                                <td><?= $index + 1 ?></td>

                                <td>

                                    <?php if ($photo !== ''): ?>

                                        <img
                                            src="<?= e($photoPath) ?>"
                                            alt="Student photo"
                                            class="student-photo"
                                            loading="lazy"
                                            onerror="this.style.display='none';this.nextElementSibling.style.display='inline-flex';"
                                        >

                                        <span
                                            class="photo-placeholder"
                                            style="display:none;">

                                            <i class="fas fa-user"></i>

                                        </span>

                                    <?php else: ?>

                                        <span class="photo-placeholder">
                                            <i class="fas fa-user"></i>
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <td>
                                    <strong><?= e($student['admission_no']) ?></strong>
                                </td>

                                <td>
                                    <?= e($student['lin_no'] ?: '—') ?>
                                </td>

                                <td>
                                    <?= e($student['student_payment_code'] ?: '—') ?>
                                </td>

                                <td>
                                    <span class="badge badge-<?= ($student['student_section'] ?? 'Day') === 'Boarding' ? 'info' : 'secondary' ?>">
                                        <?= e($student['student_section'] ?? 'Day') ?>
                                    </span>
                                </td>

                                <td>
                                    <strong><?= e($studentName) ?></strong>
                                </td>

                                <td>
                                    <?= e($student['gender'] ?: '—') ?>
                                </td>

                                <td>
                                    <?= e($student['class_name']) ?>

                                    <?php if ($student['section'] !== ''): ?>
                                        <br>
                                        <small class="text-muted">
                                            <?= e($student['section']) ?>
                                        </small>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?= e($student['academic_year'] ?: '—') ?>
                                </td>

                                <td>
                                    <?= e($student['guardian_name'] ?: '—') ?>
                                </td>

                                <td>
                                    <?= e($student['guardian_phone'] ?: '—') ?>
                                </td>

                                <td>

                                    <?php if ($status === 'active'): ?>

                                        <span class="badge badge-success">
                                            Active
                                        </span>

                                    <?php else: ?>

                                        <span class="badge badge-secondary">
                                            <?= e(ucfirst($status ?: 'Unknown')) ?>
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <td class="no-print text-nowrap">

                                    <a
                                        href="view.php?id=<?= (int)$student['id'] ?>"
                                        class="btn btn-sm btn-outline-primary"
                                        title="View student">

                                        <i class="fas fa-eye"></i>

                                    </a>

                                    <a
                                        href="edit.php?id=<?= (int)$student['id'] ?>"
                                        class="btn btn-sm btn-outline-success"
                                        title="Edit student">

                                        <i class="fas fa-edit"></i>

                                    </a>

                                    <a
                                        href="delete.php?id=<?= (int)$student['id'] ?>"
                                        class="btn btn-sm btn-outline-danger"
                                        title="Delete student">

                                        <i class="fas fa-trash-alt"></i>

                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

            <div class="small text-muted mt-3">
                School Management System &mdash; Student Records
            </div>

        </section>

    </div>

</main>

<script>
(function () {

    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    const menuButton = document.getElementById('mobileMenuBtn');

    function openMenu() {
        sidebar.classList.add('show');
        overlay.classList.add('show');
    }

    function closeMenu() {
        sidebar.classList.remove('show');
        overlay.classList.remove('show');
    }

    if (menuButton) {
        menuButton.addEventListener('click', function () {

            if (sidebar.classList.contains('show')) {
                closeMenu();
            } else {
                openMenu();
            }

        });
    }

    if (overlay) {
        overlay.addEventListener('click', closeMenu);
    }

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            closeMenu();
        }
    });

    window.addEventListener('resize', function () {
        if (window.innerWidth > 991) {
            closeMenu();
        }
    });

})();
</script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
