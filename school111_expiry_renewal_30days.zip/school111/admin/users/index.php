<?php

require_once "../../config/database.php";
require_once "../../includes/auth.php";

requireRole([
    'administrator'
]);

/* ==========================================================
   ESCAPE FUNCTION
========================================================== */

function e($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}


/* ==========================================================
   SUCCESS / ERROR MESSAGES
========================================================== */

$success = trim($_GET['success'] ?? '');
$error   = trim($_GET['error'] ?? '');


/* ==========================================================
   SEARCH
========================================================== */

$search = trim($_GET['search'] ?? '');


/* ==========================================================
   BUILD QUERY
========================================================== */

$sql = "
    SELECT
        id,
        username,
        full_name,
        role,
        status,
        created_at,
        expires_at
    FROM users
";

$params = [];
$types = '';

if ($search !== '') {

    $sql .= "
        WHERE
            username LIKE ?
            OR full_name LIKE ?
            OR role LIKE ?
    ";

    $searchValue = '%' . $search . '%';

    $params[] = $searchValue;
    $params[] = $searchValue;
    $params[] = $searchValue;

    $types = 'sss';
}

$sql .= "
    ORDER BY id DESC
";


/* ==========================================================
   PREPARE QUERY
========================================================== */

$stmt = $conn->prepare($sql);

if (!$stmt) {

    exit(
        "Failed to prepare users query: " .
        $conn->error
    );
}


/* ==========================================================
   BIND SEARCH PARAMETERS
========================================================== */

if (!empty($params)) {

    $stmt->bind_param(
        $types,
        ...$params
    );
}


/* ==========================================================
   EXECUTE QUERY
========================================================== */

$stmt->execute();

$result = $stmt->get_result();

$users = [];

while ($row = $result->fetch_assoc()) {

    $users[] = $row;
}

$stmt->close();


/* ==========================================================
   CURRENT LOGGED-IN USER
========================================================== */

$currentUserId = (int)($_SESSION['user_id'] ?? 0);

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        System Users - School Management System
    </title>

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
    >

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
    >

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: #f4f6f9;
            font-family: Arial, sans-serif;
        }


        /* ==================================================
           SIDEBAR
        ================================================== */

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100vh;
            background: #343a40;
            color: white;
            transition: all .3s ease;
            z-index: 1050;
            overflow-y: auto;
        }

        .sidebar-header {
            height: 65px;
            display: flex;
            align-items: center;
            padding: 0 20px;
            background: #212529;
            font-size: 18px;
            font-weight: bold;
        }

        .sidebar-header i {
            margin-right: 10px;
        }

        .sidebar-menu {
            list-style: none;
            padding: 15px 0;
            margin: 0;
        }

        .sidebar-menu li {
            margin: 2px 10px;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            color: #ced4da;
            text-decoration: none;
            border-radius: 5px;
        }

        .sidebar-menu a:hover {
            background: #495057;
            color: white;
        }

        .sidebar-menu a.active {
            background: #007bff;
            color: white;
        }

        .sidebar-menu i {
            width: 25px;
            margin-right: 10px;
            text-align: center;
        }


        /* ==================================================
           MAIN CONTENT
        ================================================== */

        .main-content {
            margin-left: 250px;
            min-height: 100vh;
            transition: all .3s ease;
        }

        .topbar {
            height: 65px;
            background: white;
            border-bottom: 1px solid #dee2e6;
            display: flex;
            align-items: center;
            padding: 0 25px;
        }

        .sidebar-toggle {
            border: none;
            background: none;
            font-size: 22px;
            cursor: pointer;
            margin-right: 15px;
            color: #343a40;
        }

        .page-title {
            margin: 0;
            font-size: 22px;
            font-weight: 600;
        }

        .content {
            padding: 25px;
        }


        /* ==================================================
           CARDS
        ================================================== */

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,.06);
        }

        .card-header {
            background: white;
            border-bottom: 1px solid #eee;
            padding: 18px 20px;
            font-weight: 600;
        }


        /* ==================================================
           USER AVATAR
        ================================================== */

        .user-avatar {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: #007bff;
            color: white;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-right: 10px;
        }

        .user-name {
            font-weight: 600;
        }

        .user-username {
            font-size: 13px;
            color: #6c757d;
        }


        /* ==================================================
           BADGES
        ================================================== */

        .role-badge {
            padding: 7px 10px;
            border-radius: 20px;
            font-size: 12px;
        }

        .status-badge {
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 12px;
        }


        /* ==================================================
           PAGE ACTIONS
        ================================================== */

        .page-actions {
            display: flex;
            gap: 8px;
        }

        .page-actions .btn {
            border-radius: 6px;
        }


        /* ==================================================
           MOBILE
        ================================================== */

        .mobile-topbar {
            display: none;
        }

        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,.5);
            z-index: 1040;
        }


        /* ==================================================
           COLLAPSED SIDEBAR
        ================================================== */

        .sidebar.collapsed {
            width: 75px;
        }

        .sidebar.collapsed .sidebar-header span,
        .sidebar.collapsed .sidebar-menu span {
            display: none;
        }

        .sidebar.collapsed .sidebar-header {
            justify-content: center;
            padding: 0;
        }

        .sidebar.collapsed .sidebar-header i {
            margin: 0;
        }

        .sidebar.collapsed .sidebar-menu a {
            justify-content: center;
            padding: 12px 0;
        }

        .sidebar.collapsed .sidebar-menu i {
            margin: 0;
        }

        .main-content.expanded {
            margin-left: 75px;
        }


        /* ==================================================
           RESPONSIVE
        ================================================== */

        @media (max-width: 767px) {

            .sidebar {
                left: -250px;
                width: 250px;
            }

            .sidebar.mobile-open {
                left: 0;
            }

            .main-content {
                margin-left: 0;
            }

            .topbar {
                display: none;
            }

            .mobile-topbar {
                display: flex;
                height: 60px;
                background: #343a40;
                color: white;
                align-items: center;
                padding: 0 15px;
            }

            .mobile-menu-button {
                border: none;
                background: none;
                color: white;
                font-size: 22px;
                margin-right: 15px;
            }

            .content {
                padding: 15px;
            }

            .table-responsive {
                border-radius: 8px;
            }

            .page-actions {
                width: 100%;
                margin-top: 15px;
            }

            .page-actions .btn {
                width: 100%;
            }

            .sidebar-overlay.active {
                display: block;
            }

            .action-buttons {
                min-width: 100px;
            }

        }

    </style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>

<body>


<!-- ==========================================================
     SIDEBAR
=========================================================== -->

<div
    class="sidebar"
    id="sidebar"
>

    <div class="sidebar-header">

        <i class="fas fa-school"></i>

        <span>
            School System
        </span>

    </div>


    <ul class="sidebar-menu">

        <!-- Dashboard -->

        <li>

            <a href="/admin/dashboard.php">

                <i class="fas fa-tachometer-alt"></i>

                <span>
                    Dashboard
                </span>

            </a>

        </li>


        <!-- Classes -->

        <li>

            <a href="/admin/classes/index.php">

                <i class="fas fa-chalkboard"></i>

                <span>
                    Classes
                </span>

            </a>

        </li>


        <!-- Students -->

        <li>

            <a href="/admin/students/list.php">

                <i class="fas fa-user-graduate"></i>

                <span>
                    Students
                </span>

            </a>

        </li>


        <!-- Teachers -->

        <li>

            <a href="/admin/teachers/index.php">

                <i class="fas fa-chalkboard-teacher"></i>

                <span>
                    Teachers
                </span>

            </a>

        </li>


        <!-- Bursar -->

        <li>

            <a href="/admin/bursar/index.php">

                <i class="fas fa-money-bill-wave"></i>

                <span>
                    Bursar
                </span>

            </a>

        </li>


        <!-- Assets -->

        <li>

            <a href="/admin/assets/index.php">

                <i class="fas fa-boxes"></i>

                <span>
                    Assets
                </span>

            </a>

        </li>


        <!-- Other Staff -->

        <li>

            <a href="/admin/staff/index.php">

                <i class="fas fa-users"></i>

                <span>
                    Other Staff
                </span>

            </a>

        </li>


        <!-- School Projects -->

        <li>

            <a href="/admin/projects/index.php">

                <i class="fas fa-project-diagram"></i>

                <span>
                    School Projects
                </span>

            </a>

        </li>


        <!-- Users -->

        <li>

            <a
                href="/admin/users/index.php"
                class="active"
            >

                <i class="fas fa-user-cog"></i>

                <span>
                    Users
                </span>

            </a>

        </li>


        <!-- Logout -->

        <li>

            <a href="/logout.php">

                <i class="fas fa-sign-out-alt"></i>

                <span>
                    Logout
                </span>

            </a>

        </li>

    </ul>

</div>


<div
    class="sidebar-overlay"
    id="sidebarOverlay"
></div>


<!-- ==========================================================
     MAIN CONTENT
=========================================================== -->

<div
    class="main-content"
    id="mainContent"
>


    <!-- DESKTOP TOPBAR -->

    <div class="topbar">

        <button
            class="sidebar-toggle"
            id="sidebarToggle"
            type="button"
        >

            <i class="fas fa-bars"></i>

        </button>


        <h1 class="page-title">

            System Users

        </h1>

    </div>


    <!-- MOBILE TOPBAR -->

    <div class="mobile-topbar">

        <button
            class="mobile-menu-button"
            id="mobileMenuButton"
            type="button"
        >

            <i class="fas fa-bars"></i>

        </button>

        <strong>
            System Users
        </strong>

    </div>


    <!-- CONTENT -->

    <div class="content">


        <!-- ==================================================
             PAGE HEADER
        =================================================== -->

        <div
            class="d-flex flex-wrap justify-content-between align-items-center mb-4"
        >

            <div>

                <h2 class="mb-1">

                    <i class="fas fa-users-cog text-primary"></i>

                    System Users

                </h2>

                <p class="text-muted mb-0">

                    Manage users who have access to the school
                    management system.

                </p>

            </div>


            <!-- CREATE USER BUTTON -->

            <div class="page-actions">

                <a
                    href="create.php"
                    class="btn btn-primary"
                >

                    <i class="fas fa-user-plus"></i>

                    Create User

                </a>

            </div>

        </div>


        <!-- ==================================================
             SUCCESS MESSAGE
        =================================================== -->

        <?php if ($success !== ''): ?>

            <div
                class="alert alert-success alert-dismissible fade show"
            >

                <i class="fas fa-check-circle"></i>

                <?= e($success) ?>

                <button
                    type="button"
                    class="close"
                    data-dismiss="alert"
                >

                    <span>
                        &times;
                    </span>

                </button>

            </div>

        <?php endif; ?>


        <!-- ==================================================
             ERROR MESSAGE
        =================================================== -->

        <?php if ($error !== ''): ?>

            <div
                class="alert alert-danger alert-dismissible fade show"
            >

                <i class="fas fa-exclamation-circle"></i>

                <?= e($error) ?>

                <button
                    type="button"
                    class="close"
                    data-dismiss="alert"
                >

                    <span>
                        &times;
                    </span>

                </button>

            </div>

        <?php endif; ?>


        <!-- ==================================================
             SEARCH
        =================================================== -->

        <div class="card mb-4">

            <div class="card-body">

                <form
                    method="GET"
                    action="index.php"
                >

                    <div class="form-row align-items-end">

                        <div class="form-group col-md-10 mb-md-0">

                            <label>
                                Search Users
                            </label>

                            <input
                                type="text"
                                name="search"
                                class="form-control"
                                placeholder="Search by username, full name or role..."
                                value="<?= e($search) ?>"
                            >

                        </div>


                        <div class="form-group col-md-2 mb-0">

                            <button
                                type="submit"
                                class="btn btn-primary btn-block"
                            >

                                <i class="fas fa-search"></i>

                                Search

                            </button>

                        </div>

                    </div>

                </form>

            </div>

        </div>


        <!-- ==================================================
             USERS TABLE
        =================================================== -->

        <div class="card">

            <div class="card-header">

                <div
                    class="d-flex justify-content-between align-items-center"
                >

                    <span>

                        <i class="fas fa-users-cog mr-2"></i>

                        Registered Users

                    </span>


                    <span class="badge badge-primary">

                        <?= count($users) ?>

                        User<?= count($users) === 1 ? '' : 's' ?>

                    </span>

                </div>

            </div>


            <div class="card-body p-0">

                <div class="table-responsive">

                    <table class="table table-hover mb-0">

                        <thead class="thead-light">

                            <tr>

                                <th>
                                    #
                                </th>

                                <th>
                                    User
                                </th>

                                <th>
                                    Username
                                </th>

                                <th>
                                    Role
                                </th>

                                <th>
                                    Status
                                </th>

                                <th>
                                    Created
                                </th>

                                <th>
                                    Expires
                                </th>

                                <th class="text-right">
                                    Actions
                                </th>

                            </tr>

                        </thead>


                        <tbody>


                        <?php if (empty($users)): ?>

                            <tr>

                                <td
                                    colspan="8"
                                    class="text-center py-5"
                                >

                                    <i
                                        class="fas fa-users fa-3x text-muted mb-3"
                                    ></i>

                                    <h5>
                                        No users found
                                    </h5>

                                    <p class="text-muted mb-0">

                                        No system users match your
                                        search.

                                    </p>

                                </td>

                            </tr>


                        <?php else: ?>


                            <?php foreach ($users as $index => $user): ?>

                                <?php

                                /* --------------------------------
                                   USER INITIALS
                                --------------------------------- */

                                $nameParts = preg_split(
                                    '/\s+/',
                                    trim($user['full_name'])
                                );

                                $initials = '';

                                if (!empty($nameParts[0])) {

                                    $initials .= strtoupper(
                                        substr(
                                            $nameParts[0],
                                            0,
                                            1
                                        )
                                    );
                                }

                                if (
                                    count($nameParts) > 1 &&
                                    !empty($nameParts[count($nameParts) - 1])
                                ) {

                                    $initials .= strtoupper(
                                        substr(
                                            $nameParts[
                                                count($nameParts) - 1
                                            ],
                                            0,
                                            1
                                        )
                                    );
                                }

                                if ($initials === '') {
                                    $initials = 'U';
                                }


                                /* --------------------------------
                                   ROLE LABELS
                                --------------------------------- */

                                $roleLabels = [

                                    'administrator' =>
                                        'Administrator',

                                    'assistant_administrator' =>
                                        'Assistant Administrator',

                                    'bursar' =>
                                        'Bursar',

                                    'teacher' =>
                                        'Teacher'

                                ];


                                $roleLabel =
                                    $roleLabels[
                                        $user['role']
                                    ]
                                    ??
                                    ucfirst(
                                        str_replace(
                                            '_',
                                            ' ',
                                            $user['role']
                                        )
                                    );


                                /* --------------------------------
                                   CREATED DATE
                                --------------------------------- */

                                $createdTimestamp =
                                    strtotime(
                                        $user['created_at']
                                    );

                                ?>

                                <tr>


                                    <!-- NUMBER -->

                                    <td>

                                        <?= $index + 1 ?>

                                    </td>


                                    <!-- USER -->

                                    <td>

                                        <div
                                            class="d-flex align-items-center"
                                        >

                                            <div class="user-avatar">

                                                <?= e($initials) ?>

                                            </div>


                                            <div>

                                                <div class="user-name">

                                                    <?= e(
                                                        $user['full_name']
                                                    ) ?>

                                                </div>


                                                <?php if (
                                                    (int)$user['id']
                                                    ===
                                                    $currentUserId
                                                ): ?>

                                                    <span
                                                        class="badge badge-info"
                                                    >

                                                        You

                                                    </span>

                                                <?php endif; ?>

                                            </div>

                                        </div>

                                    </td>


                                    <!-- USERNAME -->

                                    <td>

                                        <i
                                            class="fas fa-user mr-1 text-muted"
                                        ></i>

                                        <?= e(
                                            $user['username']
                                        ) ?>

                                    </td>


                                    <!-- ROLE -->

                                    <td>

                                        <span
                                            class="badge badge-primary role-badge"
                                        >

                                            <?= e(
                                                $roleLabel
                                            ) ?>

                                        </span>

                                    </td>


                                    <!-- STATUS -->

                                    <td>

                                        <?php if (
                                            $user['status']
                                            ===
                                            'active'
                                        ): ?>

                                            <span
                                                class="badge badge-success status-badge"
                                            >

                                                <i
                                                    class="fas fa-check-circle"
                                                ></i>

                                                Active

                                            </span>

                                        <?php else: ?>

                                            <span
                                                class="badge badge-secondary status-badge"
                                            >

                                                <i
                                                    class="fas fa-times-circle"
                                                ></i>

                                                Inactive

                                            </span>

                                        <?php endif; ?>

                                    </td>


                                    <!-- CREATED -->

                                    <td>

                                        <?php

                                        echo $createdTimestamp
                                            ? e(
                                                date(
                                                    'd M Y',
                                                    $createdTimestamp
                                                )
                                            )
                                            : '—';

                                        ?>

                                    </td>


                                    <!-- ACCOUNT EXPIRY -->
                                    <td>
                                        <?php
                                        $isExemptAdmin = ((int)$user['id'] === 1 && $user['username'] === 'admin');
                                        if ($isExemptAdmin):
                                        ?>
                                            <span class="badge badge-success">Never expires</span>
                                        <?php elseif (!empty($user['expires_at']) && strtotime($user['expires_at']) > time()): ?>
                                            <span class="text-success"><?= e(date('d M Y', strtotime($user['expires_at']))) ?></span>
                                        <?php elseif (!empty($user['expires_at'])): ?>
                                            <span class="badge badge-danger">Expired</span>
                                            <small class="d-block text-muted"><?= e(date('d M Y', strtotime($user['expires_at']))) ?></small>
                                        <?php else: ?>
                                            <span class="badge badge-warning">Not set</span>
                                        <?php endif; ?>
                                    </td>

                                    <!-- ACTIONS -->

                                    <td class="text-right action-buttons">


                                        <!-- EDIT BUTTON -->

                                        <a
                                            href="edit.php?id=<?= (int)$user['id'] ?>"
                                            class="btn btn-sm btn-primary"
                                            title="Edit User"
                                        >

                                            <i class="fas fa-edit"></i>

                                            <span class="d-none d-lg-inline">
                                                Edit
                                            </span>

                                        </a>


                                                                                <!-- RENEW ACCOUNT -->
                                        <?php if (!((int)$user['id'] === 1 && $user['username'] === 'admin')): ?>
                                            <a href="renew.php?id=<?= (int)$user['id'] ?>"
                                               class="btn btn-sm btn-success"
                                               title="Renew for 30 days">
                                                <i class="fas fa-calendar-plus"></i>
                                                <span class="d-none d-lg-inline">Renew 30 days</span>
                                            </a>
                                        <?php endif; ?>


                                        <!-- DELETE BUTTON -->

                                        <?php if (
                                            (int)$user['id']
                                            !==
                                            $currentUserId
                                        ): ?>

                                            <a
                                                href="delete.php?id=<?= (int)$user['id'] ?>"
                                                class="btn btn-sm btn-danger"
                                                title="Delete User"
                                                onclick="return confirm(
                                                    'Are you sure you want to delete this user? This action cannot be undone.'
                                                );"
                                            >

                                                <i class="fas fa-trash"></i>

                                                <span class="d-none d-lg-inline">
                                                    Delete
                                                </span>

                                            </a>

                                        <?php else: ?>

                                            <button
                                                type="button"
                                                class="btn btn-sm btn-secondary"
                                                disabled
                                                title="You cannot delete your own account"
                                            >

                                                <i class="fas fa-lock"></i>

                                            </button>

                                        <?php endif; ?>


                                    </td>

                                </tr>


                            <?php endforeach; ?>


                        <?php endif; ?>


                        </tbody>

                    </table>

                </div>

            </div>

        </div>


    </div>

</div>


<!-- ==========================================================
     JAVASCRIPT
=========================================================== -->

<script>

const sidebar =
    document.getElementById('sidebar');

const mainContent =
    document.getElementById('mainContent');

const sidebarToggle =
    document.getElementById('sidebarToggle');

const mobileMenuButton =
    document.getElementById('mobileMenuButton');

const sidebarOverlay =
    document.getElementById('sidebarOverlay');


/* ==========================================================
   DESKTOP SIDEBAR COLLAPSE
=========================================================== */

if (sidebarToggle) {

    sidebarToggle.addEventListener(
        'click',
        function () {

            if (window.innerWidth > 767) {

                sidebar.classList.toggle(
                    'collapsed'
                );

                mainContent.classList.toggle(
                    'expanded'
                );

            }

        }
    );

}


/* ==========================================================
   MOBILE MENU
=========================================================== */

if (mobileMenuButton) {

    mobileMenuButton.addEventListener(
        'click',
        function () {

            sidebar.classList.add(
                'mobile-open'
            );

            sidebarOverlay.classList.add(
                'active'
            );

        }
    );

}


/* ==========================================================
   CLOSE MOBILE SIDEBAR
=========================================================== */

function closeMobileSidebar()
{

    sidebar.classList.remove(
        'mobile-open'
    );

    sidebarOverlay.classList.remove(
        'active'
    );

}


/* ==========================================================
   OVERLAY CLICK
=========================================================== */

sidebarOverlay.addEventListener(
    'click',
    closeMobileSidebar
);


/* ==========================================================
   CLOSE SIDEBAR WHEN LINK CLICKED
=========================================================== */

sidebar
    .querySelectorAll('a')
    .forEach(
        function (link) {

            link.addEventListener(
                'click',
                function () {

                    if (
                        window.innerWidth <= 767
                    ) {

                        closeMobileSidebar();

                    }

                }
            );

        }
    );


/* ==========================================================
   ESCAPE KEY
=========================================================== */

document.addEventListener(
    'keydown',
    function (event) {

        if (event.key === 'Escape') {

            closeMobileSidebar();

        }

    }
);

</script>


<script
    src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
></script>

<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
></script>


</body>

</html>