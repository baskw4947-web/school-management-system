<?php

require_once "../../config/database.php";
require_once "../../includes/auth.php";

requireRole([
    'administrator'
]);

function e($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| Get User ID
|--------------------------------------------------------------------------
*/

$user_id = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$user_id || $user_id <= 0) {
    exit("Invalid user ID.");
}

/*
|--------------------------------------------------------------------------
| Current Logged In User
|--------------------------------------------------------------------------
*/

$currentUserId = (int)(
    $_SESSION['user_id'] ?? 0
);

/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_token'])) {

    $_SESSION['csrf_token'] =
        bin2hex(
            random_bytes(32)
        );
}

$csrf_token =
    $_SESSION['csrf_token'];

/*
|--------------------------------------------------------------------------
| Load User
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT
        id,
        username,
        full_name,
        role,
        status,
        created_at
    FROM users
    WHERE id = ?
    LIMIT 1
");

if (!$stmt) {

    exit(
        "Failed to prepare user query: " .
        $conn->error
    );

}

$stmt->bind_param(
    "i",
    $user_id
);

$stmt->execute();

$result =
    $stmt->get_result();

if ($result->num_rows === 0) {

    $stmt->close();

    exit("User not found.");
}

$user =
    $result->fetch_assoc();

$stmt->close();

/*
|--------------------------------------------------------------------------
| Prevent Deleting Current User
|--------------------------------------------------------------------------
*/

if ($user_id === $currentUserId) {

    exit(
        "You cannot delete the account you are currently using."
    );

}

$error = '';

/*
|--------------------------------------------------------------------------
| Delete
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /*
    |--------------------------------------------------------------------------
    | CSRF
    |--------------------------------------------------------------------------
    */

    if (
        !isset($_POST['csrf_token']) ||
        !hash_equals(
            $_SESSION['csrf_token'],
            $_POST['csrf_token']
        )
    ) {

        $error =
            "Invalid security token. Please refresh the page and try again.";

    } else {

        /*
        |--------------------------------------------------------------------------
        | Confirmation
        |--------------------------------------------------------------------------
        */

        $confirmation =
            trim(
                $_POST['confirmation'] ?? ''
            );

        if ($confirmation !== 'DELETE') {

            $error =
                "Please type DELETE to confirm the deletion.";

        } else {

            /*
            |--------------------------------------------------------------------------
            | Delete User
            |--------------------------------------------------------------------------
            */

            $stmt = $conn->prepare("
                DELETE FROM users
                WHERE id = ?
                LIMIT 1
            ");

            if (!$stmt) {

                $error =
                    "Failed to prepare delete query: " .
                    $conn->error;

            } else {

                $stmt->bind_param(
                    "i",
                    $user_id
                );

                if ($stmt->execute()) {

                    $stmt->close();

                    header(
                        "Location: index.php?success=" .
                        urlencode(
                            "User deleted successfully."
                        )
                    );

                    exit;

                } else {

                    /*
                    |--------------------------------------------------------------------------
                    | Foreign Key Constraint
                    |--------------------------------------------------------------------------
                    */

                    if ($stmt->errno === 1451) {

                        $error =
                            "This user cannot be deleted because other records are linked to this account. Consider changing the user status to inactive instead.";

                    } else {

                        $error =
                            "Failed to delete user: " .
                            $stmt->error;

                    }

                    $stmt->close();

                }

            }

        }

    }

}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
    Delete User - School Management System
</title>

<link
    rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: #f4f6f9;
    font-family: Arial, sans-serif;
}

.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 250px;
    height: 100vh;
    background: #343a40;
    color: white;
    transition: all .3s ease;
    z-index: 1050;
    overflow-y: auto;
}

.sidebar-header {
    height: 65px;
    display: flex;
    align-items: center;
    padding: 0 20px;
    background: #212529;
    font-size: 18px;
    font-weight: bold;
}

.sidebar-header i {
    margin-right: 10px;
}

.sidebar-menu {
    list-style: none;
    padding: 15px 0;
    margin: 0;
}

.sidebar-menu li {
    margin: 2px 10px;
}

.sidebar-menu a {
    display: flex;
    align-items: center;
    padding: 12px 15px;
    color: #ced4da;
    text-decoration: none;
    border-radius: 5px;
}

.sidebar-menu a:hover {
    background: #495057;
    color: white;
}

.sidebar-menu a.active {
    background: #007bff;
    color: white;
}

.sidebar-menu i {
    width: 25px;
    margin-right: 10px;
    text-align: center;
}

.main-content {
    margin-left: 250px;
    min-height: 100vh;
    transition: all .3s ease;
}

.topbar {
    height: 65px;
    background: white;
    border-bottom: 1px solid #dee2e6;
    display: flex;
    align-items: center;
    padding: 0 25px;
}

.sidebar-toggle {
    border: none;
    background: none;
    font-size: 22px;
    cursor: pointer;
    margin-right: 15px;
    color: #343a40;
}

.page-title {
    margin: 0;
    font-size: 22px;
    font-weight: 600;
}

.content {
    padding: 25px;
}

.card {
    border: none;
    border-radius: 10px;
    box-shadow: 0 2px 8px rgba(0,0,0,.06);
}

.delete-icon {
    width: 90px;
    height: 90px;
    border-radius: 50%;
    background: #f8d7da;
    color: #dc3545;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 40px;
    margin: 0 auto 20px;
}

.user-info {
    background: #f8f9fa;
    border-radius: 8px;
    padding: 20px;
}

.user-info-row {
    padding: 10px 0;
    border-bottom: 1px solid #dee2e6;
}

.user-info-row:last-child {
    border-bottom: none;
}

.user-info-label {
    font-weight: 600;
    color: #6c757d;
}

.sidebar.collapsed {
    width: 75px;
}

.sidebar.collapsed .sidebar-header span,
.sidebar.collapsed .sidebar-menu span {
    display: none;
}

.sidebar.collapsed .sidebar-header {
    justify-content: center;
    padding: 0;
}

.sidebar.collapsed .sidebar-header i {
    margin: 0;
}

.sidebar.collapsed .sidebar-menu a {
    justify-content: center;
    padding: 12px 0;
}

.sidebar.collapsed .sidebar-menu i {
    margin: 0;
}

.main-content.expanded {
    margin-left: 75px;
}

.mobile-topbar {
    display: none;
}

.sidebar-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,.5);
    z-index: 1040;
}

@media (max-width: 767px) {

    .sidebar {
        left: -250px;
        width: 250px;
    }

    .sidebar.mobile-open {
        left: 0;
    }

    .main-content {
        margin-left: 0;
    }

    .topbar {
        display: none;
    }

    .mobile-topbar {
        display: flex;
        height: 60px;
        background: #343a40;
        color: white;
        align-items: center;
        padding: 0 15px;
    }

    .mobile-menu-button {
        border: none;
        background: none;
        color: white;
        font-size: 22px;
        margin-right: 15px;
    }

    .content {
        padding: 15px;
    }

    .sidebar-overlay.active {
        display: block;
    }

}

</style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>

<body>


<!-- SIDEBAR -->

<div
    class="sidebar"
    id="sidebar"
>

    <div class="sidebar-header">

        <i class="fas fa-school"></i>

        <span>School System</span>

    </div>


    <ul class="sidebar-menu">

        <li>
            <a href="/admin/dashboard.php">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
        </li>

        <li>
            <a href="/admin/classes/index.php">
                <i class="fas fa-chalkboard"></i>
                <span>Classes</span>
            </a>
        </li>

        <li>
            <a href="/admin/students/list.php">
                <i class="fas fa-user-graduate"></i>
                <span>Students</span>
            </a>
        </li>

        <li>
            <a href="/admin/teachers/index.php">
                <i class="fas fa-chalkboard-teacher"></i>
                <span>Teachers</span>
            </a>
        </li>

        <li>
            <a href="/admin/bursar/index.php">
                <i class="fas fa-money-bill-wave"></i>
                <span>Bursar</span>
            </a>
        </li>

        <li>
            <a href="/admin/assets/index.php">
                <i class="fas fa-boxes"></i>
                <span>Assets</span>
            </a>
        </li>

        <li>
            <a href="/admin/staff/index.php">
                <i class="fas fa-users"></i>
                <span>Other Staff</span>
            </a>
        </li>

        <li>
            <a href="/admin/projects/index.php">
                <i class="fas fa-project-diagram"></i>
                <span>School Projects</span>
            </a>
        </li>

        <li>
            <a href="/admin/users/index.php" class="active">
                <i class="fas fa-user-cog"></i>
                <span>Users</span>
            </a>
        </li>

        <li>
            <a href="/logout.php">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </li>

    </ul>

</div>


<div
    class="sidebar-overlay"
    id="sidebarOverlay"
></div>


<!-- MAIN -->

<div
    class="main-content"
    id="mainContent"
>


    <div class="topbar">

        <button
            class="sidebar-toggle"
            id="sidebarToggle"
            type="button"
        >

            <i class="fas fa-bars"></i>

        </button>

        <h1 class="page-title">
            Delete User
        </h1>

    </div>


    <div class="mobile-topbar">

        <button
            class="mobile-menu-button"
            id="mobileMenuButton"
            type="button"
        >

            <i class="fas fa-bars"></i>

        </button>

        <strong>
            Delete User
        </strong>

    </div>


    <div class="content">


        <div class="row justify-content-center">

            <div class="col-lg-7">


                <div class="card">

                    <div class="card-body p-4">


                        <div class="delete-icon">

                            <i class="fas fa-user-times"></i>

                        </div>


                        <h3 class="text-center mb-2">

                            Delete System User?

                        </h3>


                        <p class="text-center text-muted">

                            This action cannot be undone.

                        </p>


                        <?php if ($error !== ''): ?>

                            <div
                                class="alert alert-danger"
                            >

                                <i class="fas fa-exclamation-circle"></i>

                                <?= e($error) ?>

                            </div>

                        <?php endif; ?>


                        <div class="user-info mb-4">


                            <div class="user-info-row row">

                                <div class="col-sm-4 user-info-label">
                                    Full Name
                                </div>

                                <div class="col-sm-8">

                                    <?= e($user['full_name']) ?>

                                </div>

                            </div>


                            <div class="user-info-row row">

                                <div class="col-sm-4 user-info-label">
                                    Username
                                </div>

                                <div class="col-sm-8">

                                    <?= e($user['username']) ?>

                                </div>

                            </div>


                            <div class="user-info-row row">

                                <div class="col-sm-4 user-info-label">
                                    Role
                                </div>

                                <div class="col-sm-8">

                                    <?= e(
                                        ucfirst(
                                            str_replace(
                                                '_',
                                                ' ',
                                                $user['role']
                                            )
                                        )
                                    ) ?>

                                </div>

                            </div>


                            <div class="user-info-row row">

                                <div class="col-sm-4 user-info-label">
                                    Status
                                </div>

                                <div class="col-sm-8">

                                    <?= e(
                                        ucfirst(
                                            $user['status']
                                        )
                                    ) ?>

                                </div>

                            </div>

                        </div>


                        <div class="alert alert-warning">

                            <i class="fas fa-exclamation-triangle"></i>

                            <strong>Warning:</strong>

                            Deleting this user may be impossible if
                            other records in the system are linked to
                            this account.

                            In that situation, it is safer to make the
                            account inactive.

                        </div>


                        <form
                            method="POST"
                            action="delete.php?id=<?= (int)$user_id ?>"
                        >

                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= e($csrf_token) ?>"
                            >


                            <div class="form-group">

                                <label>

                                    Type
                                    <strong>DELETE</strong>
                                    to confirm

                                </label>

                                <input
                                    type="text"
                                    name="confirmation"
                                    class="form-control"
                                    placeholder="DELETE"
                                    autocomplete="off"
                                    required
                                >

                            </div>


                            <div class="text-center mt-4">

                                <a
                                    href="index.php"
                                    class="btn btn-secondary mr-2"
                                >

                                    <i class="fas fa-arrow-left"></i>

                                    Cancel

                                </a>


                                <button
                                    type="submit"
                                    class="btn btn-danger"
                                >

                                    <i class="fas fa-trash"></i>

                                    Delete User

                                </button>

                            </div>

                        </form>

                    </div>

                </div>


            </div>

        </div>

    </div>

</div>


<script>

const sidebar =
    document.getElementById('sidebar');

const mainContent =
    document.getElementById('mainContent');

const sidebarToggle =
    document.getElementById('sidebarToggle');

const mobileMenuButton =
    document.getElementById('mobileMenuButton');

const sidebarOverlay =
    document.getElementById('sidebarOverlay');


if (sidebarToggle) {

    sidebarToggle.addEventListener(
        'click',
        function () {

            if (window.innerWidth > 767) {

                sidebar.classList.toggle(
                    'collapsed'
                );

                mainContent.classList.toggle(
                    'expanded'
                );

            }

        }
    );

}


if (mobileMenuButton) {

    mobileMenuButton.addEventListener(
        'click',
        function () {

            sidebar.classList.add(
                'mobile-open'
            );

            sidebarOverlay.classList.add(
                'active'
            );

        }
    );

}


function closeMobileSidebar()
{
    sidebar.classList.remove(
        'mobile-open'
    );

    sidebarOverlay.classList.remove(
        'active'
    );
}


sidebarOverlay.addEventListener(
    'click',
    closeMobileSidebar
);


sidebar.querySelectorAll('a').forEach(
    function (link) {

        link.addEventListener(
            'click',
            function () {

                if (window.innerWidth <= 767) {

                    closeMobileSidebar();

                }

            }
        );

    }
);


document.addEventListener(
    'keydown',
    function (event) {

        if (event.key === 'Escape') {

            closeMobileSidebar();

        }

    }
);

</script>


<script
    src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
></script>

<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
></script>

</body>

</html>