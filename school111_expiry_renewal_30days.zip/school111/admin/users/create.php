<?php

require_once "../../config/database.php";
require_once "../../includes/auth.php";

requireRole(['administrator']);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* -----------------------------
   CSRF TOKEN
------------------------------ */
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrf_token = $_SESSION['csrf_token'];

$error = '';

$username  = '';
$full_name = '';
$role      = 'teacher';
$status    = 'active';

/* -----------------------------
   CREATE USER
------------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /* CSRF CHECK */
    if (
        !isset($_POST['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])
    ) {
        $error = "Invalid security token. Please refresh the page and try again.";
    } else {

        $username         = trim($_POST['username'] ?? '');
        $full_name        = trim($_POST['full_name'] ?? '');
        $password         = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        $role             = $_POST['role'] ?? '';
        $status            = $_POST['status'] ?? 'active';

        /* -----------------------------
           VALIDATION
        ------------------------------ */

        if ($username === '') {

            $error = "Username is required.";

        } elseif (!preg_match('/^[A-Za-z0-9._-]{3,100}$/', $username)) {

            $error = "Username must contain 3-100 characters and may only contain letters, numbers, dots, underscores and hyphens.";

        } elseif ($full_name === '') {

            $error = "Full name is required.";

        } elseif (strlen($full_name) < 2) {

            $error = "Please enter a valid full name.";

        } elseif ($password === '') {

            $error = "Password is required.";

        } elseif (strlen($password) < 8) {

            $error = "Password must be at least 8 characters.";

        } elseif ($password !== $confirm_password) {

            $error = "Passwords do not match.";

        } elseif (
            !in_array(
                $role,
                [
                    'administrator',
                    'assistant_administrator',
                    'bursar',
                    'teacher'
                ],
                true
            )
        ) {

            $error = "Invalid user role.";

        } elseif (!in_array($status, ['active', 'inactive'], true)) {

            $error = "Invalid user status.";
        }

        /* -----------------------------
           CHECK USERNAME
        ------------------------------ */

        if ($error === '') {

            $check = $conn->prepare(
                "SELECT id FROM users WHERE username = ? LIMIT 1"
            );

            if (!$check) {

                $error = "Database error: " . $conn->error;

            } else {

                $check->bind_param("s", $username);
                $check->execute();
                $check->store_result();

                if ($check->num_rows > 0) {
                    $error = "That username already exists.";
                }

                $check->close();
            }
        }

        /* -----------------------------
           INSERT USER
        ------------------------------ */

        if ($error === '') {

            $hashed_password = password_hash(
                $password,
                PASSWORD_DEFAULT
            );

            $stmt = $conn->prepare(
                "INSERT INTO users
                (
                    username,
                    password,
                    full_name,
                    role,
                    status,
                    expires_at
                )
                VALUES (?, ?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY))"
            );

            if (!$stmt) {

                $error = "Database error: " . $conn->error;

            } else {

                $stmt->bind_param(
                    "sssss",
                    $username,
                    $hashed_password,
                    $full_name,
                    $role,
                    $status
                );

                if ($stmt->execute()) {

                    $stmt->close();

                    header(
                        "Location: index.php?success=" .
                        urlencode("User created successfully.")
                    );
                    exit;

                } else {

                    $error = "Failed to create user: " . $stmt->error;

                    $stmt->close();
                }
            }
        }
    }
}

/* -----------------------------
   ESCAPE FUNCTION
------------------------------ */
function e($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Create User - School Management System</title>

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
    >

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
    >

    <style>

        body {
            margin: 0;
            background: #f4f6f9;
            font-family: Arial, sans-serif;
        }

        /* SIDEBAR */

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            height: 100vh;
            background: #343a40;
            color: #fff;
            z-index: 1050;
            overflow-y: auto;
            transition: all 0.3s ease;
        }

        .sidebar-header {
            background: #212529;
            padding: 20px 15px;
            text-align: center;
        }

        .sidebar-header h4 {
            margin: 0;
            font-size: 20px;
        }

        .sidebar-header small {
            color: #adb5bd;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            color: #ddd;
            padding: 13px 18px;
            text-decoration: none;
            transition: 0.2s;
        }

        .sidebar a:hover {
            background: #495057;
            color: #fff;
        }

        .sidebar a.active {
            background: #007bff;
            color: #fff;
        }

        .sidebar a i {
            width: 30px;
            font-size: 16px;
        }

        /* CONTENT */

        .main-content {
            margin-left: 250px;
            min-height: 100vh;
            transition: all 0.3s ease;
        }

        .topbar {
            background: #fff;
            padding: 15px 20px;
            border-bottom: 1px solid #ddd;
            display: flex;
            align-items: center;
        }

        .menu-btn {
            display: none;
            border: none;
            background: #343a40;
            color: #fff;
            padding: 8px 12px;
            border-radius: 4px;
            margin-right: 15px;
        }

        .page-content {
            padding: 25px;
        }

        .page-title {
            font-weight: 600;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.08);
        }

        .card-header {
            background: #fff;
            border-bottom: 1px solid #eee;
            font-weight: 600;
        }

        .form-control {
            height: 45px;
            border-radius: 6px;
        }

        .btn {
            border-radius: 6px;
        }

        .password-help {
            font-size: 13px;
            color: #6c757d;
            margin-top: 5px;
        }

        /* OVERLAY */

        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1040;
        }

        /* MOBILE */

        @media (max-width: 768px) {

            .sidebar {
                left: -250px;
            }

            .sidebar.show {
                left: 0;
            }

            .main-content {
                margin-left: 0;
            }

            .menu-btn {
                display: inline-block;
            }

            .sidebar-overlay.show {
                display: block;
            }

            .page-content {
                padding: 15px;
            }
        }

    </style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar" id="sidebar">

    <div class="sidebar-header">

        <h4>
            <i class="fas fa-school"></i>
            School System
        </h4>

        <small>Administration Panel</small>

    </div>

    <a href="/admin/dashboard.php">
        <i class="fas fa-tachometer-alt"></i>
        Dashboard
    </a>

    <a href="/admin/classes/index.php">
        <i class="fas fa-chalkboard"></i>
        Classes
    </a>

    <a href="/admin/students/list.php">
        <i class="fas fa-user-graduate"></i>
        Students
    </a>

    <a href="/admin/teachers/index.php">
        <i class="fas fa-chalkboard-teacher"></i>
        Teachers
    </a>

    <a href="/admin/bursar/index.php">
        <i class="fas fa-money-bill-wave"></i>
        Bursar
    </a>

    <a href="/admin/assets/index.php">
        <i class="fas fa-boxes"></i>
        Assets
    </a>

    <a href="/admin/staff/index.php">
        <i class="fas fa-users"></i>
        Other Staff
    </a>

    <a href="/admin/projects/index.php">
        <i class="fas fa-project-diagram"></i>
        School Projects
    </a>

    <a href="/admin/users/index.php" class="active">
        <i class="fas fa-user-cog"></i>
        System Users
    </a>

    <a href="/logout.php">
        <i class="fas fa-sign-out-alt"></i>
        Logout
    </a>

</div>

<div
    class="sidebar-overlay"
    id="sidebarOverlay"
></div>


<!-- MAIN CONTENT -->

<div class="main-content">

    <!-- TOPBAR -->

    <div class="topbar">

        <button
            class="menu-btn"
            id="menuBtn"
        >
            <i class="fas fa-bars"></i>
        </button>

        <div>

            <h5 class="mb-0">
                Create System User
            </h5>

            <small class="text-muted">
                Add a new user to the school management system
            </small>

        </div>

    </div>


    <!-- PAGE -->

    <div class="page-content">

        <div class="d-flex justify-content-between align-items-center mb-4">

            <div>

                <h3 class="page-title mb-1">
                    <i class="fas fa-user-plus text-primary"></i>
                    Create User
                </h3>

                <p class="text-muted mb-0">
                    Create a login account for a staff member.
                </p>

            </div>

            <a
                href="index.php"
                class="btn btn-secondary"
            >
                <i class="fas fa-arrow-left"></i>
                Back to Users
            </a>

        </div>


        <?php if ($error !== ''): ?>

            <div
                class="alert alert-danger alert-dismissible fade show"
                role="alert"
            >

                <i class="fas fa-exclamation-circle"></i>

                <?= e($error) ?>

                <button
                    type="button"
                    class="close"
                    data-dismiss="alert"
                >
                    <span>&times;</span>
                </button>

            </div>

        <?php endif; ?>


        <div class="card">

            <div class="card-header">

                <i class="fas fa-user-cog"></i>

                User Account Information

            </div>

            <div class="card-body">

                <form
                    method="POST"
                    action=""
                >

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= e($csrf_token) ?>"
                    >


                    <div class="row">

                        <!-- USERNAME -->

                        <div class="col-md-6 mb-3">

                            <label>
                                Username
                                <span class="text-danger">*</span>
                            </label>

                            <input
                                type="text"
                                name="username"
                                class="form-control"
                                value="<?= e($username) ?>"
                                maxlength="100"
                                required
                                autocomplete="username"
                                placeholder="Enter username"
                            >

                            <div class="password-help">

                                Example:
                                john.teacher

                            </div>

                        </div>


                        <!-- FULL NAME -->

                        <div class="col-md-6 mb-3">

                            <label>
                                Full Name
                                <span class="text-danger">*</span>
                            </label>

                            <input
                                type="text"
                                name="full_name"
                                class="form-control"
                                value="<?= e($full_name) ?>"
                                maxlength="150"
                                required
                                placeholder="Enter full name"
                            >

                        </div>


                        <!-- PASSWORD -->

                        <div class="col-md-6 mb-3">

                            <label>
                                Password
                                <span class="text-danger">*</span>
                            </label>

                            <input
                                type="password"
                                name="password"
                                class="form-control"
                                minlength="8"
                                required
                                autocomplete="new-password"
                                placeholder="Enter password"
                            >

                            <div class="password-help">
                                Password must contain at least 8 characters.
                            </div>

                        </div>


                        <!-- CONFIRM PASSWORD -->

                        <div class="col-md-6 mb-3">

                            <label>
                                Confirm Password
                                <span class="text-danger">*</span>
                            </label>

                            <input
                                type="password"
                                name="confirm_password"
                                class="form-control"
                                minlength="8"
                                required
                                autocomplete="new-password"
                                placeholder="Confirm password"
                            >

                        </div>


                        <!-- ROLE -->

                        <div class="col-md-6 mb-3">

                            <label>
                                User Role
                                <span class="text-danger">*</span>
                            </label>

                            <select
                                name="role"
                                class="form-control"
                                required
                            >

                                <option
                                    value="administrator"
                                    <?= $role === 'administrator' ? 'selected' : '' ?>
                                >
                                    Administrator
                                </option>

                                <option
                                    value="assistant_administrator"
                                    <?= $role === 'assistant_administrator' ? 'selected' : '' ?>
                                >
                                    Assistant Administrator
                                </option>

                                <option
                                    value="bursar"
                                    <?= $role === 'bursar' ? 'selected' : '' ?>
                                >
                                    Bursar
                                </option>

                                <option
                                    value="teacher"
                                    <?= $role === 'teacher' ? 'selected' : '' ?>
                                >
                                    Teacher
                                </option>

                            </select>

                        </div>


                        <!-- STATUS -->

                        <div class="col-md-6 mb-3">

                            <label>
                                Account Status
                                <span class="text-danger">*</span>
                            </label>

                            <select
                                name="status"
                                class="form-control"
                                required
                            >

                                <option
                                    value="active"
                                    <?= $status === 'active' ? 'selected' : '' ?>
                                >
                                    Active
                                </option>

                                <option
                                    value="inactive"
                                    <?= $status === 'inactive' ? 'selected' : '' ?>
                                >
                                    Inactive
                                </option>

                            </select>

                        </div>

                    </div>


                    <hr>


                    <div class="d-flex justify-content-end">

                        <a
                            href="index.php"
                            class="btn btn-secondary mr-2"
                        >
                            <i class="fas fa-times"></i>
                            Cancel
                        </a>

                        <button
                            type="submit"
                            class="btn btn-primary"
                        >
                            <i class="fas fa-user-plus"></i>
                            Create User
                        </button>

                    </div>

                </form>

            </div>

        </div>

    </div>

</div>


<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>


<script>

    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    const menuBtn = document.getElementById('menuBtn');

    function openSidebar() {

        sidebar.classList.add('show');
        overlay.classList.add('show');

    }

    function closeSidebar() {

        sidebar.classList.remove('show');
        overlay.classList.remove('show');

    }

    menuBtn.addEventListener('click', function () {

        if (sidebar.classList.contains('show')) {

            closeSidebar();

        } else {

            openSidebar();

        }

    });

    overlay.addEventListener('click', closeSidebar);


    document.addEventListener('keydown', function(event) {

        if (event.key === 'Escape') {

            closeSidebar();

        }

    });


    document.querySelectorAll('.sidebar a').forEach(function(link) {

        link.addEventListener('click', function() {

            if (window.innerWidth <= 768) {

                closeSidebar();

            }

        });

    });

</script>

</body>

</html>