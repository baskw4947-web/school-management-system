<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/auth.php';
requireRole(['administrator']);

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$userId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$userId || $userId < 1) {
    header('Location: index.php?error=' . urlencode('Invalid user ID.'));
    exit;
}
$stmt = $conn->prepare("SELECT id, username FROM users WHERE id = ? LIMIT 1");
if (!$stmt) {
    exit("Database error: " . htmlspecialchars($conn->error, ENT_QUOTES, 'UTF-8'));
}
$stmt->bind_param("i", $userId);
$stmt->execute();
$stmt->bind_result($targetId, $targetUsername);
$found = $stmt->fetch();
$stmt->close();

if (!$found) {
    header('Location: index.php?error=' . urlencode('User not found.'));
    exit;
}
if ((int)$targetId === 1 && $targetUsername === 'admin') {
    header('Location: index.php?error=' . urlencode('The default administrator account does not require renewal.'));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (
        empty($_POST['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])
    ) {
        header('Location: index.php?error=' . urlencode('Invalid security token. Please try again.'));
        exit;
    }

    // Extend from the later of the current expiry or now.
    $stmt = $conn->prepare("
        UPDATE users
        SET expires_at = DATE_ADD(
            GREATEST(COALESCE(expires_at, NOW()), NOW()),
            INTERVAL 30 DAY
        )
        WHERE id = ?
          AND NOT (id = 1 AND username = 'admin')
    ");
    if (!$stmt) {
        header('Location: index.php?error=' . urlencode('Could not prepare renewal: ' . $conn->error));
        exit;
    }
    $stmt->bind_param("i", $userId);
    if ($stmt->execute()) {
        $stmt->close();
        header('Location: index.php?success=' . urlencode('Account renewed for 30 days.'));
        exit;
    }
    $error = $stmt->error;
    $stmt->close();
    header('Location: index.php?error=' . urlencode('Renewal failed: ' . $error));
    exit;
}

$csrf = htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8');
$name = htmlspecialchars($targetUsername, ENT_QUOTES, 'UTF-8');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Renew User Account</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container py-5">
  <div class="card mx-auto shadow-sm" style="max-width:540px">
    <div class="card-body p-4">
      <h4>Renew user account</h4>
      <p>Renew <strong><?= $name ?></strong> for another 30 days?</p>
      <form method="post">
        <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
        <button class="btn btn-success" type="submit">Confirm 30-day renewal</button>
        <a class="btn btn-secondary" href="index.php">Cancel</a>
      </form>
    </div>
  </div>
</div>
</body>
</html>
