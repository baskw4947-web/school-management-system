<?php
/**
 * Other Staff Members / Non-teaching Employee Management
 * Location: /admin/staff/index.php
 * Uses the site's existing MySQLi connection and authentication system.
 * Save as UTF-8 without BOM; keep this opening PHP tag at the beginning of the file.
 */
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator']);

if (!isset($conn) || !($conn instanceof mysqli)) {
    http_response_code(500);
    exit('Database connection is unavailable. Please check config/database.php.');
}
$conn->set_charset('utf8mb4');

function otherStaffE($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}
function otherStaffIdent(string $name): string {
    return '`' . str_replace('`', '``', $name) . '`';
}
function otherStaffColumns(mysqli $db, string $table): array {
    $result = $db->query('SHOW COLUMNS FROM ' . otherStaffIdent($table));
    $columns = [];
    while ($row = $result->fetch_assoc()) $columns[$row['Field']] = $row;
    $result->free();
    return $columns;
}
function otherStaffPick(array $columns, array $candidates): ?string {
    $lower = [];
    foreach ($columns as $name => $meta) $lower[strtolower((string)$name)] = (string)$name;
    foreach ($candidates as $candidate) {
        if (isset($lower[strtolower($candidate)])) return $lower[strtolower($candidate)];
    }
    return null;
}
function otherStaffEnumValues(string $type): array {
    if (stripos($type, 'enum(') !== 0) return [];
    preg_match_all("/'((?:[^'\\\\]|\\\\.)*)'/", $type, $matches);
    return array_map(static fn($value) => stripcslashes($value), $matches[1] ?? []);
}
function otherStaffIsActive($status): bool {
    $value = strtolower(trim((string)$status));
    if ($value === '') return true;
    if (is_numeric($value)) return (int)$value === 1;
    return !in_array($value, ['inactive', 'disabled', 'terminated', 'resigned', 'retired', 'dismissed', 'deleted', '0'], true);
}
function otherStaffFullName(array $row, array $map): string {
    $name = $map['full_name'] ? trim((string)($row[$map['full_name']] ?? '')) : '';
    if ($name === '') {
        $parts = [];
        foreach (['first_name', 'other_names', 'last_name'] as $key) {
            if ($map[$key] && trim((string)($row[$map[$key]] ?? '')) !== '') $parts[] = trim((string)$row[$map[$key]]);
        }
        $name = trim(implode(' ', $parts));
    }
    if ($name === '' && $map['id']) $name = 'Staff member #' . (int)($row[$map['id']] ?? 0);
    return $name;
}
function otherStaffGenerateNo(mysqli $db, string $table, ?string $column): string {
    if (!$column) return '';
    for ($i = 0; $i < 15; $i++) {
        $candidate = 'OS-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(2)));
        $stmt = $db->prepare('SELECT 1 FROM ' . otherStaffIdent($table) . ' WHERE ' . otherStaffIdent($column) . ' = ? LIMIT 1');
        $stmt->bind_param('s', $candidate);
        $stmt->execute();
        $exists = (bool)$stmt->get_result()->fetch_row();
        $stmt->close();
        if (!$exists) return $candidate;
    }
    throw new RuntimeException('Could not generate a unique staff number. Please try again.');
}
function otherStaffBind(mysqli_stmt $stmt, string $types, array &$values): void {
    $args = [$types];
    foreach ($values as &$value) $args[] = &$value;
    call_user_func_array([$stmt, 'bind_param'], $args);
}
function otherStaffFlash(string $type, string $message): void {
    $_SESSION['other_staff_flash'] = ['type' => $type, 'message' => $message];
}
function otherStaffRedirect(string $url = 'index.php'): void {
    header('Location: ' . $url);
    exit;
}
function otherStaffValidDate(string $date): bool {
    if ($date === '') return true;
    $dt = DateTime::createFromFormat('!Y-m-d', $date);
    $errors = DateTime::getLastErrors();
    return $dt !== false && $dt->format('Y-m-d') === $date &&
        ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0));
}

// Use the existing non-teaching staff table when available. Create a standard one only if none exists.
$tableMap = [];
$staffTable = null;
$createdTable = false;
$schemaError = '';
$columnInfo = [];
$map = [];
$staffRows = [];
$shownRows = [];
$flash = $_SESSION['other_staff_flash'] ?? null;
unset($_SESSION['other_staff_flash']);
$loggedInUserId = (int)($_SESSION['user_id'] ?? $_SESSION['id'] ?? ($_SESSION['user']['id'] ?? 0));

if (empty($_SESSION['other_staff_csrf'])) $_SESSION['other_staff_csrf'] = bin2hex(random_bytes(32));
$csrfToken = (string)$_SESSION['other_staff_csrf'];

try {
    $tablesResult = $conn->query('SHOW TABLES');
    while ($row = $tablesResult->fetch_row()) $tableMap[strtolower((string)$row[0])] = (string)$row[0];
    $tablesResult->free();

    foreach (['other_staff', 'staff_members', 'non_teaching_staff', 'employees', 'staff'] as $candidate) {
        if (isset($tableMap[$candidate])) { $staffTable = $tableMap[$candidate]; break; }
    }

    if (!$staffTable) {
        $conn->query("CREATE TABLE `other_staff` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `staff_no` VARCHAR(50) NOT NULL,
            `first_name` VARCHAR(100) NOT NULL,
            `last_name` VARCHAR(100) NOT NULL,
            `other_names` VARCHAR(100) DEFAULT NULL,
            `gender` VARCHAR(20) DEFAULT NULL,
            `date_of_birth` DATE DEFAULT NULL,
            `phone` VARCHAR(30) DEFAULT NULL,
            `email` VARCHAR(150) DEFAULT NULL,
            `address` TEXT DEFAULT NULL,
            `department` VARCHAR(100) DEFAULT NULL,
            `job_title` VARCHAR(120) DEFAULT NULL,
            `employment_type` VARCHAR(60) DEFAULT NULL,
            `qualification` VARCHAR(180) DEFAULT NULL,
            `date_joined` DATE DEFAULT NULL,
            `salary` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            `next_of_kin` VARCHAR(150) DEFAULT NULL,
            `next_of_kin_phone` VARCHAR(30) DEFAULT NULL,
            `status` ENUM('active','inactive','on_leave','terminated') NOT NULL DEFAULT 'active',
            `created_by` INT(11) DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`), UNIQUE KEY `uq_other_staff_no` (`staff_no`), KEY `idx_other_staff_name` (`last_name`,`first_name`), KEY `idx_other_staff_status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $staffTable = 'other_staff';
        $createdTable = true;
    }

    $columnInfo = otherStaffColumns($conn, $staffTable);
    $map = [
        'id' => otherStaffPick($columnInfo, ['id', 'staff_id', 'employee_id', 'personnel_id']),
        'staff_no' => otherStaffPick($columnInfo, ['staff_no', 'employee_no', 'employee_number', 'staff_number', 'employee_code', 'staff_code', 'personnel_no']),
        'first_name' => otherStaffPick($columnInfo, ['first_name', 'given_name', 'firstname']),
        'last_name' => otherStaffPick($columnInfo, ['last_name', 'surname', 'family_name', 'lastname']),
        'other_names' => otherStaffPick($columnInfo, ['other_names', 'middle_name', 'middle_names', 'other_name']),
        'full_name' => otherStaffPick($columnInfo, ['full_name', 'staff_name', 'employee_name', 'name', 'person_name']),
        'gender' => otherStaffPick($columnInfo, ['gender', 'sex']),
        'date_of_birth' => otherStaffPick($columnInfo, ['date_of_birth', 'dob', 'birth_date']),
        'phone' => otherStaffPick($columnInfo, ['phone', 'phone_number', 'mobile', 'telephone', 'contact']),
        'email' => otherStaffPick($columnInfo, ['email', 'email_address']),
        'address' => otherStaffPick($columnInfo, ['address', 'residential_address', 'home_address']),
        'department' => otherStaffPick($columnInfo, ['department', 'department_name', 'unit', 'section']),
        'job_title' => otherStaffPick($columnInfo, ['job_title', 'position', 'designation', 'role_title', 'title', 'occupation']),
        'employment_type' => otherStaffPick($columnInfo, ['employment_type', 'staff_type', 'contract_type', 'employment_status_type']),
        'qualification' => otherStaffPick($columnInfo, ['qualification', 'highest_qualification', 'education_level']),
        'date_joined' => otherStaffPick($columnInfo, ['date_joined', 'joining_date', 'hire_date', 'employment_date', 'date_employed']),
        'salary' => otherStaffPick($columnInfo, ['salary', 'monthly_salary', 'basic_salary', 'salary_amount', 'wage']),
        'next_of_kin' => otherStaffPick($columnInfo, ['next_of_kin', 'next_of_kin_name', 'emergency_contact_name']),
        'next_of_kin_phone' => otherStaffPick($columnInfo, ['next_of_kin_phone', 'emergency_contact_phone', 'next_of_kin_contact']),
        'status' => otherStaffPick($columnInfo, ['status', 'employment_status', 'staff_status', 'is_active']),
        'created_by' => otherStaffPick($columnInfo, ['created_by', 'user_id', 'entered_by']),
        'created_at' => otherStaffPick($columnInfo, ['created_at', 'created_on', 'date_created']),
        'updated_at' => otherStaffPick($columnInfo, ['updated_at', 'modified_at', 'updated_on'])
    ];
    if (!$map['id']) throw new RuntimeException('The staff table needs an id or staff_id column.');
    if (!$map['full_name'] && (!$map['first_name'] || !$map['last_name'])) throw new RuntimeException('The staff table needs a full name column or first_name and last_name columns.');
} catch (Throwable $e) {
    $schemaError = $e instanceof RuntimeException ? $e->getMessage() : 'Could not prepare the staff database. Check that the database account has permission to read and create the required table.';
    error_log('Other staff setup error: ' . $e->getMessage());
}

// Handle create/update/status-change actions.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $schemaError === '') {
    if (!hash_equals($csrfToken, (string)($_POST['csrf_token'] ?? ''))) {
        otherStaffFlash('danger', 'Your form session expired. Refresh the page and try again.');
        otherStaffRedirect();
    }
    $action = (string)($_POST['action'] ?? '');
    try {
        if ($action === 'save_staff') {
            $id = max(0, (int)($_POST['staff_id'] ?? 0));
            $firstName = trim((string)($_POST['first_name'] ?? ''));
            $lastName = trim((string)($_POST['last_name'] ?? ''));
            $otherNames = trim((string)($_POST['other_names'] ?? ''));
            $fullName = trim(implode(' ', array_filter([$firstName, $otherNames, $lastName], static fn($v) => $v !== '')));
            if ($fullName === '') $fullName = trim((string)($_POST['full_name'] ?? ''));
            $staffNo = trim((string)($_POST['staff_no'] ?? ''));
            $gender = trim((string)($_POST['gender'] ?? ''));
            $dob = trim((string)($_POST['date_of_birth'] ?? ''));
            $phone = trim((string)($_POST['phone'] ?? ''));
            $email = trim((string)($_POST['email'] ?? ''));
            $address = trim((string)($_POST['address'] ?? ''));
            $department = trim((string)($_POST['department'] ?? ''));
            $jobTitle = trim((string)($_POST['job_title'] ?? ''));
            $employmentType = trim((string)($_POST['employment_type'] ?? 'Permanent'));
            $qualification = trim((string)($_POST['qualification'] ?? ''));
            $dateJoined = trim((string)($_POST['date_joined'] ?? ''));
            $salaryInput = trim((string)($_POST['salary'] ?? '0'));
            $nextOfKin = trim((string)($_POST['next_of_kin'] ?? ''));
            $nextOfKinPhone = trim((string)($_POST['next_of_kin_phone'] ?? ''));
            $statusInput = trim((string)($_POST['status'] ?? 'active'));

            if ($fullName === '') throw new RuntimeException('Enter the staff member’s full name.');
            if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Enter a valid email address or leave the email field blank.');
            if (!otherStaffValidDate($dob) || !otherStaffValidDate($dateJoined)) throw new RuntimeException('Enter valid dates for date of birth and date joined.');
            if ($salaryInput === '' || !is_numeric($salaryInput) || !is_finite((float)$salaryInput) || (float)$salaryInput < 0) throw new RuntimeException('Enter a valid salary amount of zero or greater.');
            $salary = round((float)$salaryInput, 2);
            if ($staffNo === '' && $id < 1 && $map['staff_no']) $staffNo = otherStaffGenerateNo($conn, $staffTable, $map['staff_no']);

            $status = $statusInput;
            if ($map['status']) {
                $type = strtolower((string)($columnInfo[$map['status']]['Type'] ?? ''));
                $enum = otherStaffEnumValues($type);
                if ($enum && !in_array($status, $enum, true)) {
                    $status = in_array('active', $enum, true) ? 'active' : $enum[0];
                }
                if (!$enum && $type !== '' && (strpos($type, 'int') !== false || strpos($type, 'tinyint') !== false)) $status = in_array(strtolower($status), ['active','1'], true) ? '1' : '0';
            }

            $formValues = [
                'staff_no' => [$staffNo !== '' ? $staffNo : null, 's'],
                'first_name' => [$firstName !== '' ? $firstName : ($map['first_name'] ? null : null), 's'],
                'last_name' => [$lastName !== '' ? $lastName : ($map['last_name'] ? null : null), 's'],
                'other_names' => [$otherNames !== '' ? $otherNames : null, 's'],
                'full_name' => [$fullName, 's'],
                'gender' => [$gender !== '' ? $gender : null, 's'],
                'date_of_birth' => [$dob !== '' ? $dob : null, 's'],
                'phone' => [$phone !== '' ? $phone : null, 's'],
                'email' => [$email !== '' ? $email : null, 's'],
                'address' => [$address !== '' ? $address : null, 's'],
                'department' => [$department !== '' ? $department : null, 's'],
                'job_title' => [$jobTitle !== '' ? $jobTitle : null, 's'],
                'employment_type' => [$employmentType !== '' ? $employmentType : null, 's'],
                'qualification' => [$qualification !== '' ? $qualification : null, 's'],
                'date_joined' => [$dateJoined !== '' ? $dateJoined : null, 's'],
                'salary' => [$salary, 'd'],
                'next_of_kin' => [$nextOfKin !== '' ? $nextOfKin : null, 's'],
                'next_of_kin_phone' => [$nextOfKinPhone !== '' ? $nextOfKinPhone : null, 's'],
                'status' => [$status, 's']
            ];
            $data = [];
            $types = '';
            foreach ($formValues as $key => [$value, $type]) {
                $col = $map[$key] ?? null;
                if (!$col) continue;
                // Do not attempt to bind blank strings into required first/last name fields.
                if (in_array($key, ['first_name', 'last_name'], true) && $value === null && strtoupper((string)$columnInfo[$col]['Null']) === 'NO' && $columnInfo[$col]['Default'] === null) {
                    if ($key === 'first_name') $value = $firstName !== '' ? $firstName : $fullName;
                    else $value = $lastName !== '' ? $lastName : ($key === 'last_name' ? '—' : '');
                }
                if ($key === 'staff_no' && $value === null && strtoupper((string)$columnInfo[$col]['Null']) === 'NO' && $columnInfo[$col]['Default'] === null) throw new RuntimeException('Enter a staff number.');
                $data[$col] = $value;
                $types .= $type;
            }
            if ($id < 1 && $map['created_by']) {
                $meta = $columnInfo[$map['created_by']];
                if (strtoupper((string)$meta['Null']) === 'NO' && $meta['Default'] === null && $loggedInUserId < 1) throw new RuntimeException('Your user ID could not be identified. Sign out and sign back in, then try again.');
                $data[$map['created_by']] = $loggedInUserId > 0 ? $loggedInUserId : null;
                $types .= 'i';
            }

            // Check that no custom required database field is being omitted during insertion.
            if ($id < 1) {
                foreach ($columnInfo as $colName => $meta) {
                    if (array_key_exists($colName, $data)) continue;
                    if (stripos((string)$meta['Extra'], 'auto_increment') !== false) continue;
                    if (strtoupper((string)$meta['Null']) === 'YES' || $meta['Default'] !== null) continue;
                    if (in_array($colName, [$map['created_at'], $map['updated_at']], true)) continue;
                    throw new RuntimeException('Your staff table has another required column, `' . $colName . '`, with no default value. Please share the Structure tab of that table so this page can match it.');
                }
            }
            if ($id > 0) {
                $check = $conn->prepare('SELECT ' . otherStaffIdent($map['id']) . ' FROM ' . otherStaffIdent($staffTable) . ' WHERE ' . otherStaffIdent($map['id']) . ' = ? LIMIT 1');
                $check->bind_param('i', $id);
                $check->execute();
                $found = (bool)$check->get_result()->fetch_row();
                $check->close();
                if (!$found) throw new RuntimeException('Staff record not found. Refresh and try again.');
                if (!$data) throw new RuntimeException('No editable columns were found in this staff table.');
                $set = [];
                foreach (array_keys($data) as $col) $set[] = otherStaffIdent($col) . ' = ?';
                $values = array_values($data); $values[] = $id;
                $stmt = $conn->prepare('UPDATE ' . otherStaffIdent($staffTable) . ' SET ' . implode(', ', $set) . ' WHERE ' . otherStaffIdent($map['id']) . ' = ?');
                otherStaffBind($stmt, $types . 'i', $values);
                $stmt->execute(); $stmt->close();
                otherStaffFlash('success', 'Staff member updated successfully.');
            } else {
                if (!$data) throw new RuntimeException('No compatible fields were found for the staff record.');
                $columnSql = implode(', ', array_map('otherStaffIdent', array_keys($data)));
                $marks = implode(', ', array_fill(0, count($data), '?'));
                $stmt = $conn->prepare('INSERT INTO ' . otherStaffIdent($staffTable) . ' (' . $columnSql . ') VALUES (' . $marks . ')');
                $values = array_values($data);
                otherStaffBind($stmt, $types, $values);
                $stmt->execute(); $stmt->close();
                otherStaffFlash('success', 'Other staff member registered successfully.');
            }
            otherStaffRedirect();
        }

        if ($action === 'toggle_status') {
            $id = max(0, (int)($_POST['staff_id'] ?? 0));
            if ($id < 1 || !$map['status']) throw new RuntimeException('This staff table does not support status changes.');
            $stmt = $conn->prepare('SELECT ' . otherStaffIdent($map['status']) . ' FROM ' . otherStaffIdent($staffTable) . ' WHERE ' . otherStaffIdent($map['id']) . ' = ? LIMIT 1');
            $stmt->bind_param('i', $id); $stmt->execute(); $row = $stmt->get_result()->fetch_row(); $stmt->close();
            if (!$row) throw new RuntimeException('Staff member not found.');
            $current = (string)$row[0];
            $enum = otherStaffEnumValues((string)$columnInfo[$map['status']]['Type']);
            $newStatus = otherStaffIsActive($current) ? 'inactive' : 'active';
            if ($enum && !in_array($newStatus, $enum, true)) $newStatus = $enum[0];
            $colType = strtolower((string)$columnInfo[$map['status']]['Type']);
            if (!$enum && (strpos($colType, 'int') !== false || strpos($colType, 'tinyint') !== false)) $newStatus = otherStaffIsActive($current) ? '0' : '1';
            $stmt = $conn->prepare('UPDATE ' . otherStaffIdent($staffTable) . ' SET ' . otherStaffIdent($map['status']) . ' = ? WHERE ' . otherStaffIdent($map['id']) . ' = ?');
            $stmt->bind_param('si', $newStatus, $id); $stmt->execute(); $stmt->close();
            otherStaffFlash('success', 'Staff status updated to ' . str_replace('_', ' ', $newStatus) . '.');
            otherStaffRedirect();
        }
        throw new RuntimeException('Invalid request. Please refresh the page and try again.');
    } catch (Throwable $e) {
        error_log('Other staff save error: ' . $e->getMessage());
        otherStaffFlash('danger', $e instanceof RuntimeException ? $e->getMessage() : 'The staff record could not be saved. Check the hosting PHP error log.');
        otherStaffRedirect();
    }
}

// Load records and filters.
$search = trim((string)($_GET['q'] ?? ''));
$departmentFilter = trim((string)($_GET['department'] ?? ''));
$statusFilter = trim((string)($_GET['status'] ?? ''));
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 15;
$totalPages = 1;
$totalRows = 0;
$activeCount = 0;
$inactiveCount = 0;
$totalPayroll = 0.0;
$departments = [];
$rows = [];
$shownRows = [];
$editStaff = null;
$allowedStatuses = $map['status'] ? otherStaffEnumValues((string)$columnInfo[$map['status']]['Type']) : ['active', 'inactive'];
if (!$allowedStatuses) $allowedStatuses = ['active', 'inactive'];

if ($schemaError === '') {
    try {
        $result = $conn->query('SELECT * FROM ' . otherStaffIdent($staffTable) . ' ORDER BY ' . otherStaffIdent($map['id']) . ' DESC');
        while ($record = $result->fetch_assoc()) {
            $record['_id'] = (int)($record[$map['id']] ?? 0);
            $record['_staff_no'] = $map['staff_no'] ? (string)($record[$map['staff_no']] ?? '') : '';
            $record['_name'] = otherStaffFullName($record, $map);
            $record['_gender'] = $map['gender'] ? (string)($record[$map['gender']] ?? '') : '';
            $record['_phone'] = $map['phone'] ? (string)($record[$map['phone']] ?? '') : '';
            $record['_email'] = $map['email'] ? (string)($record[$map['email']] ?? '') : '';
            $record['_department'] = $map['department'] ? (string)($record[$map['department']] ?? '') : '';
            $record['_job_title'] = $map['job_title'] ? (string)($record[$map['job_title']] ?? '') : '';
            $record['_employment_type'] = $map['employment_type'] ? (string)($record[$map['employment_type']] ?? '') : '';
            $record['_date_joined'] = $map['date_joined'] ? (string)($record[$map['date_joined']] ?? '') : '';
            $record['_salary'] = $map['salary'] ? (float)($record[$map['salary']] ?? 0) : 0.0;
            $record['_status'] = $map['status'] ? (string)($record[$map['status']] ?? '') : 'active';
            if ($record['_department'] !== '') $departments[$record['_department']] = $record['_department'];
            if (otherStaffIsActive($record['_status'])) $activeCount++; else $inactiveCount++;
            $totalPayroll += $record['_salary'];
            $haystack = strtolower(implode(' ', [$record['_staff_no'], $record['_name'], $record['_phone'], $record['_email'], $record['_department'], $record['_job_title'], $record['_employment_type']]));
            if ($search !== '' && strpos($haystack, strtolower($search)) === false) continue;
            if ($departmentFilter !== '' && $record['_department'] !== $departmentFilter) continue;
            if ($statusFilter !== '' && strtolower($record['_status']) !== strtolower($statusFilter)) continue;
            $rows[] = $record;
        }
        $result->free();
        ksort($departments);
        $totalRows = count($rows);
        $totalPages = max(1, (int)ceil($totalRows / $perPage));
        if ($page > $totalPages) $page = $totalPages;
        $shownRows = array_slice($rows, ($page - 1) * $perPage, $perPage);
        $editId = max(0, (int)($_GET['edit'] ?? 0));
        if ($editId > 0) {
            $stmt = $conn->prepare('SELECT * FROM ' . otherStaffIdent($staffTable) . ' WHERE ' . otherStaffIdent($map['id']) . ' = ? LIMIT 1');
            $stmt->bind_param('i', $editId); $stmt->execute();
            $editStaff = $stmt->get_result()->fetch_assoc() ?: null;
            $stmt->close();
        }
    } catch (Throwable $e) {
        $schemaError = 'Staff records could not be loaded. Please check the database table structure and PHP error log.';
        error_log('Other staff load error: ' . $e->getMessage());
    }
}

if (isset($_GET['export']) && $_GET['export'] === 'csv' && $schemaError === '') {
    if (ob_get_length()) ob_clean();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="other_staff_' . date('Ymd') . '.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Staff No.', 'Full Name', 'Gender', 'Phone', 'Email', 'Department', 'Job Title', 'Employment Type', 'Date Joined', 'Monthly Salary', 'Status']);
    foreach ($rows as $r) fputcsv($out, [$r['_staff_no'], $r['_name'], $r['_gender'], $r['_phone'], $r['_email'], $r['_department'], $r['_job_title'], $r['_employment_type'], $r['_date_joined'], number_format($r['_salary'], 2, '.', ''), $r['_status']]);
    fclose($out); exit;
}

$formValue = static function (string $key, $default = '') use ($editStaff, $map) {
    if (!$editStaff) return $default;
    $col = $map[$key] ?? null;
    return $col ? ($editStaff[$col] ?? $default) : $default;
};
$editFullName = $editStaff ? otherStaffFullName($editStaff, $map) : '';
$defaultStatuses = ['active' => 'Active', 'inactive' => 'Inactive', 'on_leave' => 'On Leave', 'terminated' => 'Terminated'];
$exportQuery = $_GET; $exportQuery['export'] = 'csv'; unset($exportQuery['page']);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Other Staff Members | School Management System</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f6f9;font-family:Arial,Helvetica,sans-serif;color:#343a40}.sidebar{position:fixed;top:0;bottom:0;left:0;width:250px;background:#212529;overflow-y:auto;z-index:1050}.sidebar-header{padding:22px 18px;background:#171a1d;color:#fff;font-weight:700;font-size:18px}.sidebar-header small{font-size:12px;color:#adb5bd;font-weight:400}.sidebar-section{padding:15px 16px 6px;color:#868e96;font-size:11px;text-transform:uppercase;font-weight:bold;letter-spacing:.5px}.sidebar a{display:block;color:#ced4da;padding:11px 16px;text-decoration:none;border-left:4px solid transparent;font-size:14px}.sidebar a:hover,.sidebar a.active{background:#343a40;color:#fff;border-left-color:#dc3545}.sidebar a i{width:24px;text-align:center;margin-right:5px}.main{margin-left:250px;min-height:100vh}.topbar{padding:17px 25px;background:#fff;border-bottom:1px solid #e5e5e5;display:flex;align-items:center;justify-content:space-between}.content{padding:24px}.page-head,.panel,.stat-card{background:#fff;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,.05)}.page-head{padding:21px;margin-bottom:20px}.panel{padding:21px;margin-bottom:22px}.stat-card{padding:18px;margin-bottom:18px;height:calc(100% - 18px)}.stat-title{color:#6c757d;font-size:13px}.stat-number{font-size:22px;font-weight:700;overflow-wrap:anywhere}.form-control,.custom-select,.btn{border-radius:6px}.form-control,.custom-select{min-height:40px}label{font-size:13px;font-weight:600}.table th{background:#f8f9fa;white-space:nowrap;font-size:12px}.table td{vertical-align:middle;font-size:13px}.badge{padding:7px 9px}.mobile-menu{display:none}.muted-small{font-size:11px;color:#89929c}.btn-danger{background:#dc3545;border-color:#dc3545}.alert{font-size:13px}.section-title{font-size:16px;font-weight:700}.employee-name{font-weight:700}.employee-sub{font-size:11px;color:#77808a}.avatar{height:36px;width:36px;border-radius:50%;background:#fce8eb;color:#b42335;font-weight:700;display:inline-flex;align-items:center;justify-content:center;margin-right:9px}.form-section{border-bottom:1px solid #edf0f2;padding-bottom:10px;margin:7px 0 16px;font-weight:700;color:#343a40}.muted-note{font-size:12px;color:#6c757d}@media(max-width:991px){.sidebar{left:-250px;transition:left .25s}.sidebar.show{left:0}.main{margin-left:0}.mobile-menu{display:inline-block}.content{padding:15px}.topbar{padding:12px 15px}}@media print{.sidebar,.topbar,.no-print,.mobile-menu{display:none!important}.main{margin:0}.content{padding:0}.panel,.stat-card,.page-head{box-shadow:none}}
</style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<aside class="sidebar no-print" id="sidebar">
 <div class="sidebar-header"><i class="fas fa-school mr-2"></i>School Management<br><small>Administration Panel</small></div>
 <div class="sidebar-section">Main</div>
 <a href="/admin/dashboard.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
 <a href="/admin/students/list.php"><i class="fas fa-user-graduate"></i>Students</a>
 <a href="/admin/teachers/index.php"><i class="fas fa-chalkboard-teacher"></i>Teachers</a>
 <a class="active" href="/admin/staff/index.php"><i class="fas fa-users-cog"></i>Other Staff Members</a>
 <div class="sidebar-section">Classes & Learning</div>
 <a href="/admin/classes/notes.php"><i class="fas fa-book-open"></i>Subject Notes</a>
 <a href="/admin/classes/projects.php"><i class="fas fa-folder-open"></i>Student Projects</a>
 <a href="/admin/classes/timetable.php"><i class="fas fa-calendar-alt"></i>Timetable</a>
 <div class="sidebar-section">Account</div>
 <a href="/admin/dashboard.php"><i class="fas fa-cog"></i>Admin Dashboard</a>
 <a href="/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
</aside>
<div class="main">
 <div class="topbar"><div><button type="button" class="btn btn-dark mobile-menu mr-2" id="mobileMenuBtn" aria-label="Open menu"><i class="fas fa-bars"></i></button><strong>Human Resources / Staff Directory</strong></div><div class="text-muted small"><i class="fas fa-user-circle mr-1"></i><?= otherStaffE($_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Administrator') ?></div></div>
 <div class="content">
  <div class="page-head d-flex justify-content-between align-items-center flex-wrap">
   <div><h3 class="mb-1"><i class="fas fa-users-cog text-danger mr-2"></i>Other Staff Members</h3><div class="text-muted">Manage non-teaching staff, employee details, departments and employment status.</div></div>
   <div class="mt-2 no-print"><a href="index.php#staffForm" class="btn btn-danger"><i class="fas fa-user-plus mr-1"></i>Register Staff</a> <button type="button" onclick="window.print()" class="btn btn-outline-secondary"><i class="fas fa-print mr-1"></i>Print</button></div>
  </div>
  <?php if ($createdTable): ?><div class="alert alert-info"><i class="fas fa-info-circle mr-1"></i>No compatible non-teaching staff table was found, so a standard <code>other_staff</code> table was created.</div><?php endif; ?>
  <?php if ($schemaError !== ''): ?><div class="alert alert-danger"><strong><i class="fas fa-exclamation-triangle mr-1"></i>Staff page configuration issue</strong><div><?= otherStaffE($schemaError) ?></div><small>No changes were made. Check the PHP error log or share your staff table Structure tab.</small></div><?php endif; ?>
  <?php if (is_array($flash) && !empty($flash['message'])): ?><div class="alert alert-<?= otherStaffE($flash['type'] ?? 'info') ?> alert-dismissible fade show" role="alert"><?= otherStaffE($flash['message']) ?><button type="button" class="close" data-dismiss="alert"><span>&times;</span></button></div><?php endif; ?>

  <div class="row">
   <div class="col-md-6 col-xl-3"><div class="stat-card"><div class="stat-title">Staff Records</div><div class="stat-number text-primary"><?= number_format(count($rows)) ?></div><div class="muted-small">Matching current filters</div></div></div>
   <div class="col-md-6 col-xl-3"><div class="stat-card"><div class="stat-title">Active Staff</div><div class="stat-number text-success"><?= number_format($activeCount) ?></div><div class="muted-small">All staff in the register</div></div></div>
   <div class="col-md-6 col-xl-3"><div class="stat-card"><div class="stat-title">Inactive / Other Status</div><div class="stat-number text-warning"><?= number_format($inactiveCount) ?></div><div class="muted-small">Leave, inactive or terminated</div></div></div>
   <div class="col-md-6 col-xl-3"><div class="stat-card"><div class="stat-title">Monthly Salary Total</div><div class="stat-number">UGX <?= number_format($totalPayroll, 2) ?></div><div class="muted-small">Sum of recorded staff salaries</div></div></div>
  </div>

  <?php if ($schemaError === ''): ?>
  <section class="panel no-print" id="staffForm">
   <div class="d-flex justify-content-between align-items-center flex-wrap mb-3"><div class="section-title"><i class="fas fa-user-edit text-danger mr-2"></i><?= $editStaff ? 'Edit Staff Member' : 'Register a Non-Teaching Staff Member' ?></div><?php if ($editStaff): ?><a class="btn btn-sm btn-outline-secondary" href="index.php#staffForm">Cancel edit</a><?php endif; ?></div>
   <form method="post" action="index.php<?= $editStaff ? '?edit=' . (int)($editStaff[$map['id']] ?? 0) . '#staffForm' : '#staffForm' ?>" id="staffFormElement">
    <input type="hidden" name="csrf_token" value="<?= otherStaffE($csrfToken) ?>"><input type="hidden" name="action" value="save_staff"><input type="hidden" name="staff_id" value="<?= (int)($editStaff[$map['id']] ?? 0) ?>">
    <div class="form-section">Personal Information</div>
    <div class="form-row">
     <?php if ($map['staff_no']): ?><div class="form-group col-md-3"><label for="staff_no">Staff / Employee Number</label><input class="form-control" id="staff_no" name="staff_no" maxlength="50" value="<?= otherStaffE($formValue('staff_no')) ?>" placeholder="Auto-generated if blank"></div><?php endif; ?>
     <?php if ($map['first_name']): ?><div class="form-group col-md-3"><label for="first_name">First Name<?= !$map['full_name'] ? ' *' : '' ?></label><input class="form-control" id="first_name" name="first_name" value="<?= otherStaffE($formValue('first_name')) ?>" maxlength="100" <?= !$map['full_name'] ? 'required' : '' ?>></div><?php endif; ?>
     <?php if ($map['other_names']): ?><div class="form-group col-md-3"><label for="other_names">Other / Middle Names</label><input class="form-control" id="other_names" name="other_names" value="<?= otherStaffE($formValue('other_names')) ?>" maxlength="100"></div><?php endif; ?>
     <?php if ($map['last_name']): ?><div class="form-group col-md-3"><label for="last_name">Last Name<?= !$map['full_name'] ? ' *' : '' ?></label><input class="form-control" id="last_name" name="last_name" value="<?= otherStaffE($formValue('last_name')) ?>" maxlength="100" <?= !$map['full_name'] ? 'required' : '' ?>></div><?php endif; ?>
     <?php if ($map['full_name']): ?><div class="form-group col-md-6"><label for="full_name">Full Name *</label><input class="form-control" id="full_name" name="full_name" value="<?= otherStaffE($editFullName) ?>" maxlength="180" placeholder="Full name as it should appear in records" <?= (!$map['first_name'] || !$map['last_name']) ? 'required' : '' ?>></div><?php endif; ?>
     <?php if ($map['gender']): ?><div class="form-group col-md-3"><label for="gender">Gender</label><select class="custom-select" id="gender" name="gender"><option value="">Select gender</option><?php foreach (['Male','Female','Other'] as $option): ?><option value="<?= $option ?>" <?= (string)$formValue('gender') === $option ? 'selected' : '' ?>><?= $option ?></option><?php endforeach; ?></select></div><?php endif; ?>
     <?php if ($map['date_of_birth']): ?><div class="form-group col-md-3"><label for="date_of_birth">Date of Birth</label><input type="date" class="form-control" id="date_of_birth" name="date_of_birth" value="<?= otherStaffE($formValue('date_of_birth')) ?>"></div><?php endif; ?>
    </div>
    <div class="form-section">Contact Information</div>
    <div class="form-row">
     <?php if ($map['phone']): ?><div class="form-group col-md-4"><label for="phone">Phone Number</label><input class="form-control" id="phone" name="phone" maxlength="30" value="<?= otherStaffE($formValue('phone')) ?>" placeholder="e.g. 07xx xxx xxx"></div><?php endif; ?>
     <?php if ($map['email']): ?><div class="form-group col-md-4"><label for="email">Email Address</label><input type="email" class="form-control" id="email" name="email" maxlength="150" value="<?= otherStaffE($formValue('email')) ?>"></div><?php endif; ?>
     <?php if ($map['address']): ?><div class="form-group col-md-4"><label for="address">Residential Address</label><input class="form-control" id="address" name="address" value="<?= otherStaffE($formValue('address')) ?>"></div><?php endif; ?>
    </div>
    <div class="form-section">Employment Information</div>
    <div class="form-row">
     <?php if ($map['department']): ?><div class="form-group col-md-3"><label for="department">Department / Unit</label><input class="form-control" id="department" name="department" list="departmentOptions" maxlength="100" value="<?= otherStaffE($formValue('department')) ?>" placeholder="e.g. Finance"><datalist id="departmentOptions"><?php foreach ($departments as $departmentOption): ?><option value="<?= otherStaffE($departmentOption) ?>"><?php endforeach; ?></datalist></div><?php endif; ?>
     <?php if ($map['job_title']): ?><div class="form-group col-md-3"><label for="job_title">Job Title / Position</label><input class="form-control" id="job_title" name="job_title" maxlength="120" value="<?= otherStaffE($formValue('job_title')) ?>" placeholder="e.g. Accountant"></div><?php endif; ?>
     <?php if ($map['employment_type']): ?><div class="form-group col-md-3"><label for="employment_type">Employment Type</label><select class="custom-select" id="employment_type" name="employment_type"><?php foreach (['Permanent','Contract','Temporary','Part-time','Casual','Internship','Volunteer'] as $option): ?><option value="<?= otherStaffE($option) ?>" <?= (string)$formValue('employment_type', 'Permanent') === $option ? 'selected' : '' ?>><?= otherStaffE($option) ?></option><?php endforeach; ?></select></div><?php endif; ?>
     <?php if ($map['qualification']): ?><div class="form-group col-md-3"><label for="qualification">Qualification</label><input class="form-control" id="qualification" name="qualification" maxlength="180" value="<?= otherStaffE($formValue('qualification')) ?>" placeholder="Highest qualification"></div><?php endif; ?>
     <?php if ($map['date_joined']): ?><div class="form-group col-md-3"><label for="date_joined">Date Joined</label><input type="date" class="form-control" id="date_joined" name="date_joined" value="<?= otherStaffE($formValue('date_joined')) ?>"></div><?php endif; ?>
     <?php if ($map['salary']): ?><div class="form-group col-md-3"><label for="salary">Monthly Salary (UGX)</label><input type="number" class="form-control" id="salary" name="salary" min="0" step="0.01" value="<?= otherStaffE($formValue('salary', '0.00')) ?>"></div><?php endif; ?>
     <?php if ($map['status']): ?><div class="form-group col-md-3"><label for="status">Employment Status</label><select class="custom-select" id="status" name="status"><?php foreach ($allowedStatuses as $statusOption): $label = $defaultStatuses[$statusOption] ?? ucwords(str_replace('_', ' ', $statusOption)); ?><option value="<?= otherStaffE($statusOption) ?>" <?= (string)$formValue('status', $allowedStatuses[0] ?? 'active') === $statusOption ? 'selected' : '' ?>><?= otherStaffE($label) ?></option><?php endforeach; ?></select></div><?php endif; ?>
    </div>
    <?php if ($map['next_of_kin'] || $map['next_of_kin_phone']): ?><div class="form-section">Emergency Contact</div><div class="form-row"><?php if ($map['next_of_kin']): ?><div class="form-group col-md-6"><label for="next_of_kin">Next of Kin / Emergency Contact</label><input class="form-control" id="next_of_kin" name="next_of_kin" maxlength="150" value="<?= otherStaffE($formValue('next_of_kin')) ?>"></div><?php endif; ?><?php if ($map['next_of_kin_phone']): ?><div class="form-group col-md-6"><label for="next_of_kin_phone">Emergency Contact Phone</label><input class="form-control" id="next_of_kin_phone" name="next_of_kin_phone" maxlength="30" value="<?= otherStaffE($formValue('next_of_kin_phone')) ?>"></div><?php endif; ?></div><?php endif; ?>
    <button type="submit" class="btn btn-danger" id="saveStaffButton"><i class="fas fa-save mr-1"></i><?= $editStaff ? 'Update Staff Details' : 'Save Staff Member' ?></button> <button type="reset" class="btn btn-outline-secondary">Clear Form</button>
   </form>
  </section>
  <?php endif; ?>

  <section class="panel">
   <div class="d-flex justify-content-between align-items-center flex-wrap mb-3"><div><h5 class="mb-1"><i class="fas fa-address-book text-danger mr-2"></i>Other Staff Directory</h5><div class="muted-small"><?= number_format($totalRows) ?> matching staff member(s) in <?= otherStaffE($staffTable ?? 'staff table') ?></div></div><div class="no-print mt-2"><a class="btn btn-outline-success" href="?<?= otherStaffE(http_build_query($exportQuery)) ?>"><i class="fas fa-file-csv mr-1"></i>Export CSV</a></div></div>
   <form method="get" action="index.php" class="form-row align-items-end mb-3 no-print">
    <div class="form-group col-lg-5 col-md-6"><label for="q">Search staff</label><input type="search" class="form-control" id="q" name="q" value="<?= otherStaffE($search) ?>" placeholder="Staff number, name, phone, email, department"></div>
    <div class="form-group col-lg-3 col-md-3"><label for="departmentFilter">Department</label><select class="custom-select" id="departmentFilter" name="department"><option value="">All departments</option><?php foreach ($departments as $dep): ?><option value="<?= otherStaffE($dep) ?>" <?= $departmentFilter === $dep ? 'selected' : '' ?>><?= otherStaffE($dep) ?></option><?php endforeach; ?></select></div>
    <div class="form-group col-lg-2 col-md-3"><label for="statusFilter">Status</label><select class="custom-select" id="statusFilter" name="status"><option value="">All statuses</option><?php foreach ($allowedStatuses as $st): ?><option value="<?= otherStaffE($st) ?>" <?= strtolower($statusFilter) === strtolower($st) ? 'selected' : '' ?>><?= otherStaffE($defaultStatuses[$st] ?? ucwords(str_replace('_',' ',$st))) ?></option><?php endforeach; ?></select></div>
    <div class="form-group col-lg-2"><button type="submit" class="btn btn-primary"><i class="fas fa-search mr-1"></i>Search</button> <a href="index.php" class="btn btn-outline-secondary">Reset</a></div>
   </form>
   <div class="table-responsive"><table class="table table-bordered table-hover mb-0"><thead><tr><?php if ($map['staff_no']): ?><th>Staff No.</th><?php endif; ?><th>Staff Member</th><?php if ($map['department']): ?><th>Department</th><?php endif; ?><?php if ($map['job_title']): ?><th>Position</th><?php endif; ?><th>Contact</th><?php if ($map['employment_type']): ?><th>Employment</th><?php endif; ?><?php if ($map['date_joined']): ?><th>Date Joined</th><?php endif; ?><?php if ($map['salary']): ?><th class="text-right">Monthly Salary (UGX)</th><?php endif; ?><?php if ($map['status']): ?><th>Status</th><?php endif; ?><th class="no-print">Actions</th></tr></thead><tbody>
   <?php if (!$shownRows): ?><tr><td colspan="<?= 3 + count(array_filter([$map['staff_no'],$map['department'],$map['job_title'],$map['employment_type'],$map['date_joined'],$map['salary'],$map['status']])) ?>" class="text-center text-muted py-5"><i class="fas fa-users fa-2x d-block mb-2"></i><strong>No staff members found</strong><div class="small mt-1">Register a new staff member or change your search filters.</div></td></tr><?php else: foreach ($shownRows as $staff): $active = otherStaffIsActive($staff['_status']); $initials = strtoupper(substr(preg_replace('/[^A-Za-z]/', '', $staff['_name']), 0, 2)); ?>
    <tr>
     <?php if ($map['staff_no']): ?><td><strong><?= otherStaffE($staff['_staff_no'] !== '' ? $staff['_staff_no'] : '—') ?></strong></td><?php endif; ?>
     <td><div class="d-flex align-items-center"><span class="avatar"><?= otherStaffE($initials !== '' ? $initials : 'ST') ?></span><div><div class="employee-name"><?= otherStaffE($staff['_name']) ?></div><div class="employee-sub"><?= otherStaffE($staff['_gender'] !== '' ? $staff['_gender'] : 'Gender not recorded') ?></div></div></div></td>
     <?php if ($map['department']): ?><td><?= otherStaffE($staff['_department'] !== '' ? $staff['_department'] : '—') ?></td><?php endif; ?>
     <?php if ($map['job_title']): ?><td><?= otherStaffE($staff['_job_title'] !== '' ? $staff['_job_title'] : '—') ?></td><?php endif; ?>
     <td><?php if ($staff['_phone'] !== ''): ?><div><i class="fas fa-phone-alt text-muted mr-1"></i><?= otherStaffE($staff['_phone']) ?></div><?php endif; ?><?php if ($staff['_email'] !== ''): ?><div class="employee-sub"><i class="fas fa-envelope mr-1"></i><?= otherStaffE($staff['_email']) ?></div><?php endif; ?><?php if ($staff['_phone'] === '' && $staff['_email'] === ''): ?>—<?php endif; ?></td>
     <?php if ($map['employment_type']): ?><td><?= otherStaffE($staff['_employment_type'] !== '' ? $staff['_employment_type'] : '—') ?></td><?php endif; ?>
     <?php if ($map['date_joined']): ?><td><?= $staff['_date_joined'] !== '' && strtotime($staff['_date_joined']) ? otherStaffE(date('d M Y', strtotime($staff['_date_joined']))) : '—' ?></td><?php endif; ?>
     <?php if ($map['salary']): ?><td class="text-right font-weight-bold text-nowrap"><?= number_format($staff['_salary'], 2) ?></td><?php endif; ?>
     <?php if ($map['status']): ?><td><span class="badge badge-<?= $active ? 'success' : 'secondary' ?>"><?= otherStaffE($defaultStatuses[$staff['_status']] ?? ucwords(str_replace('_',' ',$staff['_status'] ?: 'active'))) ?></span></td><?php endif; ?>
     <td class="no-print text-nowrap"><a class="btn btn-sm btn-outline-primary mb-1" href="index.php?edit=<?= (int)$staff['_id'] ?>#staffForm" title="Edit staff"><i class="fas fa-edit"></i></a><?php if ($map['status']): ?><form method="post" action="index.php" class="d-inline" onsubmit="return confirm('Change the employment status for this staff member?');"><input type="hidden" name="csrf_token" value="<?= otherStaffE($csrfToken) ?>"><input type="hidden" name="action" value="toggle_status"><input type="hidden" name="staff_id" value="<?= (int)$staff['_id'] ?>"><button type="submit" class="btn btn-sm btn-outline-<?= $active ? 'warning' : 'success' ?> mb-1" title="<?= $active ? 'Deactivate' : 'Activate' ?>"><i class="fas <?= $active ? 'fa-user-slash' : 'fa-user-check' ?>"></i></button></form><?php endif; ?></td>
    </tr>
   <?php endforeach; endif; ?>
   </tbody></table></div>
   <?php if ($totalPages > 1): $pageQuery = $_GET; unset($pageQuery['export']); ?><nav class="no-print mt-3" aria-label="Staff pages"><ul class="pagination flex-wrap mb-0"><?php $pageQuery['page'] = max(1, $page - 1); ?><li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="?<?= otherStaffE(http_build_query($pageQuery)) ?>">Previous</a></li><?php for ($p = max(1, $page - 2); $p <= min($totalPages, $page + 2); $p++): $pageQuery['page'] = $p; ?><li class="page-item <?= $p === $page ? 'active' : '' ?>"><a class="page-link" href="?<?= otherStaffE(http_build_query($pageQuery)) ?>"><?= $p ?></a></li><?php endfor; ?><?php $pageQuery['page'] = min($totalPages, $page + 1); ?><li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>"><a class="page-link" href="?<?= otherStaffE(http_build_query($pageQuery)) ?>">Next</a></li></ul></nav><?php endif; ?>
  </section>
  <div class="text-center text-muted small mb-3">School Management System &mdash; Other Staff Members</div>
 </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function(){
 var sidebar=document.getElementById('sidebar'),menu=document.getElementById('mobileMenuBtn');
 if(menu&&sidebar)menu.addEventListener('click',function(){sidebar.classList.toggle('show');});
 document.addEventListener('click',function(e){if(window.innerWidth<=991&&sidebar&&sidebar.classList.contains('show')&&!sidebar.contains(e.target)&&menu&&!menu.contains(e.target))sidebar.classList.remove('show');});
 var form=document.getElementById('staffFormElement');
 if(form)form.addEventListener('submit',function(){var button=document.getElementById('saveStaffButton');if(button){button.disabled=true;button.innerHTML='<i class="fas fa-spinner fa-spin mr-1"></i>Saving staff member...';}});
})();
</script>
</body>
</html>
