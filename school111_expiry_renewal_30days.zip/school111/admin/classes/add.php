<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once "../../config/database.php";
require_once "../../includes/auth.php";

requireRole([
    'administrator',
    'assistant_administrator'
]);

/*
|--------------------------------------------------------------------------
| HELPER
|--------------------------------------------------------------------------
*/

function e($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/*
|--------------------------------------------------------------------------
| CSRF TOKEN
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrf_token = $_SESSION['csrf_token'];

/*
|--------------------------------------------------------------------------
| FORM VARIABLES
|--------------------------------------------------------------------------
*/

$class_name = '';
$section = '';
$academic_year = date('Y');
$status = 'active';

$error = '';

/*
|--------------------------------------------------------------------------
| PROCESS FORM
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /*
    |--------------------------------------------------------------------------
    | CSRF CHECK
    |--------------------------------------------------------------------------
    */

    $submitted_token = $_POST['csrf_token'] ?? '';

    if (
        empty($submitted_token) ||
        !hash_equals($csrf_token, $submitted_token)
    ) {

        $error = "Invalid form submission. Please try again.";

    } else {

        /*
        |--------------------------------------------------------------------------
        | GET FORM DATA
        |--------------------------------------------------------------------------
        */

        $class_name = trim($_POST['class_name'] ?? '');
        $section = trim($_POST['section'] ?? '');
        $academic_year = trim($_POST['academic_year'] ?? '');
        $status = trim($_POST['status'] ?? 'active');


        /*
        |--------------------------------------------------------------------------
        | VALIDATION
        |--------------------------------------------------------------------------
        */

        if ($class_name === '') {

            $error = "Class name is required.";

        } elseif (strlen($class_name) > 100) {

            $error = "Class name cannot exceed 100 characters.";

        } elseif (strlen($section) > 50) {

            $error = "Section cannot exceed 50 characters.";

        } elseif ($academic_year === '') {

            $error = "Academic year is required.";

        } elseif (!preg_match('/^\d{4}$/', $academic_year)) {

            $error = "Academic year must be a 4-digit year.";

        } elseif (
            !in_array(
                $status,
                ['active', 'inactive'],
                true
            )
        ) {

            $error = "Invalid class status.";

        }


        /*
        |--------------------------------------------------------------------------
        | CHECK DUPLICATE CLASS
        |--------------------------------------------------------------------------
        */

        if ($error === '') {

            $sectionForDatabase = $section;

            $checkSql = "
                SELECT id
                FROM classes
                WHERE class_name = ?
                AND (
                    section = ?
                    OR (section IS NULL AND ? = '')
                )
                AND academic_year = ?
                LIMIT 1
            ";

            $checkStmt = $conn->prepare($checkSql);

            if (!$checkStmt) {

                $error = "Database error: " . $conn->error;

            } else {

                $checkStmt->bind_param(
                    "ssss",
                    $class_name,
                    $sectionForDatabase,
                    $sectionForDatabase,
                    $academic_year
                );

                $checkStmt->execute();

                $checkResult = $checkStmt->get_result();

                if ($checkResult->num_rows > 0) {

                    $error =
                        "This class already exists for the selected academic year.";

                }

                $checkStmt->close();
            }
        }


        /*
        |--------------------------------------------------------------------------
        | INSERT CLASS
        |--------------------------------------------------------------------------
        */

        if ($error === '') {

            /*
            | Store NULL when section is empty.
            */

            $sectionValue = ($section === '')
                ? null
                : $section;

            $insertSql = "
                INSERT INTO classes
                (
                    class_name,
                    section,
                    academic_year,
                    status
                )
                VALUES (?, ?, ?, ?)
            ";

            $stmt = $conn->prepare($insertSql);

            if (!$stmt) {

                $error =
                    "Unable to prepare class registration: " .
                    $conn->error;

            } else {

                $stmt->bind_param(
                    "ssss",
                    $class_name,
                    $sectionValue,
                    $academic_year,
                    $status
                );

                if ($stmt->execute()) {

                    $stmt->close();

                    header(
                        "Location: index.php?success=" .
                        urlencode("Class added successfully.")
                    );

                    exit;

                } else {

                    $error =
                        "Failed to add class: " .
                        $stmt->error;

                    $stmt->close();
                }
            }
        }
    }
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Add Class | School Management System
    </title>


    <!-- Bootstrap -->

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
    >


    <!-- Font Awesome -->

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
    >


    <style>

        /*
        |--------------------------------------------------------------------------
        | BODY
        |--------------------------------------------------------------------------
        */

        body {

            background: #f8f9fa;

            margin: 0;

            padding: 0;

        }


        /*
        |--------------------------------------------------------------------------
        | SIDEBAR
        |--------------------------------------------------------------------------
        */

        .sidebar {

            position: fixed;

            top: 0;
            left: 0;

            width: 250px;

            height: 100vh;

            background: #343a40;

            color: #fff;

            z-index: 1050;

            transition: all 0.3s ease;

            overflow-y: auto;

            box-shadow: 2px 0 8px rgba(0,0,0,0.12);

        }


        .sidebar-header {

            height: 65px;

            display: flex;

            align-items: center;

            justify-content: space-between;

            padding: 0 18px;

            background: #212529;

            border-bottom: 1px solid rgba(255,255,255,0.08);

        }


        .sidebar-brand {

            font-size: 19px;

            font-weight: 600;

            white-space: nowrap;

        }


        .sidebar-brand i {

            margin-right: 8px;

        }


        .sidebar-toggle {

            border: none;

            background: transparent;

            color: #fff;

            font-size: 20px;

            cursor: pointer;

        }


        .sidebar-menu {

            padding: 15px 0;

        }


        .sidebar-menu a {

            display: flex;

            align-items: center;

            color: #ced4da;

            text-decoration: none;

            padding: 12px 18px;

            font-size: 15px;

            transition: all 0.2s ease;

        }


        .sidebar-menu a i {

            width: 25px;

            font-size: 16px;

            margin-right: 10px;

            text-align: center;

        }


        .sidebar-menu a:hover {

            background: #495057;

            color: #fff;

        }


        .sidebar-menu a.active {

            background: #007bff;

            color: #fff;

        }


        .sidebar-menu .logout-link {

            color: #ffc107;

        }


        .sidebar-menu .logout-link:hover {

            background: #495057;

            color: #ffc107;

        }


        /*
        |--------------------------------------------------------------------------
        | MAIN CONTENT
        |--------------------------------------------------------------------------
        */

        .main-content {

            margin-left: 250px;

            min-height: 100vh;

            transition: all 0.3s ease;

        }


        /*
        |--------------------------------------------------------------------------
        | TOPBAR
        |--------------------------------------------------------------------------
        */

        .topbar {

            height: 65px;

            background: #fff;

            border-bottom: 1px solid #dee2e6;

            display: flex;

            align-items: center;

            justify-content: space-between;

            padding: 0 25px;

            box-shadow: 0 1px 3px rgba(0,0,0,0.05);

        }


        .topbar-title {

            font-size: 18px;

            font-weight: 600;

            color: #343a40;

        }


        .mobile-menu-btn {

            border: none;

            background: #343a40;

            color: #fff;

            border-radius: 5px;

            padding: 7px 11px;

            font-size: 18px;

        }


        .mobile-topbar {

            display: none;

        }


        /*
        |--------------------------------------------------------------------------
        | SIDEBAR COLLAPSED
        |--------------------------------------------------------------------------
        */

        body.sidebar-collapsed .sidebar {

            width: 75px;

        }


        body.sidebar-collapsed .main-content {

            margin-left: 75px;

        }


        body.sidebar-collapsed .sidebar-brand span,
        body.sidebar-collapsed .sidebar-menu a span {

            display: none;

        }


        body.sidebar-collapsed .sidebar-menu a {

            justify-content: center;

        }


        body.sidebar-collapsed .sidebar-menu a i {

            margin-right: 0;

        }


        body.sidebar-collapsed .sidebar-header {

            justify-content: center;

        }


        body.sidebar-collapsed .sidebar-toggle {

            display: none;

        }


        /*
        |--------------------------------------------------------------------------
        | PAGE CONTENT
        |--------------------------------------------------------------------------
        */

        .page-content {

            padding: 25px;

        }


        /*
        |--------------------------------------------------------------------------
        | MOBILE OVERLAY
        |--------------------------------------------------------------------------
        */

        .sidebar-overlay {

            display: none;

            position: fixed;

            top: 0;
            left: 0;

            width: 100%;
            height: 100%;

            background: rgba(0,0,0,0.5);

            z-index: 1040;

        }


        /*
        |--------------------------------------------------------------------------
        | MOBILE
        |--------------------------------------------------------------------------
        */

        @media (max-width: 767.98px) {

            .sidebar {

                width: 250px;

                transform: translateX(-100%);

            }


            .sidebar.mobile-open {

                transform: translateX(0);

            }


            .main-content {

                margin-left: 0 !important;

            }


            body.sidebar-collapsed .sidebar {

                width: 250px;

            }


            body.sidebar-collapsed .sidebar-brand span,
            body.sidebar-collapsed .sidebar-menu a span {

                display: inline;

            }


            body.sidebar-collapsed .sidebar-menu a {

                justify-content: flex-start;

            }


            body.sidebar-collapsed .sidebar-menu a i {

                margin-right: 10px;

            }


            body.sidebar-collapsed .sidebar-header {

                justify-content: space-between;

            }


            body.sidebar-collapsed .sidebar-toggle {

                display: block;

            }


            .mobile-topbar {

                display: flex;

                height: 60px;

                background: #fff;

                border-bottom: 1px solid #dee2e6;

                align-items: center;

                padding: 0 15px;

                justify-content: space-between;

            }


            .topbar {

                display: none;

            }


            .page-content {

                padding: 15px;

            }


            .page-header {

                display: block !important;

            }


            .page-header-buttons {

                margin-top: 15px;

            }


            .sidebar-overlay.show {

                display: block;

            }

        }

    </style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>


<body>


<!-- =========================================================
     SIDEBAR
========================================================== -->

<div
    class="sidebar"
    id="sidebar"
>

    <div class="sidebar-header">

        <div class="sidebar-brand">

            <i class="fas fa-school"></i>

            <span>
                School Management
            </span>

        </div>


        <button
            type="button"
            class="sidebar-toggle"
            id="sidebarToggle"
            title="Collapse Sidebar"
        >

            <i class="fas fa-bars"></i>

        </button>

    </div>


    <div class="sidebar-menu">


        <!-- DASHBOARD -->

        <a
            href="/admin/dashboard.php"
        >

            <i class="fas fa-tachometer-alt"></i>

            <span>
                Dashboard
            </span>

        </a>


        <!-- CLASSES -->

        <a
            href="/admin/classes/index.php"
            class="active"
        >

            <i class="fas fa-chalkboard"></i>

            <span>
                Classes
            </span>

        </a>


        <!-- STUDENTS -->

        <a
            href="/admin/students/list.php"
        >

            <i class="fas fa-user-graduate"></i>

            <span>
                Students
            </span>

        </a>


        <!-- TEACHERS -->

        <a
            href="/admin/teachers/index.php"
        >

            <i class="fas fa-chalkboard-teacher"></i>

            <span>
                Teachers
            </span>

        </a>


        <!-- BURSAR -->

        <a
            href="/admin/bursar/index.php"
        >

            <i class="fas fa-money-bill-wave"></i>

            <span>
                Bursar
            </span>

        </a>


        <!-- ASSETS -->

        <a
            href="/admin/assets/index.php"
        >

            <i class="fas fa-boxes"></i>

            <span>
                Assets
            </span>

        </a>


        <!-- OTHER STAFF -->

        <a
            href="/admin/staff/index.php"
        >

            <i class="fas fa-users"></i>

            <span>
                Other Staff
            </span>

        </a>


        <!-- SCHOOL PROJECTS -->

        <a
            href="/admin/projects/index.php"
        >

            <i class="fas fa-project-diagram"></i>

            <span>
                School Projects
            </span>

        </a>


        <!-- USERS -->

        <a
            href="/admin/users/index.php"
        >

            <i class="fas fa-user-cog"></i>

            <span>
                Users
            </span>

        </a>


        <hr class="bg-secondary mx-3">


        <!-- LOGOUT -->

        <a
            href="/logout.php"
            class="logout-link"
        >

            <i class="fas fa-sign-out-alt"></i>

            <span>
                Logout
            </span>

        </a>

    </div>

</div>


<!-- =========================================================
     SIDEBAR OVERLAY
========================================================== -->

<div
    class="sidebar-overlay"
    id="sidebarOverlay"
></div>


<!-- =========================================================
     MAIN CONTENT
========================================================== -->

<div class="main-content">


    <!-- =====================================================
         MOBILE TOPBAR
    ====================================================== -->

    <div class="mobile-topbar">

        <div class="topbar-title">

            <i class="fas fa-school mr-2"></i>

            School Management

        </div>


        <button
            type="button"
            class="mobile-menu-btn"
            id="menuToggle"
        >

            <i class="fas fa-bars"></i>

        </button>

    </div>


    <!-- =====================================================
         DESKTOP TOPBAR
    ====================================================== -->

    <div class="topbar">

        <div class="topbar-title">

            <i class="fas fa-plus-circle mr-2"></i>

            Add Class

        </div>


        <div class="text-muted">

            Create New Class

        </div>

    </div>


    <!-- =====================================================
         PAGE CONTENT
    ====================================================== -->

    <div class="page-content">


        <!-- =================================================
             PAGE HEADER
        ================================================== -->

        <div
            class="page-header d-flex justify-content-between align-items-center mb-4"
        >

            <div>

                <h2 class="mb-1">
                    Add Class
                </h2>

                <p class="text-muted mb-0">
                    Create a new school class.
                </p>

            </div>


            <div class="page-header-buttons">

                <a
                    href="index.php"
                    class="btn btn-outline-secondary"
                >

                    <i class="fas fa-arrow-left mr-1"></i>

                    Back to Classes

                </a>

            </div>

        </div>


        <!-- =================================================
             ERROR MESSAGE
        ================================================== -->

        <?php if ($error !== ''): ?>

            <div
                class="alert alert-danger alert-dismissible fade show"
                role="alert"
            >

                <i class="fas fa-exclamation-circle mr-1"></i>

                <?= e($error) ?>


                <button
                    type="button"
                    class="close"
                    data-dismiss="alert"
                    aria-label="Close"
                >

                    <span aria-hidden="true">
                        &times;
                    </span>

                </button>

            </div>

        <?php endif; ?>


        <!-- =================================================
             FORM
        ================================================== -->

        <div class="row">


            <!-- FORM CARD -->

            <div class="col-lg-8">

                <div class="card shadow-sm">

                    <div class="card-header bg-primary text-white">

                        <h5 class="mb-0">

                            <i class="fas fa-chalkboard mr-2"></i>

                            Class Information

                        </h5>

                    </div>


                    <div class="card-body">

                        <form
                            method="POST"
                            action=""
                        >


                            <!-- CSRF -->

                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= e($csrf_token) ?>"
                            >


                            <!-- CLASS NAME -->

                            <div class="form-group">

                                <label for="class_name">

                                    Class Name

                                    <span class="text-danger">
                                        *
                                    </span>

                                </label>


                                <input
                                    type="text"
                                    name="class_name"
                                    id="class_name"
                                    class="form-control"
                                    placeholder="Example: Primary 1"
                                    value="<?= e($class_name) ?>"
                                    maxlength="100"
                                    required
                                >


                                <small class="form-text text-muted">

                                    Enter the name of the class, for example
                                    Primary 1, Primary 2, Senior 1 or Senior 2.

                                </small>

                            </div>


                            <!-- SECTION -->

                            <div class="form-group">

                                <label for="section">
                                    Section
                                </label>


                                <input
                                    type="text"
                                    name="section"
                                    id="section"
                                    class="form-control"
                                    placeholder="Example: A"
                                    value="<?= e($section) ?>"
                                    maxlength="50"
                                >


                                <small class="form-text text-muted">

                                    Section is optional.
                                    Example: A, B, East or West.

                                </small>

                            </div>


                            <!-- ACADEMIC YEAR -->

                            <div class="form-group">

                                <label for="academic_year">

                                    Academic Year

                                    <span class="text-danger">
                                        *
                                    </span>

                                </label>


                                <input
                                    type="text"
                                    name="academic_year"
                                    id="academic_year"
                                    class="form-control"
                                    placeholder="Example: 2026"
                                    value="<?= e($academic_year) ?>"
                                    maxlength="4"
                                    pattern="[0-9]{4}"
                                    required
                                >


                                <small class="form-text text-muted">

                                    Enter a 4-digit academic year.

                                </small>

                            </div>


                            <!-- STATUS -->

                            <div class="form-group">

                                <label for="status">
                                    Status
                                </label>


                                <select
                                    name="status"
                                    id="status"
                                    class="form-control"
                                >

                                    <option
                                        value="active"
                                        <?= $status === 'active'
                                            ? 'selected'
                                            : '' ?>
                                    >

                                        Active

                                    </option>


                                    <option
                                        value="inactive"
                                        <?= $status === 'inactive'
                                            ? 'selected'
                                            : '' ?>
                                    >

                                        Inactive

                                    </option>

                                </select>

                            </div>


                            <!-- BUTTONS -->

                            <div
                                class="border-top pt-3 mt-4"
                            >

                                <button
                                    type="submit"
                                    class="btn btn-primary"
                                >

                                    <i class="fas fa-save mr-1"></i>

                                    Save Class

                                </button>


                                <a
                                    href="index.php"
                                    class="btn btn-secondary ml-2"
                                >

                                    <i class="fas fa-times mr-1"></i>

                                    Cancel

                                </a>

                            </div>

                        </form>

                    </div>

                </div>

            </div>


            <!-- =================================================
                 INFORMATION CARD
            ================================================== -->

            <div class="col-lg-4 mt-4 mt-lg-0">

                <div class="card shadow-sm">

                    <div class="card-header bg-white">

                        <h5 class="mb-0">

                            <i class="fas fa-info-circle mr-2"></i>

                            Class Information

                        </h5>

                    </div>


                    <div class="card-body">

                        <p class="text-muted">

                            Use this page to create a class for a
                            specific academic year.

                        </p>


                        <hr>


                        <p class="mb-2">

                            <strong>
                                Example:
                            </strong>

                        </p>


                        <ul class="mb-0">

                            <li>
                                Class: Primary 1
                            </li>

                            <li>
                                Section: A
                            </li>

                            <li>
                                Academic Year: 2026
                            </li>

                            <li>
                                Status: Active
                            </li>

                        </ul>

                    </div>

                </div>


                <!-- IMPORTANT CARD -->

                <div class="card shadow-sm mt-4">

                    <div class="card-body">

                        <h6>

                            <i class="fas fa-lightbulb mr-2"></i>

                            Important

                        </h6>


                        <p class="text-muted small mb-0">

                            A class with the same class name,
                            section and academic year cannot be
                            registered twice.

                        </p>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>


<!-- =========================================================
     JAVASCRIPT
========================================================== -->

<script
    src="https://code.jquery.com/jquery-3.6.4.min.js"
></script>


<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
></script>


<script>

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const sidebar =
            document.getElementById("sidebar");

        const sidebarToggle =
            document.getElementById("sidebarToggle");

        const menuToggle =
            document.getElementById("menuToggle");

        const sidebarOverlay =
            document.getElementById("sidebarOverlay");


        /*
        |--------------------------------------------------------------------------
        | DESKTOP SIDEBAR COLLAPSE
        |--------------------------------------------------------------------------
        */

        if (sidebarToggle) {

            sidebarToggle.addEventListener(
                "click",
                function () {

                    document.body.classList.toggle(
                        "sidebar-collapsed"
                    );

                }
            );

        }


        /*
        |--------------------------------------------------------------------------
        | MOBILE MENU OPEN
        |--------------------------------------------------------------------------
        */

        if (menuToggle) {

            menuToggle.addEventListener(
                "click",
                function () {

                    sidebar.classList.add(
                        "mobile-open"
                    );

                    sidebarOverlay.classList.add(
                        "show"
                    );

                }
            );

        }


        /*
        |--------------------------------------------------------------------------
        | CLOSE MOBILE SIDEBAR
        |--------------------------------------------------------------------------
        */

        function closeMobileSidebar() {

            sidebar.classList.remove(
                "mobile-open"
            );

            sidebarOverlay.classList.remove(
                "show"
            );

        }


        /*
        |--------------------------------------------------------------------------
        | OVERLAY CLICK
        |--------------------------------------------------------------------------
        */

        if (sidebarOverlay) {

            sidebarOverlay.addEventListener(
                "click",
                closeMobileSidebar
            );

        }


        /*
        |--------------------------------------------------------------------------
        | CLOSE WHEN SIDEBAR LINK IS CLICKED
        |--------------------------------------------------------------------------
        */

        const sidebarLinks =
            document.querySelectorAll(
                ".sidebar-menu a"
            );


        sidebarLinks.forEach(
            function (link) {

                link.addEventListener(
                    "click",
                    function () {

                        if (
                            window.innerWidth <= 767
                        ) {

                            closeMobileSidebar();

                        }

                    }
                );

            }
        );


        /*
        |--------------------------------------------------------------------------
        | ESC KEY
        |--------------------------------------------------------------------------
        */

        document.addEventListener(
            "keydown",
            function (event) {

                if (
                    event.key === "Escape"
                ) {

                    closeMobileSidebar();

                }

            }
        );

    }
);

</script>


</body>

</html>