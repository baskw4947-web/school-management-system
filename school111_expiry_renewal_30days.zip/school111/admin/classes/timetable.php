<?php
ob_start();

error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
ini_set('log_errors', '1');

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/auth.php';

requireRole(['administrator', 'assistant_administrator']);

$db = $conn ?? ($mysqli ?? ($connection ?? null));

if (!$db instanceof mysqli) {
    die('ERROR: Database connection is not available.');
}

$db->set_charset('utf8mb4');

/* -------------------------------------------------------------------------
   HELPERS
------------------------------------------------------------------------- */

function e($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function redirectTimetable($url = 'timetable.php')
{
    header('Location: ' . $url);
    exit;
}

function timetableTableExists($db, $table)
{
    $table = $db->real_escape_string($table);
    $result = $db->query("SHOW TABLES LIKE '$table'");
    return $result && $result->num_rows > 0;
}

function timetablePost($name, $default = '')
{
    return trim((string)($_POST[$name] ?? $default));
}

function validTime($time)
{
    return (bool)preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $time);
}

/* -------------------------------------------------------------------------
   CHECK TABLE
------------------------------------------------------------------------- */

if (!timetableTableExists($db, 'class_timetables')) {
    exit('The class_timetables table does not exist. Please check your database.');
}

/* -------------------------------------------------------------------------
   CSRF TOKEN
------------------------------------------------------------------------- */

if (empty($_SESSION['timetable_csrf'])) {
    $_SESSION['timetable_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['timetable_csrf'];

$days = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday'
];

$terms = ['Term 1', 'Term 2', 'Term 3'];

$lessonTypes = [
    'Lesson',
    'Practical',
    'Revision',
    'Examination',
    'Assembly',
    'Other'
];

$allowedStatuses = ['active', 'cancelled'];

$success = '';
$error = '';

/* -------------------------------------------------------------------------
   HANDLE FORM SUBMISSIONS
------------------------------------------------------------------------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($csrfToken, (string)($_POST['csrf_token'] ?? ''))) {
        $error = 'Your session token is invalid. Refresh the page and try again.';
    } else {

        $action = timetablePost('action');

        /* ADD OR UPDATE LESSON */

        if ($action === 'save') {

            $id = (int)($_POST['id'] ?? 0);

            $timetableCode = timetablePost('timetable_code');
            $className = timetablePost('class_name');
            $stream = timetablePost('stream');
            $subjectName = timetablePost('subject_name');
            $teacherName = timetablePost('teacher_name');
            $room = timetablePost('room');
            $day = timetablePost('day_of_week');
            $startTime = timetablePost('start_time');
            $endTime = timetablePost('end_time');
            $academicYear = timetablePost('academic_year');
            $term = timetablePost('term');
            $lessonType = timetablePost('lesson_type', 'Lesson');
            $notes = timetablePost('notes');
            $status = timetablePost('status', 'active');

            if (
                $className === '' ||
                $subjectName === '' ||
                $teacherName === '' ||
                $day === '' ||
                $academicYear === '' ||
                $term === ''
            ) {
                $error = 'Please complete all required fields.';
            } elseif (!in_array($day, $days, true)) {
                $error = 'Please select a valid day.';
            } elseif (!in_array($term, $terms, true)) {
                $error = 'Please select a valid term.';
            } elseif (!in_array($lessonType, $lessonTypes, true)) {
                $error = 'Please select a valid lesson type.';
            } elseif (!in_array($status, $allowedStatuses, true)) {
                $error = 'Please select a valid status.';
            } elseif (!validTime($startTime) || !validTime($endTime)) {
                $error = 'Please enter valid lesson times.';
            } elseif ($startTime >= $endTime) {
                $error = 'The lesson end time must be later than the start time.';
            } else {

                if ($timetableCode === '') {
                    $timetableCode = 'TT-' . date('YmdHis') . '-' . random_int(100, 999);
                }

                /*
                 * Check timetable clashes.
                 * A clash occurs when the same class, teacher or room
                 * already has another active lesson at the same time.
                 */

                $conflictSql = "
                    SELECT id, class_name, teacher_name, room
                    FROM class_timetables
                    WHERE day_of_week = ?
                      AND academic_year = ?
                      AND term = ?
                      AND status = 'active'
                      AND start_time < ?
                      AND end_time > ?
                      AND id != ?
                      AND (
                            (class_name = ? AND COALESCE(stream, '') = ?)
                            OR teacher_name = ?
                            OR (? <> '' AND room = ?)
                      )
                    LIMIT 1
                ";

                $conflict = $db->prepare($conflictSql);

                if (!$conflict) {
                    $error = 'Could not check timetable conflicts: ' . $db->error;
                } else {

                    $conflict->bind_param(
    'sssssisssss',
    $day,
    $academicYear,
    $term,
    $endTime,
    $startTime,
    $id,
    $className,
    $stream,
    $teacherName,
    $room,
    $room
);

                    /*
                     * The conflict query has 11 placeholders:
                     * day, year, term, end, start, id, class, stream,
                     * teacher, room-not-empty, room.
                     */

                    $conflict->execute();
                    $conflictResult = $conflict->get_result();
                    $conflictRow = $conflictResult ? $conflictResult->fetch_assoc() : null;
                    $conflict->close();

                    if ($conflictRow) {
                        $error = 'Timetable clash detected. The class, teacher or room already has a lesson during this time.';
                    } else {

                        if ($id > 0) {

                            $sql = "
                                UPDATE class_timetables SET
                                    timetable_code = ?,
                                    class_name = ?,
                                    stream = ?,
                                    subject_name = ?,
                                    teacher_name = ?,
                                    room = ?,
                                    day_of_week = ?,
                                    start_time = ?,
                                    end_time = ?,
                                    academic_year = ?,
                                    term = ?,
                                    lesson_type = ?,
                                    notes = ?,
                                    status = ?
                                WHERE id = ?
                            ";

                            $stmt = $db->prepare($sql);

                            if (!$stmt) {
                                $error = 'Could not prepare update: ' . $db->error;
                            } else {

                                $stmt->bind_param(
                                    'ssssssssssssssi',
                                    $timetableCode,
                                    $className,
                                    $stream,
                                    $subjectName,
                                    $teacherName,
                                    $room,
                                    $day,
                                    $startTime,
                                    $endTime,
                                    $academicYear,
                                    $term,
                                    $lessonType,
                                    $notes,
                                    $status,
                                    $id
                                );

                                if ($stmt->execute()) {
                                    $stmt->close();
                                    $_SESSION['timetable_message'] = 'Timetable lesson updated successfully.';
                                    redirectTimetable();
                                }

                                $error = 'Update failed: ' . $stmt->error;
                                $stmt->close();
                            }

                        } else {

                            $createdBy = (int)($_SESSION['user_id'] ?? 0);

                            $sql = "
                                INSERT INTO class_timetables (
                                    timetable_code,
                                    class_name,
                                    stream,
                                    subject_name,
                                    teacher_name,
                                    room,
                                    day_of_week,
                                    start_time,
                                    end_time,
                                    academic_year,
                                    term,
                                    lesson_type,
                                    notes,
                                    status,
                                    created_by
                                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            ";

                            $stmt = $db->prepare($sql);

                            if (!$stmt) {
                                $error = 'Could not prepare insert: ' . $db->error;
                            } else {

                                $stmt->bind_param(
                                    'ssssssssssssssi',
                                    $timetableCode,
                                    $className,
                                    $stream,
                                    $subjectName,
                                    $teacherName,
                                    $room,
                                    $day,
                                    $startTime,
                                    $endTime,
                                    $academicYear,
                                    $term,
                                    $lessonType,
                                    $notes,
                                    $status,
                                    $createdBy
                                );

                                if ($stmt->execute()) {
                                    $stmt->close();
                                    $_SESSION['timetable_message'] = 'Timetable lesson added successfully.';
                                    redirectTimetable();
                                }

                                $error = 'Could not save timetable lesson: ' . $stmt->error;
                                $stmt->close();
                            }
                        }
                    }
                }
            }
        }

        /* CHANGE STATUS */

        elseif ($action === 'status') {

            $id = (int)($_POST['id'] ?? 0);
            $newStatus = timetablePost('status');

            if ($id < 1 || !in_array($newStatus, $allowedStatuses, true)) {
                $error = 'Invalid timetable status request.';
            } else {

                $stmt = $db->prepare("
                    UPDATE class_timetables
                    SET status = ?
                    WHERE id = ?
                ");

                if ($stmt) {
                    $stmt->bind_param('si', $newStatus, $id);

                    if ($stmt->execute()) {
                        $stmt->close();
                        $_SESSION['timetable_message'] = 'Timetable status updated.';
                        redirectTimetable();
                    }

                    $error = 'Could not update status: ' . $stmt->error;
                    $stmt->close();
                } else {
                    $error = 'Could not prepare status update: ' . $db->error;
                }
            }
        }

        /* DELETE LESSON */

        elseif ($action === 'delete') {

            $id = (int)($_POST['id'] ?? 0);

            if ($id < 1) {
                $error = 'Invalid timetable record.';
            } else {

                $stmt = $db->prepare("
                    DELETE FROM class_timetables
                    WHERE id = ?
                ");

                if ($stmt) {
                    $stmt->bind_param('i', $id);

                    if ($stmt->execute()) {
                        $stmt->close();
                        $_SESSION['timetable_message'] = 'Timetable lesson deleted successfully.';
                        redirectTimetable();
                    }

                    $error = 'Could not delete lesson: ' . $stmt->error;
                    $stmt->close();
                } else {
                    $error = 'Could not prepare delete: ' . $db->error;
                }
            }
        }
    }
}

/* -------------------------------------------------------------------------
   FLASH MESSAGE
------------------------------------------------------------------------- */

if (!empty($_SESSION['timetable_message'])) {
    $success = $_SESSION['timetable_message'];
    unset($_SESSION['timetable_message']);
}

/* -------------------------------------------------------------------------
   FILTERS
------------------------------------------------------------------------- */

$search = trim((string)($_GET['search'] ?? ''));
$filterClass = trim((string)($_GET['class_name'] ?? ''));
$filterYear = trim((string)($_GET['academic_year'] ?? ''));
$filterTerm = trim((string)($_GET['term'] ?? ''));
$filterDay = trim((string)($_GET['day'] ?? ''));
$filterStatus = trim((string)($_GET['status'] ?? ''));

$where = [];
$params = [];
$types = '';

if ($search !== '') {
    $where[] = "(
        class_name LIKE ?
        OR subject_name LIKE ?
        OR teacher_name LIKE ?
        OR timetable_code LIKE ?
        OR room LIKE ?
    )";

    $searchLike = '%' . $search . '%';

    for ($i = 0; $i < 5; $i++) {
        $params[] = $searchLike;
        $types .= 's';
    }
}

if ($filterClass !== '') {
    $where[] = 'class_name = ?';
    $params[] = $filterClass;
    $types .= 's';
}

if ($filterYear !== '') {
    $where[] = 'academic_year = ?';
    $params[] = $filterYear;
    $types .= 's';
}

if ($filterTerm !== '') {
    $where[] = 'term = ?';
    $params[] = $filterTerm;
    $types .= 's';
}

if ($filterDay !== '') {
    $where[] = 'day_of_week = ?';
    $params[] = $filterDay;
    $types .= 's';
}

if ($filterStatus !== '') {
    $where[] = 'status = ?';
    $params[] = $filterStatus;
    $types .= 's';
}

$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

/* -------------------------------------------------------------------------
   STATISTICS
------------------------------------------------------------------------- */

$statistics = [
    'total' => 0,
    'active' => 0,
    'cancelled' => 0,
    'teachers' => 0
];

$statsResult = $db->query("
    SELECT
        COUNT(*) AS total,
        SUM(status = 'active') AS active,
        SUM(status = 'cancelled') AS cancelled,
        COUNT(DISTINCT teacher_name) AS teachers
    FROM class_timetables
");

if ($statsResult) {
    $statistics = array_merge($statistics, $statsResult->fetch_assoc());
}

/* -------------------------------------------------------------------------
   FILTER OPTIONS
------------------------------------------------------------------------- */

$classOptions = [];
$yearOptions = [];

$result = $db->query("
    SELECT DISTINCT class_name
    FROM class_timetables
    WHERE class_name <> ''
    ORDER BY class_name
");

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $classOptions[] = $row['class_name'];
    }
}

$result = $db->query("
    SELECT DISTINCT academic_year
    FROM class_timetables
    WHERE academic_year <> ''
    ORDER BY academic_year DESC
");

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $yearOptions[] = $row['academic_year'];
    }
}

/* -------------------------------------------------------------------------
   LOAD TIMETABLE RECORDS
------------------------------------------------------------------------- */

$sql = "
    SELECT *
    FROM class_timetables
    $whereSql
    ORDER BY
        FIELD(day_of_week,
            'Monday',
            'Tuesday',
            'Wednesday',
            'Thursday',
            'Friday',
            'Saturday',
            'Sunday'
        ),
        start_time ASC
";

$stmt = $db->prepare($sql);

$timetableRows = [];

if ($stmt) {

    if ($types !== '') {
        $stmt->bind_param($types, ...$params);
    }

    if ($stmt->execute()) {
        $result = $stmt->get_result();

        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $timetableRows[] = $row;
            }
        }
    } else {
        $error = $error ?: 'Could not load timetable: ' . $stmt->error;
    }

    $stmt->close();

} else {
    $error = $error ?: 'Could not prepare timetable query: ' . $db->error;
}

/* -------------------------------------------------------------------------
   LOAD EDIT RECORD
------------------------------------------------------------------------- */

$editRecord = null;
$editId = (int)($_GET['edit'] ?? 0);

if ($editId > 0) {

    $editStmt = $db->prepare("
        SELECT *
        FROM class_timetables
        WHERE id = ?
        LIMIT 1
    ");

    if ($editStmt) {
        $editStmt->bind_param('i', $editId);
        $editStmt->execute();

        $editResult = $editStmt->get_result();
        $editRecord = $editResult ? $editResult->fetch_assoc() : null;

        $editStmt->close();
    }

    if (!$editRecord) {
        $error = 'The timetable record you selected was not found.';
    }
}

/* -------------------------------------------------------------------------
   GROUP RECORDS BY DAY
------------------------------------------------------------------------- */

$weeklyTimetable = [];

foreach ($days as $day) {
    $weeklyTimetable[$day] = [];
}

foreach ($timetableRows as $lesson) {
    if (isset($weeklyTimetable[$lesson['day_of_week']])) {
        $weeklyTimetable[$lesson['day_of_week']][] = $lesson;
    }
}

$formRecord = $editRecord ?: [
    'id' => 0,
    'timetable_code' => '',
    'class_name' => '',
    'stream' => '',
    'subject_name' => '',
    'teacher_name' => '',
    'room' => '',
    'day_of_week' => 'Monday',
    'start_time' => '',
    'end_time' => '',
    'academic_year' => date('Y'),
    'term' => 'Term 1',
    'lesson_type' => 'Lesson',
    'notes' => '',
    'status' => 'active'
];

$formStartTime = !empty($formRecord['start_time'])
    ? substr($formRecord['start_time'], 0, 5)
    : '';

$formEndTime = !empty($formRecord['end_time'])
    ? substr($formRecord['end_time'], 0, 5)
    : '';

?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Class Timetable - School Management System</title>

    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <link rel="stylesheet"
          href="/assets/css/sidebar-unified.css?v=20261106">

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: #f4f6f9;
            font-family: Arial, Helvetica, sans-serif;
        }

        /* SIDEBAR */

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100vh;
            background: #343a40;
            color: #fff;
            z-index: 1050;
            transition: all .3s ease;
            overflow-y: auto;
        }

        .sidebar-header {
            height: 70px;
            display: flex;
            align-items: center;
            padding: 0 20px;
            background: #212529;
            font-size: 20px;
            font-weight: bold;
        }

        .sidebar-header i {
            margin-right: 10px;
        }

        .sidebar-menu {
            padding: 15px 0;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            color: #ced4da;
            padding: 13px 20px;
            text-decoration: none;
            font-size: 15px;
            transition: .2s;
        }

        .sidebar-menu a i {
            width: 28px;
            font-size: 17px;
        }

        .sidebar-menu a:hover {
            background: #495057;
            color: #fff;
        }

        .sidebar-menu a.active {
            background: #007bff;
            color: #fff;
        }

        .sidebar-menu .logout {
            color: #ffb3b3;
        }

        .sidebar-menu .logout:hover {
            background: #dc3545;
            color: #fff;
        }

        /* MAIN CONTENT */

        .main-content {
            margin-left: 250px;
            min-height: 100vh;
            transition: all .3s ease;
        }

        .topbar {
            height: 70px;
            background: #fff;
            border-bottom: 1px solid #dee2e6;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 25px;
        }

        .menu-btn {
            border: none;
            background: #343a40;
            color: #fff;
            width: 42px;
            height: 42px;
            border-radius: 5px;
            display: none;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }

        .page-content {
            padding: 30px;
        }

        .page-title {
            font-size: 27px;
            font-weight: 600;
            color: #343a40;
            margin-bottom: 5px;
        }

        .page-subtitle {
            color: #6c757d;
            margin-bottom: 25px;
        }

        /* STATISTICS */

        .stat-card {
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,.06);
            display: flex;
            align-items: center;
        }

        .stat-icon {
            width: 58px;
            height: 58px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin-right: 15px;
            flex-shrink: 0;
        }

        .stat-icon.blue {
            background: #e7f1ff;
            color: #007bff;
        }

        .stat-icon.green {
            background: #e8f8ef;
            color: #28a745;
        }

        .stat-icon.orange {
            background: #fff3df;
            color: #fd7e14;
        }

        .stat-icon.purple {
            background: #f0e8ff;
            color: #6f42c1;
        }

        .stat-number {
            font-size: 25px;
            font-weight: bold;
            color: #343a40;
        }

        .stat-label {
            color: #6c757d;
            font-size: 14px;
        }

        /* PANELS */

        .section-card {
            background: #fff;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,.06);
            margin-bottom: 30px;
        }

        .section-title {
            font-size: 19px;
            font-weight: 600;
            color: #343a40;
            margin-bottom: 20px;
        }

        .form-control {
            height: 42px;
            border-radius: 6px;
        }

        textarea.form-control {
            height: auto;
        }

        .btn {
            border-radius: 5px;
        }

        /* TIMETABLE */

        .day-card {
            background: #fff;
            border: 1px solid #e9ecef;
            border-radius: 9px;
            margin-bottom: 20px;
            overflow: hidden;
            height: calc(100% - 20px);
        }

        .day-heading {
            background: #343a40;
            color: #fff;
            padding: 13px 15px;
            font-weight: bold;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .day-body {
            padding: 12px;
            min-height: 100px;
        }

        .lesson-card {
            border-left: 4px solid #007bff;
            background: #f8f9fa;
            padding: 12px;
            margin-bottom: 10px;
            border-radius: 5px;
        }

        .lesson-card.cancelled {
            border-left-color: #dc3545;
            opacity: .75;
        }

        .lesson-time {
            color: #007bff;
            font-weight: bold;
            font-size: 13px;
        }

        .lesson-subject {
            font-size: 16px;
            font-weight: bold;
            color: #343a40;
            margin: 5px 0;
        }

        .lesson-details {
            font-size: 12px;
            color: #6c757d;
            line-height: 1.7;
        }

        .lesson-actions {
            margin-top: 10px;
            display: flex;
            flex-wrap: wrap;
            gap: 5px;
        }

        .lesson-actions form {
            display: inline;
        }

        .empty-day {
            color: #adb5bd;
            text-align: center;
            padding: 20px 5px;
            font-size: 13px;
        }

        .table th {
            background: #f8f9fa;
            white-space: nowrap;
        }

        .table td {
            vertical-align: middle;
        }

        .filter-card {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,.06);
            margin-bottom: 25px;
        }

        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,.45);
            z-index: 1040;
        }

        /* COLLAPSED DESKTOP SIDEBAR */

        @media (min-width: 992px) {
            body.sidebar-collapsed .sidebar {
                width: 75px;
            }

            body.sidebar-collapsed .main-content {
                margin-left: 75px;
            }

            body.sidebar-collapsed .sidebar-header span,
            body.sidebar-collapsed .sidebar-menu span {
                display: none;
            }

            body.sidebar-collapsed .sidebar-header {
                justify-content: center;
                padding: 0;
            }

            body.sidebar-collapsed .sidebar-header i {
                margin-right: 0;
            }

            body.sidebar-collapsed .sidebar-menu a {
                justify-content: center;
                padding: 15px 0;
            }

            body.sidebar-collapsed .sidebar-menu a i {
                margin: 0;
                width: auto;
            }
        }

        /* MOBILE */

        @media (max-width: 991px) {
            .sidebar {
                left: -250px;
            }

            .sidebar.mobile-open {
                left: 0;
            }

            .main-content {
                margin-left: 0;
            }

            .menu-btn {
                display: flex;
            }

            .sidebar-overlay.active {
                display: block;
            }

            .page-content {
                padding: 20px 15px;
            }

            .topbar {
                padding: 0 15px;
            }

            .page-title {
                font-size: 23px;
            }
        }

        @media print {
            .sidebar,
            .sidebar-overlay,
            .topbar,
            .no-print,
            .lesson-actions {
                display: none !important;
            }

            .main-content {
                margin-left: 0 !important;
            }

            .page-content {
                padding: 0;
            }

            body {
                background: #fff;
            }

            .section-card,
            .day-card {
                box-shadow: none;
            }
        }
    </style>
</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar" id="sidebar">

    <div class="sidebar-header">
        <i class="fas fa-school"></i>
        <span>School System</span>
    </div>

    <div class="sidebar-menu">

        <a href="/admin/dashboard.php">
            <i class="fas fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>

        <a href="/admin/classes/index.php" class="active">
            <i class="fas fa-chalkboard"></i>
            <span>Classes</span>
        </a>

        <a href="/admin/students/list.php">
            <i class="fas fa-user-graduate"></i>
            <span>Students</span>
        </a>

        <a href="/admin/teachers/index.php">
            <i class="fas fa-chalkboard-teacher"></i>
            <span>Teachers</span>
        </a>

        <a href="/admin/bursar/index.php">
            <i class="fas fa-money-bill-wave"></i>
            <span>Bursar</span>
        </a>

        <a href="/admin/assets/index.php">
            <i class="fas fa-boxes"></i>
            <span>Assets</span>
        </a>

        <a href="/admin/staff/index.php">
            <i class="fas fa-users-cog"></i>
            <span>Other Staff</span>
        </a>

        <a href="/admin/projects/index.php">
            <i class="fas fa-project-diagram"></i>
            <span>School Projects</span>
        </a>

        <a href="/admin/users/index.php">
            <i class="fas fa-users"></i>
            <span>Users</span>
        </a>

        <a href="/logout.php" class="logout">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>

    </div>
</div>

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<!-- MAIN CONTENT -->

<div class="main-content">

    <div class="topbar no-print">

        <button type="button" class="menu-btn" id="menuBtn" title="Menu">
            <i class="fas fa-bars"></i>
        </button>

        <div class="ml-auto text-muted">
            <i class="fas fa-calendar-alt mr-1"></i>
            Class Timetable
        </div>

    </div>

    <div class="page-content">

        <!-- PAGE HEADING -->

        <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

            <div>
                <div class="page-title">Class Timetable</div>

                <div class="page-subtitle">
                    Create, manage and view school lesson timetables.
                </div>
            </div>

            <div class="mt-2 no-print">

                <button type="button"
                        onclick="window.print()"
                        class="btn btn-outline-secondary">
                    <i class="fas fa-print mr-1"></i>
                    Print Timetable
                </button>

                <a href="/admin/classes/index.php"
                   class="btn btn-outline-primary">
                    <i class="fas fa-arrow-left mr-1"></i>
                    Back to Classes
                </a>

            </div>

        </div>

        <!-- ALERTS -->

        <?php if ($success !== ''): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle mr-2"></i>
                <?= e($success) ?>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
        <?php endif; ?>

        <?php if ($error !== ''): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-triangle mr-2"></i>
                <?= e($error) ?>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
        <?php endif; ?>

        <!-- STATISTICS -->

        <div class="row">

            <div class="col-lg-3 col-md-6">
                <div class="stat-card">
                    <div class="stat-icon blue">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div>
                        <div class="stat-number">
                            <?= (int)$statistics['total'] ?>
                        </div>
                        <div class="stat-label">Total Lessons</div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="stat-card">
                    <div class="stat-icon green">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div>
                        <div class="stat-number">
                            <?= (int)$statistics['active'] ?>
                        </div>
                        <div class="stat-label">Active Lessons</div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="stat-card">
                    <div class="stat-icon orange">
                        <i class="fas fa-ban"></i>
                    </div>
                    <div>
                        <div class="stat-number">
                            <?= (int)$statistics['cancelled'] ?>
                        </div>
                        <div class="stat-label">Cancelled Lessons</div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="stat-card">
                    <div class="stat-icon purple">
                        <i class="fas fa-chalkboard-teacher"></i>
                    </div>
                    <div>
                        <div class="stat-number">
                            <?= (int)$statistics['teachers'] ?>
                        </div>
                        <div class="stat-label">Teachers Assigned</div>
                    </div>
                </div>
            </div>

        </div>

        <!-- ADD / EDIT FORM -->

        <div class="section-card no-print" id="lessonForm">

            <div class="section-title">

                <i class="fas fa-<?= $editRecord ? 'edit' : 'plus-circle' ?> mr-2 text-primary"></i>

                <?= $editRecord ? 'Edit Timetable Lesson' : 'Add Timetable Lesson' ?>

            </div>

            <form method="POST" action="timetable.php">

                <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                <input type="hidden" name="action" value="save">
                <input type="hidden" name="id" value="<?= (int)$formRecord['id'] ?>">

                <div class="form-row">

                    <div class="form-group col-lg-3 col-md-6">
                        <label>Class Name <span class="text-danger">*</span></label>
                        <input type="text"
                               name="class_name"
                               class="form-control"
                               list="classNames"
                               value="<?= e($formRecord['class_name']) ?>"
                               placeholder="e.g. Senior One"
                               required>

                        <datalist id="classNames">
                            <?php foreach ($classOptions as $classOption): ?>
                                <option value="<?= e($classOption) ?>">
                            <?php endforeach; ?>
                        </datalist>
                    </div>

                    <div class="form-group col-lg-3 col-md-6">
                        <label>Stream / Section</label>
                        <input type="text"
                               name="stream"
                               class="form-control"
                               value="<?= e($formRecord['stream']) ?>"
                               placeholder="e.g. East">
                    </div>

                    <div class="form-group col-lg-3 col-md-6">
                        <label>Subject <span class="text-danger">*</span></label>
                        <input type="text"
                               name="subject_name"
                               class="form-control"
                               value="<?= e($formRecord['subject_name']) ?>"
                               placeholder="Subject name"
                               required>
                    </div>

                    <div class="form-group col-lg-3 col-md-6">
                        <label>Teacher Name <span class="text-danger">*</span></label>
                        <input type="text"
                               name="teacher_name"
                               class="form-control"
                               value="<?= e($formRecord['teacher_name']) ?>"
                               placeholder="Full teacher name"
                               required>
                    </div>

                    <div class="form-group col-lg-3 col-md-6">
                        <label>Day <span class="text-danger">*</span></label>
                        <select name="day_of_week" class="form-control" required>
                            <?php foreach ($days as $day): ?>
                                <option value="<?= e($day) ?>"
                                    <?= $formRecord['day_of_week'] === $day ? 'selected' : '' ?>>
                                    <?= e($day) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group col-lg-3 col-md-6">
                        <label>Start Time <span class="text-danger">*</span></label>
                        <input type="time"
                               name="start_time"
                               class="form-control"
                               value="<?= e($formStartTime) ?>"
                               required>
                    </div>

                    <div class="form-group col-lg-3 col-md-6">
                        <label>End Time <span class="text-danger">*</span></label>
                        <input type="time"
                               name="end_time"
                               class="form-control"
                               value="<?= e($formEndTime) ?>"
                               required>
                    </div>

                    <div class="form-group col-lg-3 col-md-6">
                        <label>Room</label>
                        <input type="text"
                               name="room"
                               class="form-control"
                               value="<?= e($formRecord['room']) ?>"
                               placeholder="Room / Venue">
                    </div>

                    <div class="form-group col-lg-3 col-md-6">
                        <label>Academic Year <span class="text-danger">*</span></label>
                        <input type="text"
                               name="academic_year"
                               class="form-control"
                               value="<?= e($formRecord['academic_year']) ?>"
                               placeholder="e.g. 2026"
                               required>
                    </div>

                    <div class="form-group col-lg-3 col-md-6">
                        <label>Term <span class="text-danger">*</span></label>
                        <select name="term" class="form-control" required>
                            <?php foreach ($terms as $term): ?>
                                <option value="<?= e($term) ?>"
                                    <?= $formRecord['term'] === $term ? 'selected' : '' ?>>
                                    <?= e($term) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group col-lg-3 col-md-6">
                        <label>Lesson Type</label>
                        <select name="lesson_type" class="form-control">
                            <?php foreach ($lessonTypes as $type): ?>
                                <option value="<?= e($type) ?>"
                                    <?= $formRecord['lesson_type'] === $type ? 'selected' : '' ?>>
                                    <?= e($type) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group col-lg-3 col-md-6">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <option value="active"
                                <?= $formRecord['status'] === 'active' ? 'selected' : '' ?>>
                                Active
                            </option>
                            <option value="cancelled"
                                <?= $formRecord['status'] === 'cancelled' ? 'selected' : '' ?>>
                                Cancelled
                            </option>
                        </select>
                    </div>

                    <div class="form-group col-12">
                        <label>Notes</label>
                        <textarea name="notes"
                                  class="form-control"
                                  rows="2"
                                  placeholder="Optional lesson information"><?= e($formRecord['notes']) ?></textarea>
                    </div>

                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save mr-1"></i>
                    <?= $editRecord ? 'Update Lesson' : 'Save Lesson' ?>
                </button>

                <?php if ($editRecord): ?>
                    <a href="timetable.php" class="btn btn-secondary">
                        Cancel Editing
                    </a>
                <?php else: ?>
                    <button type="reset" class="btn btn-outline-secondary">
                        Clear Form
                    </button>
                <?php endif; ?>

            </form>

        </div>

        <!-- FILTERS -->

        <div class="filter-card no-print">

            <div class="section-title">
                <i class="fas fa-filter mr-2 text-primary"></i>
                Filter Timetable
            </div>

            <form method="GET" action="timetable.php">

                <div class="form-row">

                    <div class="form-group col-lg-3 col-md-6">
                        <label>Search</label>
                        <input type="text"
                               name="search"
                               class="form-control"
                               value="<?= e($search) ?>"
                               placeholder="Class, subject, teacher...">
                    </div>

                    <div class="form-group col-lg-2 col-md-6">
                        <label>Class</label>
                        <select name="class_name" class="form-control">
                            <option value="">All Classes</option>
                            <?php foreach ($classOptions as $classOption): ?>
                                <option value="<?= e($classOption) ?>"
                                    <?= $filterClass === $classOption ? 'selected' : '' ?>>
                                    <?= e($classOption) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group col-lg-2 col-md-6">
                        <label>Academic Year</label>
                        <select name="academic_year" class="form-control">
                            <option value="">All Years</option>
                            <?php foreach ($yearOptions as $yearOption): ?>
                                <option value="<?= e($yearOption) ?>"
                                    <?= $filterYear === $yearOption ? 'selected' : '' ?>>
                                    <?= e($yearOption) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group col-lg-2 col-md-6">
                        <label>Term</label>
                        <select name="term" class="form-control">
                            <option value="">All Terms</option>
                            <?php foreach ($terms as $term): ?>
                                <option value="<?= e($term) ?>"
                                    <?= $filterTerm === $term ? 'selected' : '' ?>>
                                    <?= e($term) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group col-lg-1 col-md-6">
                        <label>Day</label>
                        <select name="day" class="form-control">
                            <option value="">All</option>
                            <?php foreach ($days as $day): ?>
                                <option value="<?= e($day) ?>"
                                    <?= $filterDay === $day ? 'selected' : '' ?>>
                                    <?= e(substr($day, 0, 3)) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group col-lg-2 col-md-6">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <option value="">All Statuses</option>
                            <option value="active" <?= $filterStatus === 'active' ? 'selected' : '' ?>>
                                Active
                            </option>
                            <option value="cancelled" <?= $filterStatus === 'cancelled' ? 'selected' : '' ?>>
                                Cancelled
                            </option>
                        </select>
                    </div>

                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search mr-1"></i>
                    Apply Filters
                </button>

                <a href="timetable.php" class="btn btn-outline-secondary">
                    Reset Filters
                </a>

            </form>

        </div>

        <!-- WEEKLY TIMETABLE -->

        <div class="section-card">

            <div class="d-flex flex-wrap justify-content-between align-items-center mb-3">

                <div class="section-title mb-0">
                    <i class="fas fa-calendar-week mr-2 text-primary"></i>
                    Weekly Timetable
                </div>

                <span class="badge badge-primary">
                    <?= count($timetableRows) ?> lessons displayed
                </span>

            </div>

            <div class="row">

                <?php foreach ($days as $day): ?>

                    <?php
                    $dayLessons = $weeklyTimetable[$day];
                    ?>

                    <div class="col-xl-4 col-md-6 mb-3">

                        <div class="day-card">

                            <div class="day-heading">
                                <span><?= e($day) ?></span>
                                <span class="badge badge-light">
                                    <?= count($dayLessons) ?>
                                </span>
                            </div>

                            <div class="day-body">

                                <?php if (empty($dayLessons)): ?>

                                    <div class="empty-day">
                                        <i class="far fa-calendar-times fa-2x mb-2"></i>
                                        <br>
                                        No lessons scheduled
                                    </div>

                                <?php else: ?>

                                    <?php foreach ($dayLessons as $lesson): ?>

                                        <div class="lesson-card <?= $lesson['status'] === 'cancelled' ? 'cancelled' : '' ?>">

                                            <div class="lesson-time">
                                                <i class="far fa-clock mr-1"></i>
                                                <?= e(date('g:i A', strtotime($lesson['start_time']))) ?>
                                                -
                                                <?= e(date('g:i A', strtotime($lesson['end_time']))) ?>
                                            </div>

                                            <div class="lesson-subject">
                                                <?= e($lesson['subject_name']) ?>
                                            </div>

                                            <div class="lesson-details">

                                                <div>
                                                    <i class="fas fa-chalkboard mr-1"></i>
                                                    <?= e($lesson['class_name']) ?>
                                                    <?php if (!empty($lesson['stream'])): ?>
                                                        - <?= e($lesson['stream']) ?>
                                                    <?php endif; ?>
                                                </div>

                                                <div>
                                                    <i class="fas fa-user-tie mr-1"></i>
                                                    <?= e($lesson['teacher_name']) ?>
                                                </div>

                                                <?php if (!empty($lesson['room'])): ?>
                                                    <div>
                                                        <i class="fas fa-door-open mr-1"></i>
                                                        <?= e($lesson['room']) ?>
                                                    </div>
                                                <?php endif; ?>

                                                <div>
                                                    <i class="fas fa-calendar mr-1"></i>
                                                    <?= e($lesson['academic_year']) ?>
                                                    - <?= e($lesson['term']) ?>
                                                </div>

                                                <div>
                                                    <span class="badge badge-info">
                                                        <?= e($lesson['lesson_type']) ?>
                                                    </span>

                                                    <?php if ($lesson['status'] === 'active'): ?>
                                                        <span class="badge badge-success">Active</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-danger">Cancelled</span>
                                                    <?php endif; ?>
                                                </div>

                                            </div>

                                            <div class="lesson-actions no-print">

                                                <a href="timetable.php?edit=<?= (int)$lesson['id'] ?>"
                                                   class="btn btn-sm btn-primary">
                                                    <i class="fas fa-edit"></i> Edit
                                                </a>

                                                <form method="POST"
                                                      action="timetable.php"
                                                      onsubmit="return confirm('Change this lesson status?');">

                                                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                                                    <input type="hidden" name="action" value="status">
                                                    <input type="hidden" name="id" value="<?= (int)$lesson['id'] ?>">

                                                    <?php if ($lesson['status'] === 'active'): ?>
                                                        <input type="hidden" name="status" value="cancelled">
                                                        <button type="submit" class="btn btn-sm btn-warning">
                                                            <i class="fas fa-ban"></i>
                                                        </button>
                                                    <?php else: ?>
                                                        <input type="hidden" name="status" value="active">
                                                        <button type="submit" class="btn btn-sm btn-success">
                                                            <i class="fas fa-check"></i>
                                                        </button>
                                                    <?php endif; ?>

                                                </form>

                                                <form method="POST"
                                                      action="timetable.php"
                                                      onsubmit="return confirm('Permanently delete this timetable lesson?');">

                                                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="id" value="<?= (int)$lesson['id'] ?>">

                                                    <button type="submit" class="btn btn-sm btn-danger">
                                                        <i class="fas fa-trash"></i>
                                                    </button>

                                                </form>

                                            </div>

                                        </div>

                                    <?php endforeach; ?>

                                <?php endif; ?>

                            </div>

                        </div>

                    </div>

                <?php endforeach; ?>

            </div>

        </div>

        <!-- TIMETABLE TABLE -->

        <div class="section-card">

            <div class="section-title">
                <i class="fas fa-list mr-2 text-primary"></i>
                Timetable Records
            </div>

            <div class="table-responsive">

                <table class="table table-bordered table-hover">

                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Class</th>
                        <th>Subject</th>
                        <th>Teacher</th>
                        <th>Day</th>
                        <th>Time</th>
                        <th>Year</th>
                        <th>Term</th>
                        <th>Status</th>
                        <th class="no-print">Actions</th>
                    </tr>
                    </thead>

                    <tbody>

                    <?php if (empty($timetableRows)): ?>

                        <tr>
                            <td colspan="10" class="text-center text-muted py-4">
                                No timetable records found.
                            </td>
                        </tr>

                    <?php else: ?>

                        <?php $number = 1; ?>

                        <?php foreach ($timetableRows as $lesson): ?>

                            <tr>

                                <td><?= $number++ ?></td>

                                <td>
                                    <strong><?= e($lesson['class_name']) ?></strong>
                                    <?php if (!empty($lesson['stream'])): ?>
                                        <br><small class="text-muted"><?= e($lesson['stream']) ?></small>
                                    <?php endif; ?>
                                </td>

                                <td><?= e($lesson['subject_name']) ?></td>

                                <td><?= e($lesson['teacher_name']) ?></td>

                                <td><?= e($lesson['day_of_week']) ?></td>

                                <td>
                                    <?= e(date('g:i A', strtotime($lesson['start_time']))) ?>
                                    -
                                    <?= e(date('g:i A', strtotime($lesson['end_time']))) ?>
                                </td>

                                <td><?= e($lesson['academic_year']) ?></td>

                                <td><?= e($lesson['term']) ?></td>

                                <td>
                                    <?php if ($lesson['status'] === 'active'): ?>
                                        <span class="badge badge-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Cancelled</span>
                                    <?php endif; ?>
                                </td>

                                <td class="no-print">

                                    <a href="timetable.php?edit=<?= (int)$lesson['id'] ?>"
                                       class="btn btn-sm btn-primary"
                                       title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>

                                    <form method="POST"
                                          action="timetable.php"
                                          class="d-inline"
                                          onsubmit="return confirm('Delete this timetable lesson?');">

                                        <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?= (int)$lesson['id'] ?>">

                                        <button type="submit"
                                                class="btn btn-sm btn-danger"
                                                title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </button>

                                    </form>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
    const sidebar = document.getElementById('sidebar');
    const menuBtn = document.getElementById('menuBtn');
    const overlay = document.getElementById('sidebarOverlay');

    menuBtn.addEventListener('click', function () {
        if (window.innerWidth <= 991) {
            sidebar.classList.toggle('mobile-open');
            overlay.classList.toggle('active');
        } else {
            document.body.classList.toggle('sidebar-collapsed');
        }
    });

    overlay.addEventListener('click', function () {
        sidebar.classList.remove('mobile-open');
        overlay.classList.remove('active');
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            sidebar.classList.remove('mobile-open');
            overlay.classList.remove('active');
        }
    });

    document.querySelectorAll('.sidebar-menu a').forEach(function (link) {
        link.addEventListener('click', function () {
            if (window.innerWidth <= 991) {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('active');
            }
        });
    });

    <?php if ($editRecord): ?>
    window.addEventListener('load', function () {
        document.getElementById('lessonForm').scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    });
    <?php endif; ?>
</script>

</body>
</html>
