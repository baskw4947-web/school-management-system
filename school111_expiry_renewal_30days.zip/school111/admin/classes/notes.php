<?php
/**
 * Subject Notes / Lesson Materials Management
 * Install at /admin/classes/notes.php
 * Save as UTF-8 without BOM (the opening PHP tag must be first).
 */
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator', 'teacher', 'subject_teacher', 'headteacher', 'head_teacher']);

if (!isset($conn) || !($conn instanceof mysqli)) {
    http_response_code(500);
    exit('Database connection is unavailable. Please check config/database.php.');
}
$conn->set_charset('utf8mb4');
$userId = (int)($_SESSION['user_id'] ?? $_SESSION['id'] ?? ($_SESSION['user']['id'] ?? 0));

const NOTE_MAX_UPLOAD_BYTES = 26214400; // 25 MB

function notes_e($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}
function notes_ident(string $name): string {
    return '`' . str_replace('`', '``', $name) . '`';
}
function notes_table_map(mysqli $db): array {
    $map = [];
    $result = $db->query('SHOW TABLES');
    while ($row = $result->fetch_row()) $map[strtolower((string)$row[0])] = (string)$row[0];
    $result->free();
    return $map;
}
function notes_columns(mysqli $db, string $table): array {
    $columns = [];
    $result = $db->query('SHOW COLUMNS FROM ' . notes_ident($table));
    while ($row = $result->fetch_assoc()) $columns[strtolower((string)$row['Field'])] = $row;
    $result->free();
    return $columns;
}
function notes_pick(array $columns, array $candidates): ?string {
    foreach ($candidates as $name) {
        $key = strtolower($name);
        if (isset($columns[$key])) return (string)$columns[$key]['Field'];
    }
    return null;
}
function notes_enum_values(?string $type): array {
    if (!$type || stripos($type, 'enum(') !== 0) return [];
    preg_match_all("/'((?:[^'\\\\]|\\\\.)*)'/", $type, $matches);
    return array_map(static fn($v) => stripcslashes($v), $matches[1] ?? []);
}
function notes_bind(mysqli_stmt $stmt, string $types, array &$values): void {
    $args = [$types];
    foreach ($values as &$value) $args[] = &$value;
    call_user_func_array([$stmt, 'bind_param'], $args);
}
function notes_flash(string $type, string $message): void {
    $_SESSION['subject_notes_flash'] = ['type' => $type, 'message' => $message];
}
function notes_redirect(string $url = 'notes.php'): void {
    header('Location: ' . $url);
    exit;
}
function notes_make_code(mysqli $db, ?string $column): string {
    if (!$column) return '';
    for ($i = 0; $i < 12; $i++) {
        $code = 'NOTE-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
        $stmt = $db->prepare('SELECT 1 FROM `subject_notes` WHERE ' . notes_ident($column) . ' = ? LIMIT 1');
        $stmt->bind_param('s', $code);
        $stmt->execute();
        $exists = (bool)$stmt->get_result()->fetch_row();
        $stmt->close();
        if (!$exists) return $code;
    }
    throw new RuntimeException('Could not generate a unique note reference. Please try again.');
}
function notes_safe_delete(string $relativePath): void {
    if ($relativePath === '' || strpos($relativePath, 'uploads/subject_notes/') !== 0) return;
    $root = realpath(__DIR__ . '/../../uploads/subject_notes');
    $path = realpath(__DIR__ . '/../../' . $relativePath);
    if ($root && $path && strpos($path, $root . DIRECTORY_SEPARATOR) === 0 && is_file($path)) @unlink($path);
}
function notes_lookup_names(mysqli $db, array $tables, array $tableCandidates, array $nameCandidates): array {
    $table = null;
    foreach ($tableCandidates as $candidate) {
        if (isset($tables[strtolower($candidate)])) { $table = $tables[strtolower($candidate)]; break; }
    }
    if (!$table) return [];
    try {
        $columns = notes_columns($db, $table);
        $name = notes_pick($columns, $nameCandidates);
        if (!$name) return [];
        $result = $db->query('SELECT DISTINCT TRIM(CAST(' . notes_ident($name) . ' AS CHAR)) AS item_name FROM ' . notes_ident($table) . ' WHERE ' . notes_ident($name) . ' IS NOT NULL AND TRIM(CAST(' . notes_ident($name) . ' AS CHAR)) <> \'\' ORDER BY item_name');
        $values = [];
        while ($row = $result->fetch_assoc()) $values[] = (string)$row['item_name'];
        $result->free();
        return array_values(array_unique($values));
    } catch (Throwable $e) {
        error_log('Subject notes lookup (' . $table . '): ' . $e->getMessage());
        return [];
    }
}
function notes_normalize_row(array $row, array $map): array {
    $get = static function (string $key, $default = '') use ($row, $map) {
        $column = $map[$key] ?? null;
        return $column && array_key_exists($column, $row) ? ($row[$column] ?? $default) : $default;
    };
    return [
        'id' => (int)$get('id', 0),
        'code' => (string)$get('code'),
        'title' => (string)$get('title'),
        'subject' => (string)$get('subject'),
        'class' => (string)$get('class'),
        'year' => (string)$get('year'),
        'term' => (string)$get('term'),
        'topic' => (string)$get('topic'),
        'description' => (string)$get('description'),
        'content' => (string)$get('content'),
        'file_name' => (string)$get('file_name'),
        'file_path' => (string)$get('file_path'),
        'file_mime' => (string)$get('file_mime'),
        'file_size' => (int)$get('file_size', 0),
        'status' => (string)$get('status', 'published'),
        'created_by' => (int)$get('created_by', 0),
        'created_at' => (string)$get('created_at'),
        'updated_at' => (string)$get('updated_at'),
    ];
}

if (empty($_SESSION['subject_notes_csrf'])) $_SESSION['subject_notes_csrf'] = bin2hex(random_bytes(32));
$csrfToken = (string)$_SESSION['subject_notes_csrf'];
$flash = $_SESSION['subject_notes_flash'] ?? null;
unset($_SESSION['subject_notes_flash']);
$schemaError = '';
$pageError = '';
$createdTable = false;
$map = [];
$columns = [];
$statusValues = [];
$subjectOptions = [];
$classOptions = [];
$allNotes = [];
$shownNotes = [];
$search = trim((string)($_GET['q'] ?? ''));
$filterSubject = trim((string)($_GET['subject'] ?? ''));
$filterClass = trim((string)($_GET['class'] ?? ''));
$filterStatus = trim((string)($_GET['status'] ?? ''));
$filterYear = trim((string)($_GET['year'] ?? ''));
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 15;
$totalPages = 1;
$editNote = null;
$uploadDir = __DIR__ . '/../../uploads/subject_notes';
$uploadRelativeDir = 'uploads/subject_notes';
$allowedExtensions = ['pdf','doc','docx','ppt','pptx','xls','xlsx','txt','rtf','odt','ods','odp','jpg','jpeg','png','gif','webp','mp3','wav','m4a','mp4','webm'];

try {
    $tables = notes_table_map($conn);
    if (!isset($tables['subject_notes'])) {
        $conn->query("CREATE TABLE `subject_notes` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `note_code` VARCHAR(40) DEFAULT NULL,
            `title` VARCHAR(200) NOT NULL,
            `subject_name` VARCHAR(150) NOT NULL,
            `class_name` VARCHAR(100) DEFAULT NULL,
            `academic_year` VARCHAR(20) DEFAULT NULL,
            `term` VARCHAR(30) DEFAULT NULL,
            `topic` VARCHAR(180) DEFAULT NULL,
            `description` TEXT NULL,
            `note_content` LONGTEXT NULL,
            `file_name` VARCHAR(255) DEFAULT NULL,
            `file_path` VARCHAR(500) DEFAULT NULL,
            `file_mime` VARCHAR(150) DEFAULT NULL,
            `file_size` BIGINT UNSIGNED DEFAULT NULL,
            `status` ENUM('draft','published','archived') NOT NULL DEFAULT 'published',
            `uploaded_by` INT DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uq_subject_notes_code` (`note_code`),
            KEY `idx_subject_notes_subject` (`subject_name`),
            KEY `idx_subject_notes_class` (`class_name`),
            KEY `idx_subject_notes_status` (`status`),
            KEY `idx_subject_notes_year_term` (`academic_year`,`term`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $createdTable = true;
        $tables = notes_table_map($conn);
    }
    $columns = notes_columns($conn, $tables['subject_notes'] ?? 'subject_notes');
    $map = [
        'id' => notes_pick($columns, ['id','note_id']),
        'code' => notes_pick($columns, ['note_code','note_no','reference_no','code']),
        'title' => notes_pick($columns, ['title','note_title','lesson_title','topic_title']),
        'subject' => notes_pick($columns, ['subject_name','subject','subject_title']),
        'class' => notes_pick($columns, ['class_name','class_level','stream_name','class']),
        'year' => notes_pick($columns, ['academic_year','school_year','fiscal_year','year']),
        'term' => notes_pick($columns, ['term','semester']),
        'topic' => notes_pick($columns, ['topic','lesson_topic','unit_title']),
        'description' => notes_pick($columns, ['description','summary','remarks']),
        'content' => notes_pick($columns, ['note_content','content','lesson_content','body','notes']),
        'file_name' => notes_pick($columns, ['file_name','original_filename','attachment_name','material_name']),
        'file_path' => notes_pick($columns, ['file_path','attachment_path','material_path','file_url','attachment','file']),
        'file_mime' => notes_pick($columns, ['file_mime','mime_type','mime']),
        'file_size' => notes_pick($columns, ['file_size','filesize','size_bytes']),
        'status' => notes_pick($columns, ['status','publish_status']),
        'created_by' => notes_pick($columns, ['uploaded_by','created_by','teacher_id','user_id']),
        'created_at' => notes_pick($columns, ['created_at','uploaded_at','date_created','created_on']),
        'updated_at' => notes_pick($columns, ['updated_at','modified_at','updated_on']),
    ];
    if (!$map['id'] || !$map['title'] || !$map['subject']) {
        throw new RuntimeException('Your existing subject_notes table does not have the required ID, title and subject columns. Please share its Structure tab so this page can be matched to it.');
    }
    $statusValues = $map['status'] ? notes_enum_values((string)($columns[strtolower($map['status'])]['Type'] ?? '')) : [];
    $subjectOptions = notes_lookup_names($conn, $tables, ['subjects','school_subjects','academic_subjects','subject'], ['subject_name','name','title','subject','subject_title']);
    $classOptions = notes_lookup_names($conn, $tables, ['classes','school_classes','class_levels','classrooms','class'], ['class_name','class_level','name','title','stream_name']);
} catch (Throwable $e) {
    error_log('notes.php setup error: ' . $e->getMessage());
    $schemaError = $e instanceof RuntimeException ? $e->getMessage() : 'The subject notes table could not be prepared. Check the hosting PHP error log.';
}

// Download through an authenticated route. Never trust a path supplied by the URL.
if (isset($_GET['download']) && $schemaError === '' && $map['file_path']) {
    try {
        $downloadId = max(0, (int)$_GET['download']);
        $stmt = $conn->prepare('SELECT * FROM `subject_notes` WHERE ' . notes_ident($map['id']) . ' = ? LIMIT 1');
        $stmt->bind_param('i', $downloadId);
        $stmt->execute();
        $raw = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$raw) throw new RuntimeException('The requested material was not found.');
        $note = notes_normalize_row($raw, $map);
        $relative = $note['file_path'];
        if (strpos($relative, $uploadRelativeDir . '/') !== 0) throw new RuntimeException('The stored file path is not valid.');
        $base = realpath($uploadDir);
        $file = realpath(__DIR__ . '/../../' . $relative);
        if (!$base || !$file || strpos($file, $base . DIRECTORY_SEPARATOR) !== 0 || !is_file($file)) throw new RuntimeException('The uploaded material file could not be found on the server.');
        $downloadName = $note['file_name'] !== '' ? $note['file_name'] : basename($file);
        $downloadName = str_replace(["\r", "\n", '"'], ['', '', ''], $downloadName);
        $mime = $note['file_mime'] !== '' ? $note['file_mime'] : 'application/octet-stream';
        if (ob_get_length()) ob_clean();
        header('X-Content-Type-Options: nosniff');
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . (string)filesize($file));
        header('Content-Disposition: attachment; filename="' . basename($downloadName) . '"; filename*=UTF-8\'\'' . rawurlencode(basename($downloadName)));
        readfile($file);
        exit;
    } catch (Throwable $e) {
        notes_flash('danger', $e instanceof RuntimeException ? $e->getMessage() : 'Could not download this material.');
        notes_redirect();
    }
}

// Handle create/update/delete/status actions.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $schemaError === '') {
    $postedToken = (string)($_POST['csrf_token'] ?? '');
    if (!hash_equals($csrfToken, $postedToken)) {
        notes_flash('danger', 'Your form session expired. Refresh the page and try again.');
        notes_redirect();
    }
    $action = (string)($_POST['action'] ?? '');
    $newFileAbsolute = '';
    try {
        if ($action === 'save_note') {
            $id = max(0, (int)($_POST['note_id'] ?? 0));
            $title = trim((string)($_POST['title'] ?? ''));
            $subject = trim((string)($_POST['subject_name'] ?? ''));
            $className = trim((string)($_POST['class_name'] ?? ''));
            $year = trim((string)($_POST['academic_year'] ?? date('Y')));
            $term = trim((string)($_POST['term'] ?? ''));
            $topic = trim((string)($_POST['topic'] ?? ''));
            $description = trim((string)($_POST['description'] ?? ''));
            $content = trim((string)($_POST['note_content'] ?? ''));
            $requestedStatus = trim((string)($_POST['status'] ?? 'published'));
            if ($title === '') throw new RuntimeException('Enter a lesson note title.');
            if (mb_strlen($title) > 200) throw new RuntimeException('The title cannot exceed 200 characters.');
            if ($subject === '') throw new RuntimeException('Select or enter a subject.');
            if (mb_strlen($subject) > 150) throw new RuntimeException('The subject name cannot exceed 150 characters.');
            if ($year !== '' && mb_strlen($year) > 20) throw new RuntimeException('The academic year cannot exceed 20 characters.');
            if ($term !== '' && mb_strlen($term) > 30) throw new RuntimeException('The term cannot exceed 30 characters.');
            $statusOptions = $statusValues ?: ['draft','published','archived'];
            $status = in_array($requestedStatus, $statusOptions, true) ? $requestedStatus : (in_array('published', $statusOptions, true) ? 'published' : $statusOptions[0]);

            $oldNote = null;
            if ($id > 0) {
                $check = $conn->prepare('SELECT * FROM `subject_notes` WHERE ' . notes_ident($map['id']) . ' = ? LIMIT 1');
                $check->bind_param('i', $id);
                $check->execute();
                $oldRaw = $check->get_result()->fetch_assoc();
                $check->close();
                if (!$oldRaw) throw new RuntimeException('The note you are editing was not found. Refresh the page.');
                $oldNote = notes_normalize_row($oldRaw, $map);
            }

            $uploaded = false;
            if (isset($_FILES['attachment']) && (int)($_FILES['attachment']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
                $file = $_FILES['attachment'];
                if ((int)$file['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('The attachment could not be uploaded. Check the upload size settings and try again.');
                if ((int)$file['size'] < 1 || (int)$file['size'] > NOTE_MAX_UPLOAD_BYTES) throw new RuntimeException('Choose a file smaller than 25 MB.');
                $originalName = basename((string)$file['name']);
                $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
                if (!in_array($extension, $allowedExtensions, true)) throw new RuntimeException('Unsupported file type. Allowed: PDF, Word, PowerPoint, Excel, text, images, audio and video files.');
                if (!$map['file_path']) throw new RuntimeException('Your subject_notes table does not have a file path / attachment column, so uploads cannot be linked. Please share its Structure tab.');
                if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true) && !is_dir($uploadDir)) throw new RuntimeException('The upload directory could not be created. Create public_html/uploads/subject_notes and give PHP permission to write to it.');
                $randomName = bin2hex(random_bytes(16)) . '.' . $extension;
                $destination = $uploadDir . DIRECTORY_SEPARATOR . $randomName;
                if (!move_uploaded_file((string)$file['tmp_name'], $destination)) throw new RuntimeException('The uploaded file could not be saved. Check write permissions on uploads/subject_notes.');
                $newFileAbsolute = $destination;
                $filePath = $uploadRelativeDir . '/' . $randomName;
                $fileMime = 'application/octet-stream';
                if (function_exists('finfo_open')) {
                    $finfo = finfo_open(FILEINFO_MIME_TYPE);
                    if ($finfo) { $fileMime = (string)(finfo_file($finfo, $destination) ?: $fileMime); finfo_close($finfo); }
                }
                $fileSize = (int)filesize($destination);
                $uploaded = true;
            }
            if ($content === '' && !$uploaded && (!$oldNote || $oldNote['file_path'] === '')) throw new RuntimeException('Enter lesson note content or attach a learning material file.');

            $data = [];
            $types = '';
            $put = static function (?string $column, $value, string $type) use (&$data, &$types, $columns): void {
                if ($column && isset($columns[strtolower($column)])) { $data[$column] = $value; $types .= $type; }
            };
            if ($id < 1 && $map['code']) $put($map['code'], notes_make_code($conn, $map['code']), 's');
            $put($map['title'], $title, 's');
            $put($map['subject'], $subject, 's');
            $put($map['class'], $className !== '' ? $className : null, 's');
            $put($map['year'], $year !== '' ? $year : null, 's');
            $put($map['term'], $term !== '' ? $term : null, 's');
            $put($map['topic'], $topic !== '' ? $topic : null, 's');
            $put($map['description'], $description !== '' ? $description : null, 's');
            $put($map['content'], $content !== '' ? $content : null, 's');
            if ($uploaded) {
                $put($map['file_name'], $originalName, 's');
                $put($map['file_path'], $filePath, 's');
                $put($map['file_mime'], $fileMime, 's');
                $put($map['file_size'], $fileSize, 'i');
            }
            if ($map['status']) $put($map['status'], $status, 's');
            if ($id < 1 && $map['created_by']) {
                $colInfo = $columns[strtolower($map['created_by'])];
                if (strtoupper((string)$colInfo['Null']) === 'NO' && $colInfo['Default'] === null && $userId < 1) throw new RuntimeException('Your logged-in user ID could not be identified. Sign out and sign in again.');
                $put($map['created_by'], $userId > 0 ? $userId : null, 'i');
            }
            if ($id < 1 && $map['created_at']) {
                $ci = $columns[strtolower($map['created_at'])];
                if (strtoupper((string)$ci['Null']) === 'NO' && $ci['Default'] === null) $put($map['created_at'], date('Y-m-d H:i:s'), 's');
            }
            if ($id < 1) {
                foreach ($columns as $columnName => $info) {
                    if (array_key_exists((string)$info['Field'], $data)) continue;
                    if (stripos((string)$info['Extra'], 'auto_increment') !== false) continue;
                    if (strtoupper((string)$info['Null']) === 'YES' || $info['Default'] !== null) continue;
                    throw new RuntimeException('The subject_notes table has an additional required column named `' . $info['Field'] . '` without a default. Please share its Structure tab so this form can match it.');
                }
            }
            if ($id > 0) {
                if (!$data) throw new RuntimeException('No editable note fields were found in the current database table.');
                $set = [];
                foreach (array_keys($data) as $column) $set[] = notes_ident($column) . ' = ?';
                $values = array_values($data);
                $values[] = $id;
                $stmt = $conn->prepare('UPDATE `subject_notes` SET ' . implode(', ', $set) . ' WHERE ' . notes_ident($map['id']) . ' = ?');
                notes_bind($stmt, $types . 'i', $values);
                $stmt->execute();
                $stmt->close();
                if ($uploaded && $oldNote && $oldNote['file_path'] !== '') notes_safe_delete($oldNote['file_path']);
                notes_flash('success', 'Lesson note updated successfully.');
            } else {
                $columnSql = implode(', ', array_map('notes_ident', array_keys($data)));
                $marks = implode(', ', array_fill(0, count($data), '?'));
                $stmt = $conn->prepare('INSERT INTO `subject_notes` (' . $columnSql . ') VALUES (' . $marks . ')');
                $values = array_values($data);
                notes_bind($stmt, $types, $values);
                $stmt->execute();
                $stmt->close();
                notes_flash('success', 'Lesson note created successfully.');
            }
            notes_redirect();
        }

        if ($action === 'change_status') {
            if (!$map['status']) throw new RuntimeException('The subject_notes table has no supported status column.');
            $id = max(0, (int)($_POST['note_id'] ?? 0));
            $requested = trim((string)($_POST['new_status'] ?? ''));
            $statusOptions = $statusValues ?: ['draft','published','archived'];
            if ($id < 1 || !in_array($requested, $statusOptions, true)) throw new RuntimeException('Choose a valid note and status.');
            $stmt = $conn->prepare('UPDATE `subject_notes` SET ' . notes_ident($map['status']) . ' = ? WHERE ' . notes_ident($map['id']) . ' = ?');
            $stmt->bind_param('si', $requested, $id);
            $stmt->execute();
            $stmt->close();
            notes_flash('success', 'Lesson note status updated.');
            notes_redirect();
        }

        if ($action === 'delete_note') {
            $id = max(0, (int)($_POST['note_id'] ?? 0));
            if ($id < 1) throw new RuntimeException('Select a valid note to delete.');
            $stmt = $conn->prepare('SELECT * FROM `subject_notes` WHERE ' . notes_ident($map['id']) . ' = ? LIMIT 1');
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $raw = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if (!$raw) throw new RuntimeException('The note was already removed or could not be found.');
            $note = notes_normalize_row($raw, $map);
            $stmt = $conn->prepare('DELETE FROM `subject_notes` WHERE ' . notes_ident($map['id']) . ' = ?');
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $stmt->close();
            if ($note['file_path'] !== '') notes_safe_delete($note['file_path']);
            notes_flash('success', 'Lesson note deleted.');
            notes_redirect();
        }
        throw new RuntimeException('Invalid request. Refresh the page and try again.');
    } catch (Throwable $e) {
        if ($newFileAbsolute !== '' && is_file($newFileAbsolute)) @unlink($newFileAbsolute);
        error_log('notes.php action error: ' . $e->getMessage());
        notes_flash('danger', $e instanceof RuntimeException ? $e->getMessage() : 'The lesson note could not be saved. Review the database structure and PHP error log.');
        notes_redirect();
    }
}

// Read and filter records. Search and totals are computed after loading the normalized records.
if ($schemaError === '') {
    try {
        $idColumn = $map['id'];
        $result = $conn->query('SELECT * FROM `subject_notes` ORDER BY ' . notes_ident($idColumn) . ' DESC');
        while ($raw = $result->fetch_assoc()) $allNotes[] = notes_normalize_row($raw, $map);
        $result->free();
        $filtered = [];
        foreach ($allNotes as $note) {
            if ($filterSubject !== '' && strcasecmp($note['subject'], $filterSubject) !== 0) continue;
            if ($filterClass !== '' && strcasecmp($note['class'], $filterClass) !== 0) continue;
            if ($filterYear !== '' && $note['year'] !== $filterYear) continue;
            if ($filterStatus !== '' && strcasecmp($note['status'], $filterStatus) !== 0) continue;
            if ($search !== '') {
                $haystack = strtolower(implode(' ', [$note['code'],$note['title'],$note['subject'],$note['class'],$note['year'],$note['term'],$note['topic'],$note['description'],$note['content'],$note['file_name']]));
                if (strpos($haystack, strtolower($search)) === false) continue;
            }
            $filtered[] = $note;
        }
        $totalPages = max(1, (int)ceil(count($filtered) / $perPage));
        if ($page > $totalPages) $page = $totalPages;
        $shownNotes = array_slice($filtered, ($page - 1) * $perPage, $perPage);
    } catch (Throwable $e) {
        error_log('notes.php list error: ' . $e->getMessage());
        $pageError = 'Lesson notes could not be loaded. Please check the hosting PHP error log.';
    }
}

$editId = max(0, (int)($_GET['edit'] ?? 0));
if ($editId > 0 && $schemaError === '' && $pageError === '') {
    foreach ($allNotes as $candidate) if ($candidate['id'] === $editId) { $editNote = $candidate; break; }
    if (!$editNote) $pageError = 'The note selected for editing could not be found.';
}
$statusOptions = $statusValues ?: ['draft','published','archived'];
$stats = ['total' => count($allNotes), 'published' => 0, 'draft' => 0, 'files' => 0];
foreach ($allNotes as $note) {
    $s = strtolower($note['status']);
    if ($s === 'published') $stats['published']++;
    if ($s === 'draft') $stats['draft']++;
    if ($note['file_path'] !== '') $stats['files']++;
}
$yearOptions = [];
foreach ($allNotes as $note) if ($note['year'] !== '') $yearOptions[$note['year']] = true;
$yearOptions = array_keys($yearOptions);
rsort($yearOptions, SORT_NATURAL);
$subjectOptions = array_values(array_unique(array_merge($subjectOptions, array_filter(array_map(static fn($n) => $n['subject'], $allNotes)))));
$classOptions = array_values(array_unique(array_merge($classOptions, array_filter(array_map(static fn($n) => $n['class'], $allNotes)))));
sort($subjectOptions, SORT_NATURAL | SORT_FLAG_CASE);
sort($classOptions, SORT_NATURAL | SORT_FLAG_CASE);
$displayName = (string)($_SESSION['full_name'] ?? $_SESSION['name'] ?? 'Teacher');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Subject Notes | School Management System</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
:root{--navy:#17243a;--navy2:#243754;--bg:#f4f6fa;--blue:#2865cf;--muted:#778398;--accent:#70a7ff}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:#263348;font-family:Arial,Helvetica,sans-serif}.sidebar{position:fixed;top:0;left:0;bottom:0;width:250px;background:var(--navy);color:#fff;overflow-y:auto;z-index:1040;padding:20px 0}.brand{padding:0 22px 22px;border-bottom:1px solid rgba(255,255,255,.12);margin-bottom:16px}.brand h5{margin:0;font-weight:700}.brand small{color:#b8c5d8}.nav-label{color:#95a7c0;text-transform:uppercase;font-size:10px;letter-spacing:1.2px;padding:14px 22px 5px}.sidebar a{color:#d8e1ed;display:block;padding:10px 22px;text-decoration:none;font-size:13px;border-left:3px solid transparent}.sidebar a i{width:22px}.sidebar a:hover,.sidebar a.active{background:var(--navy2);color:#fff;border-left-color:var(--accent)}.main{margin-left:250px;min-height:100vh}.topbar{padding:18px 25px;background:#fff;border-bottom:1px solid #e7ebf2;display:flex;align-items:center;justify-content:space-between;gap:12px}.content{padding:24px}.page-head,.panel,.stat-card{background:#fff;border-radius:10px;box-shadow:0 3px 15px rgba(24,42,70,.05);border:1px solid #edf0f5}.page-head{padding:22px;margin-bottom:20px}.panel{padding:21px;margin-bottom:22px}.stat-card{padding:18px;height:100%;margin-bottom:18px}.stat-label{font-size:12px;color:var(--muted)}.stat-value{font-size:23px;font-weight:700;margin-top:6px;overflow-wrap:anywhere}.stat-icon{float:right;width:38px;height:38px;border-radius:9px;background:#eef4ff;color:#326bd1;text-align:center;line-height:38px}.panel-title{font-size:17px;font-weight:700;margin-bottom:17px;color:#1d2d44}.form-control,.custom-select,.btn{border-radius:6px}.form-control,.custom-select{font-size:13px;min-height:39px}label{font-size:12px;color:#4e5c70;font-weight:600}.table thead th{background:#f7f9fc;color:#68768a;font-size:10px;text-transform:uppercase;letter-spacing:.4px;border-top:0;white-space:nowrap}.table td{font-size:12px;vertical-align:middle}.btn{font-size:12px}.btn-primary{background:var(--blue);border-color:var(--blue)}.badge{font-size:10px;padding:6px 8px}.mobile-menu{display:none}.muted{color:#8490a1;font-size:11px}.note-title{font-weight:700;color:#243754}.content-preview{max-width:300px;white-space:normal;overflow-wrap:anywhere}.section-divider{border-top:1px solid #edf0f5;margin:18px 0}.upload-help{font-size:11px;color:#778398}.empty-state{padding:35px 10px;text-align:center;color:#8290a4}.empty-state i{font-size:30px;margin-bottom:12px;color:#bec8d7}.alert{font-size:13px}.footer-note{text-align:center;color:#97a1b1;font-size:11px;padding:7px 0 0}.form-required{color:#dc3545}@media(max-width:991px){.sidebar{transform:translateX(-100%);transition:transform .2s}.sidebar.show{transform:translateX(0)}.main{margin-left:0}.mobile-menu{display:inline-block!important}.content{padding:15px}.topbar{padding:14px 15px}.page-head,.panel{padding:16px}}@media print{.sidebar,.topbar,.no-print,.footer-note{display:none!important}.main{margin:0}.content{padding:0}body{background:#fff}.page-head,.panel,.stat-card{box-shadow:none;border:0}}
</style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<nav id="sidebar" class="sidebar no-print">
 <div class="brand"><h5><i class="fas fa-school mr-2"></i>School Management</h5><small>Teaching &amp; Learning</small></div>
 <div class="nav-label">Main</div>
 <a href="/admin/dashboard.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
 <a href="/admin/classes/index.php"><i class="fas fa-chalkboard"></i>Classes Dashboard</a>
 <div class="nav-label">Teaching</div>
 <a href="/admin/classes/notes.php" class="active"><i class="fas fa-book-open"></i>Subject Notes</a>
 <a href="/admin/classes/exams.php"><i class="fas fa-file-alt"></i>Examinations</a>
 <a href="/admin/classes/student_reports.php"><i class="fas fa-file-invoice"></i>Student Reports</a>
 <div class="nav-label">Account</div>
 <a href="/admin/dashboard.php"><i class="fas fa-user-shield"></i>Admin Dashboard</a>
 <a href="/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
</nav>
<main class="main">
 <div class="topbar"><div class="d-flex align-items-center"><button class="btn btn-outline-secondary mobile-menu mr-3" id="mobileMenuBtn" type="button" aria-label="Open menu"><i class="fas fa-bars"></i></button><div><div class="text-uppercase text-primary small font-weight-bold">Teaching &amp; Learning</div><strong>Subject Notes and Learning Materials</strong></div></div><div class="text-muted small"><i class="fas fa-user-circle mr-1"></i><?= notes_e($displayName) ?></div></div>
 <div class="content">
  <?php if ($createdTable): ?><div class="alert alert-info"><i class="fas fa-info-circle mr-1"></i>The <code>subject_notes</code> database table was created successfully.</div><?php endif; ?>
  <?php if ($schemaError !== ''): ?><div class="alert alert-danger"><strong><i class="fas fa-exclamation-triangle mr-1"></i>Database setup issue:</strong> <?= notes_e($schemaError) ?></div><?php endif; ?>
  <?php if ($pageError !== ''): ?><div class="alert alert-warning"><?= notes_e($pageError) ?></div><?php endif; ?>
  <?php if (is_array($flash) && !empty($flash['message'])): ?><div class="alert alert-<?= notes_e($flash['type'] ?? 'info') ?> alert-dismissible fade show" role="alert"><?= notes_e($flash['message']) ?><button type="button" class="close" data-dismiss="alert"><span>&times;</span></button></div><?php endif; ?>

  <section class="page-head d-flex justify-content-between align-items-center flex-wrap">
   <div><h3 class="mb-1"><i class="fas fa-book-open text-primary mr-2"></i>Subject Notes</h3><div class="text-muted">Create, upload and manage lesson notes and learning materials for each subject.</div></div>
   <div class="mt-2 no-print"><button class="btn btn-primary" type="button" onclick="document.getElementById('noteForm').scrollIntoView({behavior:'smooth'});"><i class="fas fa-plus-circle mr-1"></i>New Note</button> <button class="btn btn-outline-secondary" type="button" onclick="window.print();"><i class="fas fa-print mr-1"></i>Print List</button></div>
  </section>

  <div class="row">
   <div class="col-sm-6 col-xl-3"><div class="stat-card"><span class="stat-icon"><i class="fas fa-book"></i></span><div class="stat-label">All Lesson Notes</div><div class="stat-value text-primary"><?= number_format($stats['total']) ?></div></div></div>
   <div class="col-sm-6 col-xl-3"><div class="stat-card"><span class="stat-icon" style="background:#e1f7ef;color:#16845b"><i class="fas fa-check-circle"></i></span><div class="stat-label">Published</div><div class="stat-value text-success"><?= number_format($stats['published']) ?></div></div></div>
   <div class="col-sm-6 col-xl-3"><div class="stat-card"><span class="stat-icon" style="background:#fff4dc;color:#a06b00"><i class="fas fa-edit"></i></span><div class="stat-label">Draft Notes</div><div class="stat-value text-warning"><?= number_format($stats['draft']) ?></div></div></div>
   <div class="col-sm-6 col-xl-3"><div class="stat-card"><span class="stat-icon" style="background:#e6f4ff;color:#196ba5"><i class="fas fa-paperclip"></i></span><div class="stat-label">Uploaded Materials</div><div class="stat-value"><?= number_format($stats['files']) ?></div></div></div>
  </div>

  <?php if ($schemaError === ''): ?>
  <section class="panel no-print" id="noteForm">
   <div class="panel-title"><i class="fas fa-<?= $editNote ? 'edit' : 'plus-circle' ?> text-primary mr-2"></i><?= $editNote ? 'Edit Lesson Note' : 'Create a Lesson Note' ?></div>
   <form method="post" action="notes.php<?= $editNote ? '?edit=' . (int)$editNote['id'] . '#noteForm' : '#noteForm' ?>" enctype="multipart/form-data" id="subjectNoteForm">
    <input type="hidden" name="csrf_token" value="<?= notes_e($csrfToken) ?>"><input type="hidden" name="action" value="save_note"><input type="hidden" name="note_id" value="<?= (int)($editNote['id'] ?? 0) ?>">
    <div class="form-row">
     <div class="form-group col-lg-6"><label for="title">Lesson note title <span class="form-required">*</span></label><input class="form-control" type="text" id="title" name="title" maxlength="200" required value="<?= notes_e($editNote['title'] ?? '') ?>" placeholder="e.g. Introduction to Linear Equations"></div>
     <div class="form-group col-lg-3 col-md-6"><label for="subject_name">Subject <span class="form-required">*</span></label><input class="form-control" type="text" id="subject_name" name="subject_name" list="subjectsList" maxlength="150" required value="<?= notes_e($editNote['subject'] ?? '') ?>" placeholder="Select or type a subject"><datalist id="subjectsList"><?php foreach ($subjectOptions as $subjectOption): ?><option value="<?= notes_e($subjectOption) ?>"><?php endforeach; ?></datalist></div>
     <div class="form-group col-lg-3 col-md-6"><label for="class_name">Class / Stream</label><input class="form-control" type="text" id="class_name" name="class_name" list="classesList" value="<?= notes_e($editNote['class'] ?? '') ?>" placeholder="e.g. S.1 West"><datalist id="classesList"><?php foreach ($classOptions as $classOption): ?><option value="<?= notes_e($classOption) ?>"><?php endforeach; ?></datalist></div>
    </div>
    <div class="form-row">
     <div class="form-group col-md-3"><label for="academic_year">Academic Year</label><input class="form-control" type="text" id="academic_year" name="academic_year" maxlength="20" value="<?= notes_e($editNote['year'] ?? date('Y')) ?>" placeholder="2026"></div>
     <div class="form-group col-md-3"><label for="term">Term</label><select class="custom-select" id="term" name="term"><option value="">Select term</option><?php foreach (['Term I','Term II','Term III','Term 1','Term 2','Term 3'] as $termOption): ?><option value="<?= notes_e($termOption) ?>" <?= (string)($editNote['term'] ?? '') === $termOption ? 'selected' : '' ?>><?= notes_e($termOption) ?></option><?php endforeach; ?></select></div>
     <div class="form-group col-md-3"><label for="topic">Topic / Unit</label><input class="form-control" type="text" id="topic" name="topic" maxlength="180" value="<?= notes_e($editNote['topic'] ?? '') ?>" placeholder="Topic or unit name"></div>
     <?php if ($map['status']): ?><div class="form-group col-md-3"><label for="status">Publication Status</label><select class="custom-select" id="status" name="status"><?php foreach ($statusOptions as $statusOption): ?><option value="<?= notes_e($statusOption) ?>" <?= (string)($editNote['status'] ?? 'published') === $statusOption ? 'selected' : '' ?>><?= notes_e(ucwords(str_replace('_',' ',$statusOption))) ?></option><?php endforeach; ?></select></div><?php endif; ?>
    </div>
    <div class="form-group"><label for="description">Short description / learning objectives</label><textarea class="form-control" id="description" name="description" rows="2" placeholder="Briefly describe what students will learn."><?= notes_e($editNote['description'] ?? '') ?></textarea></div>
    <div class="form-group"><label for="note_content">Lesson notes / learning content</label><textarea class="form-control" id="note_content" name="note_content" rows="7" placeholder="Type the lesson notes, examples, activities, homework or references here."><?= notes_e($editNote['content'] ?? '') ?></textarea><small class="form-text text-muted">You may type the notes here, upload a file below, or do both.</small></div>
    <div class="form-group"><label for="attachment"><i class="fas fa-paperclip mr-1"></i>Upload a learning material</label><input class="form-control-file" type="file" id="attachment" name="attachment" accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.txt,.rtf,.odt,.ods,.odp,.jpg,.jpeg,.png,.gif,.webp,.mp3,.wav,.m4a,.mp4,.webm"><small class="upload-help">Maximum 25 MB. Accepted: PDF, Word, PowerPoint, Excel, text, images, audio and video.</small><?php if ($editNote && $editNote['file_path'] !== ''): ?><div class="mt-2 small"><i class="fas fa-file-alt text-primary mr-1"></i>Current file: <?= notes_e($editNote['file_name'] ?: basename($editNote['file_path'])) ?> — <a href="notes.php?download=<?= (int)$editNote['id'] ?>">Download</a>. Upload another file to replace it.</div><?php endif; ?></div>
    <button type="submit" class="btn btn-primary" id="saveNoteButton"><i class="fas fa-save mr-1"></i><?= $editNote ? 'Update Lesson Note' : 'Save Lesson Note' ?></button>
    <?php if ($editNote): ?> <a class="btn btn-outline-secondary" href="notes.php#noteForm">Cancel Edit</a><?php else: ?> <button type="reset" class="btn btn-outline-secondary">Clear Form</button><?php endif; ?>
   </form>
  </section>
  <?php endif; ?>

  <section class="panel">
   <div class="d-flex justify-content-between align-items-center flex-wrap mb-3"><div class="panel-title mb-1"><i class="fas fa-list text-primary mr-2"></i>Saved Lesson Notes</div><span class="small text-muted"><?= number_format(count($allNotes)) ?> total record(s)</span></div>
   <form method="get" action="notes.php" class="form-row align-items-end mb-3 no-print">
    <div class="form-group col-xl-3 col-md-6"><label for="q">Search notes</label><input class="form-control" type="search" id="q" name="q" value="<?= notes_e($search) ?>" placeholder="Title, topic, subject, filename..."></div>
    <div class="form-group col-xl-2 col-md-6"><label for="subjectFilter">Subject</label><select class="custom-select" id="subjectFilter" name="subject"><option value="">All subjects</option><?php foreach ($subjectOptions as $option): ?><option value="<?= notes_e($option) ?>" <?= $filterSubject === $option ? 'selected' : '' ?>><?= notes_e($option) ?></option><?php endforeach; ?></select></div>
    <div class="form-group col-xl-2 col-md-4"><label for="classFilter">Class / Stream</label><select class="custom-select" id="classFilter" name="class"><option value="">All classes</option><?php foreach ($classOptions as $option): ?><option value="<?= notes_e($option) ?>" <?= $filterClass === $option ? 'selected' : '' ?>><?= notes_e($option) ?></option><?php endforeach; ?></select></div>
    <div class="form-group col-xl-2 col-md-4"><label for="yearFilter">Academic Year</label><select class="custom-select" id="yearFilter" name="year"><option value="">All years</option><?php foreach ($yearOptions as $option): ?><option value="<?= notes_e($option) ?>" <?= $filterYear === $option ? 'selected' : '' ?>><?= notes_e($option) ?></option><?php endforeach; ?></select></div>
    <div class="form-group col-xl-2 col-md-4"><label for="statusFilter">Status</label><select class="custom-select" id="statusFilter" name="status"><option value="">All statuses</option><?php foreach ($statusOptions as $option): ?><option value="<?= notes_e($option) ?>" <?= $filterStatus === $option ? 'selected' : '' ?>><?= notes_e(ucwords(str_replace('_',' ',$option))) ?></option><?php endforeach; ?></select></div>
    <div class="form-group col-xl-1 col-md-12"><button class="btn btn-primary btn-block" type="submit" title="Filter"><i class="fas fa-search"></i></button></div>
   </form>
   <div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Lesson Note</th><th>Subject / Class</th><th>Year / Term</th><th>Learning Material</th><th>Status</th><th>Created</th><th class="no-print">Actions</th></tr></thead><tbody>
   <?php if (!$shownNotes): ?><tr><td colspan="7"><div class="empty-state"><i class="fas fa-book-open d-block"></i><strong>No lesson notes found</strong><div class="small mt-1">Create a note above or adjust your search filters.</div></div></td></tr><?php else: foreach ($shownNotes as $note): $st = strtolower($note['status']); $badge = $st === 'published' ? 'success' : ($st === 'archived' ? 'secondary' : 'warning'); ?>
    <tr>
     <td><div class="note-title"><?= notes_e($note['title']) ?></div><?php if ($note['code'] !== ''): ?><div class="muted"><?= notes_e($note['code']) ?></div><?php endif; ?><?php if ($note['topic'] !== ''): ?><div class="muted">Topic: <?= notes_e($note['topic']) ?></div><?php endif; ?><?php if ($note['description'] !== ''): ?><div class="content-preview muted mt-1"><?= notes_e(mb_strimwidth($note['description'], 0, 120, '…')) ?></div><?php endif; ?></td>
     <td><strong><?= notes_e($note['subject']) ?></strong><div class="muted"><?= notes_e($note['class'] ?: 'All classes') ?></div></td>
     <td><?= notes_e($note['year'] ?: '—') ?><div class="muted"><?= notes_e($note['term'] ?: '—') ?></div></td>
     <td><?php if ($note['file_path'] !== ''): ?><a href="notes.php?download=<?= (int)$note['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-download mr-1"></i>Download</a><div class="muted mt-1"><?= notes_e($note['file_name'] ?: basename($note['file_path'])) ?></div><?php else: ?><span class="text-muted">Text notes only</span><?php endif; ?><?php if ($note['content'] !== ''): ?><div class="muted mt-1"><i class="fas fa-align-left mr-1"></i>Text content available</div><?php endif; ?></td>
     <td><span class="badge badge-<?= $badge ?>"><?= notes_e(ucwords(str_replace('_',' ',$note['status'] ?: 'published'))) ?></span></td>
     <td class="text-nowrap"><?= $note['created_at'] !== '' ? notes_e(date('d M Y', strtotime($note['created_at']))) : '—' ?></td>
     <td class="no-print text-nowrap"><a href="notes.php?edit=<?= (int)$note['id'] ?>#noteForm" class="btn btn-sm btn-outline-primary" title="Edit"><i class="fas fa-edit"></i></a>
      <?php if ($map['status'] && count($statusOptions) > 1): ?><div class="dropdown d-inline"><button class="btn btn-sm btn-outline-secondary dropdown-toggle" data-toggle="dropdown" type="button">Status</button><div class="dropdown-menu dropdown-menu-right"><?php foreach ($statusOptions as $statusAction): if ($statusAction === $note['status']) continue; ?><form method="post" action="notes.php" class="m-0"><input type="hidden" name="csrf_token" value="<?= notes_e($csrfToken) ?>"><input type="hidden" name="action" value="change_status"><input type="hidden" name="note_id" value="<?= (int)$note['id'] ?>"><input type="hidden" name="new_status" value="<?= notes_e($statusAction) ?>"><button class="dropdown-item" type="submit"><?= notes_e(ucwords(str_replace('_',' ',$statusAction))) ?></button></form><?php endforeach; ?></div></div><?php endif; ?>
      <form method="post" action="notes.php" class="d-inline" onsubmit="return confirm('Delete this lesson note and its uploaded material? This cannot be undone.');"><input type="hidden" name="csrf_token" value="<?= notes_e($csrfToken) ?>"><input type="hidden" name="action" value="delete_note"><input type="hidden" name="note_id" value="<?= (int)$note['id'] ?>"><button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="fas fa-trash"></i></button></form>
     </td>
    </tr>
   <?php endforeach; endif; ?>
   </tbody></table></div>
   <?php if ($totalPages > 1): $pageQuery = $_GET; unset($pageQuery['download']); ?><nav class="no-print mt-3" aria-label="Lesson note pages"><ul class="pagination mb-0 flex-wrap"><?php $pageQuery['page'] = max(1, $page - 1); ?><li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="?<?= notes_e(http_build_query($pageQuery)) ?>">Previous</a></li><?php for ($p = max(1, $page - 2); $p <= min($totalPages, $page + 2); $p++): $pageQuery['page'] = $p; ?><li class="page-item <?= $p === $page ? 'active' : '' ?>"><a class="page-link" href="?<?= notes_e(http_build_query($pageQuery)) ?>"><?= $p ?></a></li><?php endfor; ?><?php $pageQuery['page'] = min($totalPages, $page + 1); ?><li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>"><a class="page-link" href="?<?= notes_e(http_build_query($pageQuery)) ?>">Next</a></li></ul></nav><?php endif; ?>
  </section>
  <div class="footer-note">School Management System &mdash; Subject Notes and Learning Materials</div>
 </div>
</main>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function(){
 var sidebar=document.getElementById('sidebar'),menu=document.getElementById('mobileMenuBtn');
 if(menu&&sidebar)menu.addEventListener('click',function(){sidebar.classList.toggle('show');});
 document.addEventListener('click',function(e){if(window.innerWidth<=991&&sidebar&&sidebar.classList.contains('show')&&!sidebar.contains(e.target)&&menu&&!menu.contains(e.target))sidebar.classList.remove('show');});
 var form=document.getElementById('subjectNoteForm');
 if(form)form.addEventListener('submit',function(){var btn=document.getElementById('saveNoteButton');if(btn){btn.disabled=true;btn.innerHTML='<i class="fas fa-spinner fa-spin mr-1"></i>Saving note...';}});
})();
</script>
</body>
</html>
