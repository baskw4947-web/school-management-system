<?php
require_once "../../config/database.php";
require_once "../../includes/auth.php";

requireRole(['administrator', 'assistant_administrator']);

function e($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/*
|--------------------------------------------------------------------------
| Statistics
|--------------------------------------------------------------------------
| These tables are optional for now. If they do not exist yet, the
| dashboard will simply display 0.
|--------------------------------------------------------------------------
*/

$totalSubjects = 0;
$totalNotes = 0;
$totalExams = 0;
$totalProjects = 0;

function tableExists($conn, $table)
{
    $table = $conn->real_escape_string($table);

    $result = $conn->query("SHOW TABLES LIKE '$table'");

    return $result && $result->num_rows > 0;
}

/*
|--------------------------------------------------------------------------
| Subjects
|--------------------------------------------------------------------------
*/

if (tableExists($conn, 'subjects')) {

    $result = $conn->query("
        SELECT COUNT(*) AS total
        FROM subjects
    ");

    if ($result) {
        $row = $result->fetch_assoc();
        $totalSubjects = (int)$row['total'];
    }
}

/*
|--------------------------------------------------------------------------
| Notes
|--------------------------------------------------------------------------
*/

if (tableExists($conn, 'subject_notes')) {

    $result = $conn->query("
        SELECT COUNT(*) AS total
        FROM subject_notes
    ");

    if ($result) {
        $row = $result->fetch_assoc();
        $totalNotes = (int)$row['total'];
    }
}

/*
|--------------------------------------------------------------------------
| Exams
|--------------------------------------------------------------------------
*/

if (tableExists($conn, 'exams')) {

    $result = $conn->query("
        SELECT COUNT(*) AS total
        FROM exams
    ");

    if ($result) {
        $row = $result->fetch_assoc();
        $totalExams = (int)$row['total'];
    }
}

/*
|--------------------------------------------------------------------------
| Projects
|--------------------------------------------------------------------------
*/

if (tableExists($conn, 'projects')) {

    $result = $conn->query("
        SELECT COUNT(*) AS total
        FROM projects
    ");

    if ($result) {
        $row = $result->fetch_assoc();
        $totalProjects = (int)$row['total'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Subjects Dashboard - School Management System</title>

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
    >

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
    >

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: #f4f6f9;
            font-family: Arial, Helvetica, sans-serif;
        }

        /* =========================================================
           SIDEBAR
        ========================================================= */

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100vh;
            background: #343a40;
            color: #fff;
            z-index: 1050;
            transition: all 0.3s ease;
            overflow-y: auto;
        }

        .sidebar-header {
            height: 70px;
            display: flex;
            align-items: center;
            padding: 0 20px;
            background: #212529;
            font-size: 20px;
            font-weight: bold;
        }

        .sidebar-header i {
            margin-right: 10px;
        }

        .sidebar-menu {
            padding: 15px 0;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            color: #ced4da;
            padding: 13px 20px;
            text-decoration: none;
            transition: all 0.2s ease;
            font-size: 15px;
        }

        .sidebar-menu a i {
            width: 28px;
            font-size: 17px;
        }

        .sidebar-menu a:hover {
            background: #495057;
            color: #fff;
        }

        .sidebar-menu a.active {
            background: #007bff;
            color: #fff;
        }

        .sidebar-menu .logout {
            color: #ffb3b3;
        }

        .sidebar-menu .logout:hover {
            background: #dc3545;
            color: #fff;
        }

        /* =========================================================
           MAIN CONTENT
        ========================================================= */

        .main-content {
            margin-left: 250px;
            min-height: 100vh;
            transition: all 0.3s ease;
        }

        .topbar {
            height: 70px;
            background: #fff;
            border-bottom: 1px solid #dee2e6;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 25px;
        }

        .menu-btn {
            border: none;
            background: #343a40;
            color: #fff;
            width: 42px;
            height: 42px;
            border-radius: 5px;
            display: none;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }

        .page-content {
            padding: 30px;
        }

        .page-title {
            font-size: 27px;
            font-weight: 600;
            color: #343a40;
            margin-bottom: 5px;
        }

        .page-subtitle {
            color: #6c757d;
            margin-bottom: 25px;
        }

        /* =========================================================
           STAT CARDS
        ========================================================= */

        .stat-card {
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
            display: flex;
            align-items: center;
        }

        .stat-icon {
            width: 58px;
            height: 58px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin-right: 15px;
        }

        .stat-icon.blue {
            background: #e7f1ff;
            color: #007bff;
        }

        .stat-icon.green {
            background: #e8f8ef;
            color: #28a745;
        }

        .stat-icon.orange {
            background: #fff3df;
            color: #fd7e14;
        }

        .stat-icon.purple {
            background: #f0e8ff;
            color: #6f42c1;
        }

        .stat-number {
            font-size: 25px;
            font-weight: bold;
            color: #343a40;
        }

        .stat-label {
            color: #6c757d;
            font-size: 14px;
        }

        /* =========================================================
           MODULE CARDS
        ========================================================= */

        .module-card {
            background: #fff;
            border-radius: 12px;
            padding: 30px 25px;
            height: 100%;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
            transition: all 0.25s ease;
            border: 1px solid #eee;
        }

        .module-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.10);
        }

        .module-icon {
            width: 70px;
            height: 70px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 30px;
            margin-bottom: 20px;
        }

        .notes-icon {
            background: #e7f1ff;
            color: #007bff;
        }

        .exam-icon {
            background: #fff0f0;
            color: #dc3545;
        }

        .project-icon {
            background: #e9f8ef;
            color: #28a745;
        }

        .report-icon {
            background: #f1eaff;
            color: #6f42c1;
        }

        .module-card h4 {
            font-size: 20px;
            font-weight: 600;
            color: #343a40;
        }

        .module-card p {
            color: #6c757d;
            min-height: 50px;
        }

        .module-card .btn {
            margin-top: 10px;
        }

        /* =========================================================
           QUICK ACTIONS
        ========================================================= */

        .section-card {
            background: #fff;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
            margin-top: 30px;
        }

        .section-title {
            font-size: 19px;
            font-weight: 600;
            color: #343a40;
            margin-bottom: 20px;
        }

        .quick-action {
            display: flex;
            align-items: center;
            padding: 14px;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            text-decoration: none !important;
            color: #343a40;
            margin-bottom: 10px;
            transition: 0.2s;
        }

        .quick-action:hover {
            background: #f8f9fa;
            border-color: #007bff;
        }

        .quick-action i {
            width: 38px;
            height: 38px;
            background: #e9ecef;
            color: #007bff;
            border-radius: 7px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
        }

        /* =========================================================
           OVERLAY
        ========================================================= */

        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.45);
            z-index: 1040;
        }

        /* =========================================================
           COLLAPSED DESKTOP SIDEBAR
        ========================================================= */

        @media (min-width: 992px) {

            body.sidebar-collapsed .sidebar {
                width: 75px;
            }

            body.sidebar-collapsed .main-content {
                margin-left: 75px;
            }

            body.sidebar-collapsed .sidebar-header span,
            body.sidebar-collapsed .sidebar-menu span {
                display: none;
            }

            body.sidebar-collapsed .sidebar-header {
                justify-content: center;
                padding: 0;
            }

            body.sidebar-collapsed .sidebar-header i {
                margin-right: 0;
            }

            body.sidebar-collapsed .sidebar-menu a {
                justify-content: center;
                padding: 15px 0;
            }

            body.sidebar-collapsed .sidebar-menu a i {
                margin: 0;
                width: auto;
            }
        }

        /* =========================================================
           MOBILE
        ========================================================= */

        @media (max-width: 991px) {

            .sidebar {
                left: -250px;
            }

            .sidebar.mobile-open {
                left: 0;
            }

            .main-content {
                margin-left: 0;
            }

            .menu-btn {
                display: flex;
            }

            .sidebar-overlay.active {
                display: block;
            }

            .page-content {
                padding: 20px 15px;
            }

            .topbar {
                padding: 0 15px;
            }

            .page-title {
                font-size: 23px;
            }
        }

        @media (max-width: 575px) {

            .stat-card {
                margin-bottom: 15px;
            }

            .module-card {
                padding: 25px 20px;
            }

        }

    </style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>

<body>

<!-- =============================================================
     SIDEBAR
============================================================= -->

<div class="sidebar" id="sidebar">

    <div class="sidebar-header">
        <i class="fas fa-school"></i>
        <span>School System</span>
    </div>

    <div class="sidebar-menu">

        <a href="/admin/dashboard.php">
            <i class="fas fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>

        <a href="/admin/classes/index.php" class="active">
            <i class="fas fa-chalkboard"></i>
            <span>Classes</span>
        </a>

        <a href="/admin/students/list.php">
            <i class="fas fa-user-graduate"></i>
            <span>Students</span>
        </a>

        <a href="/admin/teachers/index.php">
            <i class="fas fa-chalkboard-teacher"></i>
            <span>Teachers</span>
        </a>

        <a href="/admin/bursar/index.php">
            <i class="fas fa-money-bill-wave"></i>
            <span>Bursar</span>
        </a>

        <a href="/admin/assets/index.php">
            <i class="fas fa-boxes"></i>
            <span>Assets</span>
        </a>

        <a href="/admin/staff/index.php">
            <i class="fas fa-users-cog"></i>
            <span>Other Staff</span>
        </a>

        <a href="/admin/projects/index.php">
            <i class="fas fa-project-diagram"></i>
            <span>School Projects</span>
        </a>

        <a href="/admin/users/index.php">
            <i class="fas fa-users"></i>
            <span>Users</span>
        </a>

        <a href="/logout.php" class="logout">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>

    </div>

</div>

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<!-- =============================================================
     MAIN CONTENT
============================================================= -->

<div class="main-content">

    <!-- TOP BAR -->

    <div class="topbar">

        <button
            type="button"
            class="menu-btn"
            id="menuBtn"
            title="Menu"
        >
            <i class="fas fa-bars"></i>
        </button>

        <div class="ml-auto text-muted">
            <i class="fas fa-book-open mr-1"></i>
            Subjects
        </div>

    </div>

    <!-- PAGE -->

    <div class="page-content">

        <div class="d-flex flex-wrap justify-content-between align-items-center">

            <div>

                <div class="page-title">
                    Subjects Dashboard
                </div>

                <div class="page-subtitle">
                    Manage subjects, notes, examinations, projects and academic reports.
                </div>

            </div>

            <div class="mt-2 mt-md-0">

                <a
                    href="https://sserumedia.work/admin/classes/index.php"
                    class="btn btn-outline-secondary"
                >
                    <i class="fas fa-arrow-left mr-1"></i>
                    Back to Classes
                </a>

            </div>

        </div>

        <!-- =====================================================
             STATISTICS
        ====================================================== -->

        <div class="row">

            <div class="col-lg-3 col-md-6">

                <div class="stat-card">

                    <div class="stat-icon blue">
                        <i class="fas fa-book"></i>
                    </div>

                    <div>

                        <div class="stat-number">
                            <?= $totalSubjects ?>
                        </div>

                        <div class="stat-label">
                            Total Subjects
                        </div>

                    </div>

                </div>

            </div>


            <div class="col-lg-3 col-md-6">

                <div class="stat-card">

                    <div class="stat-icon green">
                        <i class="fas fa-file-alt"></i>
                    </div>

                    <div>

                        <div class="stat-number">
                            <?= $totalNotes ?>
                        </div>

                        <div class="stat-label">
                            Subject Notes
                        </div>

                    </div>

                </div>

            </div>


            <div class="col-lg-3 col-md-6">

                <div class="stat-card">

                    <div class="stat-icon orange">
                        <i class="fas fa-edit"></i>
                    </div>

                    <div>

                        <div class="stat-number">
                            <?= $totalExams ?>
                        </div>

                        <div class="stat-label">
                            Examinations
                        </div>

                    </div>

                </div>

            </div>


            <div class="col-lg-3 col-md-6">

                <div class="stat-card">

                    <div class="stat-icon purple">
                        <i class="fas fa-project-diagram"></i>
                    </div>

                    <div>

                        <div class="stat-number">
                            <?= $totalProjects ?>
                        </div>

                        <div class="stat-label">
                            Projects
                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- =====================================================
             SUBJECT MANAGEMENT
        ====================================================== -->

        <div class="section-card">

            <div class="section-title">

                <i class="fas fa-book-open mr-2 text-primary"></i>

                Subject Management

            </div>

            <div class="row">

                <!-- NOTES -->

                <div class="col-lg-3 col-md-6 mb-4">

                    <div class="module-card">

                        <div class="module-icon notes-icon">

                            <i class="fas fa-file-alt"></i>

                        </div>

                        <h4>
                            Subject Notes
                        </h4>

                        <p>
                            Create, upload and manage lesson notes and learning materials for each subject.
                        </p>

                        <a
                            href="notes.php"
                            class="btn btn-primary btn-block"
                        >
                            <i class="fas fa-arrow-right mr-1"></i>
                            Manage Notes
                        </a>

                    </div>

                </div>


                <!-- EXAMS -->

                <div class="col-lg-3 col-md-6 mb-4">

                    <div class="module-card">

                        <div class="module-icon exam-icon">

                            <i class="fas fa-file-signature"></i>

                        </div>

                        <h4>
                            Exams
                        </h4>

                        <p>
                            Create examinations, tests, assign subjects and manage examination records.
                        </p>

                        <a
                            href="exams.php"
                            class="btn btn-danger btn-block"
                        >
                            <i class="fas fa-arrow-right mr-1"></i>
                            Manage Exams
                        </a>

                    </div>

                </div>


                <!-- PROJECTS -->

                <div class="col-lg-3 col-md-6 mb-4">

                    <div class="module-card">

                        <div class="module-icon project-icon">

                            <i class="fas fa-project-diagram"></i>

                        </div>

                        <h4>
                            Projects
                        </h4>

                        <p>
                            Create student projects, assign projects to classes and monitor submissions.
                        </p>

                        <a
                            href="projects.php"
                            class="btn btn-success btn-block"
                        >
                            <i class="fas fa-arrow-right mr-1"></i>
                            Manage Projects
                        </a>

                    </div>

                </div>


                <!-- REPORTS -->

                <div class="col-lg-3 col-md-6 mb-4">

                    <div class="module-card">

                        <div class="module-icon report-icon">

                            <i class="fas fa-chart-bar"></i>

                        </div>

                        <h4>
                            Reports
                        </h4>

                        <p>
                            View subject performance, exam results, project performance and academic reports.
                        </p>

                        <a
                            href="student_reports.php"
                            class="btn btn-dark btn-block"
                        >
                            <i class="fas fa-arrow-right mr-1"></i>
                            View Reports
                        </a>

                    </div>

                </div>

            </div>

        </div>


        <!-- =====================================================
             QUICK ACTIONS
        ====================================================== -->

        <div class="section-card">

            <div class="section-title">

                <i class="fas fa-bolt mr-2 text-warning"></i>

                Quick Actions

            </div>

            <div class="row">

                <div class="col-md-6">

                    <a href="notes.php" class="quick-action">

                        <i class="fas fa-plus"></i>

                        <div>
                            <strong>Add Subject Notes</strong>
                            <br>
                            <small class="text-muted">
                                Add new learning material
                            </small>
                        </div>

                    </a>

                </div>


                <div class="col-md-6">

                    <a href="exams.php" class="quick-action">

                        <i class="fas fa-file-signature"></i>

                        <div>
                            <strong>Create Examination</strong>
                            <br>
                            <small class="text-muted">
                                Create a test or examination
                            </small>
                        </div>

                    </a>

                </div>


                <div class="col-md-6">

                    <a href="projects.php" class="quick-action">

                        <i class="fas fa-project-diagram"></i>

                        <div>
                            <strong>Create Project</strong>
                            <br>
                            <small class="text-muted">
                                Assign a new student project
                            </small>
                        </div>

                    </a>

                </div>


                <div class="col-md-6">

                    <a href="reports.php" class="quick-action">

                        <i class="fas fa-chart-line"></i>

                        <div>
                            <strong>Generate Report</strong>
                            <br>
                            <small class="text-muted">
                                View academic performance
                            </small>
                        </div>

                    </a>

                </div>

            </div>

        </div>

    </div>

</div>


<!-- =============================================================
     JAVASCRIPT
============================================================= -->

<script>

    const sidebar = document.getElementById('sidebar');
    const menuBtn = document.getElementById('menuBtn');
    const overlay = document.getElementById('sidebarOverlay');

    menuBtn.addEventListener('click', function () {

        if (window.innerWidth <= 991) {

            sidebar.classList.toggle('mobile-open');
            overlay.classList.toggle('active');

        } else {

            document.body.classList.toggle('sidebar-collapsed');

        }

    });


    overlay.addEventListener('click', function () {

        sidebar.classList.remove('mobile-open');
        overlay.classList.remove('active');

    });


    document.addEventListener('keydown', function (event) {

        if (event.key === 'Escape') {

            sidebar.classList.remove('mobile-open');
            overlay.classList.remove('active');

        }

    });


    document.querySelectorAll('.sidebar-menu a').forEach(function (link) {

        link.addEventListener('click', function () {

            if (window.innerWidth <= 991) {

                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('active');

            }

        });

    });

</script>

</body>
</html>