<?php

require_once "../../config/database.php";
require_once "../../includes/auth.php";

requireRole([
    'administrator',
    'assistant_administrator'
]);

/* ==========================================================
   ESCAPE FUNCTION
========================================================== */

function e($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}


/* ==========================================================
   GET CLASS STATISTICS
========================================================== */

$totalClasses = 0;
$activeClasses = 0;
$totalStudents = 0;

$result = $conn->query("
    SELECT COUNT(*) AS total
    FROM classes
");

if ($result) {

    $row = $result->fetch_assoc();

    $totalClasses = (int)$row['total'];
}


/* ==========================================================
   ACTIVE CLASSES
========================================================== */

$result = $conn->query("
    SELECT COUNT(*) AS total
    FROM classes
    WHERE status = 'active'
");

if ($result) {

    $row = $result->fetch_assoc();

    $activeClasses = (int)$row['total'];
}


/* ==========================================================
   TOTAL STUDENTS
========================================================== */

$result = $conn->query("
    SELECT COUNT(*) AS total
    FROM students
");

if ($result) {

    $row = $result->fetch_assoc();

    $totalStudents = (int)$row['total'];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Classes Dashboard - School Management System
    </title>


    <!-- Bootstrap -->

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
    >


    <!-- Font Awesome -->

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
    >


    <style>

        * {
            box-sizing: border-box;
        }


        body {
            margin: 0;
            background: #f4f6f9;
            font-family: Arial, sans-serif;
        }


        /* ==================================================
           SIDEBAR
        ================================================== */

        .sidebar {

            position: fixed;

            top: 0;
            left: 0;

            width: 250px;
            height: 100vh;

            background: #343a40;

            color: white;

            transition: all .3s ease;

            z-index: 1050;

            overflow-y: auto;
        }


        .sidebar-header {

            height: 65px;

            display: flex;

            align-items: center;

            padding: 0 20px;

            background: #212529;

            font-size: 18px;

            font-weight: bold;
        }


        .sidebar-header i {

            margin-right: 10px;
        }


        .sidebar-menu {

            list-style: none;

            padding: 15px 0;

            margin: 0;
        }


        .sidebar-menu li {

            margin: 2px 10px;
        }


        .sidebar-menu a {

            display: flex;

            align-items: center;

            padding: 12px 15px;

            color: #ced4da;

            text-decoration: none;

            border-radius: 5px;

            transition: .2s;
        }


        .sidebar-menu a:hover {

            background: #495057;

            color: white;
        }


        .sidebar-menu a.active {

            background: #007bff;

            color: white;
        }


        .sidebar-menu i {

            width: 25px;

            margin-right: 10px;

            text-align: center;
        }


        /* ==================================================
           MAIN CONTENT
        ================================================== */

        .main-content {

            margin-left: 250px;

            min-height: 100vh;

            transition: all .3s ease;
        }


        .topbar {

            height: 65px;

            background: white;

            border-bottom: 1px solid #dee2e6;

            display: flex;

            align-items: center;

            padding: 0 25px;
        }


        .sidebar-toggle {

            border: none;

            background: none;

            font-size: 22px;

            cursor: pointer;

            margin-right: 15px;

            color: #343a40;
        }


        .page-title {

            margin: 0;

            font-size: 22px;

            font-weight: 600;
        }


        .content {

            padding: 25px;
        }


        /* ==================================================
           WELCOME SECTION
        ================================================== */

        .welcome-card {

            background: linear-gradient(
                135deg,
                #007bff,
                #0056b3
            );

            color: white;

            border-radius: 12px;

            padding: 25px;

            margin-bottom: 25px;

            box-shadow:
                0 5px 15px rgba(0,0,0,.08);
        }


        .welcome-card h2 {

            font-weight: 600;

            margin-bottom: 5px;
        }


        .welcome-card p {

            margin-bottom: 0;

            opacity: .9;
        }


        .welcome-icon {

            font-size: 55px;

            opacity: .25;
        }


        /* ==================================================
           STATISTICS
        ================================================== */

        .stat-card {

            background: white;

            border-radius: 10px;

            padding: 20px;

            margin-bottom: 25px;

            box-shadow:
                0 2px 8px rgba(0,0,0,.06);

            display: flex;

            align-items: center;
        }


        .stat-icon {

            width: 55px;

            height: 55px;

            border-radius: 10px;

            display: flex;

            align-items: center;

            justify-content: center;

            color: white;

            font-size: 22px;

            margin-right: 15px;
        }


        .stat-icon.blue {

            background: #007bff;
        }


        .stat-icon.green {

            background: #28a745;
        }


        .stat-icon.orange {

            background: #fd7e14;
        }


        .stat-number {

            font-size: 25px;

            font-weight: bold;

            line-height: 1;
        }


        .stat-label {

            color: #6c757d;

            margin-top: 5px;
        }


        /* ==================================================
           MODULE CARDS
        ================================================== */

        .module-card {

            background: white;

            border-radius: 12px;

            padding: 25px;

            height: 100%;

            box-shadow:
                0 2px 8px rgba(0,0,0,.06);

            transition: all .2s ease;

            border: 1px solid transparent;
        }


        .module-card:hover {

            transform: translateY(-4px);

            box-shadow:
                0 7px 20px rgba(0,0,0,.10);

            border-color: #007bff;
        }


        .module-icon {

            width: 65px;

            height: 65px;

            border-radius: 12px;

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 28px;

            color: white;

            margin-bottom: 18px;
        }


        .module-card h4 {

            font-size: 19px;

            font-weight: 600;

            margin-bottom: 8px;
        }


        .module-card p {

            color: #6c757d;

            min-height: 45px;
        }


        .module-card .btn {

            margin-top: 10px;

            border-radius: 6px;
        }


        .bg-blue {

            background: #007bff;
        }


        .bg-green {

            background: #28a745;
        }


        .bg-purple {

            background: #6f42c1;
        }


        .bg-orange {

            background: #fd7e14;
        }


        .bg-cyan {

            background: #17a2b8;
        }


        /* ==================================================
           SECTION TITLE
        ================================================== */

        .section-title {

            font-size: 20px;

            font-weight: 600;

            margin-bottom: 20px;
        }


        /* ==================================================
           MOBILE
        ================================================== */

        .mobile-topbar {

            display: none;
        }


        .sidebar-overlay {

            display: none;

            position: fixed;

            top: 0;

            left: 0;

            width: 100%;

            height: 100%;

            background: rgba(0,0,0,.5);

            z-index: 1040;
        }


        /* ==================================================
           COLLAPSED SIDEBAR
        ================================================== */

        .sidebar.collapsed {

            width: 75px;
        }


        .sidebar.collapsed
        .sidebar-header span,

        .sidebar.collapsed
        .sidebar-menu span {

            display: none;
        }


        .sidebar.collapsed
        .sidebar-header {

            justify-content: center;

            padding: 0;
        }


        .sidebar.collapsed
        .sidebar-header i {

            margin: 0;
        }


        .sidebar.collapsed
        .sidebar-menu a {

            justify-content: center;

            padding: 12px 0;
        }


        .sidebar.collapsed
        .sidebar-menu i {

            margin: 0;
        }


        .main-content.expanded {

            margin-left: 75px;
        }


        /* ==================================================
           RESPONSIVE
        ================================================== */

        @media (max-width: 767px) {

            .sidebar {

                left: -250px;

                width: 250px;
            }


            .sidebar.mobile-open {

                left: 0;
            }


            .main-content {

                margin-left: 0;
            }


            .topbar {

                display: none;
            }


            .mobile-topbar {

                display: flex;

                height: 60px;

                background: #343a40;

                color: white;

                align-items: center;

                padding: 0 15px;
            }


            .mobile-menu-button {

                border: none;

                background: none;

                color: white;

                font-size: 22px;

                margin-right: 15px;
            }


            .content {

                padding: 15px;
            }


            .welcome-card {

                padding: 20px;
            }


            .welcome-icon {

                display: none;
            }

        }

    </style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>


<body>


<!-- ==========================================================
     SIDEBAR
=========================================================== -->

<div
    class="sidebar"
    id="sidebar"
>

    <div class="sidebar-header">

        <i class="fas fa-school"></i>

        <span>
            School System
        </span>

    </div>


    <ul class="sidebar-menu">


        <!-- Dashboard -->

        <li>

            <a href="/admin/dashboard.php">

                <i class="fas fa-tachometer-alt"></i>

                <span>
                    Dashboard
                </span>

            </a>

        </li>


        <!-- Classes -->

        <li>

            <a
                href="/admin/classes/index.php"
                class="active"
            >

                <i class="fas fa-chalkboard"></i>

                <span>
                    Classes
                </span>

            </a>

        </li>


        <!-- Students -->

        <li>

            <a href="/admin/students/list.php">

                <i class="fas fa-user-graduate"></i>

                <span>
                    Students
                </span>

            </a>

        </li>


        <!-- Teachers -->

        <li>

            <a href="/admin/teachers/index.php">

                <i class="fas fa-chalkboard-teacher"></i>

                <span>
                    Teachers
                </span>

            </a>

        </li>


        <!-- Bursar -->

        <li>

            <a href="/admin/bursar/index.php">

                <i class="fas fa-money-bill-wave"></i>

                <span>
                    Bursar
                </span>

            </a>

        </li>


        <!-- Assets -->

        <li>

            <a href="/admin/assets/index.php">

                <i class="fas fa-boxes"></i>

                <span>
                    Assets
                </span>

            </a>

        </li>


        <!-- Other Staff -->

        <li>

            <a href="/admin/staff/index.php">

                <i class="fas fa-users"></i>

                <span>
                    Other Staff
                </span>

            </a>

        </li>


        <!-- Projects -->

        <li>

            <a href="/admin/projects/index.php">

                <i class="fas fa-project-diagram"></i>

                <span>
                    School Projects
                </span>

            </a>

        </li>


        <!-- Users -->

        <li>

            <a href="/admin/users/index.php">

                <i class="fas fa-user-cog"></i>

                <span>
                    Users
                </span>

            </a>

        </li>


        <!-- Logout -->

        <li>

            <a href="/logout.php">

                <i class="fas fa-sign-out-alt"></i>

                <span>
                    Logout
                </span>

            </a>

        </li>

    </ul>

</div>


<!-- OVERLAY -->

<div
    class="sidebar-overlay"
    id="sidebarOverlay"
></div>


<!-- ==========================================================
     MAIN CONTENT
=========================================================== -->

<div
    class="main-content"
    id="mainContent"
>


    <!-- DESKTOP TOPBAR -->

    <div class="topbar">

        <button
            class="sidebar-toggle"
            id="sidebarToggle"
            type="button"
        >

            <i class="fas fa-bars"></i>

        </button>


        <h1 class="page-title">

            Classes Dashboard

        </h1>

    </div>


    <!-- MOBILE TOPBAR -->

    <div class="mobile-topbar">

        <button
            class="mobile-menu-button"
            id="mobileMenuButton"
            type="button"
        >

            <i class="fas fa-bars"></i>

        </button>


        <strong>
            Classes Dashboard
        </strong>

    </div>


    <!-- CONTENT -->

    <div class="content">


        <!-- ==================================================
             WELCOME
        =================================================== -->

        <div class="welcome-card">

            <div
                class="row align-items-center"
            >

                <div class="col-md-9">

                    <h2>

                        <i class="fas fa-chalkboard"></i>

                        Classes Management

                    </h2>

                    <p>

                        Manage classes, subjects, timetables,
                        teachers and students from one place.

                    </p>

                </div>


                <div
                    class="col-md-3 text-right"
                >

                    <i
                        class="fas fa-school welcome-icon"
                    ></i>

                </div>

            </div>

        </div>


        <!-- ==================================================
             STATISTICS
        =================================================== -->

        <div class="row">


            <!-- TOTAL CLASSES -->

            <div class="col-md-4">

                <div class="stat-card">

                    <div
                        class="stat-icon blue"
                    >

                        <i class="fas fa-chalkboard"></i>

                    </div>


                    <div>

                        <div class="stat-number">

                            <?= $totalClasses ?>

                        </div>

                        <div class="stat-label">

                            Total Classes

                        </div>

                    </div>

                </div>

            </div>


            <!-- ACTIVE CLASSES -->

            <div class="col-md-4">

                <div class="stat-card">

                    <div
                        class="stat-icon green"
                    >

                        <i class="fas fa-check-circle"></i>

                    </div>


                    <div>

                        <div class="stat-number">

                            <?= $activeClasses ?>

                        </div>

                        <div class="stat-label">

                            Active Classes

                        </div>

                    </div>

                </div>

            </div>


            <!-- STUDENTS -->

            <div class="col-md-4">

                <div class="stat-card">

                    <div
                        class="stat-icon orange"
                    >

                        <i class="fas fa-user-graduate"></i>

                    </div>


                    <div>

                        <div class="stat-number">

                            <?= $totalStudents ?>

                        </div>

                        <div class="stat-label">

                            Total Students

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- ==================================================
             MANAGEMENT MODULES
        =================================================== -->

        <h3 class="section-title">

            <i class="fas fa-th-large text-primary"></i>

            Class Management

        </h3>


        <div class="row">


            <!-- CLASS LIST -->

            <div class="col-lg-4 col-md-6 mb-4">

                <div class="module-card">

                    <div
                        class="module-icon bg-blue"
                    >

                        <i class="fas fa-list"></i>

                    </div>


                    <h4>
                        Class List
                    </h4>


                    <p>

                        View, add, edit and manage
                        all school classes.

                    </p>


                    <a
                        href="class_list.php"
                        class="btn btn-primary"
                    >

                        <i class="fas fa-arrow-right"></i>

                        Open Class List

                    </a>

                </div>

            </div>


            <!-- SUBJECTS -->

            <div class="col-lg-4 col-md-6 mb-4">

                <div class="module-card">

                    <div
                        class="module-icon bg-green"
                    >

                        <i class="fas fa-book"></i>

                    </div>


                    <h4>
                        Subjects
                    </h4>


                    <p>

                        Manage school subjects and
                        organize subjects for classes.

                    </p>


                    <a
                        href="subjects.php"
                        class="btn btn-success"
                    >

                        <i class="fas fa-arrow-right"></i>

                        Manage Subjects

                    </a>

                </div>

            </div>


            <!-- TIMETABLE -->

            <div class="col-lg-4 col-md-6 mb-4">

                <div class="module-card">

                    <div
                        class="module-icon bg-purple"
                    >

                        <i class="fas fa-calendar-alt"></i>

                    </div>


                    <h4>
                        Timetable
                    </h4>


                    <p>

                        Create and manage class
                        timetables and lesson schedules.

                    </p>


                    <a
                        href="timetable.php"
                        class="btn btn-primary"
                        style="background:#6f42c1;border-color:#6f42c1;"
                    >

                        <i class="fas fa-arrow-right"></i>

                        Manage Timetable

                    </a>

                </div>

            </div>


            <!-- TEACHERS -->

            <div class="col-lg-4 col-md-6 mb-4">

                <div class="module-card">

                    <div
                        class="module-icon bg-orange"
                    >

                        <i class="fas fa-chalkboard-teacher"></i>

                    </div>


                    <h4>
                        Teachers
                    </h4>


                    <p>

                        View and manage teachers
                        responsible for classes and subjects.

                    </p>


                    <a
                        href="../teachers/index.php"
                        class="btn btn-warning"
                    >

                        <i class="fas fa-arrow-right"></i>

                        View Teachers

                    </a>

                </div>

            </div>


            <!-- STUDENTS -->

            <div class="col-lg-4 col-md-6 mb-4">

                <div class="module-card">

                    <div
                        class="module-icon bg-cyan"
                    >

                        <i class="fas fa-user-graduate"></i>

                    </div>


                    <h4>
                        Students
                    </h4>


                    <p>

                        View students assigned to
                        classes and manage student records.

                    </p>


                    <a
                        href="../students/list.php"
                        class="btn btn-info"
                    >

                        <i class="fas fa-arrow-right"></i>

                        View Students

                    </a>

                </div>

            </div>


        </div>


    </div>

</div>


<!-- ==========================================================
     JAVASCRIPT
=========================================================== -->

<script>

const sidebar =
    document.getElementById('sidebar');

const mainContent =
    document.getElementById('mainContent');

const sidebarToggle =
    document.getElementById('sidebarToggle');

const mobileMenuButton =
    document.getElementById('mobileMenuButton');

const sidebarOverlay =
    document.getElementById('sidebarOverlay');


/* ==========================================================
   DESKTOP SIDEBAR
=========================================================== */

if (sidebarToggle) {

    sidebarToggle.addEventListener(
        'click',
        function () {

            if (window.innerWidth > 767) {

                sidebar.classList.toggle(
                    'collapsed'
                );

                mainContent.classList.toggle(
                    'expanded'
                );

            }

        }
    );

}


/* ==========================================================
   MOBILE MENU
=========================================================== */

if (mobileMenuButton) {

    mobileMenuButton.addEventListener(
        'click',
        function () {

            sidebar.classList.add(
                'mobile-open'
            );

            sidebarOverlay.classList.add(
                'active'
            );

        }
    );

}


/* ==========================================================
   CLOSE MOBILE SIDEBAR
=========================================================== */

function closeMobileSidebar()
{

    sidebar.classList.remove(
        'mobile-open'
    );

    sidebarOverlay.classList.remove(
        'active'
    );

}


/* ==========================================================
   OVERLAY
=========================================================== */

sidebarOverlay.addEventListener(
    'click',
    closeMobileSidebar
);


/* ==========================================================
   CLOSE WHEN LINK CLICKED
=========================================================== */

sidebar
    .querySelectorAll('a')
    .forEach(
        function (link) {

            link.addEventListener(
                'click',
                function () {

                    if (
                        window.innerWidth <= 767
                    ) {

                        closeMobileSidebar();

                    }

                }
            );

        }
    );


/* ==========================================================
   ESCAPE KEY
=========================================================== */

document.addEventListener(
    'keydown',
    function (event) {

        if (event.key === 'Escape') {

            closeMobileSidebar();

        }

    }
);

</script>


<script
    src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
></script>

<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
></script>


</body>

</html>