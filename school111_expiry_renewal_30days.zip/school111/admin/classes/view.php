<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once "../../config/database.php";
require_once "../../includes/auth.php";

requireRole([
    'administrator',
    'assistant_administrator'
]);

/*
|--------------------------------------------------------------------------
| HELPER
|--------------------------------------------------------------------------
*/

function e($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| GET CLASS ID
|--------------------------------------------------------------------------
*/

$class_id = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$class_id || $class_id <= 0) {

    header(
        "Location: index.php?error=" .
        urlencode("Invalid class ID.")
    );

    exit;
}

/*
|--------------------------------------------------------------------------
| STUDENT SEARCH
|--------------------------------------------------------------------------
*/

$student_search = trim(
    $_GET['student_search'] ?? ''
);

/*
|--------------------------------------------------------------------------
| LOAD CLASS INFORMATION
|--------------------------------------------------------------------------
*/

$classSql = "
    SELECT
        c.id,
        c.class_name,
        c.section,
        c.academic_year,
        c.status,
        COUNT(s.id) AS student_count
    FROM classes c
    LEFT JOIN students s
        ON s.class_id = c.id
    WHERE c.id = ?
    GROUP BY
        c.id,
        c.class_name,
        c.section,
        c.academic_year,
        c.status
    LIMIT 1
";

$classStmt = $conn->prepare($classSql);

if (!$classStmt) {

    die(
        "Database query preparation failed: " .
        e($conn->error)
    );
}

$classStmt->bind_param(
    "i",
    $class_id
);

if (!$classStmt->execute()) {

    die(
        "Database query failed: " .
        e($classStmt->error)
    );
}

$classResult = $classStmt->get_result();

if ($classResult->num_rows === 0) {

    $classStmt->close();

    header(
        "Location: index.php?error=" .
        urlencode("Class not found.")
    );

    exit;
}

$class = $classResult->fetch_assoc();

$classStmt->close();

/*
|--------------------------------------------------------------------------
| LOAD STUDENTS
|--------------------------------------------------------------------------
*/

$studentsSql = "
    SELECT
        s.id,
        s.admission_no,
        s.lin_no,
        s.student_payment_code,
        s.student_section,
        s.first_name,
        s.last_name,
        s.other_names,
        s.gender,
        s.photo,
        s.status,
        g.full_name AS guardian_name,
        g.phone AS guardian_phone
    FROM students s
    LEFT JOIN guardians g
        ON g.id = s.guardian_id
    WHERE s.class_id = ?
";

$studentParams = [$class_id];
$studentTypes = "i";

/*
|--------------------------------------------------------------------------
| STUDENT SEARCH FILTER
|--------------------------------------------------------------------------
*/

if ($student_search !== '') {

    $studentsSql .= "
        AND (
            s.admission_no LIKE ?
            OR s.lin_no LIKE ?
            OR s.student_payment_code LIKE ?
            OR s.first_name LIKE ?
            OR s.last_name LIKE ?
            OR s.other_names LIKE ?
            OR CONCAT(
                s.first_name,
                ' ',
                s.other_names,
                ' ',
                s.last_name
            ) LIKE ?
        )
    ";

    $searchValue = "%" . $student_search . "%";

    $studentParams[] = $searchValue;
    $studentParams[] = $searchValue;
    $studentParams[] = $searchValue;
    $studentParams[] = $searchValue;
    $studentParams[] = $searchValue;
    $studentParams[] = $searchValue;
    $studentParams[] = $searchValue;

    $studentTypes .= "sssssss";
}

$studentsSql .= "
    ORDER BY
        s.last_name ASC,
        s.first_name ASC
";

/*
|--------------------------------------------------------------------------
| PREPARE STUDENT QUERY
|--------------------------------------------------------------------------
*/

$studentsStmt = $conn->prepare($studentsSql);

if (!$studentsStmt) {

    die(
        "Student query preparation failed: " .
        e($conn->error)
    );
}

/*
|--------------------------------------------------------------------------
| BIND PARAMETERS
|--------------------------------------------------------------------------
*/

$studentsStmt->bind_param(
    $studentTypes,
    ...$studentParams
);

/*
|--------------------------------------------------------------------------
| EXECUTE
|--------------------------------------------------------------------------
*/

if (!$studentsStmt->execute()) {

    die(
        "Student query failed: " .
        e($studentsStmt->error)
    );
}

$studentsResult = $studentsStmt->get_result();

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        <?= e($class['class_name']) ?>
        |
        Class Details
    </title>

    <!-- Bootstrap -->

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
    >

    <!-- Font Awesome -->

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
    >

    <style>

        /*
        |--------------------------------------------------------------------------
        | BODY
        |--------------------------------------------------------------------------
        */

        body {
            background: #f8f9fa;
            margin: 0;
            padding: 0;
        }


        /*
        |--------------------------------------------------------------------------
        | SIDEBAR
        |--------------------------------------------------------------------------
        */

        .sidebar {

            position: fixed;

            top: 0;
            left: 0;

            width: 250px;
            height: 100vh;

            background: #343a40;

            color: #fff;

            z-index: 1050;

            transition: all 0.3s ease;

            overflow-y: auto;

            box-shadow: 2px 0 8px rgba(0,0,0,0.12);

        }


        .sidebar-header {

            height: 65px;

            display: flex;

            align-items: center;

            justify-content: space-between;

            padding: 0 18px;

            background: #212529;

            border-bottom: 1px solid rgba(255,255,255,0.08);

        }


        .sidebar-brand {

            font-size: 19px;

            font-weight: 600;

            white-space: nowrap;

        }


        .sidebar-brand i {

            margin-right: 8px;

        }


        .sidebar-toggle {

            border: none;

            background: transparent;

            color: #fff;

            font-size: 20px;

            cursor: pointer;

        }


        .sidebar-menu {

            padding: 15px 0;

        }


        .sidebar-menu a {

            display: flex;

            align-items: center;

            color: #ced4da;

            text-decoration: none;

            padding: 12px 18px;

            font-size: 15px;

            transition: all 0.2s ease;

        }


        .sidebar-menu a i {

            width: 25px;

            font-size: 16px;

            margin-right: 10px;

            text-align: center;

        }


        .sidebar-menu a:hover {

            background: #495057;

            color: #fff;

        }


        .sidebar-menu a.active {

            background: #007bff;

            color: #fff;

        }


        .sidebar-menu .logout-link {

            color: #ffc107;

        }


        .sidebar-menu .logout-link:hover {

            background: #495057;

            color: #ffc107;

        }


        /*
        |--------------------------------------------------------------------------
        | MAIN CONTENT
        |--------------------------------------------------------------------------
        */

        .main-content {

            margin-left: 250px;

            min-height: 100vh;

            transition: all 0.3s ease;

        }


        /*
        |--------------------------------------------------------------------------
        | TOPBAR
        |--------------------------------------------------------------------------
        */

        .topbar {

            height: 65px;

            background: #fff;

            border-bottom: 1px solid #dee2e6;

            display: flex;

            align-items: center;

            justify-content: space-between;

            padding: 0 25px;

            box-shadow: 0 1px 3px rgba(0,0,0,0.05);

        }


        .topbar-title {

            font-size: 18px;

            font-weight: 600;

            color: #343a40;

        }


        .mobile-menu-btn {

            border: none;

            background: #343a40;

            color: #fff;

            border-radius: 5px;

            padding: 7px 11px;

            font-size: 18px;

        }


        .mobile-topbar {

            display: none;

        }


        /*
        |--------------------------------------------------------------------------
        | SIDEBAR COLLAPSED
        |--------------------------------------------------------------------------
        */

        body.sidebar-collapsed .sidebar {

            width: 75px;

        }


        body.sidebar-collapsed .main-content {

            margin-left: 75px;

        }


        body.sidebar-collapsed .sidebar-brand span,
        body.sidebar-collapsed .sidebar-menu a span {

            display: none;

        }


        body.sidebar-collapsed .sidebar-menu a {

            justify-content: center;

        }


        body.sidebar-collapsed .sidebar-menu a i {

            margin-right: 0;

        }


        body.sidebar-collapsed .sidebar-header {

            justify-content: center;

        }


        body.sidebar-collapsed .sidebar-toggle {

            display: none;

        }


        /*
        |--------------------------------------------------------------------------
        | CLASS PAGE
        |--------------------------------------------------------------------------
        */

        .page-content {

            padding: 25px;

        }


        .class-header {

            border-radius: 10px;

        }


        .student-photo {

            width: 45px;

            height: 45px;

            object-fit: cover;

            border-radius: 50%;

            border: 1px solid #ddd;

        }


        .student-photo-placeholder {

            width: 45px;

            height: 45px;

            border-radius: 50%;

            background: #e9ecef;

            display: flex;

            align-items: center;

            justify-content: center;

            color: #6c757d;

            font-size: 18px;

        }


        .table td,
        .table th {

            vertical-align: middle;

        }


        /*
        |--------------------------------------------------------------------------
        | MOBILE OVERLAY
        |--------------------------------------------------------------------------
        */

        .sidebar-overlay {

            display: none;

            position: fixed;

            top: 0;
            left: 0;

            width: 100%;
            height: 100%;

            background: rgba(0,0,0,0.5);

            z-index: 1040;

        }


        /*
        |--------------------------------------------------------------------------
        | MOBILE
        |--------------------------------------------------------------------------
        */

        @media (max-width: 767.98px) {

            .sidebar {

                width: 250px;

                transform: translateX(-100%);

            }


            .sidebar.mobile-open {

                transform: translateX(0);

            }


            .main-content {

                margin-left: 0 !important;

            }


            body.sidebar-collapsed .sidebar {

                width: 250px;

            }


            body.sidebar-collapsed .sidebar-brand span,
            body.sidebar-collapsed .sidebar-menu a span {

                display: inline;

            }


            body.sidebar-collapsed .sidebar-menu a {

                justify-content: flex-start;

            }


            body.sidebar-collapsed .sidebar-menu a i {

                margin-right: 10px;

            }


            body.sidebar-collapsed .sidebar-header {

                justify-content: space-between;

            }


            body.sidebar-collapsed .sidebar-toggle {

                display: block;

            }


            .mobile-topbar {

                display: flex;

                height: 60px;

                background: #fff;

                border-bottom: 1px solid #dee2e6;

                align-items: center;

                padding: 0 15px;

                justify-content: space-between;

            }


            .topbar {

                display: none;

            }


            .page-content {

                padding: 15px;

            }


            .page-header {

                display: block !important;

            }


            .page-header-buttons {

                margin-top: 15px;

            }


            .sidebar-overlay.show {

                display: block;

            }

        }

    </style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>


<body>


<!-- =========================================================
     SIDEBAR
========================================================== -->

<div
    class="sidebar"
    id="sidebar"
>

    <div class="sidebar-header">

        <div class="sidebar-brand">

            <i class="fas fa-school"></i>

            <span>
                School Management
            </span>

        </div>


        <button
            type="button"
            class="sidebar-toggle"
            id="sidebarToggle"
            title="Collapse Sidebar"
        >

            <i class="fas fa-bars"></i>

        </button>

    </div>


    <div class="sidebar-menu">

        <!-- Dashboard -->

        <a
            href="/admin/dashboard.php"
        >

            <i class="fas fa-tachometer-alt"></i>

            <span>
                Dashboard
            </span>

        </a>


        <!-- Classes -->

        <a
            href="/admin/classes/index.php"
            class="active"
        >

            <i class="fas fa-chalkboard"></i>

            <span>
                Classes
            </span>

        </a>


        <!-- Students -->

        <a
            href="/admin/students/list.php"
        >

            <i class="fas fa-user-graduate"></i>

            <span>
                Students
            </span>

        </a>


        <!-- Teachers -->

        <a
            href="/admin/teachers/index.php"
        >

            <i class="fas fa-chalkboard-teacher"></i>

            <span>
                Teachers
            </span>

        </a>


        <!-- Bursar -->

        <a
            href="/admin/bursar/index.php"
        >

            <i class="fas fa-money-bill-wave"></i>

            <span>
                Bursar
            </span>

        </a>


        <!-- Assets -->

        <a
            href="/admin/assets/index.php"
        >

            <i class="fas fa-boxes"></i>

            <span>
                Assets
            </span>

        </a>


        <!-- Other Staff -->

        <a
            href="/admin/staff/index.php"
        >

            <i class="fas fa-users"></i>

            <span>
                Other Staff
            </span>

        </a>


        <!-- School Projects -->

        <a
            href="/admin/projects/index.php"
        >

            <i class="fas fa-project-diagram"></i>

            <span>
                School Projects
            </span>

        </a>


        <!-- Users -->

        <a
            href="/admin/users/index.php"
        >

            <i class="fas fa-user-cog"></i>

            <span>
                Users
            </span>

        </a>


        <hr
            class="bg-secondary mx-3"
        >


        <!-- Logout -->

        <a
            href="/logout.php"
            class="logout-link"
        >

            <i class="fas fa-sign-out-alt"></i>

            <span>
                Logout
            </span>

        </a>

    </div>

</div>


<!-- =========================================================
     SIDEBAR OVERLAY
========================================================== -->

<div
    class="sidebar-overlay"
    id="sidebarOverlay"
></div>


<!-- =========================================================
     MAIN CONTENT
========================================================== -->

<div class="main-content">


    <!-- =====================================================
         MOBILE TOPBAR
    ====================================================== -->

    <div class="mobile-topbar">

        <div class="topbar-title">

            <i class="fas fa-school mr-2"></i>

            School Management

        </div>


        <button
            type="button"
            class="mobile-menu-btn"
            id="menuToggle"
        >

            <i class="fas fa-bars"></i>

        </button>

    </div>


    <!-- =====================================================
         DESKTOP TOPBAR
    ====================================================== -->

    <div class="topbar">

        <div class="topbar-title">

            <i class="fas fa-chalkboard mr-2"></i>

            Class Details

        </div>


        <div class="text-muted">

            <?= e($class['class_name']) ?>

            <?php if (!empty($class['section'])): ?>

                -
                <?= e($class['section']) ?>

            <?php endif; ?>

        </div>

    </div>


    <!-- =====================================================
         PAGE CONTENT
    ====================================================== -->

    <div class="page-content">


        <!-- =================================================
             PAGE HEADER
        ================================================== -->

        <div
            class="page-header d-flex justify-content-between align-items-center mb-4"
        >

            <div>

                <h2 class="mb-1">
                    Class Details
                </h2>

                <p class="text-muted mb-0">
                    View class information and students.
                </p>

            </div>


            <div class="page-header-buttons">

                <a
                    href="edit.php?id=<?= (int)$class['id'] ?>"
                    class="btn btn-warning mr-2"
                >

                    <i class="fas fa-edit mr-1"></i>

                    Edit Class

                </a>


                <a
                    href="index.php"
                    class="btn btn-outline-secondary"
                >

                    <i class="fas fa-arrow-left mr-1"></i>

                    Back to Classes

                </a>

            </div>

        </div>


        <!-- =================================================
             SUCCESS MESSAGE
        ================================================== -->

        <?php if (
            isset($_GET['success']) &&
            $_GET['success'] !== ''
        ): ?>

            <div
                class="alert alert-success alert-dismissible fade show"
                role="alert"
            >

                <i class="fas fa-check-circle mr-1"></i>

                <?= e($_GET['success']) ?>


                <button
                    type="button"
                    class="close"
                    data-dismiss="alert"
                    aria-label="Close"
                >

                    <span aria-hidden="true">
                        &times;
                    </span>

                </button>

            </div>

        <?php endif; ?>


        <!-- =================================================
             CLASS INFORMATION
        ================================================== -->

        <div
            class="card shadow-sm class-header mb-4"
        >

            <div
                class="card-header bg-primary text-white"
            >

                <div
                    class="d-flex justify-content-between align-items-center"
                >

                    <h4 class="mb-0">

                        <?= e($class['class_name']) ?>

                        <?php if (
                            !empty($class['section'])
                        ): ?>

                            -
                            <?= e($class['section']) ?>

                        <?php endif; ?>

                    </h4>


                    <?php if (
                        $class['status'] === 'active'
                    ): ?>

                        <span class="badge badge-success">
                            Active
                        </span>

                    <?php else: ?>

                        <span class="badge badge-secondary">
                            Inactive
                        </span>

                    <?php endif; ?>

                </div>

            </div>


            <div class="card-body">

                <div class="row">


                    <!-- CLASS -->

                    <div class="col-md-3 mb-3">

                        <small class="text-muted">
                            Class
                        </small>

                        <h5 class="mb-0">
                            <?= e($class['class_name']) ?>
                        </h5>

                    </div>


                    <!-- SECTION -->

                    <div class="col-md-3 mb-3">

                        <small class="text-muted">
                            Section
                        </small>

                        <h5 class="mb-0">

                            <?php if (
                                !empty($class['section'])
                            ): ?>

                                <?= e($class['section']) ?>

                            <?php else: ?>

                                <span class="text-muted">
                                    No Section
                                </span>

                            <?php endif; ?>

                        </h5>

                    </div>


                    <!-- ACADEMIC YEAR -->

                    <div class="col-md-3 mb-3">

                        <small class="text-muted">
                            Academic Year
                        </small>

                        <h5 class="mb-0">
                            <?= e($class['academic_year']) ?>
                        </h5>

                    </div>


                    <!-- TOTAL STUDENTS -->

                    <div class="col-md-3 mb-3">

                        <small class="text-muted">
                            Total Students
                        </small>

                        <h5 class="mb-0">

                            <span class="badge badge-info">
                                <?= (int)$class['student_count'] ?>
                            </span>

                        </h5>

                    </div>

                </div>

            </div>

        </div>


        <!-- =================================================
             STUDENT LIST
        ================================================== -->

        <div class="card shadow-sm">

            <div class="card-header bg-white">

                <div
                    class="d-flex justify-content-between align-items-center"
                >

                    <h5 class="mb-0">

                        <i class="fas fa-user-graduate mr-2"></i>

                        Students in this Class

                    </h5>


                    <span class="badge badge-primary">

                        <?= (int)$studentsResult->num_rows ?>

                        <?=

                            $studentsResult->num_rows === 1

                            ? 'Student'

                            : 'Students'

                        ?>

                    </span>

                </div>

            </div>


            <!-- =================================================
                 SEARCH
            ================================================== -->

            <div class="card-body border-bottom">

                <form
                    method="GET"
                    action="view.php"
                >

                    <input
                        type="hidden"
                        name="id"
                        value="<?= (int)$class['id'] ?>"
                    >


                    <div class="form-row">

                        <div
                            class="col-md-9 mb-2 mb-md-0"
                        >

                            <label
                                for="student_search"
                                class="sr-only"
                            >
                                Search Students
                            </label>


                            <input
                                type="text"
                                name="student_search"
                                id="student_search"
                                class="form-control"
                                placeholder="Search by admission number, LIN number or student name..."
                                value="<?= e($student_search) ?>"
                            >

                        </div>


                        <div class="col-md-3">

                            <div class="d-flex">

                                <button
                                    type="submit"
                                    class="btn btn-dark mr-2 flex-grow-1"
                                >

                                    <i class="fas fa-search mr-1"></i>

                                    Search

                                </button>


                                <?php if (
                                    $student_search !== ''
                                ): ?>

                                    <a
                                        href="view.php?id=<?= (int)$class['id'] ?>"
                                        class="btn btn-outline-secondary"
                                    >

                                        Clear

                                    </a>

                                <?php endif; ?>

                            </div>

                        </div>

                    </div>

                </form>


                <?php if (
                    $student_search !== ''
                ): ?>

                    <div class="mt-2 text-muted">

                        Search results for:

                        <strong>
                            <?= e($student_search) ?>
                        </strong>

                    </div>

                <?php endif; ?>

            </div>


            <!-- =================================================
                 STUDENT TABLE
            ================================================== -->

            <div class="card-body p-0">

                <div class="table-responsive">

                    <table
                        class="table table-hover table-bordered mb-0"
                    >

                        <thead class="thead-dark">

                            <tr>

                                <th width="50">
                                    #
                                </th>

                                <th width="70">
                                    Photo
                                </th>

                                <th>
                                    Admission No.
                                </th>

                                <th>
                                    LIN No.
                                </th>

                                <th>
                                    Student Payment Code
                                </th>

                                <th>
                                    Student Section
                                </th>

                                <th>
                                    Student Name
                                </th>

                                <th>
                                    Gender
                                </th>

                                <th>
                                    Guardian
                                </th>

                                <th>
                                    Phone
                                </th>

                                <th>
                                    Status
                                </th>

                                <th width="90">
                                    Action
                                </th>

                            </tr>

                        </thead>


                        <tbody>


                        <?php if (
                            $studentsResult->num_rows > 0
                        ): ?>

                            <?php $number = 1; ?>


                            <?php while (
                                $student =
                                $studentsResult->fetch_assoc()
                            ): ?>

                                <tr>


                                    <!-- NUMBER -->

                                    <td>
                                        <?= $number++ ?>
                                    </td>


                                    <!-- PHOTO -->

                                    <td>

                                        <?php if (
                                            !empty(
                                                $student['photo']
                                            )
                                        ): ?>

                                            <img
                                                src="/uploads/students/<?= e($student['photo']) ?>"
                                                alt="Student Photo"
                                                class="student-photo"
                                                onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"
                                            >


                                            <div
                                                class="student-photo-placeholder"
                                                style="display:none;"
                                            >

                                                <i class="fas fa-user"></i>

                                            </div>

                                        <?php else: ?>

                                            <div
                                                class="student-photo-placeholder"
                                            >

                                                <i class="fas fa-user"></i>

                                            </div>

                                        <?php endif; ?>

                                    </td>


                                    <!-- ADMISSION -->

                                    <td>

                                        <strong>
                                            <?= e(
                                                $student['admission_no']
                                            ) ?>
                                        </strong>

                                    </td>


                                    <!-- LIN -->

                                    <td>

                                        <?php if (
                                            !empty(
                                                $student['lin_no']
                                            )
                                        ): ?>

                                            <?= e(
                                                $student['lin_no']
                                            ) ?>

                                        <?php else: ?>

                                            <span class="text-muted">
                                                -
                                            </span>

                                        <?php endif; ?>

                                    </td>


                                    <td><?= e($student['student_payment_code'] ?: '—') ?></td>

                                    <!-- DAY / BOARDING SECTION -->
                                    <td>
                                        <span class="badge badge-<?= ($student['student_section'] ?? 'Day') === 'Boarding' ? 'info' : 'secondary' ?>">
                                            <?= e($student['student_section'] ?? 'Day') ?>
                                        </span>
                                    </td>

                                    <!-- NAME -->

                                    <td>

                                        <?php

                                        $studentName = trim(
                                            $student['first_name'] .
                                            ' ' .
                                            $student['other_names'] .
                                            ' ' .
                                            $student['last_name']
                                        );

                                        ?>

                                        <strong>
                                            <?= e($studentName) ?>
                                        </strong>

                                    </td>


                                    <!-- GENDER -->

                                    <td>

                                        <?= e(
                                            $student['gender']
                                        ) ?>

                                    </td>


                                    <!-- GUARDIAN -->

                                    <td>

                                        <?php if (
                                            !empty(
                                                $student['guardian_name']
                                            )
                                        ): ?>

                                            <?= e(
                                                $student['guardian_name']
                                            ) ?>

                                        <?php else: ?>

                                            <span class="text-muted">
                                                -
                                            </span>

                                        <?php endif; ?>

                                    </td>


                                    <!-- PHONE -->

                                    <td>

                                        <?php if (
                                            !empty(
                                                $student['guardian_phone']
                                            )
                                        ): ?>

                                            <?= e(
                                                $student['guardian_phone']
                                            ) ?>

                                        <?php else: ?>

                                            <span class="text-muted">
                                                -
                                            </span>

                                        <?php endif; ?>

                                    </td>


                                    <!-- STATUS -->

                                    <td>

                                        <?php if (
                                            $student['status'] === 'active'
                                        ): ?>

                                            <span
                                                class="badge badge-success"
                                            >
                                                Active
                                            </span>

                                        <?php else: ?>

                                            <span
                                                class="badge badge-secondary"
                                            >
                                                Inactive
                                            </span>

                                        <?php endif; ?>

                                    </td>


                                    <!-- ACTION -->

                                    <td>

                                        <a
                                            href="../students/view.php?id=<?= (int)$student['id'] ?>"
                                            class="btn btn-sm btn-info"
                                        >

                                            <i class="fas fa-eye"></i>

                                            View

                                        </a>

                                    </td>

                                </tr>

                            <?php endwhile; ?>


                        <?php else: ?>

                            <tr>

                                <td
                                    colspan="12"
                                    class="text-center py-5"
                                >

                                    <div class="text-muted">

                                        <?php if (
                                            $student_search !== ''
                                        ): ?>

                                            <h5>
                                                No Students Found
                                            </h5>

                                            <p class="mb-3">

                                                No students matched

                                                <strong>
                                                    <?= e(
                                                        $student_search
                                                    ) ?>
                                                </strong>

                                                in this class.

                                            </p>


                                            <a
                                                href="view.php?id=<?= (int)$class['id'] ?>"
                                                class="btn btn-outline-secondary"
                                            >

                                                Clear Search

                                            </a>

                                        <?php else: ?>

                                            <h5>
                                                No Students Found
                                            </h5>

                                            <p class="mb-3">

                                                There are currently no
                                                students assigned to this
                                                class.

                                            </p>


                                            <a
                                                href="../students/register.php"
                                                class="btn btn-primary"
                                            >

                                                <i class="fas fa-user-plus mr-1"></i>

                                                Register Student

                                            </a>

                                        <?php endif; ?>

                                    </div>

                                </td>

                            </tr>

                        <?php endif; ?>


                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    </div>

</div>


<!-- =========================================================
     JAVASCRIPT
========================================================== -->

<script
    src="https://code.jquery.com/jquery-3.6.4.min.js"
></script>


<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
></script>


<script>

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const sidebar =
            document.getElementById("sidebar");

        const sidebarToggle =
            document.getElementById("sidebarToggle");

        const menuToggle =
            document.getElementById("menuToggle");

        const sidebarOverlay =
            document.getElementById("sidebarOverlay");


        /*
        |--------------------------------------------------------------------------
        | DESKTOP SIDEBAR COLLAPSE
        |--------------------------------------------------------------------------
        */

        if (sidebarToggle) {

            sidebarToggle.addEventListener(
                "click",
                function () {

                    document.body.classList.toggle(
                        "sidebar-collapsed"
                    );

                }
            );

        }


        /*
        |--------------------------------------------------------------------------
        | MOBILE MENU OPEN
        |--------------------------------------------------------------------------
        */

        if (menuToggle) {

            menuToggle.addEventListener(
                "click",
                function () {

                    sidebar.classList.add(
                        "mobile-open"
                    );

                    sidebarOverlay.classList.add(
                        "show"
                    );

                }
            );

        }


        /*
        |--------------------------------------------------------------------------
        | CLOSE MOBILE SIDEBAR
        |--------------------------------------------------------------------------
        */

        function closeMobileSidebar() {

            sidebar.classList.remove(
                "mobile-open"
            );

            sidebarOverlay.classList.remove(
                "show"
            );

        }


        /*
        |--------------------------------------------------------------------------
        | OVERLAY CLICK
        |--------------------------------------------------------------------------
        */

        if (sidebarOverlay) {

            sidebarOverlay.addEventListener(
                "click",
                closeMobileSidebar
            );

        }


        /*
        |--------------------------------------------------------------------------
        | CLOSE SIDEBAR WHEN LINK IS CLICKED ON MOBILE
        |--------------------------------------------------------------------------
        */

        const sidebarLinks =
            document.querySelectorAll(
                ".sidebar-menu a"
            );


        sidebarLinks.forEach(
            function (link) {

                link.addEventListener(
                    "click",
                    function () {

                        if (
                            window.innerWidth <= 767
                        ) {

                            closeMobileSidebar();

                        }

                    }
                );

            }
        );


        /*
        |--------------------------------------------------------------------------
        | ESC KEY CLOSE
        |--------------------------------------------------------------------------
        */

        document.addEventListener(
            "keydown",
            function (event) {

                if (
                    event.key === "Escape"
                ) {

                    closeMobileSidebar();

                }

            }
        );

    }
);

</script>


</body>

</html>

<?php

$studentsStmt->close();

?>