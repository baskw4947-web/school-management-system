<?php
/**
 * School Management System - Examination Setup and Marks Entry
 * Suggested location: /admin/students/exams.php
 * Creates school_exams and school_exam_results if they do not exist.
 * Save as UTF-8 without BOM; do not put spaces before this opening PHP tag.
 */

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator', 'teacher', 'class_teacher', 'headteacher', 'director_of_studies', 'academic']);

if (!isset($conn) || !($conn instanceof mysqli)) {
    http_response_code(500);
    exit('Database connection is unavailable. Please check config/database.php.');
}
$conn->set_charset('utf8mb4');
$userId = (int)($_SESSION['user_id'] ?? $_SESSION['id'] ?? 0);

function examE($value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function examFlash(string $type, string $message): void { $_SESSION['exams_flash'] = ['type' => $type, 'message' => $message]; }
function examRedirect(string $url = 'exams.php'): void { header('Location: ' . $url); exit; }
function examTableExists(mysqli $db, string $table): bool {
    $safe = $db->real_escape_string($table);
    $result = $db->query("SHOW TABLES LIKE '{$safe}'");
    $exists = $result && $result->num_rows > 0;
    if ($result) $result->free();
    return $exists;
}
function examColumns(mysqli $db, string $table): array {
    $columns = [];
    $result = $db->query('SHOW COLUMNS FROM `' . str_replace('`', '``', $table) . '`');
    while ($row = $result->fetch_assoc()) $columns[strtolower($row['Field'])] = $row['Field'];
    $result->free();
    return $columns;
}
function examValidDate(string $date): bool {
    if ($date === '') return true;
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) return false;
    [$y, $m, $d] = array_map('intval', explode('-', $date));
    return checkdate($m, $d, $y);
}
function examGrade(float $percentage): string {
    if ($percentage >= 85) return 'A';
    if ($percentage >= 70) return 'B';
    if ($percentage >= 60) return 'C';
    if ($percentage >= 50) return 'D';
    return 'E';
}
function examMakeCode(mysqli $db): string {
    for ($i = 0; $i < 12; $i++) {
        $code = 'EX-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(2)));
        $stmt = $db->prepare('SELECT 1 FROM school_exams WHERE exam_code = ? LIMIT 1');
        $stmt->bind_param('s', $code);
        $stmt->execute();
        $exists = (bool)$stmt->get_result()->fetch_row();
        $stmt->close();
        if (!$exists) return $code;
    }
    throw new RuntimeException('Could not generate an examination number. Please try again.');
}

$pageError = '';
$createdTables = [];
$students = [];
$exams = [];
$results = [];
$flash = $_SESSION['exams_flash'] ?? null;
unset($_SESSION['exams_flash']);
if (empty($_SESSION['exams_csrf'])) $_SESSION['exams_csrf'] = bin2hex(random_bytes(32));
$csrfToken = (string)$_SESSION['exams_csrf'];
$search = trim((string)($_GET['q'] ?? ''));
$classFilter = trim((string)($_GET['class'] ?? ''));
$yearFilter = trim((string)($_GET['year'] ?? ''));
$examEditId = max(0, (int)($_GET['edit'] ?? 0));
$resultEditId = max(0, (int)($_GET['edit_result'] ?? 0));
$selectedExamId = max(0, (int)($_GET['result_exam'] ?? 0));

try {
    if (!examTableExists($conn, 'school_exams')) {
        $conn->query("CREATE TABLE school_exams (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            exam_code VARCHAR(40) NOT NULL,
            title VARCHAR(150) NOT NULL,
            exam_type VARCHAR(50) NOT NULL DEFAULT 'End of Term',
            class_name VARCHAR(100) NOT NULL,
            subject_name VARCHAR(150) NOT NULL,
            term VARCHAR(30) NOT NULL,
            academic_year VARCHAR(10) NOT NULL,
            exam_date DATE DEFAULT NULL,
            duration_minutes INT UNSIGNED DEFAULT NULL,
            max_marks DECIMAL(7,2) NOT NULL DEFAULT 100.00,
            instructions TEXT DEFAULT NULL,
            status ENUM('scheduled','open','closed','cancelled') NOT NULL DEFAULT 'open',
            created_by INT DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_school_exam_code (exam_code),
            KEY idx_school_exam_class_year (class_name, academic_year),
            KEY idx_school_exam_subject (subject_name),
            KEY idx_school_exam_date (exam_date),
            KEY idx_school_exam_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $createdTables[] = 'school_exams';
    }
    if (!examTableExists($conn, 'school_exam_results')) {
        $conn->query("CREATE TABLE school_exam_results (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            exam_id INT UNSIGNED NOT NULL,
            student_id INT DEFAULT NULL,
            student_name VARCHAR(150) NOT NULL,
            admission_no VARCHAR(50) DEFAULT NULL,
            marks_obtained DECIMAL(7,2) NOT NULL DEFAULT 0.00,
            percentage DECIMAL(6,2) NOT NULL DEFAULT 0.00,
            grade VARCHAR(5) NOT NULL,
            remarks VARCHAR(255) DEFAULT NULL,
            entered_by INT DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_school_exam_result_exam (exam_id),
            KEY idx_school_exam_result_student (student_id),
            KEY idx_school_exam_result_grade (grade)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $createdTables[] = 'school_exam_results';
    }

    // Load existing students when the students table is available. Manual entry remains possible.
    if (examTableExists($conn, 'students')) {
        $studentCols = examColumns($conn, 'students');
        $studentIdCol = $studentCols['id'] ?? ($studentCols['student_id'] ?? null);
        if ($studentIdCol) {
            $studentResult = $conn->query('SELECT * FROM students ORDER BY `' . str_replace('`', '``', $studentIdCol) . '` DESC LIMIT 3000');
            while ($s = $studentResult->fetch_assoc()) {
                $id = (int)($s[$studentIdCol] ?? 0);
                if ($id < 1) continue;
                $first = trim((string)($s['first_name'] ?? ''));
                $other = trim((string)($s['other_names'] ?? $s['middle_name'] ?? ''));
                $last = trim((string)($s['last_name'] ?? ''));
                $name = trim(implode(' ', array_filter([$first, $other, $last], static fn($v) => $v !== '')));
                if ($name === '') $name = trim((string)($s['full_name'] ?? $s['student_name'] ?? $s['name'] ?? ''));
                if ($name === '') $name = 'Student #' . $id;
                $admission = (string)($s['admission_no'] ?? $s['admission_number'] ?? $s['registration_no'] ?? '');
                $studentClass = (string)($s['class_name'] ?? $s['class'] ?? $s['class_level'] ?? $s['stream'] ?? '');
                $linNo = trim((string)($s['lin_no'] ?? ''));
                $studentPaymentCode = trim((string)($s['student_payment_code'] ?? ''));
                $studentSection = trim((string)($s['student_section'] ?? 'Day')) ?: 'Day';
                $students[] = ['id' => $id, 'name' => $name, 'admission' => $admission, 'lin_no' => $linNo, 'student_payment_code' => $studentPaymentCode, 'student_section' => $studentSection, 'class_name' => $studentClass];
            }
            $studentResult->free();
        }
    }
} catch (Throwable $e) {
    $pageError = 'The examination page could not prepare its database tables. Please check that your database user has permission to create tables.';
    error_log('exams.php setup error: ' . $e->getMessage());
}

// Process form submissions only when the required tables are available.
if ($pageError === '' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($csrfToken, (string)($_POST['csrf_token'] ?? ''))) {
        examFlash('danger', 'Your form session expired. Refresh the page and try again.');
        examRedirect();
    }
    $action = (string)($_POST['action'] ?? '');
    try {
        if ($action === 'save_exam') {
            $id = max(0, (int)($_POST['exam_id'] ?? 0));
            $title = trim((string)($_POST['title'] ?? ''));
            $type = trim((string)($_POST['exam_type'] ?? 'End of Term'));
            $className = trim((string)($_POST['class_name'] ?? ''));
            $subjectName = trim((string)($_POST['subject_name'] ?? ''));
            $term = trim((string)($_POST['term'] ?? 'Term I'));
            $year = trim((string)($_POST['academic_year'] ?? date('Y')));
            $examDate = trim((string)($_POST['exam_date'] ?? ''));
            $durationRaw = trim((string)($_POST['duration_minutes'] ?? ''));
            $maxMarksRaw = trim((string)($_POST['max_marks'] ?? '100'));
            $instructions = trim((string)($_POST['instructions'] ?? ''));
            $status = trim((string)($_POST['status'] ?? 'open'));

            if ($title === '' || mb_strlen($title) > 150) throw new RuntimeException('Enter an examination title (maximum 150 characters).');
            if ($className === '' || mb_strlen($className) > 100) throw new RuntimeException('Enter a valid class or stream.');
            if ($subjectName === '' || mb_strlen($subjectName) > 150) throw new RuntimeException('Enter the subject name.');
            if (!in_array($type, ['Beginning of Term','Midterm','End of Term','Weekly Test','Monthly Test','Mock Examination','Practical','Oral','Other'], true)) throw new RuntimeException('Choose a valid examination type.');
            if (!in_array($term, ['Term I','Term II','Term III','Term 1','Term 2','Term 3'], true)) throw new RuntimeException('Choose a valid term.');
            if (!preg_match('/^\d{4}$/', $year)) throw new RuntimeException('Enter a valid four-digit academic year.');
            if (!examValidDate($examDate)) throw new RuntimeException('Enter a valid examination date.');
            if ($durationRaw !== '' && (!ctype_digit($durationRaw) || (int)$durationRaw < 1 || (int)$durationRaw > 1000)) throw new RuntimeException('Duration must be between 1 and 1000 minutes.');
            if ($maxMarksRaw === '' || !is_numeric($maxMarksRaw) || !is_finite((float)$maxMarksRaw) || (float)$maxMarksRaw <= 0 || (float)$maxMarksRaw > 100000) throw new RuntimeException('Maximum marks must be greater than zero and not exceed 100,000.');
            if (!in_array($status, ['scheduled','open','closed','cancelled'], true)) throw new RuntimeException('Choose a valid examination status.');

            $maxMarks = round((float)$maxMarksRaw, 2);
            $duration = $durationRaw !== '' ? (int)$durationRaw : null;
            $examDateDb = $examDate !== '' ? $examDate : null;
            $instructionsDb = $instructions !== '' ? $instructions : null;
            if ($id > 0) {
                $check = $conn->prepare('SELECT id FROM school_exams WHERE id = ? LIMIT 1');
                $check->bind_param('i', $id); $check->execute(); $exists = (bool)$check->get_result()->fetch_row(); $check->close();
                if (!$exists) throw new RuntimeException('The examination you are editing could not be found.');
                $stmt = $conn->prepare('UPDATE school_exams SET title=?, exam_type=?, class_name=?, subject_name=?, term=?, academic_year=?, exam_date=?, duration_minutes=?, max_marks=?, instructions=?, status=? WHERE id=?');
                $stmt->bind_param('sssssssidssi', $title, $type, $className, $subjectName, $term, $year, $examDateDb, $duration, $maxMarks, $instructionsDb, $status, $id);
                $stmt->execute(); $stmt->close();
                examFlash('success', 'Examination updated successfully.');
            } else {
                $code = examMakeCode($conn);
                $stmt = $conn->prepare('INSERT INTO school_exams (exam_code,title,exam_type,class_name,subject_name,term,academic_year,exam_date,duration_minutes,max_marks,instructions,status,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)');
                $stmt->bind_param('ssssssssidssi', $code, $title, $type, $className, $subjectName, $term, $year, $examDateDb, $duration, $maxMarks, $instructionsDb, $status, $userId);
                $stmt->execute(); $newExamId = (int)$stmt->insert_id; $stmt->close();
                examFlash('success', 'Examination created successfully. Examination No: ' . $code);
                examRedirect('exams.php?result_exam=' . $newExamId . '#results');
            }
            examRedirect('exams.php');
        }

        if ($action === 'delete_exam') {
            $id = max(0, (int)($_POST['exam_id'] ?? 0));
            if ($id < 1) throw new RuntimeException('Select a valid examination to delete.');
            $conn->begin_transaction();
            $stmt = $conn->prepare('DELETE FROM school_exam_results WHERE exam_id = ?');
            $stmt->bind_param('i', $id); $stmt->execute(); $stmt->close();
            $stmt = $conn->prepare('DELETE FROM school_exams WHERE id = ?');
            $stmt->bind_param('i', $id); $stmt->execute(); $deleted = $stmt->affected_rows; $stmt->close();
            $conn->commit();
            examFlash($deleted ? 'success' : 'warning', $deleted ? 'Examination and its recorded marks were deleted.' : 'No examination was deleted.');
            examRedirect();
        }

        if ($action === 'save_result') {
            $resultId = max(0, (int)($_POST['result_id'] ?? 0));
            $examId = max(0, (int)($_POST['result_exam_id'] ?? 0));
            $studentId = max(0, (int)($_POST['student_id'] ?? 0));
            $studentName = trim((string)($_POST['student_name'] ?? ''));
            $admissionNo = trim((string)($_POST['admission_no'] ?? ''));
            $marksRaw = trim((string)($_POST['marks_obtained'] ?? ''));
            $remarks = trim((string)($_POST['remarks'] ?? ''));
            if ($examId < 1) throw new RuntimeException('Select an examination first.');
            $stmt = $conn->prepare('SELECT id, class_name, max_marks, status FROM school_exams WHERE id = ? LIMIT 1');
            $stmt->bind_param('i', $examId); $stmt->execute(); $examRow = $stmt->get_result()->fetch_assoc(); $stmt->close();
            if (!$examRow) throw new RuntimeException('The selected examination does not exist.');
            if ($examRow['status'] === 'cancelled') throw new RuntimeException('This examination is cancelled; marks cannot be entered.');
            if ($studentId > 0) {
                $studentFound = null;
                foreach ($students as $student) if ((int)$student['id'] === $studentId) { $studentFound = $student; break; }
                if (!$studentFound) throw new RuntimeException('Select a valid student from the student list, or use manual entry.');
                $studentName = $studentFound['name'];
                $admissionNo = $studentFound['admission'];
            }
            if ($studentName === '' || mb_strlen($studentName) > 150) throw new RuntimeException('Select a student or enter the student’s full name.');
            if (mb_strlen($admissionNo) > 50) throw new RuntimeException('Admission number must be 50 characters or fewer.');
            if ($marksRaw === '' || !is_numeric($marksRaw) || !is_finite((float)$marksRaw)) throw new RuntimeException('Enter a valid mark.');
            $marks = round((float)$marksRaw, 2);
            $maxMarks = (float)$examRow['max_marks'];
            if ($marks < 0 || $marks > $maxMarks) throw new RuntimeException('Marks must be between 0 and ' . number_format($maxMarks, 2) . '.');
            if (mb_strlen($remarks) > 255) throw new RuntimeException('Remarks must be 255 characters or fewer.');
            if ($studentId > 0) {
                $checkSql = 'SELECT id FROM school_exam_results WHERE exam_id=? AND student_id=?' . ($resultId > 0 ? ' AND id<>?' : '') . ' LIMIT 1';
                $check = $conn->prepare($checkSql);
                if ($resultId > 0) $check->bind_param('iii', $examId, $studentId, $resultId); else $check->bind_param('ii', $examId, $studentId);
                $check->execute(); $duplicate = (bool)$check->get_result()->fetch_row(); $check->close();
                if ($duplicate) throw new RuntimeException('A result for this student already exists in this examination. Edit the existing result instead.');
            }
            $percentage = round(($marks / $maxMarks) * 100, 2);
            $grade = examGrade($percentage);
            $admissionDb = $admissionNo !== '' ? $admissionNo : null;
            $remarksDb = $remarks !== '' ? $remarks : null;
            $studentIdDb = $studentId > 0 ? $studentId : null;
            if ($resultId > 0) {
                $check = $conn->prepare('SELECT id FROM school_exam_results WHERE id=? LIMIT 1');
                $check->bind_param('i', $resultId); $check->execute(); $resultExists = (bool)$check->get_result()->fetch_row(); $check->close();
                if (!$resultExists) throw new RuntimeException('The result you are editing could not be found.');
                $stmt = $conn->prepare('UPDATE school_exam_results SET exam_id=?, student_id=?, student_name=?, admission_no=?, marks_obtained=?, percentage=?, grade=?, remarks=?, entered_by=? WHERE id=?');
                $stmt->bind_param('iissddssii', $examId, $studentIdDb, $studentName, $admissionDb, $marks, $percentage, $grade, $remarksDb, $userId, $resultId);
                $stmt->execute(); $stmt->close();
                examFlash('success', 'Student examination result updated. Grade: ' . $grade . '.');
            } else {
                $stmt = $conn->prepare('INSERT INTO school_exam_results (exam_id,student_id,student_name,admission_no,marks_obtained,percentage,grade,remarks,entered_by) VALUES (?,?,?,?,?,?,?,?,?)');
                $stmt->bind_param('iissddssi', $examId, $studentIdDb, $studentName, $admissionDb, $marks, $percentage, $grade, $remarksDb, $userId);
                $stmt->execute(); $stmt->close();
                examFlash('success', 'Student mark recorded successfully. Percentage: ' . number_format($percentage, 2) . '%. Grade: ' . $grade . '.');
            }
            examRedirect('exams.php?result_exam=' . $examId . '#results');
        }

        if ($action === 'delete_result') {
            $resultId = max(0, (int)($_POST['result_id'] ?? 0));
            $examId = max(0, (int)($_POST['result_exam_id'] ?? 0));
            if ($resultId < 1) throw new RuntimeException('Select a valid result to delete.');
            $stmt = $conn->prepare('DELETE FROM school_exam_results WHERE id = ?');
            $stmt->bind_param('i', $resultId); $stmt->execute(); $deleted = $stmt->affected_rows; $stmt->close();
            examFlash($deleted ? 'success' : 'warning', $deleted ? 'Examination result deleted.' : 'No result was deleted.');
            examRedirect('exams.php?result_exam=' . $examId . '#results');
        }
        throw new RuntimeException('Invalid form action. Refresh the page and try again.');
    } catch (Throwable $e) {
        try { $conn->rollback(); } catch (Throwable $ignored) {}
        error_log('exams.php action error: ' . $e->getMessage());
        $message = $e instanceof RuntimeException ? $e->getMessage() : 'The action could not be completed. Please check the PHP error log.';
        examFlash('danger', $message);
        $keepExam = max(0, (int)($_POST['result_exam_id'] ?? $_POST['exam_id'] ?? 0));
        examRedirect($keepExam > 0 && $action !== 'delete_exam' ? 'exams.php?result_exam=' . $keepExam . '#results' : 'exams.php');
    }
}

// Reload flash after a redirect or postback.
$flash = $_SESSION['exams_flash'] ?? $flash;
unset($_SESSION['exams_flash']);

if ($pageError === '') {
    try {
        $where = [];
        $params = [];
        $types = '';
        if ($search !== '') {
            $where[] = '(exam_code LIKE ? OR title LIKE ? OR class_name LIKE ? OR subject_name LIKE ?)';
            $like = '%' . $search . '%';
            array_push($params, $like, $like, $like, $like); $types .= 'ssss';
        }
        if ($classFilter !== '') { $where[] = 'class_name = ?'; $params[] = $classFilter; $types .= 's'; }
        if ($yearFilter !== '') { $where[] = 'academic_year = ?'; $params[] = $yearFilter; $types .= 's'; }
        $sql = 'SELECT * FROM school_exams' . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY academic_year DESC, exam_date DESC, id DESC LIMIT 500';
        $stmt = $conn->prepare($sql);
        if ($types !== '') {
            $bindArgs = [$types]; foreach ($params as $key => &$value) $bindArgs[] = &$value;
            call_user_func_array([$stmt, 'bind_param'], $bindArgs);
        }
        $stmt->execute(); $rs = $stmt->get_result();
        while ($r = $rs->fetch_assoc()) $exams[] = $r;
        $stmt->close();
    } catch (Throwable $e) {
        $pageError = 'Examination records could not be loaded. Please check the PHP error log.';
        error_log('exams.php list error: ' . $e->getMessage());
    }
}

$editExam = null;
if ($examEditId > 0 && $pageError === '') {
    $stmt = $conn->prepare('SELECT * FROM school_exams WHERE id=? LIMIT 1');
    $stmt->bind_param('i', $examEditId); $stmt->execute(); $editExam = $stmt->get_result()->fetch_assoc(); $stmt->close();
}
$editResult = null;
if ($resultEditId > 0 && $pageError === '') {
    $stmt = $conn->prepare('SELECT * FROM school_exam_results WHERE id=? LIMIT 1');
    $stmt->bind_param('i', $resultEditId); $stmt->execute(); $editResult = $stmt->get_result()->fetch_assoc(); $stmt->close();
    if ($editResult && $selectedExamId < 1) $selectedExamId = (int)$editResult['exam_id'];
}

// Use all exams for the marks-entry selector even when the exam-list filters are active.
$allExamOptions = [];
if ($pageError === '') {
    $rs = $conn->query('SELECT id, exam_code, title, class_name, subject_name, term, academic_year, max_marks, status FROM school_exams ORDER BY academic_year DESC, exam_date DESC, id DESC LIMIT 1000');
    while ($r = $rs->fetch_assoc()) $allExamOptions[] = $r;
    $rs->free();
}
if ($selectedExamId < 1 && $editResult) $selectedExamId = (int)$editResult['exam_id'];
if ($selectedExamId < 1 && $allExamOptions) {
    foreach ($allExamOptions as $option) if ($option['status'] !== 'cancelled') { $selectedExamId = (int)$option['id']; break; }
    if ($selectedExamId < 1) $selectedExamId = (int)$allExamOptions[0]['id'];
}
$selectedExam = null;
foreach ($allExamOptions as $option) if ((int)$option['id'] === $selectedExamId) { $selectedExam = $option; break; }

if ($pageError === '' && $selectedExamId > 0) {
    try {
        $stmt = $conn->prepare('SELECT r.*, s.lin_no AS current_lin_no, s.student_payment_code AS current_student_payment_code, s.student_section AS current_student_section FROM school_exam_results r LEFT JOIN students s ON s.id = r.student_id WHERE r.exam_id = ? ORDER BY r.student_name ASC, r.id ASC');
        $stmt->bind_param('i', $selectedExamId); $stmt->execute(); $rs = $stmt->get_result();
        while ($r = $rs->fetch_assoc()) $results[] = $r;
        $stmt->close();
    } catch (Throwable $e) { error_log('exams.php result list error: ' . $e->getMessage()); }
}

$examCount = count($allExamOptions);
$openExamCount = 0;
foreach ($allExamOptions as $ex) if (in_array($ex['status'], ['open','scheduled'], true)) $openExamCount++;
$studentResultCount = 0;
if ($pageError === '') {
    $countResult = $conn->query('SELECT COUNT(*) AS total FROM school_exam_results');
    if ($countResult) { $studentResultCount = (int)($countResult->fetch_assoc()['total'] ?? 0); $countResult->free(); }
}
$classes = [];
$years = [];
foreach ($allExamOptions as $ex) { $classes[$ex['class_name']] = true; $years[$ex['academic_year']] = true; }
$classes = array_keys($classes); sort($classes, SORT_NATURAL | SORT_FLAG_CASE);
$years = array_keys($years); rsort($years, SORT_NATURAL);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Examination Management | School Management System</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f6f9;font-family:Arial,Helvetica,sans-serif;color:#343a40}.sidebar{position:fixed;top:0;bottom:0;left:0;width:250px;background:#212529;overflow-y:auto;z-index:1050}.sidebar-header{padding:22px 18px;background:#171a1d;color:#fff;font-weight:700;font-size:18px}.sidebar-section{padding:15px 16px 6px;color:#868e96;font-size:11px;text-transform:uppercase;font-weight:bold;letter-spacing:.5px}.sidebar a{display:block;color:#ced4da;padding:11px 16px;text-decoration:none;border-left:4px solid transparent;font-size:14px}.sidebar a:hover,.sidebar a.active{background:#343a40;color:#fff;border-left-color:#dc3545}.sidebar a i{width:24px;text-align:center;margin-right:5px}.main{margin-left:250px;min-height:100vh}.topbar{padding:17px 25px;background:#fff;border-bottom:1px solid #e5e5e5;display:flex;align-items:center;justify-content:space-between}.content{padding:24px}.page-head,.panel,.stat-card{background:#fff;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,.05)}.page-head{padding:21px;margin-bottom:20px}.panel{padding:21px;margin-bottom:22px}.stat-card{padding:18px;margin-bottom:18px}.stat-title{color:#6c757d;font-size:13px}.stat-number{font-size:22px;font-weight:700}.form-control,.custom-select,.btn{border-radius:6px}.form-control,.custom-select{min-height:38px}label{font-size:13px;font-weight:600}.table th{background:#f8f9fa;white-space:nowrap;font-size:12px}.table td{vertical-align:middle;font-size:13px}.mobile-menu{display:none}.alert{font-size:13px}.field-note{font-size:12px;color:#6c757d}.mark-grade{font-weight:700}.status-pill{display:inline-block;padding:5px 9px;border-radius:16px;font-size:11px;font-weight:700}.status-open{color:#155724;background:#d4edda}.status-scheduled{color:#856404;background:#fff3cd}.status-closed{color:#495057;background:#e2e3e5}.status-cancelled{color:#721c24;background:#f8d7da}.table td{vertical-align:middle}.table .remark-cell{min-width:150px;max-width:250px;overflow-wrap:anywhere}.form-section-title{font-size:16px;font-weight:700;border-bottom:1px solid #e9ecef;padding-bottom:10px;margin-bottom:16px}.filter-card{border:1px solid #edf0f5}.empty-state{text-align:center;color:#6c757d;padding:30px 12px}.nowrap{white-space:nowrap}@media(max-width:991px){.sidebar{left:-250px;transition:left .25s}.sidebar.show{left:0}.main{margin-left:0}.mobile-menu{display:inline-block}.content{padding:15px}.topbar{padding:12px 15px}}@media print{.sidebar,.topbar,.no-print{display:none!important}.main{margin:0}.content{padding:0}.page-head,.panel,.stat-card{box-shadow:none;border:0}}
</style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<aside class="sidebar no-print" id="sidebar">
 <div class="sidebar-header"><i class="fas fa-school mr-2"></i>School Management<br><small class="text-muted">Academic Panel</small></div>
 <div class="sidebar-section">Students &amp; Learning</div>
 <a href="/admin/students/list.php"><i class="fas fa-user-graduate"></i>Students</a>
 <a href="/admin/classes/student_reports.php"><i class="fas fa-file-alt"></i>Student Reports</a>
 <a href="/admin/classes/exams.php" class="active"><i class="fas fa-clipboard-list"></i>Examinations</a>
 <div class="sidebar-section">Academic</div>
 <a href="/admin/teachers/index.php"><i class="fas fa-chalkboard-teacher"></i>Teachers</a>
 <a href="/admin/classes/index.php"><i class="fas fa-school"></i>Classes</a>
 <div class="sidebar-section">Administration</div>
 <a href="/admin/dashboard.php"><i class="fas fa-user-shield"></i>Admin Dashboard</a>
 <a href="/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
</aside>
<div class="main">
 <div class="topbar">
  <div class="d-flex align-items-start"><button type="button" id="mobileMenuBtn" class="btn btn-outline-secondary mobile-menu mr-3" aria-label="Open menu"><i class="fas fa-bars"></i></button><div><div class="small text-uppercase text-danger font-weight-bold">Students / Assessment</div><h4 class="mb-1 font-weight-bold">Examination Management</h4><div class="text-muted small">Create examinations, enter student marks and calculate grades.</div></div></div>
  <div class="text-muted small"><i class="fas fa-user-circle mr-1"></i><?= examE($_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Teacher') ?></div>
 </div>
 <div class="content">
  <div class="page-head d-flex justify-content-between align-items-center flex-wrap">
   <div><h3 class="mb-1"><i class="fas fa-clipboard-check text-danger mr-2"></i>Examination Form</h3><div class="text-muted">Set exam details for each class and subject, then enter marks for each student.</div></div>
   <div class="mt-2 no-print"><button type="button" class="btn btn-danger" onclick="document.getElementById('examForm').scrollIntoView({behavior:'smooth'});"><i class="fas fa-plus mr-1"></i>New Examination</button> <button type="button" class="btn btn-outline-secondary" onclick="window.print()"><i class="fas fa-print mr-1"></i>Print</button></div>
  </div>

  <?php if ($createdTables): ?><div class="alert alert-info"><i class="fas fa-info-circle mr-1"></i>Created database table(s): <?= examE(implode(', ', $createdTables)) ?>.</div><?php endif; ?>
  <?php if ($pageError !== ''): ?><div class="alert alert-danger"><strong><i class="fas fa-exclamation-triangle mr-1"></i>Database issue:</strong> <?= examE($pageError) ?></div><?php endif; ?>
  <?php if (is_array($flash) && !empty($flash['message'])): ?><div class="alert alert-<?= examE($flash['type'] ?? 'info') ?> alert-dismissible fade show" role="alert"><?= examE($flash['message']) ?><button type="button" class="close" data-dismiss="alert"><span>&times;</span></button></div><?php endif; ?>

  <div class="row">
   <div class="col-md-4"><div class="stat-card"><div class="stat-title">Total Examinations</div><div class="stat-number text-primary"><?= number_format($examCount) ?></div></div></div>
   <div class="col-md-4"><div class="stat-card"><div class="stat-title">Open / Scheduled</div><div class="stat-number text-success"><?= number_format($openExamCount) ?></div></div></div>
   <div class="col-md-4"><div class="stat-card"><div class="stat-title">Student Results Recorded</div><div class="stat-number text-danger"><?= number_format($studentResultCount) ?></div></div></div>
  </div>

  <?php if ($pageError === ''): ?>
  <section class="panel no-print" id="examForm">
   <h5 class="form-section-title"><i class="fas fa-edit text-danger mr-2"></i><?= $editExam ? 'Edit Examination' : 'Create Examination' ?></h5>
   <form method="post" action="exams.php<?= $editExam ? '?edit='.(int)$editExam['id'] : '' ?>" autocomplete="off">
    <input type="hidden" name="csrf_token" value="<?= examE($csrfToken) ?>"><input type="hidden" name="action" value="save_exam"><input type="hidden" name="exam_id" value="<?= (int)($editExam['id'] ?? 0) ?>">
    <div class="form-row">
     <div class="form-group col-lg-5 col-md-6"><label for="title">Examination title *</label><input class="form-control" id="title" name="title" maxlength="150" required value="<?= examE($editExam['title'] ?? '') ?>" placeholder="e.g. End of Term I Examination"></div>
     <div class="form-group col-lg-3 col-md-6"><label for="exam_type">Exam type *</label><select class="custom-select" name="exam_type" id="exam_type" required><?php foreach (['Beginning of Term','Midterm','End of Term','Weekly Test','Monthly Test','Mock Examination','Practical','Oral','Other'] as $t): ?><option value="<?= examE($t) ?>" <?= ($editExam['exam_type'] ?? 'End of Term') === $t ? 'selected' : '' ?>><?= examE($t) ?></option><?php endforeach; ?></select></div>
     <div class="form-group col-lg-2 col-md-6"><label for="term">Term *</label><select class="custom-select" name="term" id="term" required><?php foreach (['Term I','Term II','Term III'] as $t): ?><option value="<?= examE($t) ?>" <?= ($editExam['term'] ?? 'Term I') === $t ? 'selected' : '' ?>><?= examE($t) ?></option><?php endforeach; ?></select></div>
     <div class="form-group col-lg-2 col-md-6"><label for="academic_year">Year *</label><input class="form-control" id="academic_year" name="academic_year" maxlength="4" pattern="\d{4}" required value="<?= examE($editExam['academic_year'] ?? date('Y')) ?>"></div>
    </div>
    <div class="form-row">
     <div class="form-group col-lg-3 col-md-6"><label for="class_name">Class / Stream *</label><input class="form-control" id="class_name" name="class_name" maxlength="100" required value="<?= examE($editExam['class_name'] ?? '') ?>" list="classSuggestions" placeholder="e.g. S.1 WEST"><datalist id="classSuggestions"><?php foreach ($classes as $classOption): ?><option value="<?= examE($classOption) ?>"><?php endforeach; ?></datalist></div>
     <div class="form-group col-lg-3 col-md-6"><label for="subject_name">Subject *</label><input class="form-control" id="subject_name" name="subject_name" maxlength="150" required value="<?= examE($editExam['subject_name'] ?? '') ?>" list="subjectSuggestions" placeholder="e.g. Mathematics"><datalist id="subjectSuggestions"><?php foreach (['Agriculture','Biology','C.R.E','Chemistry','Computer Studies','English','Entrepreneurship','Fine Art','Geography','History','Kiswahili','Luganda','Mathematics','Physical Education','Physics','Technical Drawing'] as $subjectOption): ?><option value="<?= examE($subjectOption) ?>"><?php endforeach; ?></datalist></div>
     <div class="form-group col-lg-2 col-md-6"><label for="exam_date">Examination date</label><input type="date" class="form-control" id="exam_date" name="exam_date" value="<?= examE($editExam['exam_date'] ?? '') ?>"></div>
     <div class="form-group col-lg-2 col-md-6"><label for="duration_minutes">Duration (minutes)</label><input type="number" min="1" max="1000" class="form-control" id="duration_minutes" name="duration_minutes" value="<?= examE($editExam['duration_minutes'] ?? '') ?>" placeholder="e.g. 120"></div>
     <div class="form-group col-lg-2 col-md-6"><label for="max_marks">Maximum marks *</label><input type="number" min="0.01" max="100000" step="0.01" class="form-control" id="max_marks" name="max_marks" required value="<?= examE($editExam['max_marks'] ?? '100') ?>"></div>
    </div>
    <div class="form-row">
     <div class="form-group col-md-3"><label for="status">Status</label><select class="custom-select" name="status" id="status"><?php foreach (['scheduled','open','closed','cancelled'] as $st): ?><option value="<?= examE($st) ?>" <?= ($editExam['status'] ?? 'open') === $st ? 'selected' : '' ?>><?= examE(ucfirst($st)) ?></option><?php endforeach; ?></select></div>
     <div class="form-group col-md-9"><label for="instructions">Instructions / Notes</label><textarea class="form-control" id="instructions" name="instructions" rows="2" placeholder="Instructions for students or notes for the teacher"><?= examE($editExam['instructions'] ?? '') ?></textarea></div>
    </div>
    <button type="submit" class="btn btn-danger"><i class="fas fa-save mr-1"></i><?= $editExam ? 'Update Examination' : 'Save Examination' ?></button>
    <?php if ($editExam): ?> <a href="exams.php" class="btn btn-outline-secondary">Cancel edit</a><?php else: ?> <button type="reset" class="btn btn-outline-secondary">Clear form</button><?php endif; ?>
    <div class="field-note mt-2">The mark grade is calculated from the percentage of the maximum marks: A ≥ 85%, B ≥ 70%, C ≥ 60%, D ≥ 50%, otherwise E. These are the default bands from the report-card example.</div>
   </form>
  </section>

  <section class="panel no-print">
   <div class="d-flex justify-content-between align-items-center flex-wrap mb-3"><div><h5 class="mb-1"><i class="fas fa-list text-danger mr-2"></i>Examinations</h5><div class="small text-muted">Open an exam to enter results. You can also edit or delete exam setup details.</div></div></div>
   <form method="get" action="exams.php" class="form-row align-items-end mb-3">
    <div class="form-group col-lg-5 col-md-6"><label for="q">Search title, subject, class or exam number</label><input class="form-control" type="search" name="q" id="q" value="<?= examE($search) ?>" placeholder="Search examinations"></div>
    <div class="form-group col-lg-2 col-md-3"><label for="class_filter">Class</label><select class="custom-select" id="class_filter" name="class"><option value="">All classes</option><?php foreach ($classes as $cl): ?><option value="<?= examE($cl) ?>" <?= $classFilter === $cl ? 'selected' : '' ?>><?= examE($cl) ?></option><?php endforeach; ?></select></div>
    <div class="form-group col-lg-2 col-md-3"><label for="year_filter">Year</label><select class="custom-select" id="year_filter" name="year"><option value="">All years</option><?php foreach ($years as $y): ?><option value="<?= examE($y) ?>" <?= $yearFilter === $y ? 'selected' : '' ?>><?= examE($y) ?></option><?php endforeach; ?></select></div>
    <div class="form-group col-lg-3"><button class="btn btn-primary" type="submit"><i class="fas fa-search mr-1"></i>Filter</button> <a class="btn btn-outline-secondary" href="exams.php">Reset</a></div>
   </form>
   <div class="table-responsive"><table class="table table-hover table-bordered mb-0"><thead><tr><th>Exam No.</th><th>Examination</th><th>Class / Subject</th><th>Term / Year</th><th>Date</th><th>Out of</th><th>Status</th><th>Actions</th></tr></thead><tbody>
   <?php if (!$exams): ?><tr><td colspan="8" class="text-center text-muted py-4"><i class="fas fa-clipboard-list fa-2x mb-2"></i><br>No examinations found. Use the form above to create one.</td></tr><?php else: foreach ($exams as $ex): ?><tr>
    <td class="nowrap"><strong><?= examE($ex['exam_code']) ?></strong></td><td><strong><?= examE($ex['title']) ?></strong><div class="small text-muted"><?= examE($ex['exam_type']) ?></div></td><td><?= examE($ex['class_name']) ?><div class="small text-muted"><?= examE($ex['subject_name']) ?></div></td><td><?= examE($ex['term']) ?><div class="small text-muted"><?= examE($ex['academic_year']) ?></div></td><td class="nowrap"><?= $ex['exam_date'] ? examE(date('d M Y', strtotime($ex['exam_date']))) : '—' ?></td><td><?= number_format((float)$ex['max_marks'], 2) ?></td><td><span class="status-pill status-<?= examE($ex['status']) ?>"><?= examE(ucfirst($ex['status'])) ?></span></td>
    <td class="nowrap"><a class="btn btn-sm btn-outline-success mb-1" href="exams.php?result_exam=<?= (int)$ex['id'] ?>#results" title="Enter marks"><i class="fas fa-pen"></i> Marks</a> <a class="btn btn-sm btn-outline-primary mb-1" href="exams.php?edit=<?= (int)$ex['id'] ?>#examForm" title="Edit exam"><i class="fas fa-edit"></i></a> <form method="post" class="d-inline" onsubmit="return confirm('Delete this examination and all marks recorded for it?');"><input type="hidden" name="csrf_token" value="<?= examE($csrfToken) ?>"><input type="hidden" name="action" value="delete_exam"><input type="hidden" name="exam_id" value="<?= (int)$ex['id'] ?>"><button class="btn btn-sm btn-outline-danger mb-1" type="submit" title="Delete examination"><i class="fas fa-trash"></i></button></form></td>
   </tr><?php endforeach; endif; ?>
   </tbody></table></div>
  </section>

  <section class="panel" id="results">
   <h5 class="form-section-title"><i class="fas fa-marker text-danger mr-2"></i>Enter Student Marks</h5>
   <?php if (!$allExamOptions): ?><div class="alert alert-info mb-0">Create an examination above first. The marks-entry form will be available after an examination has been saved.</div>
   <?php else: ?>
   <form method="get" action="exams.php#results" class="form-row align-items-end mb-4 no-print">
    <div class="form-group col-md-8"><label for="result_exam">Select examination</label><select class="custom-select" name="result_exam" id="result_exam" required onchange="this.form.submit()"><?php foreach ($allExamOptions as $op): ?><option value="<?= (int)$op['id'] ?>" <?= $selectedExamId === (int)$op['id'] ? 'selected' : '' ?>><?= examE($op['exam_code'].' | '.$op['title'].' | '.$op['class_name'].' — '.$op['subject_name'].' | '.$op['term'].' '.$op['academic_year'].' (out of '.number_format((float)$op['max_marks'], 2).')') ?></option><?php endforeach; ?></select></div>
    <div class="form-group col-md-4"><button type="submit" class="btn btn-primary"><i class="fas fa-folder-open mr-1"></i>Load Examination</button> <?php if ($selectedExamId): ?><button class="btn btn-outline-secondary" type="button" onclick="window.print()"><i class="fas fa-print"></i></button><?php endif; ?></div>
   </form>
   <?php if ($selectedExam): ?>
   <div class="alert alert-light border"><strong><?= examE($selectedExam['title']) ?></strong> &mdash; <?= examE($selectedExam['class_name']) ?> / <?= examE($selectedExam['subject_name']) ?>, <?= examE($selectedExam['term']) ?> <?= examE($selectedExam['academic_year']) ?>. Maximum mark: <strong><?= number_format((float)$selectedExam['max_marks'], 2) ?></strong>.</div>
   <form method="post" action="exams.php?result_exam=<?= (int)$selectedExamId ?>#results" class="no-print" id="resultForm">
    <input type="hidden" name="csrf_token" value="<?= examE($csrfToken) ?>"><input type="hidden" name="action" value="save_result"><input type="hidden" name="result_exam_id" value="<?= (int)$selectedExamId ?>"><input type="hidden" name="result_id" value="<?= (int)($editResult['id'] ?? 0) ?>">
    <div class="form-row">
     <?php if ($students): ?><div class="form-group col-lg-4 col-md-6"><label for="student_id">Choose student (optional)</label><select class="custom-select" name="student_id" id="student_id"><option value="0">Manual entry / student not listed</option><?php foreach ($students as $s): ?><option value="<?= (int)$s['id'] ?>" data-name="<?= examE($s['name']) ?>" data-admission="<?= examE($s['admission']) ?>" data-lin="<?= examE($s['lin_no']) ?>" data-payment-code="<?= examE($s['student_payment_code']) ?>" data-section="<?= examE($s['student_section']) ?>" <?= (int)($editResult['student_id'] ?? 0) === (int)$s['id'] ? 'selected' : '' ?>><?= examE($s['name'].($s['admission'] !== '' ? ' — Admission: '.$s['admission'] : '').($s['lin_no'] !== '' ? ' — LIN: '.$s['lin_no'] : '').($s['student_payment_code'] !== '' ? ' — Payment Code: '.$s['student_payment_code'] : '').' — '.$s['student_section'].($s['class_name'] !== '' ? ' — '.$s['class_name'] : '')) ?></option><?php endforeach; ?></select></div><?php endif; ?>
     <div class="form-group col-lg-4 col-md-6"><label for="student_name">Student full name *</label><input class="form-control" id="student_name" name="student_name" maxlength="150" required value="<?= examE($editResult['student_name'] ?? '') ?>" placeholder="Enter student's full name"></div>
     <div class="form-group col-lg-2 col-md-6"><label for="admission_no">Admission number</label><input class="form-control" id="admission_no" name="admission_no" maxlength="50" value="<?= examE($editResult['admission_no'] ?? '') ?>" placeholder="Admission no."></div>
     <div class="form-group col-lg-2 col-md-6"><label for="marks_obtained">Marks (out of <?= $selectedExam ? number_format((float)$selectedExam['max_marks'], 2) : '100' ?>) *</label><input class="form-control" type="number" name="marks_obtained" id="marks_obtained" min="0" max="<?= examE($selectedExam['max_marks']) ?>" step="0.01" required value="<?= isset($editResult['marks_obtained']) ? examE($editResult['marks_obtained']) : '' ?>" placeholder="0.00"></div>
    </div>
    <div class="form-row"><div class="form-group col-md-8"><label for="remarks">Teacher's remarks</label><input class="form-control" type="text" id="remarks" name="remarks" maxlength="255" value="<?= examE($editResult['remarks'] ?? '') ?>" placeholder="e.g. Good work; revise algebra"></div><div class="form-group col-md-4"><label>Calculated percentage / grade</label><div class="form-control bg-light" id="gradePreview" aria-live="polite">Enter marks to calculate grade</div></div></div>
    <button type="submit" class="btn btn-danger"><i class="fas fa-save mr-1"></i><?= $editResult ? 'Update Student Result' : 'Save Student Marks' ?></button>
    <?php if ($editResult): ?><a class="btn btn-outline-secondary" href="exams.php?result_exam=<?= (int)$selectedExamId ?>#results">Cancel edit</a><?php endif; ?>
   </form>
   <hr class="my-4">
   <div class="d-flex flex-wrap justify-content-between align-items-center mb-3"><div><h6 class="font-weight-bold mb-1">Recorded Results</h6><div class="small text-muted"><?= count($results) ?> student result(s) for this examination.</div></div><button class="btn btn-outline-secondary btn-sm no-print" onclick="window.print()" type="button"><i class="fas fa-print mr-1"></i>Print Results</button></div>
   <div class="table-responsive"><table class="table table-bordered table-hover mb-0"><thead><tr><th>#</th><th>Student</th><th>Admission No.</th><th class="text-right">Marks</th><th class="text-right">Percentage</th><th>Grade</th><th>Remarks</th><th class="no-print">Actions</th></tr></thead><tbody>
   <?php if (!$results): ?><tr><td colspan="8" class="text-center text-muted py-4">No student marks have been entered for this examination yet.</td></tr><?php else: $i=1; foreach ($results as $rr): ?><tr><td><?= $i++ ?></td><td><strong><?= examE($rr['student_name']) ?></strong></td><td><?= examE($rr['admission_no'] ?: '—') ?><div class="small text-muted">LIN: <?= examE($rr['current_lin_no'] ?? '—') ?> | Payment Code: <?= examE($rr['current_student_payment_code'] ?? '—') ?> | <?= examE($rr['current_student_section'] ?? 'Day') ?></div></td><td class="text-right font-weight-bold"><?= number_format((float)$rr['marks_obtained'], 2) ?> / <?= number_format((float)$selectedExam['max_marks'], 2) ?></td><td class="text-right"><?= number_format((float)$rr['percentage'], 2) ?>%</td><td><span class="badge badge-<?= $rr['grade'] === 'A' ? 'success' : ($rr['grade'] === 'B' ? 'primary' : ($rr['grade'] === 'E' ? 'danger' : 'secondary')) ?> mark-grade"><?= examE($rr['grade']) ?></span></td><td class="remark-cell"><?= examE($rr['remarks'] ?: '—') ?></td><td class="no-print nowrap"><a class="btn btn-sm btn-outline-primary" href="exams.php?result_exam=<?= (int)$selectedExamId ?>&edit_result=<?= (int)$rr['id'] ?>#results" title="Edit result"><i class="fas fa-edit"></i></a> <form method="post" class="d-inline" onsubmit="return confirm('Delete this student's result?');"><input type="hidden" name="csrf_token" value="<?= examE($csrfToken) ?>"><input type="hidden" name="action" value="delete_result"><input type="hidden" name="result_id" value="<?= (int)$rr['id'] ?>"><input type="hidden" name="result_exam_id" value="<?= (int)$selectedExamId ?>"><button type="submit" class="btn btn-sm btn-outline-danger" title="Delete result"><i class="fas fa-trash"></i></button></form></td></tr><?php endforeach; endif; ?>
   </tbody></table></div>
   <?php endif; ?>
   <?php endif; ?>
  </section>
  <?php endif; ?>
  <div class="text-center text-muted small pb-3">School Management System &mdash; Examination Management. Grade bands can be adjusted to match your school's official policy.</div>
 </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function(){
 var sidebar=document.getElementById('sidebar'),menu=document.getElementById('mobileMenuBtn');
 if(menu&&sidebar)menu.addEventListener('click',function(){sidebar.classList.toggle('show');});
 document.addEventListener('click',function(e){if(window.innerWidth<=991&&sidebar&&sidebar.classList.contains('show')&&!sidebar.contains(e.target)&&menu&&!menu.contains(e.target))sidebar.classList.remove('show');});
 var select=document.getElementById('student_id'),name=document.getElementById('student_name'),adm=document.getElementById('admission_no');
 if(select){select.addEventListener('change',function(){var opt=select.options[select.selectedIndex];if(select.value!=='0'&&opt){name.value=opt.getAttribute('data-name')||'';adm.value=opt.getAttribute('data-admission')||'';}else{name.value='';adm.value='';}});}
 var marks=document.getElementById('marks_obtained'),max=<?= $selectedExam ? json_encode((float)$selectedExam['max_marks']) : '100' ?>,preview=document.getElementById('gradePreview');
 function updateGrade(){if(!marks||!preview)return; if(marks.value===''||!isFinite(Number(marks.value))||max<=0){preview.textContent='Enter marks to calculate grade';return;}var p=Number(marks.value)/max*100;var g=p>=85?'A':(p>=70?'B':(p>=60?'C':(p>=50?'D':'E')));preview.textContent=p.toFixed(2)+'% — Grade '+g;}
 if(marks){marks.addEventListener('input',updateGrade);updateGrade();}
 var forms=document.querySelectorAll('form');forms.forEach(function(form){form.addEventListener('submit',function(){var btn=form.querySelector('button[type="submit"]');if(btn&&form.id==='resultForm'){btn.disabled=true;btn.innerHTML='<i class="fas fa-spinner fa-spin mr-1"></i>Saving...';}});});
})();
</script>
</body>
</html>
