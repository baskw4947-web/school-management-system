<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once "../../config/database.php";
require_once "../../includes/auth.php";

requireRole([
    'administrator',
    'assistant_administrator'
]);

function e($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/*
|--------------------------------------------------------------------------
| SEARCH & FILTER
|--------------------------------------------------------------------------
*/

$search = trim($_GET['search'] ?? '');
$status = trim($_GET['status'] ?? '');

/*
|--------------------------------------------------------------------------
| BUILD QUERY
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        c.id,
        c.class_name,
        c.section,
        c.academic_year,
        c.status,
        COUNT(s.id) AS student_count
    FROM classes c
    LEFT JOIN students s
        ON s.class_id = c.id
";

$where = [];
$params = [];
$types = '';

/*
|--------------------------------------------------------------------------
| SEARCH
|--------------------------------------------------------------------------
*/

if ($search !== '') {

    $where[] = "
        (
            c.class_name LIKE ?
            OR c.section LIKE ?
            OR c.academic_year LIKE ?
        )
    ";

    $searchValue = "%" . $search . "%";

    $params[] = $searchValue;
    $params[] = $searchValue;
    $params[] = $searchValue;

    $types .= "sss";
}

/*
|--------------------------------------------------------------------------
| STATUS FILTER
|--------------------------------------------------------------------------
*/

if (
    $status !== '' &&
    in_array($status, ['active', 'inactive'], true)
) {

    $where[] = "c.status = ?";

    $params[] = $status;

    $types .= "s";
}

/*
|--------------------------------------------------------------------------
| WHERE CLAUSE
|--------------------------------------------------------------------------
*/

if (!empty($where)) {

    $sql .= " WHERE " . implode(" AND ", $where);
}

/*
|--------------------------------------------------------------------------
| GROUP & ORDER
|--------------------------------------------------------------------------
*/

$sql .= "
    GROUP BY
        c.id,
        c.class_name,
        c.section,
        c.academic_year,
        c.status

    ORDER BY
        c.academic_year DESC,
        c.class_name ASC,
        c.section ASC
";

/*
|--------------------------------------------------------------------------
| PREPARE QUERY
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare($sql);

if (!$stmt) {

    die(
        "Database query preparation failed: " .
        e($conn->error)
    );
}

/*
|--------------------------------------------------------------------------
| BIND SEARCH PARAMETERS
|--------------------------------------------------------------------------
*/

if (!empty($params)) {

    $stmt->bind_param(
        $types,
        ...$params
    );
}

/*
|--------------------------------------------------------------------------
| EXECUTE
|--------------------------------------------------------------------------
*/

if (!$stmt->execute()) {

    die(
        "Database query failed: " .
        e($stmt->error)
    );
}

$result = $stmt->get_result();

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Classes | School Management System
    </title>


    <!-- Bootstrap 4.6.2 -->

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
    >


    <!-- Font Awesome -->

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
    >


    <style>

        * {
            box-sizing: border-box;
        }


        body {
            margin: 0;

            background: #f4f6f9;

            font-family:
                Arial,
                Helvetica,
                sans-serif;
        }


        /*
        |--------------------------------------------------------------------------
        | SIDEBAR
        |--------------------------------------------------------------------------
        */

        .sidebar {

            position: fixed;

            top: 0;
            left: 0;

            width: 250px;
            height: 100vh;

            background: #343a40;

            color: #fff;

            z-index: 1050;

            overflow-y: auto;

            transition:
                all 0.3s ease;
        }


        .sidebar-header {

            height: 65px;

            display: flex;

            align-items: center;

            justify-content: space-between;

            padding: 0 18px;

            background: #212529;

            border-bottom:
                1px solid #495057;
        }


        .sidebar-header h4 {

            margin: 0;

            font-size: 20px;

            font-weight: 600;

            white-space: nowrap;
        }


        .sidebar-header button {

            border: none;

            background: transparent;

            color: #fff;

            font-size: 20px;

            cursor: pointer;
        }


        /*
        |--------------------------------------------------------------------------
        | SIDEBAR MENU
        |--------------------------------------------------------------------------
        */

        .sidebar-menu {

            padding: 15px 0;
        }


        .sidebar-menu a {

            display: flex;

            align-items: center;

            color: #ddd;

            text-decoration: none;

            padding: 13px 20px;

            font-size: 15px;

            transition:
                0.2s;
        }


        .sidebar-menu a i {

            width: 25px;

            margin-right: 12px;

            text-align: center;

            font-size: 16px;
        }


        .sidebar-menu a:hover {

            background: #495057;

            color: #fff;
        }


        .sidebar-menu a.active {

            background: #007bff;

            color: #fff;
        }


        .sidebar-divider {

            border-top:
                1px solid #495057;

            margin:
                10px 15px;
        }


        /*
        |--------------------------------------------------------------------------
        | COLLAPSED SIDEBAR
        |--------------------------------------------------------------------------
        */

        body.sidebar-collapsed
        .sidebar {

            width: 75px;
        }


        body.sidebar-collapsed
        .sidebar-header h4 {

            display: none;
        }


        body.sidebar-collapsed
        .sidebar-menu a {

            justify-content: center;

            padding-left: 0;
            padding-right: 0;
        }


        body.sidebar-collapsed
        .sidebar-menu a i {

            margin-right: 0;
        }


        body.sidebar-collapsed
        .sidebar-menu a span {

            display: none;
        }


        /*
        |--------------------------------------------------------------------------
        | MAIN CONTENT
        |--------------------------------------------------------------------------
        */

        .main-content {

            margin-left: 250px;

            min-height: 100vh;

            transition:
                all 0.3s ease;
        }


        body.sidebar-collapsed
        .main-content {

            margin-left: 75px;
        }


        /*
        |--------------------------------------------------------------------------
        | TOP BAR
        |--------------------------------------------------------------------------
        */

        .topbar {

            height: 65px;

            background: #fff;

            border-bottom:
                1px solid #ddd;

            display: flex;

            align-items: center;

            justify-content: space-between;

            padding:
                0 25px;

            box-shadow:
                0 1px 3px rgba(0,0,0,0.05);
        }


        .topbar-left {

            display: flex;

            align-items: center;
        }


        .topbar-left button {

            border: none;

            background: transparent;

            font-size: 21px;

            color: #343a40;

            cursor: pointer;

            margin-right: 15px;
        }


        .page-title {

            font-size: 20px;

            font-weight: 600;

            color: #343a40;
        }


        .topbar-user {

            color: #6c757d;

            font-size: 14px;
        }


        /*
        |--------------------------------------------------------------------------
        | CONTENT
        |--------------------------------------------------------------------------
        */

        .content-wrapper {

            padding: 25px;
        }


        .page-header {

            background: #fff;

            border-radius: 8px;

            padding: 20px;

            margin-bottom: 20px;

            box-shadow:
                0 2px 5px rgba(0,0,0,0.05);

            display: flex;

            justify-content: space-between;

            align-items: center;
        }


        .page-header h2 {

            margin: 0;

            font-size: 25px;

            color: #343a40;
        }


        .page-header p {

            margin:
                5px 0 0;

            color: #6c757d;
        }


        /*
        |--------------------------------------------------------------------------
        | CARDS
        |--------------------------------------------------------------------------
        */

        .card {

            border: none;

            border-radius: 8px;

            box-shadow:
                0 2px 8px rgba(0,0,0,0.06);
        }


        /*
        |--------------------------------------------------------------------------
        | MOBILE TOPBAR
        |--------------------------------------------------------------------------
        */

        .mobile-topbar {

            display: none;
        }


        .sidebar-overlay {

            display: none;
        }


        /*
        |--------------------------------------------------------------------------
        | MOBILE
        |--------------------------------------------------------------------------
        */

        @media (max-width: 767.98px) {

            .sidebar {

                width: 250px;

                transform:
                    translateX(-100%);
            }


            .sidebar.mobile-open {

                transform:
                    translateX(0);
            }


            body.sidebar-collapsed
            .sidebar {

                width: 250px;
            }


            body.sidebar-collapsed
            .sidebar-header h4 {

                display: block;
            }


            body.sidebar-collapsed
            .sidebar-menu a {

                justify-content: flex-start;

                padding-left: 20px;
                padding-right: 20px;
            }


            body.sidebar-collapsed
            .sidebar-menu a i {

                margin-right: 12px;
            }


            body.sidebar-collapsed
            .sidebar-menu a span {

                display: inline;
            }


            .main-content,
            body.sidebar-collapsed
            .main-content {

                margin-left: 0;
            }


            .topbar {

                display: none;
            }


            .mobile-topbar {

                display: flex;

                height: 60px;

                background: #212529;

                color: #fff;

                align-items: center;

                justify-content: space-between;

                padding:
                    0 15px;

                position: sticky;

                top: 0;

                z-index: 1000;
            }


            .mobile-topbar button {

                background: transparent;

                border: none;

                color: #fff;

                font-size: 22px;
            }


            .mobile-topbar-title {

                font-size: 17px;

                font-weight: 600;
            }


            .content-wrapper {

                padding: 15px;
            }


            .page-header {

                display: block;
            }


            .page-header .header-buttons {

                margin-top: 15px;
            }


            .page-header
            .header-buttons .btn {

                margin-bottom: 5px;
            }


            .sidebar-overlay {

                position: fixed;

                top: 0;
                left: 0;

                width: 100%;
                height: 100%;

                background:
                    rgba(0,0,0,0.45);

                z-index: 1040;
            }


            .sidebar-overlay.show {

                display: block;
            }

        }

    </style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>


<body>


<!-- ==========================================================
     SIDEBAR
=========================================================== -->

<div
    class="sidebar"
    id="sidebar"
>


    <!-- SIDEBAR HEADER -->

    <div class="sidebar-header">

        <h4>
            School Admin
        </h4>


        <button
            type="button"
            id="sidebarClose"
            class="d-md-none"
        >

            <i class="fas fa-times"></i>

        </button>

    </div>


    <!-- SIDEBAR MENU -->

    <div class="sidebar-menu">


        <!-- DASHBOARD -->

        <a
            href="/admin/dashboard.php"
        >

            <i class="fas fa-tachometer-alt"></i>

            <span>
                Dashboard
            </span>

        </a>


        <!-- CLASSES -->

        <a
            href="/admin/classes/index.php"
            class="active"
        >

            <i class="fas fa-chalkboard"></i>

            <span>
                Classes
            </span>

        </a>


        <!-- STUDENTS -->

        <a
            href="/admin/students/list.php"
        >

            <i class="fas fa-user-graduate"></i>

            <span>
                Students
            </span>

        </a>


        <!-- TEACHERS -->

        <a
            href="/admin/teachers/index.php"
        >

            <i class="fas fa-chalkboard-teacher"></i>

            <span>
                Teachers
            </span>

        </a>


        <!-- BURSAR -->

        <a
            href="/admin/bursar/index.php"
        >

            <i class="fas fa-money-bill-wave"></i>

            <span>
                Bursar
            </span>

        </a>


        <!-- ASSETS -->

        <a
            href="/admin/assets/index.php"
        >

            <i class="fas fa-boxes"></i>

            <span>
                Assets
            </span>

        </a>


        <!-- OTHER STAFF -->

        <a
            href="/admin/staff/index.php"
        >

            <i class="fas fa-users"></i>

            <span>
                Other Staff
            </span>

        </a>


        <!-- SCHOOL PROJECTS -->

        <a
            href="/admin/projects/index.php"
        >

            <i class="fas fa-project-diagram"></i>

            <span>
                School Projects
            </span>

        </a>


        <!-- USERS -->

        <a
            href="/admin/users/index.php"
        >

            <i class="fas fa-user-cog"></i>

            <span>
                Users
            </span>

        </a>


        <div class="sidebar-divider"></div>


        <!-- LOGOUT -->

        <a
            href="/logout.php"
        >

            <i class="fas fa-sign-out-alt"></i>

            <span>
                Logout
            </span>

        </a>


    </div>

</div>


<!-- ==========================================================
     SIDEBAR OVERLAY
=========================================================== -->

<div
    class="sidebar-overlay"
    id="sidebarOverlay"
></div>


<!-- ==========================================================
     MAIN CONTENT
=========================================================== -->

<div class="main-content">


    <!-- ======================================================
         DESKTOP TOPBAR
    ======================================================= -->

    <div class="topbar">


        <div class="topbar-left">

            <button
                type="button"
                id="sidebarToggle"
                title="Toggle Sidebar"
            >

                <i class="fas fa-bars"></i>

            </button>


            <div class="page-title">

                Classes

            </div>

        </div>


        <div class="topbar-user">

            <i class="fas fa-user-circle"></i>

            <?= e(
                $_SESSION['full_name']
                ?? $_SESSION['username']
                ?? 'User'
            ) ?>

        </div>

    </div>


    <!-- ======================================================
         MOBILE TOPBAR
    ======================================================= -->

    <div class="mobile-topbar">


        <button
            type="button"
            id="menuToggle"
        >

            <i class="fas fa-bars"></i>

        </button>


        <div class="mobile-topbar-title">

            Classes

        </div>


        <div style="width:25px;"></div>

    </div>


    <!-- ======================================================
         PAGE CONTENT
    ======================================================= -->

    <div class="content-wrapper">


        <!-- PAGE HEADER -->

        <div class="page-header">


            <div>

                <h2 class="mb-1">

                    <i class="fas fa-chalkboard text-primary"></i>

                    Classes

                </h2>


                <p>

                    Manage school classes,
                    sections and academic years.

                </p>

            </div>


            <div class="header-buttons">

                <a
                    href="add.php"
                    class="btn btn-primary"
                >

                    <i class="fas fa-plus"></i>

                    Add Class

                </a>

            </div>

        </div>


        <!-- SUCCESS MESSAGE -->

        <?php if (
            isset($_GET['success']) &&
            $_GET['success'] !== ''
        ): ?>

            <div
                class="alert alert-success alert-dismissible fade show"
                role="alert"
            >

                <i class="fas fa-check-circle"></i>

                <?= e($_GET['success']) ?>


                <button
                    type="button"
                    class="close"
                    data-dismiss="alert"
                    aria-label="Close"
                >

                    <span aria-hidden="true">
                        &times;
                    </span>

                </button>

            </div>

        <?php endif; ?>


        <!-- ERROR MESSAGE -->

        <?php if (
            isset($_GET['error']) &&
            $_GET['error'] !== ''
        ): ?>

            <div
                class="alert alert-danger alert-dismissible fade show"
                role="alert"
            >

                <i class="fas fa-exclamation-circle"></i>

                <?= e($_GET['error']) ?>


                <button
                    type="button"
                    class="close"
                    data-dismiss="alert"
                    aria-label="Close"
                >

                    <span aria-hidden="true">
                        &times;
                    </span>

                </button>

            </div>

        <?php endif; ?>


        <!-- ==================================================
             SEARCH / FILTER
        =================================================== -->

        <div class="card shadow-sm mb-4">


            <div class="card-body">

                <form
                    method="GET"
                    action="index.php"
                >


                    <div class="form-row">


                        <!-- SEARCH -->

                        <div class="col-md-6 mb-3">

                            <label for="search">

                                Search Classes

                            </label>


                            <input
                                type="text"
                                id="search"
                                name="search"
                                class="form-control"
                                placeholder="Class name, section or academic year"
                                value="<?= e($search) ?>"
                            >

                        </div>


                        <!-- STATUS -->

                        <div class="col-md-3 mb-3">

                            <label for="status">

                                Status

                            </label>


                            <select
                                name="status"
                                id="status"
                                class="form-control"
                            >

                                <option value="">

                                    All Statuses

                                </option>


                                <option
                                    value="active"
                                    <?= $status === 'active'
                                        ? 'selected'
                                        : '' ?>
                                >

                                    Active

                                </option>


                                <option
                                    value="inactive"
                                    <?= $status === 'inactive'
                                        ? 'selected'
                                        : '' ?>
                                >

                                    Inactive

                                </option>

                            </select>

                        </div>


                        <!-- BUTTONS -->

                        <div class="col-md-3 mb-3 d-flex align-items-end">


                            <button
                                type="submit"
                                class="btn btn-dark mr-2"
                            >

                                <i class="fas fa-search"></i>

                                Search

                            </button>


                            <a
                                href="index.php"
                                class="btn btn-outline-secondary"
                            >

                                <i class="fas fa-redo"></i>

                                Reset

                            </a>

                        </div>


                    </div>

                </form>

            </div>

        </div>


        <!-- ==================================================
             CLASSES TABLE
        =================================================== -->

        <div class="card shadow-sm">


            <div class="card-header bg-white">


                <div class="d-flex justify-content-between align-items-center">


                    <h5 class="mb-0">

                        <i class="fas fa-list"></i>

                        Class List

                    </h5>


                    <span class="badge badge-primary">

                        <?= (int)$result->num_rows ?>

                        Classes

                    </span>


                </div>

            </div>


            <div class="card-body p-0">


                <div class="table-responsive">


                    <table
                        class="table table-hover table-bordered mb-0"
                    >


                        <thead class="thead-dark">


                            <tr>


                                <th width="60">

                                    #

                                </th>


                                <th>

                                    Class

                                </th>


                                <th>

                                    Section

                                </th>


                                <th>

                                    Academic Year

                                </th>


                                <th>

                                    Students

                                </th>


                                <th>

                                    Status

                                </th>


                                <th width="220">

                                    Actions

                                </th>


                            </tr>

                        </thead>


                        <tbody>


                        <?php if (
                            $result->num_rows > 0
                        ): ?>


                            <?php $number = 1; ?>


                            <?php while (
                                $class = $result->fetch_assoc()
                            ): ?>


                                <tr>


                                    <!-- NUMBER -->

                                    <td>

                                        <?= $number++ ?>

                                    </td>


                                    <!-- CLASS -->

                                    <td>

                                        <strong>

                                            <?= e(
                                                $class['class_name']
                                            ) ?>

                                        </strong>

                                    </td>


                                    <!-- SECTION -->

                                    <td>

                                        <?php if (
                                            !empty(
                                                $class['section']
                                            )
                                        ): ?>

                                            <?= e(
                                                $class['section']
                                            ) ?>

                                        <?php else: ?>

                                            <span class="text-muted">

                                                No Section

                                            </span>

                                        <?php endif; ?>

                                    </td>


                                    <!-- ACADEMIC YEAR -->

                                    <td>

                                        <?= e(
                                            $class['academic_year']
                                        ) ?>

                                    </td>


                                    <!-- STUDENTS -->

                                    <td>

                                        <span
                                            class="badge badge-info"
                                        >

                                            <i class="fas fa-user-graduate"></i>

                                            <?= (int)$class['student_count'] ?>

                                        </span>

                                    </td>


                                    <!-- STATUS -->

                                    <td>

                                        <?php if (
                                            $class['status']
                                            === 'active'
                                        ): ?>

                                            <span
                                                class="badge badge-success"
                                            >

                                                <i class="fas fa-check"></i>

                                                Active

                                            </span>

                                        <?php else: ?>

                                            <span
                                                class="badge badge-secondary"
                                            >

                                                Inactive

                                            </span>

                                        <?php endif; ?>

                                    </td>


                                    <!-- ACTIONS -->

                                    <td>


                                        <a
                                            href="view.php?id=<?= (int)$class['id'] ?>"
                                            class="btn btn-sm btn-info"
                                        >

                                            <i class="fas fa-eye"></i>

                                            View

                                        </a>


                                        <a
                                            href="edit.php?id=<?= (int)$class['id'] ?>"
                                            class="btn btn-sm btn-warning"
                                        >

                                            <i class="fas fa-edit"></i>

                                            Edit

                                        </a>


                                        <?php if (
                                            (int)$class['student_count']
                                            === 0
                                        ): ?>


                                            <a
                                                href="delete.php?id=<?= (int)$class['id'] ?>"
                                                class="btn btn-sm btn-danger"
                                                onclick="return confirm('Are you sure you want to delete this class?');"
                                            >

                                                <i class="fas fa-trash"></i>

                                                Delete

                                            </a>


                                        <?php else: ?>


                                            <button
                                                type="button"
                                                class="btn btn-sm btn-secondary"
                                                disabled
                                                title="This class has students"
                                            >

                                                <i class="fas fa-lock"></i>

                                                Delete

                                            </button>


                                        <?php endif; ?>


                                    </td>


                                </tr>


                            <?php endwhile; ?>


                        <?php else: ?>


                            <tr>


                                <td
                                    colspan="7"
                                    class="text-center py-5"
                                >


                                    <div class="text-muted">


                                        <i
                                            class="fas fa-chalkboard fa-3x mb-3"
                                        ></i>


                                        <h5>

                                            No Classes Found

                                        </h5>


                                        <p class="mb-3">

                                            There are no classes
                                            matching your search.

                                        </p>


                                        <a
                                            href="add.php"
                                            class="btn btn-primary"
                                        >

                                            <i class="fas fa-plus"></i>

                                            Add First Class

                                        </a>


                                    </div>


                                </td>


                            </tr>


                        <?php endif; ?>


                        </tbody>

                    </table>

                </div>

            </div>

        </div>


    </div>

</div>


<!-- ==========================================================
     JAVASCRIPT
=========================================================== -->

<script
    src="https://code.jquery.com/jquery-3.6.4.min.js"
></script>


<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
></script>


<script>

    /*
    |--------------------------------------------------------------------------
    | ELEMENTS
    |--------------------------------------------------------------------------
    */

    const sidebar =
        document.getElementById('sidebar');

    const sidebarToggle =
        document.getElementById('sidebarToggle');

    const menuToggle =
        document.getElementById('menuToggle');

    const sidebarClose =
        document.getElementById('sidebarClose');

    const sidebarOverlay =
        document.getElementById('sidebarOverlay');


    /*
    |--------------------------------------------------------------------------
    | DESKTOP SIDEBAR TOGGLE
    |--------------------------------------------------------------------------
    */

    if (sidebarToggle) {

        sidebarToggle.addEventListener(
            'click',
            function () {

                document.body.classList.toggle(
                    'sidebar-collapsed'
                );

            }
        );

    }


    /*
    |--------------------------------------------------------------------------
    | MOBILE MENU OPEN
    |--------------------------------------------------------------------------
    */

    if (menuToggle) {

        menuToggle.addEventListener(
            'click',
            function () {

                sidebar.classList.add(
                    'mobile-open'
                );

                sidebarOverlay.classList.add(
                    'show'
                );

            }
        );

    }


    /*
    |--------------------------------------------------------------------------
    | CLOSE MOBILE SIDEBAR
    |--------------------------------------------------------------------------
    */

    function closeMobileSidebar() {

        sidebar.classList.remove(
            'mobile-open'
        );

        sidebarOverlay.classList.remove(
            'show'
        );

    }


    /*
    |--------------------------------------------------------------------------
    | CLOSE BUTTON
    |--------------------------------------------------------------------------
    */

    if (sidebarClose) {

        sidebarClose.addEventListener(
            'click',
            closeMobileSidebar
        );

    }


    /*
    |--------------------------------------------------------------------------
    | OVERLAY CLICK
    |--------------------------------------------------------------------------
    */

    if (sidebarOverlay) {

        sidebarOverlay.addEventListener(
            'click',
            closeMobileSidebar
        );

    }


    /*
    |--------------------------------------------------------------------------
    | ESCAPE KEY
    |--------------------------------------------------------------------------
    */

    document.addEventListener(
        'keydown',
        function (event) {

            if (event.key === 'Escape') {

                closeMobileSidebar();

            }

        }
    );


    /*
    |--------------------------------------------------------------------------
    | CLOSE SIDEBAR AFTER LINK CLICK
    |--------------------------------------------------------------------------
    */

    document
        .querySelectorAll('.sidebar-menu a')
        .forEach(function (link) {

            link.addEventListener(
                'click',
                function () {

                    closeMobileSidebar();

                }
            );

        });

</script>


</body>

</html>

<?php

$stmt->close();

?>