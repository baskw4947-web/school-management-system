<?php
/**
 * Student report entry and printing page for the school management system.
 * Teachers enter student details and subject marks/grades here; reports are saved
 * in student_term_reports and student_term_report_subjects.
 * Save UTF-8 without BOM. Do not place spaces before this opening PHP tag.
 */

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator', 'teacher', 'class_teacher', 'headteacher', 'director_of_studies', 'academic']);

if (!isset($conn) || !($conn instanceof mysqli)) {
    http_response_code(500);
    exit('Database connection is unavailable. Please check config/database.php.');
}
$conn->set_charset('utf8mb4');
$userId = (int)($_SESSION['user_id'] ?? $_SESSION['id'] ?? 0);

function srE($value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function srFlash(string $type, string $message): void { $_SESSION['student_reports_flash'] = ['type' => $type, 'message' => $message]; }
function srRedirect(string $url = 'student_reports.php'): void { header('Location: ' . $url); exit; }
function srTableExists(mysqli $db, string $table): bool {
    // Only internally supplied table names are passed to this helper.
    $safe = $db->real_escape_string($table);
    $result = $db->query("SHOW TABLES LIKE '{$safe}'");
    $yes = $result && $result->num_rows > 0;
    if ($result) $result->free();
    return $yes;
}
function srColumns(mysqli $db, string $table): array {
    $columns = []; $result = $db->query('SHOW COLUMNS FROM `' . str_replace('`', '``', $table) . '`');
    while ($row = $result->fetch_assoc()) $columns[strtolower($row['Field'])] = $row['Field'];
    $result->free(); return $columns;
}
function srValidDate(string $value): bool {
    if ($value === '') return true;
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) return false;
    [$y, $m, $d] = array_map('intval', explode('-', $value));
    return checkdate($m, $d, $y);
}
function srGradeForMark(?float $mark): string {
    if ($mark === null) return '';
    if ($mark >= 85) return 'A';
    if ($mark >= 70) return 'B';
    if ($mark >= 60) return 'C';
    if ($mark >= 50) return 'D';
    return 'E';
}
function srFmt($number, int $decimals = 2): string {
    if ($number === null || $number === '') return '';
    return number_format((float)$number, $decimals, '.', '');
}
function srTermRoman(string $term): string {
    $v = strtolower(trim($term));
    if (preg_match('/(?:term\s*)?(?:3|iii)$/i', $v)) return 'III';
    if (preg_match('/(?:term\s*)?(?:2|ii)$/i', $v)) return 'II';
    if (preg_match('/(?:term\s*)?(?:1|i)$/i', $v)) return 'I';
    return $term;
}

$defaultSubjects = [
    ['527','Agriculture'], ['553','Biology'], ['223','C.R.E'], ['545','Chemistry'],
    ['840','Computer Studies'], ['112','English'], ['845','Entrepreneurship'], ['610','Fine Art'],
    ['273','Geography'], ['241','History'], ['','Kiswahili'], ['335','Luganda'],
    ['456','Mathematics'], ['','Physical Education'], ['535','Physics'], ['','Technical Drawing']
];

$pageError = '';
$createdTables = [];
try {
    if (!srTableExists($conn, 'student_term_reports')) {
        $conn->query("CREATE TABLE `student_term_reports` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `student_id` INT NULL,
            `student_name` VARCHAR(150) NOT NULL,
            `admission_no` VARCHAR(50) DEFAULT NULL,
            `student_number` VARCHAR(50) DEFAULT NULL,
            `class_name` VARCHAR(100) NOT NULL,
            `term` VARCHAR(30) NOT NULL,
            `academic_year` VARCHAR(10) NOT NULL,
            `report_title` VARCHAR(150) NOT NULL,
            `class_teacher_comment` TEXT DEFAULT NULL,
            `headteacher_comment` TEXT DEFAULT NULL,
            `next_term_begins` DATE DEFAULT NULL,
            `term_closes` DATE DEFAULT NULL,
            `fees_balance` DECIMAL(12,2) DEFAULT NULL,
            `created_by` INT DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_term_report_student` (`student_id`),
            KEY `idx_term_report_class_term` (`class_name`,`term`,`academic_year`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $createdTables[] = 'student_term_reports';
    }
    if (!srTableExists($conn, 'student_term_report_subjects')) {
        $conn->query("CREATE TABLE `student_term_report_subjects` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `report_id` INT UNSIGNED NOT NULL,
            `subject_code` VARCHAR(30) DEFAULT NULL,
            `subject_name` VARCHAR(150) NOT NULL,
            `aoi2` DECIMAL(5,2) DEFAULT NULL,
            `aoi1` DECIMAL(5,2) DEFAULT NULL,
            `total_scores` DECIMAL(6,2) DEFAULT NULL,
            `avg_score` DECIMAL(6,2) DEFAULT NULL,
            `out20` DECIMAL(5,2) DEFAULT NULL,
            `identifier_value` TINYINT DEFAULT NULL,
            `out80` DECIMAL(5,2) DEFAULT NULL,
            `final_mark` DECIMAL(5,2) DEFAULT NULL,
            `grade` VARCHAR(5) DEFAULT NULL,
            `comment` VARCHAR(255) DEFAULT NULL,
            `initials` VARCHAR(20) DEFAULT NULL,
            `sort_order` INT NOT NULL DEFAULT 0,
            PRIMARY KEY (`id`),
            KEY `idx_term_report_subject_report` (`report_id`),
            CONSTRAINT `fk_term_report_subject_report` FOREIGN KEY (`report_id`) REFERENCES `student_term_reports` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $createdTables[] = 'student_term_report_subjects';
    }
    // Upgrade existing report tables safely without deleting old reports.
    $reportCols = srColumns($conn, 'student_term_reports');
    if (!isset($reportCols['report_level'])) {
        $conn->query("ALTER TABLE student_term_reports ADD COLUMN report_level ENUM('O_LEVEL','A_LEVEL') NOT NULL DEFAULT 'O_LEVEL' AFTER student_id");
    }
    $subjectCols = srColumns($conn, 'student_term_report_subjects');
    if (!isset($subjectCols['points'])) {
        $conn->query("ALTER TABLE student_term_report_subjects ADD COLUMN points DECIMAL(6,2) DEFAULT NULL AFTER grade");
    }
} catch (Throwable $e) {
    $pageError = 'Could not prepare the student-report tables. Ask your hosting administrator to check MySQL table-creation permissions.';
    error_log('student_reports.php schema error: ' . $e->getMessage());
}

if (empty($_SESSION['student_reports_csrf'])) $_SESSION['student_reports_csrf'] = bin2hex(random_bytes(32));
$csrfToken = (string)$_SESSION['student_reports_csrf'];
$flash = $_SESSION['student_reports_flash'] ?? null;
unset($_SESSION['student_reports_flash']);

// Load existing student records for the optional quick-fill dropdown. Manual entry remains available.
$studentOptions = [];
if ($pageError === '' && srTableExists($conn, 'students')) {
    try {
        $studentCols = srColumns($conn, 'students');
        $idCol = $studentCols['id'] ?? ($studentCols['student_id'] ?? null);
        if ($idCol) {
            $result = $conn->query('SELECT * FROM `students` ORDER BY `' . str_replace('`','',$idCol) . '` DESC LIMIT 1000');
            while ($s = $result->fetch_assoc()) {
                $id = (int)($s[$idCol] ?? 0);
                if ($id < 1) continue;
                $first = trim((string)($s['first_name'] ?? ''));
                $last = trim((string)($s['last_name'] ?? ''));
                $other = trim((string)($s['other_names'] ?? $s['middle_name'] ?? ''));
                $name = trim(implode(' ', array_filter([$first, $other, $last], static fn($x) => $x !== '')));
                if ($name === '') $name = trim((string)($s['full_name'] ?? $s['student_name'] ?? $s['name'] ?? ''));
                if ($name === '') $name = 'Student #' . $id;
                $admission = (string)($s['admission_no'] ?? $s['admission_number'] ?? $s['registration_no'] ?? '');
                $studentNumber = (string)($s['student_number'] ?? $s['student_no'] ?? '');
                $className = (string)($s['class_name'] ?? $s['class'] ?? $s['class_level'] ?? '');
                $linNo = trim((string)($s['lin_no'] ?? ''));
                $studentPaymentCode = trim((string)($s['student_payment_code'] ?? ''));
                $studentSection = trim((string)($s['student_section'] ?? 'Day')) ?: 'Day';
                $studentOptions[] = ['id'=>$id, 'name'=>$name, 'admission'=>$admission, 'lin_no'=>$linNo, 'student_payment_code'=>$studentPaymentCode, 'student_section'=>$studentSection, 'student_number'=>$studentNumber, 'class_name'=>$className];
            }
            $result->free();
        }
    } catch (Throwable $e) { error_log('student_reports.php student lookup error: ' . $e->getMessage()); }
}

// Delete report (subjects are removed by the foreign-key cascade).
if ($pageError === '' && $_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_report') {
    if (!hash_equals($csrfToken, (string)($_POST['csrf_token'] ?? ''))) {
        srFlash('danger', 'Your session expired. Refresh the page and try again.'); srRedirect();
    }
    $deleteId = (int)($_POST['report_id'] ?? 0);
    try {
        if ($deleteId < 1) throw new RuntimeException('Invalid report selected.');
        $stmt = $conn->prepare('DELETE FROM student_term_reports WHERE id = ?');
        $stmt->bind_param('i', $deleteId); $stmt->execute(); $deleted = $stmt->affected_rows; $stmt->close();
        srFlash($deleted ? 'success' : 'warning', $deleted ? 'Student report deleted.' : 'No report was deleted.');
    } catch (Throwable $e) {
        error_log('student_reports.php delete error: ' . $e->getMessage());
        srFlash('danger', 'Unable to delete this report. Check the PHP error log.');
    }
    srRedirect();
}

// Save a report and its subject rows inside a transaction.
if ($pageError === '' && $_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_report') {
    if (!hash_equals($csrfToken, (string)($_POST['csrf_token'] ?? ''))) {
        srFlash('danger', 'Your session expired. Refresh the page and try again.'); srRedirect();
    }
    $reportId = (int)($_POST['report_id'] ?? 0);
    $studentId = (int)($_POST['student_id'] ?? 0);
    $reportLevel = strtoupper(trim((string)($_POST['report_level'] ?? 'O_LEVEL')));
    if (!in_array($reportLevel, ['O_LEVEL','A_LEVEL'], true)) $reportLevel = 'O_LEVEL';
    $studentName = trim((string)($_POST['student_name'] ?? ''));
    $admissionNo = trim((string)($_POST['admission_no'] ?? ''));
    $studentNumber = trim((string)($_POST['student_number'] ?? ''));
    $className = trim((string)($_POST['class_name'] ?? ''));
    $term = trim((string)($_POST['term'] ?? 'Term I'));
    $year = trim((string)($_POST['academic_year'] ?? date('Y')));
    $reportTitle = trim((string)($_POST['report_title'] ?? ''));
    $classComment = trim((string)($_POST['class_teacher_comment'] ?? ''));
    $headComment = trim((string)($_POST['headteacher_comment'] ?? ''));
    $nextTermBegins = trim((string)($_POST['next_term_begins'] ?? ''));
    $termCloses = trim((string)($_POST['term_closes'] ?? ''));
    $feesBalanceRaw = trim((string)($_POST['fees_balance'] ?? ''));
    $validationError = '';

    if ($studentName === '') $validationError = 'Enter the student name.';
    elseif (mb_strlen($studentName) > 150) $validationError = 'Student name must be 150 characters or fewer.';
    elseif ($className === '') $validationError = 'Enter the student class, for example S.1 WEST.';
    elseif (!in_array($term, ['Term I','Term II','Term III','Term 1','Term 2','Term 3'], true)) $validationError = 'Select a valid term.';
    elseif ($year === '' || !preg_match('/^\d{4}$/', $year)) $validationError = 'Enter a valid four-digit academic year.';
    elseif (!srValidDate($nextTermBegins) || !srValidDate($termCloses)) $validationError = 'Enter valid dates for next term and term closing.';
    elseif ($feesBalanceRaw !== '' && (!is_numeric($feesBalanceRaw) || (float)$feesBalanceRaw < 0)) $validationError = 'Fees balance must be a non-negative number.';

    $subjectNames = $_POST['subject_name'] ?? [];
    $subjectCodes = $_POST['subject_code'] ?? [];
    $aoi2Values = $_POST['aoi2'] ?? [];
    $aoi1Values = $_POST['aoi1'] ?? [];
    $out20Values = $_POST['out20'] ?? [];
    $identifierValues = $_POST['identifier_value'] ?? [];
    $out80Values = $_POST['out80'] ?? [];
    $gradeValues = $_POST['grade'] ?? [];
    $pointsValues = $_POST['points'] ?? [];
    $commentValues = $_POST['subject_comment'] ?? [];
    $initialValues = $_POST['initials'] ?? [];
    $subjectRows = [];
    $subjectCount = is_array($subjectNames) ? count($subjectNames) : 0;
    for ($i = 0; $i < $subjectCount; $i++) {
        $sn = trim((string)($subjectNames[$i] ?? ''));
        $sc = trim((string)($subjectCodes[$i] ?? ''));
        if ($sn === '') continue;
        $readNumber = static function ($array, $index): ?float {
            $v = trim((string)($array[$index] ?? ''));
            if ($v === '') return null;
            if (!is_numeric($v)) throw new RuntimeException('Marks must be numeric. Check subject: ' . trim((string)($_POST['subject_name'][$index] ?? '')) . '.');
            $f = (float)$v;
            if (!is_finite($f) || $f < 0) throw new RuntimeException('Marks cannot be negative. Check subject: ' . trim((string)($_POST['subject_name'][$index] ?? '')) . '.');
            return $f;
        };
        try {
            if ($reportLevel === 'O_LEVEL') {
                $aoi2 = $readNumber($aoi2Values, $i); $aoi1 = $readNumber($aoi1Values, $i);
                $out20 = $readNumber($out20Values, $i); $out80 = $readNumber($out80Values, $i);
            } else {
                $aoi2 = $aoi1 = $out80 = null;
                $out20 = $readNumber($out20Values, $i);
            }
            if ($reportLevel === 'O_LEVEL' && $aoi2 !== null && $aoi2 > 3) throw new RuntimeException('AOI 2 must be between 0 and 3 for ' . $sn . '.');
            if ($reportLevel === 'O_LEVEL' && $aoi1 !== null && $aoi1 > 3) throw new RuntimeException('AOI 1 must be between 0 and 3 for ' . $sn . '.');
            if ($reportLevel === 'O_LEVEL' && $out20 !== null && $out20 > 20) throw new RuntimeException('The Out of 20 score cannot exceed 20 for ' . $sn . '.');
            if ($reportLevel === 'O_LEVEL' && $out80 !== null && $out80 > 80)
                throw new RuntimeException('The Out of 80 score cannot exceed 80 for ' . $sn . '.');
            if ($reportLevel === 'A_LEVEL' && $out20 !== null && $out20 > 100)
                throw new RuntimeException('A-Level mark cannot exceed 100 for ' . $sn . '.');
            /* legacy O-Level range validation retained below */

            $identifierRaw = trim((string)($identifierValues[$i] ?? ''));
            $identifier = $identifierRaw === '' ? null : (int)$identifierRaw;
            if ($identifier !== null && !in_array($identifier, [1,2,3], true)) throw new RuntimeException('Learning-outcome identifier must be 1, 2 or 3 for ' . $sn . '.');
            $finalMark = $reportLevel === 'A_LEVEL' ? $out20 : (($out20 === null && $out80 === null) ? null : ((float)($out20 ?? 0) + (float)($out80 ?? 0)));
            $pointsRaw = trim((string)($pointsValues[$i] ?? ''));
            $points = $pointsRaw === '' ? null : (is_numeric($pointsRaw) ? (float)$pointsRaw : null);
            if ($pointsRaw !== '' && ($points === null || $points < 0 || $points > 20)) throw new RuntimeException('A-Level points must be between 0 and 20 for ' . $sn . '.');
            $grade = strtoupper(trim((string)($gradeValues[$i] ?? '')));
            if ($grade !== '' && !in_array($grade, ['A','B','C','D','E'], true)) throw new RuntimeException('Select a valid grade for ' . $sn . '.');
            if ($grade === '' && $finalMark !== null) $grade = srGradeForMark($finalMark);
            if ($finalMark !== null && $finalMark > 100) throw new RuntimeException('The final mark cannot exceed 100 for ' . $sn . '.');
            $totalScores = ($aoi2 === null && $aoi1 === null) ? null : (float)($aoi2 ?? 0) + (float)($aoi1 ?? 0);
            $avgScore = $totalScores === null ? null : $totalScores / 2;
            $subjectRows[] = [
                'code'=>$sc, 'name'=>$sn, 'aoi2'=>$aoi2, 'aoi1'=>$aoi1,
                'total_scores'=>$totalScores, 'avg_score'=>$avgScore, 'out20'=>$out20,
                'identifier_value'=>$identifier, 'out80'=>$out80, 'final_mark'=>$finalMark,
                'grade'=>$grade !== '' ? $grade : null, 'points'=>$reportLevel === 'A_LEVEL' ? $points : null,
                'comment'=>trim((string)($commentValues[$i] ?? '')),
                'initials'=>trim((string)($initialValues[$i] ?? '')), 'sort_order'=>$i
            ];
        } catch (RuntimeException $e) { $validationError = $e->getMessage(); break; }
    }
    if ($validationError === '' && !$subjectRows) $validationError = 'Enter at least one subject and its details.';
    if ($reportTitle === '') $reportTitle = ($reportLevel === 'A_LEVEL' ? 'A Level ' : 'O Level ') . 'End of ' . $term . ' Report';
    if ($validationError !== '') {
        srFlash('danger', $validationError);
        srRedirect($reportId > 0 ? 'student_reports.php?edit=' . $reportId : 'student_reports.php');
    }

    try {
        $conn->begin_transaction();
        if ($reportId > 0) {
            $check = $conn->prepare('SELECT id FROM student_term_reports WHERE id = ? LIMIT 1');
            $check->bind_param('i', $reportId); $check->execute();
            $exists = (bool)$check->get_result()->fetch_row(); $check->close();
            if (!$exists) throw new RuntimeException('The report you are editing no longer exists.');
            $sid = $studentId > 0 ? $studentId : null;
            $admission = $admissionNo !== '' ? $admissionNo : null;
            $studentNo = $studentNumber !== '' ? $studentNumber : null;
            $classC = $classComment !== '' ? $classComment : null;
            $headC = $headComment !== '' ? $headComment : null;
            $nextDate = $nextTermBegins !== '' ? $nextTermBegins : null;
            $closeDate = $termCloses !== '' ? $termCloses : null;
            $feesBalance = $feesBalanceRaw !== '' ? (float)$feesBalanceRaw : null;
            $stmt = $conn->prepare('UPDATE student_term_reports SET report_level=?, student_id=?, student_name=?, admission_no=?, student_number=?, class_name=?, term=?, academic_year=?, report_title=?, class_teacher_comment=?, headteacher_comment=?, next_term_begins=?, term_closes=?, fees_balance=? WHERE id=?');
            $stmt->bind_param('sisssssssssssdi', $reportLevel, $sid, $studentName, $admission, $studentNo, $className, $term, $year, $reportTitle, $classC, $headC, $nextDate, $closeDate, $feesBalance, $reportId);
            $stmt->execute(); $stmt->close();
            $del = $conn->prepare('DELETE FROM student_term_report_subjects WHERE report_id = ?');
            $del->bind_param('i', $reportId); $del->execute(); $del->close();
            $savedId = $reportId;
        } else {
            $sid = $studentId > 0 ? $studentId : null;
            $admission = $admissionNo !== '' ? $admissionNo : null;
            $studentNo = $studentNumber !== '' ? $studentNumber : null;
            $classC = $classComment !== '' ? $classComment : null;
            $headC = $headComment !== '' ? $headComment : null;
            $nextDate = $nextTermBegins !== '' ? $nextTermBegins : null;
            $closeDate = $termCloses !== '' ? $termCloses : null;
            $feesBalance = $feesBalanceRaw !== '' ? (float)$feesBalanceRaw : null;
            $stmt = $conn->prepare('INSERT INTO student_term_reports (report_level,student_id,student_name,admission_no,student_number,class_name,term,academic_year,report_title,class_teacher_comment,headteacher_comment,next_term_begins,term_closes,fees_balance,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
            $stmt->bind_param('sisssssssssssdi', $reportLevel, $sid, $studentName, $admission, $studentNo, $className, $term, $year, $reportTitle, $classC, $headC, $nextDate, $closeDate, $feesBalance, $userId);
            $stmt->execute(); $savedId = (int)$stmt->insert_id; $stmt->close();
        }

        $subjectStmt = $conn->prepare('INSERT INTO student_term_report_subjects (report_id,subject_code,subject_name,aoi2,aoi1,total_scores,avg_score,out20,identifier_value,out80,final_mark,grade,points,comment,initials,sort_order) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
        foreach ($subjectRows as $sub) {
            $sidReport = $savedId; $code = $sub['code'] !== '' ? $sub['code'] : null; $sname = $sub['name'];
            $a2 = $sub['aoi2']; $a1 = $sub['aoi1']; $total = $sub['total_scores']; $avg = $sub['avg_score']; $o20 = $sub['out20']; $ident = $sub['identifier_value']; $o80 = $sub['out80']; $final = $sub['final_mark']; $grade = $sub['grade'];
            $points = $sub['points']; $comment = $sub['comment'] !== '' ? $sub['comment'] : null; $initials = $sub['initials'] !== '' ? $sub['initials'] : null; $sort = (int)$sub['sort_order'];
            $subjectStmt->bind_param('issdddddiddsdssi', $sidReport, $code, $sname, $a2, $a1, $total, $avg, $o20, $ident, $o80, $final, $grade, $points, $comment, $initials, $sort);
            $subjectStmt->execute();
        }
        $subjectStmt->close();
        $conn->commit();
        srFlash('success', 'Student report saved successfully. You can now view or print the report.');
        srRedirect('student_reports.php?print=' . $savedId);
    } catch (Throwable $e) {
        try { $conn->rollback(); } catch (Throwable $ignored) {}
        error_log('student_reports.php save error: ' . $e->getMessage());
        srFlash('danger', $e instanceof RuntimeException ? $e->getMessage() : 'The report could not be saved. Check the hosting PHP error log and confirm table creation is allowed.');
        srRedirect($reportId > 0 ? 'student_reports.php?edit=' . $reportId : 'student_reports.php');
    }
}

// Printing one saved report.
$printId = (int)($_GET['print'] ?? 0);
if ($printId > 0 && $pageError === '') {
    try {
        $stmt = $conn->prepare('SELECT * FROM student_term_reports WHERE id = ? LIMIT 1');
        $stmt->bind_param('i', $printId); $stmt->execute(); $report = $stmt->get_result()->fetch_assoc(); $stmt->close();
        if ($report && !empty($report['student_id'])) {
            $studentStmt = $conn->prepare('SELECT lin_no, student_payment_code, student_section FROM students WHERE id = ? LIMIT 1');
            $linkedStudentId = (int)$report['student_id'];
            $studentStmt->bind_param('i', $linkedStudentId);
            $studentStmt->execute();
            $currentStudentDetails = $studentStmt->get_result()->fetch_assoc() ?: [];
            $studentStmt->close();
            $report['lin_no'] = $currentStudentDetails['lin_no'] ?? '';
            $report['student_payment_code'] = $currentStudentDetails['student_payment_code'] ?? '';
            $report['student_section'] = $currentStudentDetails['student_section'] ?? 'Day';
        } else if ($report) {
            $report['lin_no'] = '';
            $report['student_payment_code'] = '';
            $report['student_section'] = 'Day';
        }
        if (!$report) { http_response_code(404); $pageError = 'The requested student report was not found.'; }
        else {
            $subjectRows = [];
            $stmt = $conn->prepare('SELECT * FROM student_term_report_subjects WHERE report_id = ? ORDER BY sort_order, id');
            $stmt->bind_param('i', $printId); $stmt->execute(); $result = $stmt->get_result();
            while ($r = $result->fetch_assoc()) $subjectRows[] = $r;
            $stmt->close();
            $totalAoi = 0.0; $totalOut20 = 0.0; $totalOut80 = 0.0; $totalFinal = 0.0; $totalAvg = 0.0; $aoiCount = 0; $avgCount = 0; $identifiedCount = 0; $identifierSum = 0.0;
            foreach ($subjectRows as $sub) {
                if ($sub['total_scores'] !== null) $totalAoi += (float)$sub['total_scores'];
                if ($sub['avg_score'] !== null) { $totalAvg += (float)$sub['avg_score']; $avgCount++; }
                if ($sub['out20'] !== null) $totalOut20 += (float)$sub['out20'];
                if ($sub['out80'] !== null) $totalOut80 += (float)$sub['out80'];
                if ($sub['final_mark'] !== null) $totalFinal += (float)$sub['final_mark'];
                if ($sub['identifier_value'] !== null) { $identifierSum += (float)$sub['identifier_value']; $identifiedCount++; }
                $aoiCount++;
            }
            $averageIdentifier = $identifiedCount ? $identifierSum / $identifiedCount : null;
            $averageFinal = count($subjectRows) ? $totalFinal / count($subjectRows) : null;
            $averageOut20 = count($subjectRows) ? $totalOut20 / count($subjectRows) : null;
            $averageOut80 = count($subjectRows) ? $totalOut80 / count($subjectRows) : null;
            $romanTerm = srTermRoman((string)$report['term']);
            $stmt = null;
            ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?= srE($report['student_name']) ?> - Student Report</title>
<style>
*{box-sizing:border-box}body{font-family:Arial,Helvetica,sans-serif;color:#171717;margin:0;background:#ececec;padding:16px}.toolbar{max-width:210mm;margin:0 auto 12px;display:flex;justify-content:flex-end;gap:8px}.toolbar a,.toolbar button{background:#1d3557;color:#fff;border:0;border-radius:5px;padding:10px 14px;text-decoration:none;cursor:pointer;font-size:13px}.toolbar .secondary{background:#5b6573}.paper{width:210mm;max-width:100%;min-height:297mm;margin:auto;background:#fff;padding:8mm;box-shadow:0 2px 12px #0002}.school-header{display:grid;grid-template-columns:25mm 1fr;gap:5mm;align-items:center}.crest{width:24mm;height:27mm;display:flex;align-items:center;justify-content:center}.crest img{width:100%;height:100%;object-fit:contain}.school-name{text-align:center}.school-name h1{font-size:15pt;margin:0 0 1mm}.school-name h2{font-size:13pt;margin:0 0 1.5mm}.contact{font-size:7.5pt;line-height:1.35}.report-title{text-align:center;font-size:13pt;font-weight:500;margin:3mm 0}.student-details{font-size:8.5pt;line-height:1.6}.detail-row{display:flex;justify-content:space-between;gap:5mm;flex-wrap:wrap}.student-details strong{font-weight:700}.marks{border-collapse:collapse;width:100%;table-layout:fixed;margin-top:3mm;font-size:6.4pt}.marks th,.marks td{border:1px solid #555;padding:1.15mm .6mm;vertical-align:middle;overflow-wrap:anywhere}.marks th{text-align:center;height:19mm}.marks .vertical{writing-mode:vertical-rl;transform:rotate(180deg);margin:auto;line-height:1}.marks th:nth-child(1){width:22%}.marks th:nth-child(2),.marks th:nth-child(3),.marks th:nth-child(4),.marks th:nth-child(5),.marks th:nth-child(6),.marks th:nth-child(7),.marks th:nth-child(8),.marks th:nth-child(9){width:5.2%}.marks th:nth-child(10){width:5%}.marks th:nth-child(11){width:15%}.marks th:nth-child(12){width:6.4%}.marks td.num{text-align:center;white-space:nowrap}.marks .subj{font-weight:600}.marks .sumrow td{font-weight:bold;background:#fafafa}.identifier-note{text-align:center;font-size:7pt;margin:2mm 0}.identifier-note strong{border:1px solid #555;padding:1mm 2mm}.comments{font-size:7.4pt;line-height:1.5;margin-top:3mm}.comment-line{margin:2mm 0}.signature-area{position:relative;padding-right:30mm;min-height:23mm;font-size:7pt}.signature-row{display:flex;justify-content:space-between;gap:8mm;margin:4mm 0}.line{display:inline-block;min-width:30mm;border-bottom:1px dotted #333;height:4mm}.stamp{position:absolute;right:0;top:0;width:27mm;height:27mm;border:2px solid #777;border-radius:50%;display:flex;align-items:center;justify-content:center;text-align:center;font-size:6pt;font-weight:bold;color:#555;transform:rotate(-10deg)}.date-fees{display:flex;flex-direction:column;gap:2mm;font-size:7pt;margin:2mm 0}.grading-key{margin-top:4mm;font-size:6.3pt;border-collapse:collapse;width:100%}.grading-key th,.grading-key td{border:1px solid #666;padding:1mm;text-align:center}.grading-key .left{text-align:left}.footer{text-align:center;font-size:7pt;margin-top:3mm}@media(max-width:760px){body{padding:0}.paper{width:100%;padding:10px;box-shadow:none;overflow-x:auto}.marks{min-width:700px}.school-name h1{font-size:14px}.school-name h2{font-size:12px}}@page{size:A4 portrait;margin:7mm}@media print{body{padding:0;background:#fff}.toolbar{display:none!important}.paper{width:auto;max-width:none;min-height:0;margin:0;padding:1mm;box-shadow:none}.marks th,.marks td{padding:.85mm .35mm}.marks{font-size:6pt}tr{page-break-inside:avoid}}
</style></head><body><div class="toolbar"><button onclick="window.print()"><i>Print / Save PDF</i></button><a class="secondary" href="student_reports.php">Back to Report Entry</a></div>
<main class="paper"><header class="school-header"><div class="crest"><img src="/assets/images/school-badge.png" alt="St John's Secondary School badge"></div><div class="school-name"><h1>ST. JOHN'S SECONDARY SCHOOL</h1><h2>MUDUUMA</h2><div class="contact"><div>Quantum Possum</div><div>P. O. Box 15166, Kibuli, Kampala - Uganda.</div><div>stjohnsssmuduuma@gmail.com</div><div>www.stjohnssmuduuma.com</div></div></div></header>
<h3 class="report-title"><?= srE($report['report_title']) ?> — <?= ($report['report_level'] ?? 'O_LEVEL')==='A_LEVEL'?'A’LEVEL':'O’LEVEL' ?></h3><section class="student-details"><div class="detail-row"><span>NAME: <strong><?= srE($report['student_name']) ?></strong></span><span>ADMISSION NUMBER: <strong><?= srE($report['admission_no'] ?: '—') ?></strong></span></div><div class="detail-row" style="justify-content:center"><span>CLASS: <strong><?= srE($report['class_name']) ?></strong></span><span>TERM: <strong><?= srE($romanTerm) ?></strong></span><span>YEAR: <strong><?= srE($report['academic_year']) ?></strong></span></div><div class="detail-row" style="justify-content:center"><span>LIN NUMBER: <strong><?= srE($report['lin_no'] ?: '—') ?></strong></span><span>PAYMENT CODE: <strong><?= srE($report['student_payment_code'] ?: '—') ?></strong></span><span>STUDENT SECTION: <strong><?= srE($report['student_section'] ?: 'Day') ?></strong></span><span>STUDENT NUMBER: <strong><?= srE($report['student_number'] ?: '—') ?></strong></span></div></section>
<?php if (($report['report_level'] ?? 'O_LEVEL') === 'A_LEVEL'): ?>
<table class="marks"><thead><tr><th>SUBJECT</th><th>MARK / 100</th><th>GRADE</th><th>POINTS</th><th>COMMENT</th><th>INITIALS</th></tr></thead><tbody>
<?php $aTotal=0; $aCount=0; foreach ($subjectRows as $sub): if ($sub['final_mark'] !== null) {$aTotal+=(float)$sub['final_mark'];$aCount++;} ?>
<tr><td><strong><?= srE(trim(($sub['subject_code'] ?? '').' '.($sub['subject_name'] ?? ''))) ?></strong></td><td class="num"><?= srE(srFmt($sub['final_mark'],0)) ?></td><td class="num"><strong><?= srE($sub['grade']) ?></strong></td><td class="num"><?= srE($sub['points'] ?? '') ?></td><td><?= srE($sub['comment']) ?></td><td class="num"><?= srE($sub['initials']) ?></td></tr>
<?php endforeach; ?><tr class="sumrow"><td>AVERAGE</td><td class="num"><?= $aCount ? srE(srFmt($aTotal/$aCount,2)) : '—' ?></td><td colspan="4"></td></tr></tbody></table>
<?php else: ?>
<table class="marks"><thead><tr><th>SUBJECT / UNIT</th><th><div class="vertical">AOI 2</div></th><th><div class="vertical">AOI 1</div></th><th><div class="vertical">TOTAL SCORES</div></th><th><div class="vertical">AVG</div></th><th><div class="vertical">Out of 20</div></th><th><div class="vertical">Identifier</div></th><th><div class="vertical">Out of 80</div></th><th><div class="vertical">FINAL</div></th><th><div class="vertical">GRADE</div></th><th><div class="vertical">POINTS</div></th><th>COMMENT</th><th>INITIALS</th></tr></thead><tbody>
<?php foreach ($subjectRows as $sub): ?><tr><td><span class="subj"><?= srE($sub['subject_code']) ?> <?= srE($sub['subject_name']) ?></span></td><td class="num"><?= srE(srFmt($sub['aoi2'],1)) ?></td><td class="num"><?= srE(srFmt($sub['aoi1'],1)) ?></td><td class="num"><?= srE(srFmt($sub['total_scores'],1)) ?></td><td class="num"><?= srE(srFmt($sub['avg_score'],2)) ?></td><td class="num"><?= srE(srFmt($sub['out20'],0)) ?></td><td class="num"><?= srE($sub['identifier_value']) ?></td><td class="num"><?= srE(srFmt($sub['out80'],0)) ?></td><td class="num"><strong><?= srE(srFmt($sub['final_mark'],0)) ?></strong></td><td class="num"><strong><?= srE($sub['grade']) ?></strong></td><td class="num"><?= srE($sub['points'] ?? '') ?></td><td><?= srE($sub['comment']) ?></td><td class="num"><?= srE($sub['initials']) ?></td></tr><?php endforeach; ?>
<tr class="sumrow"><td>TOTAL</td><td></td><td></td><td><?= srE(srFmt($totalAoi,1)) ?></td><td></td><td><?= srE(srFmt($totalOut20,0)) ?></td><td></td><td><?= srE(srFmt($totalOut80,0)) ?></td><td><?= srE(srFmt($totalFinal,0)) ?></td><td colspan="2"></td><td></td></tr>
<tr class="sumrow"><td>AVERAGE</td><td></td><td></td><td><?= count($subjectRows) ? srE(srFmt($totalAoi / count($subjectRows),1)) : '' ?></td><td><?= $avgCount ? srE(srFmt($totalAvg / $avgCount,2)) : '' ?></td><td><?= count($subjectRows) ? srE(srFmt($averageOut20,2)) : '' ?></td><td><?= $averageIdentifier !== null ? srE(srFmt($averageIdentifier,1)) : '' ?></td><td><?= count($subjectRows) ? srE(srFmt($averageOut80,2)) : '' ?></td><td><?= $averageFinal !== null ? srE(srFmt($averageFinal,2)) : '' ?></td><td colspan="3"></td></tr>
</tbody></table><?php endif; ?><?php if (($report['report_level'] ?? 'O_LEVEL') === 'O_LEVEL'): ?><div class="identifier-note">Identifier &nbsp; <strong>1</strong> Basic &nbsp; <strong>2</strong> Moderate &nbsp; <strong>3</strong> Outstanding learning outcomes</div><?php endif; ?>
<div class="comments"><div class="comment-line">Class Teacher's comment: <?= srE($report['class_teacher_comment'] ?: '........................................................................................................') ?></div><div class="signature-area"><div class="signature-row"><span>SIGNATURE: <span class="line"></span></span><span>DATE: <span class="line"></span></span></div><div class="stamp">ST. JOHN'S<br>SECONDARY SCHOOL<br><br>MUDUUMA<br><small>QUANTUM POSSUM</small></div></div><div class="comment-line">Headteacher's comment: <?= srE($report['headteacher_comment'] ?: '........................................................................................................') ?></div><div class="signature-area"><div class="signature-row"><span>SIGNATURE / STAMP: <span class="line"></span></span><span>DATE: <span class="line"></span></span></div></div></div>
<div class="date-fees"><div>Next Term: BEGIN ON: <strong><?= $report['next_term_begins'] ? srE(date('jS F, Y', strtotime($report['next_term_begins']))) : '________________________' ?></strong></div><div>CLOSE ON: <strong><?= $report['term_closes'] ? srE(date('jS F, Y', strtotime($report['term_closes']))) : '________________________' ?></strong></div><div>Fees balance: <strong><?= $report['fees_balance'] !== null ? 'UGX ' . srE(number_format((float)$report['fees_balance'],2)) : '................................................................' ?></strong></div></div>
<table class="grading-key"><tr><th>Mark Range</th><th>100 - 85</th><th>84 - 70</th><th>69 - 60</th><th>59 - 50</th><th>49 - 0</th></tr><tr><th>Grade</th><td>A</td><td>B</td><td>C</td><td>D</td><td>E</td></tr><tr><th class="left" colspan="6">Keywords used / Description of terms</th></tr><tr><th>Identifier</th><th colspan="2">Score range</th><th colspan="3">Descriptor</th></tr><tr><td>3</td><td colspan="2">2.50 - 3.00</td><td colspan="3" class="left">Outstanding: All Learning Outcomes achieved for overall achievement</td></tr><tr><td>2</td><td colspan="2">1.50 - 2.49</td><td colspan="3" class="left">Moderate: Many Learning Outcomes achieved for overall achievement</td></tr><tr><td>1</td><td colspan="2">0.90 - 1.49</td><td colspan="3" class="left">Basic: A few Learning Outcomes achieved</td></tr></table><div class="footer">Quantum Possum... To the best of my Ability</div></main></body></html>
<?php
            exit;
        }
    } catch (Throwable $e) {
        error_log('student_reports.php print error: ' . $e->getMessage());
        $pageError = 'The report could not be loaded for printing. Check the PHP error log.';
    }
}

// Load edit values and their subject rows.
$editId = max(0, (int)($_GET['edit'] ?? 0));
$editReport = null; $formSubjects = []; $formError = '';
if ($editId > 0 && $pageError === '') {
    try {
        $stmt = $conn->prepare('SELECT * FROM student_term_reports WHERE id = ? LIMIT 1');
        $stmt->bind_param('i', $editId); $stmt->execute(); $editReport = $stmt->get_result()->fetch_assoc(); $stmt->close();
        if ($editReport) {
            $stmt = $conn->prepare('SELECT * FROM student_term_report_subjects WHERE report_id = ? ORDER BY sort_order,id');
            $stmt->bind_param('i', $editId); $stmt->execute(); $rs = $stmt->get_result();
            while ($r = $rs->fetch_assoc()) $formSubjects[] = $r;
            $stmt->close();
        } else $pageError = 'The report selected for editing was not found.';
    } catch (Throwable $e) { error_log('student_reports.php edit error: ' . $e->getMessage()); $pageError = 'Could not load that report for editing.'; }
}
if (!$formSubjects) {
    foreach ($defaultSubjects as $i => $s) $formSubjects[] = ['subject_code'=>$s[0], 'subject_name'=>$s[1], 'aoi2'=>null, 'aoi1'=>null, 'out20'=>null, 'identifier_value'=>null, 'out80'=>null, 'grade'=>null, 'comment'=>'', 'initials'=>''];
}

// Fetch recent reports for the history table.
$reports = [];
$search = trim((string)($_GET['q'] ?? ''));
if ($pageError === '') {
    try {
        if ($search !== '') {
            $like = '%' . $search . '%';
            $stmt = $conn->prepare('SELECT r.*, (SELECT COUNT(*) FROM student_term_report_subjects s WHERE s.report_id=r.id) AS subject_count FROM student_term_reports r WHERE r.student_name LIKE ? OR r.admission_no LIKE ? OR r.class_name LIKE ? OR r.academic_year LIKE ? ORDER BY r.created_at DESC, r.id DESC LIMIT 100');
            $stmt->bind_param('ssss', $like, $like, $like, $like);
        } else {
            $stmt = $conn->prepare('SELECT r.*, (SELECT COUNT(*) FROM student_term_report_subjects s WHERE s.report_id=r.id) AS subject_count FROM student_term_reports r ORDER BY r.created_at DESC, r.id DESC LIMIT 100');
        }
        $stmt->execute(); $result = $stmt->get_result(); while ($r = $result->fetch_assoc()) $reports[] = $r; $stmt->close();
    } catch (Throwable $e) { error_log('student_reports.php list error: ' . $e->getMessage()); $pageError = 'Could not load saved reports. Check the PHP error log.'; }
}

function srMarkInput($name, $value, $max = null, $step = '0.1'): string {
    $maxAttr = $max !== null ? ' max="' . srE($max) . '"' : '';
    return '<input class="form-control form-control-sm mark-input" type="number" name="' . srE($name) . '[]" min="0"' . $maxAttr . ' step="' . srE($step) . '" value="' . srE($value) . '" placeholder="—">';
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Student Reports | School Management System</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f6f9;font-family:Arial,Helvetica,sans-serif;color:#343a40}.sidebar{position:fixed;top:0;bottom:0;left:0;width:250px;background:#212529;overflow-y:auto;z-index:1050}.sidebar-header{padding:22px 18px;background:#171a1d;color:#fff;font-weight:700;font-size:18px}.sidebar-section{padding:15px 16px 6px;color:#868e96;font-size:11px;text-transform:uppercase;font-weight:bold;letter-spacing:.5px}.sidebar a{display:block;color:#ced4da;padding:11px 16px;text-decoration:none;border-left:4px solid transparent;font-size:14px}.sidebar a:hover,.sidebar a.active{background:#343a40;color:#fff;border-left-color:#dc3545}.sidebar a i{width:24px;text-align:center;margin-right:5px}.main{margin-left:250px;min-height:100vh}.topbar{padding:17px 25px;background:#fff;border-bottom:1px solid #e5e5e5;display:flex;align-items:center;justify-content:space-between}.content{padding:24px}.page-head,.panel,.stat-card{background:#fff;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,.05)}.page-head{padding:21px;margin-bottom:20px}.panel{padding:21px;margin-bottom:22px}.stat-card{padding:18px;margin-bottom:18px}.stat-title{color:#6c757d;font-size:13px}.stat-number{font-size:22px;font-weight:700}.form-control,.custom-select,.btn{border-radius:6px}.form-control,.custom-select{min-height:38px}label{font-size:13px;font-weight:600}.table th{background:#f8f9fa;white-space:nowrap;font-size:12px}.table td{vertical-align:middle;font-size:13px}.mobile-menu{display:none}.subject-grid th{font-size:10px!important;text-transform:uppercase;color:#596579}.subject-grid td{padding:5px;min-width:78px}.subject-grid td:first-child{min-width:175px}.subject-grid td:nth-child(9){min-width:80px}.subject-grid input,.subject-grid select{min-width:65px}.subject-grid td:first-child input{min-width:145px}.subject-grid td:nth-last-child(2) input{min-width:130px}.subject-grid .final-input{background:#f1f5f9;font-weight:700}.section-note{font-size:12px;color:#718096}.form-section-title{font-weight:700;font-size:16px;border-bottom:1px solid #e9ecef;padding-bottom:10px;margin-bottom:16px}.action-btns form{display:inline}.alert{font-size:13px}@media(max-width:991px){.sidebar{left:-250px;transition:left .25s}.sidebar.show{left:0}.main{margin-left:0}.mobile-menu{display:inline-block}.content{padding:15px}.topbar{padding:12px 15px}}@media print{.sidebar,.topbar,.no-print{display:none!important}.main{margin:0}.content{padding:0}}
</style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<aside class="sidebar no-print" id="sidebar">
 <div class="sidebar-header"><i class="fas fa-school mr-2"></i>School Management<br><small class="text-muted">Teacher &amp; Academic Panel</small></div>
 <div class="sidebar-section">Main</div><a href="/admin/dashboard.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
 <div class="sidebar-section">Students &amp; Learning</div><a href="/admin/students/list.php"><i class="fas fa-user-graduate"></i>Students</a><a href="/admin/classes/student_reports.php" class="active"><i class="fas fa-file-alt"></i>Student Reports</a>
 <div class="sidebar-section">Bursar &amp; Finance</div><a href="/admin/bursar/index.php"><i class="fas fa-wallet"></i>Bursar Dashboard</a><a href="/admin/bursar/fees_report.php"><i class="fas fa-file-invoice-dollar"></i>Fees Report</a>
 <div class="sidebar-section">System</div><a href="/admin/dashboard.php"><i class="fas fa-user-shield"></i>Admin Dashboard</a><a href="/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
</aside>
<main class="main">
 <div class="topbar"><div><button type="button" class="btn btn-dark mobile-menu mr-2" id="mobileMenuBtn" aria-label="Toggle menu"><i class="fas fa-bars"></i></button><strong><i class="fas fa-graduation-cap mr-2 text-danger"></i>Student Assessment &amp; Reports</strong></div><div class="text-muted small"><i class="fas fa-user-circle mr-1"></i><?= srE($_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Teacher') ?></div></div>
 <div class="content">
  <div class="page-head d-flex justify-content-between align-items-center flex-wrap"><div><h3 class="mb-1"><i class="fas fa-file-signature text-danger mr-2"></i><?= $editReport ? 'Edit Student Report' : 'Enter Student Marks & Grades' ?></h3><div class="text-muted">Enter the student's details and assess each subject, then save and print the term report.</div></div><div class="mt-2 no-print"><button class="btn btn-outline-secondary" type="button" onclick="window.print()"><i class="fas fa-print mr-1"></i>Print page</button></div></div>
  <?php if ($createdTables): ?><div class="alert alert-info"><i class="fas fa-info-circle mr-1"></i>The report tables were created automatically: <?= srE(implode(', ', $createdTables)) ?>.</div><?php endif; ?>
  <?php if ($pageError !== ''): ?><div class="alert alert-danger"><strong><i class="fas fa-exclamation-triangle mr-1"></i>Page setup problem:</strong> <?= srE($pageError) ?></div><?php endif; ?>
  <?php if (is_array($flash) && !empty($flash['message'])): ?><div class="alert alert-<?= srE($flash['type'] ?? 'info') ?> alert-dismissible fade show" role="alert"><?= srE($flash['message']) ?><button type="button" class="close" data-dismiss="alert"><span>&times;</span></button></div><?php endif; ?>

  <?php if ($pageError === ''): ?>
  <section class="panel">
   <div class="form-section-title"><i class="fas fa-user-graduate text-danger mr-2"></i>Student &amp; Term Details</div>
   <form method="post" action="student_reports.php<?= $editReport ? '?edit='.(int)$editReport['id'] : '' ?>" id="reportForm">
    <input type="hidden" name="csrf_token" value="<?= srE($csrfToken) ?>"><input type="hidden" name="action" value="save_report"><input type="hidden" name="report_id" value="<?= (int)($editReport['id'] ?? 0) ?>">
    <div class="form-group col-md-4"><label for="report_level">Report Card Type</label><select class="custom-select" name="report_level" id="report_level"><option value="O_LEVEL" <?= ($editReport['report_level'] ?? 'O_LEVEL')==='O_LEVEL'?'selected':'' ?>>O’Level — Ordinary Level</option><option value="A_LEVEL" <?= ($editReport['report_level'] ?? 'O_LEVEL')==='A_LEVEL'?'selected':'' ?>>A’Level — Advanced Level</option></select></div>
    <div class="form-row">
     <div class="form-group col-lg-6"><label for="registered_student_id">Select student from registered students (optional)</label><select class="custom-select" id="registered_student_id" name="student_id"><option value="0">-- Select or enter a student manually --</option><?php foreach ($studentOptions as $s): ?><option value="<?= (int)$s['id'] ?>" data-name="<?= srE($s['name']) ?>" data-admission="<?= srE($s['admission']) ?>" data-number="<?= srE($s['student_number']) ?>" data-lin="<?= srE($s['lin_no']) ?>" data-payment-code="<?= srE($s['student_payment_code']) ?>" data-section="<?= srE($s['student_section']) ?>" data-class="<?= srE($s['class_name']) ?>" <?= (int)($editReport['student_id'] ?? 0)===(int)$s['id']?'selected':'' ?>><?= srE($s['name']) ?><?= $s['admission']!==''?' — Admission: '.srE($s['admission']):'' ?><?= $s['lin_no']!==''?' — LIN: '.srE($s['lin_no']):'' ?><?= $s['student_payment_code']!==''?' — Payment Code: '.srE($s['student_payment_code']):'' ?> — <?= srE($s['student_section']) ?></option><?php endforeach; ?></select><small class="form-text text-muted">Choosing a registered student fills in their available details. You can still type a name manually.</small></div>
     <div class="form-group col-lg-6"><label for="student_name">Student full name <span class="text-danger">*</span></label><input class="form-control" id="student_name" name="student_name" maxlength="150" required value="<?= srE($editReport['student_name'] ?? '') ?>" placeholder="Enter full student name"></div>
    </div>
    <div class="form-row">
     <div class="form-group col-md-3"><label for="admission_no">Admission number</label><input class="form-control" id="admission_no" name="admission_no" maxlength="50" value="<?= srE($editReport['admission_no'] ?? '') ?>" placeholder="e.g. 26/F/2668"></div>
     <div class="form-group col-md-3"><label for="student_number">Student number</label><input class="form-control" id="student_number" name="student_number" maxlength="50" value="<?= srE($editReport['student_number'] ?? '') ?>" placeholder="Student number"></div>
     <div class="form-group col-md-3"><label for="lin_no_preview">LIN Number (registered student)</label><input class="form-control" id="lin_no_preview" value="" readonly placeholder="Filled from student record"></div>
     <div class="form-group col-md-3"><label for="student_payment_code_preview">Student Payment Code</label><input class="form-control" id="student_payment_code_preview" value="" readonly placeholder="Filled from student record"></div>
     <div class="form-group col-md-3"><label for="student_section_preview">Student Section</label><input class="form-control" id="student_section_preview" value="" readonly placeholder="Day / Boarding"></div>
     <div class="form-group col-md-3"><label for="class_name">Class / Stream <span class="text-danger">*</span></label><input class="form-control" id="class_name" name="class_name" maxlength="100" required value="<?= srE($editReport['class_name'] ?? '') ?>" placeholder="e.g. S.1 WEST"></div>
     <div class="form-group col-md-3"><label for="academic_year">Academic year <span class="text-danger">*</span></label><input class="form-control" type="number" min="2000" max="2100" id="academic_year" name="academic_year" required value="<?= srE($editReport['academic_year'] ?? date('Y')) ?>"></div>
    </div>
    <div class="form-row">
     <div class="form-group col-md-3"><label for="term">Term <span class="text-danger">*</span></label><select class="custom-select" id="term" name="term" required><?php foreach (['Term I','Term II','Term III'] as $t): ?><option value="<?= srE($t) ?>" <?= ($editReport['term'] ?? 'Term I')===$t?'selected':'' ?>><?= srE($t) ?></option><?php endforeach; ?></select></div>
     <div class="form-group col-md-5"><label for="report_title">Report title</label><input class="form-control" id="report_title" name="report_title" maxlength="150" value="<?= srE($editReport['report_title'] ?? '') ?>" placeholder="Auto-generated if left blank"></div>
     <div class="form-group col-md-2"><label for="next_term_begins">Next term begins</label><input class="form-control" type="date" id="next_term_begins" name="next_term_begins" value="<?= srE($editReport['next_term_begins'] ?? '') ?>"></div>
     <div class="form-group col-md-2"><label for="term_closes">Term closes</label><input class="form-control" type="date" id="term_closes" name="term_closes" value="<?= srE($editReport['term_closes'] ?? '') ?>"></div>
    </div>

    <div class="form-section-title mt-3"><i class="fas fa-list-ol text-danger mr-2"></i>Subject Marks &amp; Grades</div>
    <p class="section-note" id="assessmentNote">Enter AOI scores (0–3), the score out of 20 and out of 80, the learning-outcome identifier, grade, subject comment and teacher initials. Final = Out of 20 + Out of 80. If no grade is selected, the system assigns one from the final mark: A 85–100, B 70–84, C 60–69, D 50–59, E 0–49.</p>
    <div class="table-responsive">
     <table class="table table-bordered table-sm subject-grid" id="subjectTable">
      <thead><tr><th>Code</th><th>Subject / Unit *</th><th class="olevel-only">AOI 2</th><th class="olevel-only">AOI 1</th><th class="olevel-only">Total scores</th><th class="olevel-only">Average</th><th>Mark / Out of 20</th><th class="olevel-only">Identifier</th><th class="olevel-only">Out of 80</th><th>Final</th><th>Grade</th><th class="alevel-only">Points</th><th>Comment</th><th>Initials</th><th class="no-print">Remove</th></tr></thead>
      <tbody id="subjectRows">
      <?php foreach ($formSubjects as $i => $sub): $a2=$sub['aoi2']??null; $a1=$sub['aoi1']??null; $o20=$sub['out20']??null; $o80=$sub['out80']??null; $total=($a2===null||$a2==='')&&($a1===null||$a1==='')?null:(float)($a2??0)+(float)($a1??0); $avg=$total===null?null:$total/2; $final=($o20===null||$o20==='')&&($o80===null||$o80==='')?null:(float)($o20??0)+(float)($o80??0); ?>
       <tr>
        <td><input class="form-control form-control-sm" name="subject_code[]" maxlength="30" value="<?= srE($sub['subject_code'] ?? '') ?>" placeholder="Code"></td>
        <td><input class="form-control form-control-sm" name="subject_name[]" maxlength="150" required value="<?= srE($sub['subject_name'] ?? '') ?>" placeholder="Subject name"></td>
        <td class="olevel-only"><?= srMarkInput('aoi2', $a2, 3) ?></td><td class="olevel-only"><?= srMarkInput('aoi1', $a1, 3) ?></td>
        <td class="olevel-only"><input class="form-control form-control-sm computed-total" readonly value="<?= $total===null?'':srE(srFmt($total,1)) ?>" tabindex="-1"></td>
        <td class="olevel-only"><input class="form-control form-control-sm computed-avg" readonly value="<?= $avg===null?'':srE(srFmt($avg,2)) ?>" tabindex="-1"></td>
        <td><?= srMarkInput('out20', $o20, 20, '1') ?></td>
        <td class="olevel-only"><select class="form-control form-control-sm" name="identifier_value[]"><option value="">—</option><?php foreach ([1=>'1 Basic',2=>'2 Moderate',3=>'3 Outstanding'] as $iv=>$il): ?><option value="<?= $iv ?>" <?= (string)($sub['identifier_value']??'')===(string)$iv?'selected':'' ?>><?= srE($il) ?></option><?php endforeach; ?></select></td>
        <td class="olevel-only"><?= srMarkInput('out80', $o80, 80, '1') ?></td>
        <td><input class="form-control form-control-sm final-input" readonly value="<?= $final===null?'':srE(srFmt($final,0)) ?>" tabindex="-1"></td>
        <td><select class="form-control form-control-sm grade-select" name="grade[]"><option value="">Auto</option><?php foreach (['A','B','C','D','E'] as $g): ?><option value="<?= $g ?>" <?= strtoupper((string)($sub['grade']??''))===$g?'selected':'' ?>><?= $g ?></option><?php endforeach; ?></select></td>
        <td class="alevel-only"><input class="form-control form-control-sm" type="number" min="0" max="20" step="0.5" name="points[]" placeholder="Points"></td>
        <td><input class="form-control form-control-sm" name="subject_comment[]" maxlength="255" value="<?= srE($sub['comment'] ?? '') ?>" placeholder="Comment"></td>
        <td><input class="form-control form-control-sm" name="initials[]" maxlength="20" value="<?= srE($sub['initials'] ?? '') ?>" placeholder="Initials"></td>
        <td class="no-print text-center"><button class="btn btn-sm btn-outline-danger remove-subject" type="button" title="Remove subject"><i class="fas fa-times"></i></button></td>
       </tr>
      <?php endforeach; ?>
      </tbody>
     </table>
    </div>
    <div class="d-flex flex-wrap justify-content-between align-items-center no-print mb-3"><button class="btn btn-outline-primary" type="button" id="addSubject"><i class="fas fa-plus mr-1"></i>Add subject</button><span class="section-note">You can change the sample subjects or add your school's own subjects.</span></div>

    <div class="form-section-title mt-4"><i class="fas fa-comment-alt text-danger mr-2"></i>Term Comments &amp; Fees</div>
    <div class="form-row"><div class="form-group col-md-6"><label for="class_teacher_comment">Class teacher's comment</label><textarea class="form-control" id="class_teacher_comment" name="class_teacher_comment" rows="3" placeholder="Overall performance and advice"><?= srE($editReport['class_teacher_comment'] ?? '') ?></textarea></div><div class="form-group col-md-6"><label for="headteacher_comment">Headteacher's comment</label><textarea class="form-control" id="headteacher_comment" name="headteacher_comment" rows="3" placeholder="Headteacher's overall comment"><?= srE($editReport['headteacher_comment'] ?? '') ?></textarea></div></div>
    <div class="form-row"><div class="form-group col-md-4"><label for="fees_balance">Fees balance (UGX)</label><input class="form-control" type="number" min="0" step="0.01" id="fees_balance" name="fees_balance" value="<?= srE($editReport['fees_balance'] ?? '') ?>" placeholder="Optional"></div></div>
    <div class="no-print"><button type="submit" class="btn btn-danger" id="saveReportBtn"><i class="fas fa-save mr-1"></i><?= $editReport ? 'Update Report' : 'Save & Generate Report' ?></button> <?php if ($editReport): ?><a class="btn btn-outline-secondary" href="student_reports.php">Cancel editing</a><?php else: ?><button type="reset" class="btn btn-outline-secondary"><i class="fas fa-undo mr-1"></i>Reset form</button><?php endif; ?></div>
   </form>
  </section>

  <section class="panel no-print"><div class="d-flex flex-wrap justify-content-between align-items-center mb-3"><div><h5 class="mb-1"><i class="fas fa-history text-danger mr-2"></i>Saved Student Reports</h5><div class="text-muted small">Open, edit or delete a report. The newest 100 reports are available here.</div></div></div>
   <form class="form-row align-items-end mb-3" method="get" action="student_reports.php"><div class="form-group col-md-6"><label for="q">Search by student, admission number, class or year</label><input class="form-control" type="search" id="q" name="q" value="<?= srE($search) ?>" placeholder="Type a student name..."></div><div class="form-group col-md-3"><button class="btn btn-primary" type="submit"><i class="fas fa-search mr-1"></i>Search</button> <a class="btn btn-outline-secondary" href="student_reports.php">Reset</a></div></form>
   <div class="table-responsive"><table class="table table-bordered table-hover mb-0"><thead><tr><th>Student</th><th>Admission No.</th><th>Class</th><th>Term / Year</th><th>Subjects</th><th>Created</th><th>Actions</th></tr></thead><tbody>
   <?php if (!$reports): ?><tr><td colspan="7" class="text-center text-muted py-4"><i class="fas fa-file-alt fa-2x mb-2"></i><br>No reports saved yet. Complete the form above to create one.</td></tr><?php else: foreach ($reports as $r): ?><tr><td><strong><?= srE($r['student_name']) ?></strong></td><td><?= srE($r['admission_no'] ?: '—') ?></td><td><?= srE($r['class_name']) ?></td><td><?= srE($r['term']) ?> / <?= srE($r['academic_year']) ?></td><td><?= (int)$r['subject_count'] ?></td><td><?= srE(date('d M Y', strtotime($r['created_at']))) ?></td><td class="text-nowrap"><a class="btn btn-sm btn-outline-primary" target="_blank" href="student_reports.php?print=<?= (int)$r['id'] ?>" title="View / print"><i class="fas fa-print"></i></a> <a class="btn btn-sm btn-outline-secondary" href="student_reports.php?edit=<?= (int)$r['id'] ?>" title="Edit"><i class="fas fa-edit"></i></a> <form method="post" class="d-inline" onsubmit="return confirm('Delete this student report and all its subject marks?');"><input type="hidden" name="csrf_token" value="<?= srE($csrfToken) ?>"><input type="hidden" name="action" value="delete_report"><input type="hidden" name="report_id" value="<?= (int)$r['id'] ?>"><button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="fas fa-trash"></i></button></form></td></tr><?php endforeach; endif; ?>
   </tbody></table></div>
  </section>
  <?php endif; ?>
  <div class="text-center text-muted small mb-3">School Management System &mdash; Student Assessment &amp; Reports</div>
 </div>
</main>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function(){
 var sidebar=document.getElementById('sidebar'),menu=document.getElementById('mobileMenuBtn');
 if(menu&&sidebar)menu.addEventListener('click',function(){sidebar.classList.toggle('show');});
 document.addEventListener('click',function(e){if(window.innerWidth<=991&&sidebar&&sidebar.classList.contains('show')&&!sidebar.contains(e.target)&&menu&&!menu.contains(e.target))sidebar.classList.remove('show');});
 var studentSelect=document.getElementById('registered_student_id');
 if(studentSelect)studentSelect.addEventListener('change',function(){var opt=this.options[this.selectedIndex];if(!opt||!opt.value)return;['student_name','admission_no','student_number','class_name'].forEach(function(id,key){var el=document.getElementById(id);var prop=['name','admission','number','class'][key];if(el&&opt.dataset[prop])el.value=opt.dataset[prop];});var lin=document.getElementById('lin_no_preview');if(lin)lin.value=opt.dataset.lin||'';var paymentCode=document.getElementById('student_payment_code_preview');if(paymentCode)paymentCode.value=opt.dataset.paymentCode||'';var section=document.getElementById('student_section_preview');if(section)section.value=opt.dataset.section||'Day';});if(studentSelect&&studentSelect.value)studentSelect.dispatchEvent(new Event('change'));
 function gradeFor(mark){if(mark>=85)return 'A';if(mark>=70)return 'B';if(mark>=60)return 'C';if(mark>=50)return 'D';return 'E';}
 function calculateRow(tr){var a2=tr.querySelector('[name="aoi2[]"]'),a1=tr.querySelector('[name="aoi1[]"]'),o20=tr.querySelector('[name="out20[]"]'),o80=tr.querySelector('[name="out80[]"]');var v2=a2.value===''?null:parseFloat(a2.value),v1=a1.value===''?null:parseFloat(a1.value),v20=o20.value===''?null:parseFloat(o20.value),v80=o80.value===''?null:parseFloat(o80.value);var total=tr.querySelector('.computed-total'),avg=tr.querySelector('.computed-avg'),finalInput=tr.querySelector('.final-input'),grade=tr.querySelector('.grade-select');if(v2===null&&v1===null){total.value='';avg.value='';}else{var t=(v2||0)+(v1||0);total.value=t.toFixed(1);avg.value=(t/2).toFixed(2);}if(v20===null&&v80===null){finalInput.value='';}else{var f=(level&&level.value==='A_LEVEL')?(v20||0):((v20||0)+(v80||0));finalInput.value=f.toFixed(0);grade.value=gradeFor(f);}}
 document.querySelectorAll('#subjectRows tr').forEach(function(tr){tr.querySelectorAll('[name="aoi2[]"],[name="aoi1[]"],[name="out20[]"],[name="out80[]"]').forEach(function(input){input.addEventListener('input',function(){calculateRow(tr);});});var rm=tr.querySelector('.remove-subject');if(rm)rm.addEventListener('click',function(){if(document.querySelectorAll('#subjectRows tr').length>1)tr.remove();else{tr.querySelectorAll('input').forEach(function(i){i.value='';});tr.querySelectorAll('select').forEach(function(s){s.value='';});}});});
 var add=document.getElementById('addSubject');if(add)add.addEventListener('click',function(){var tbody=document.getElementById('subjectRows');var tr=document.createElement('tr');tr.innerHTML='<td><input class="form-control form-control-sm" name="subject_code[]" maxlength="30" placeholder="Code"></td><td><input class="form-control form-control-sm" name="subject_name[]" maxlength="150" required placeholder="Subject name"></td><td class="olevel-only"><input class="form-control form-control-sm mark-input" type="number" name="aoi2[]" min="0" max="3" step="0.1" placeholder="—"></td><td class="olevel-only"><input class="form-control form-control-sm mark-input" type="number" name="aoi1[]" min="0" max="3" step="0.1" placeholder="—"></td><td class="olevel-only"><input class="form-control form-control-sm computed-total" readonly tabindex="-1"></td><td class="olevel-only"><input class="form-control form-control-sm computed-avg" readonly tabindex="-1"></td><td><input class="form-control form-control-sm mark-input" type="number" name="out20[]" min="0" max="20" step="1" placeholder="—"></td><td class="olevel-only"><select class="form-control form-control-sm" name="identifier_value[]"><option value="">—</option><option value="1">1 Basic</option><option value="2">2 Moderate</option><option value="3">3 Outstanding</option></select></td><td class="olevel-only"><input class="form-control form-control-sm mark-input" type="number" name="out80[]" min="0" max="80" step="1" placeholder="—"></td><td><input class="form-control form-control-sm final-input" readonly tabindex="-1"></td><td><select class="form-control form-control-sm grade-select" name="grade[]"><option value="">Auto</option><option>A</option><option>B</option><option>C</option><option>D</option><option>E</option></select></td><td class="alevel-only"><input class="form-control form-control-sm" type="number" min="0" max="20" step="0.5" name="points[]" placeholder="Points"></td>
        <td><input class="form-control form-control-sm" name="subject_comment[]" maxlength="255" placeholder="Comment"></td><td><input class="form-control form-control-sm" name="initials[]" maxlength="20" placeholder="Initials"></td><td class="no-print text-center"><button class="btn btn-sm btn-outline-danger remove-subject" type="button"><i class="fas fa-times"></i></button></td>';tbody.appendChild(tr);tr.querySelectorAll('[name="aoi2[]"],[name="aoi1[]"],[name="out20[]"],[name="out80[]"]').forEach(function(input){input.addEventListener('input',function(){calculateRow(tr);});});tr.querySelector('.remove-subject').addEventListener('click',function(){if(document.querySelectorAll('#subjectRows tr').length>1)tr.remove();else tr.remove();});});
 var term=document.getElementById('term'),title=document.getElementById('report_title');if(term&&title)term.addEventListener('change',function(){if(title.value.trim()===''||/^(O|A) Level End of Term/.test(title.value))title.value=(level&&level.value==='A_LEVEL'?'A Level ':'O Level ')+'End of '+term.value+' Report';});
 var level=document.getElementById('report_level');
 function setLevel(){if(!level)return;var a=level.value==='A_LEVEL';document.querySelectorAll('.alevel-only').forEach(function(e){e.style.display=a?'table-cell':'none';});document.querySelectorAll('.olevel-only').forEach(function(e){e.style.display=a?'none':'table-cell';});var note=document.getElementById('assessmentNote');if(note)note.textContent=a?'A-Level: enter the subject mark out of 100, grade and points (0–20).':'O-Level: enter AOI scores, Out of 20 and Out of 80, learning-outcome identifier and grade.';document.querySelectorAll('[name="out20[]"]').forEach(function(e){e.max=a?'100':'20';e.placeholder=a?'Mark / 100':'—';});}
 if(level){level.addEventListener('change',setLevel);setLevel();}
 var form=document.getElementById('reportForm');if(form)form.addEventListener('submit',function(){var btn=document.getElementById('saveReportBtn');if(btn){btn.disabled=true;btn.innerHTML='<i class="fas fa-spinner fa-spin mr-1"></i>Saving report...';}});
})();
</script>
</body>
</html>
