<?php
/**
 * Student report template based on the supplied St. John's Secondary School report.
 * Save this file as UTF-8 without BOM. It currently shows the sample student/report
 * shown in the picture. Replace $student and $subjects with database records when
 * connecting this template to your school system.
 */

// ------------------------- SAMPLE STUDENT DETAILS -------------------------
$student = [
    'school_name'       => "ST. JOHN'S SECONDARY SCHOOL",
    'school_location'   => 'MUDUUMA',
    'motto'             => 'Quantum Possum',
    'postal_address'    => 'P. O. Box 15166, Kibuli, Kampala - Uganda.',
    'email'             => 'stjohnsssmuduuma@gmail.com',
    'website'           => 'www.stjohnssmuduuma.com',
    'report_title'      => 'O Level End of Term I Report',
    'name'              => 'PRECIOUS BABRA',
    'class'             => 'S.1 WEST',
    'term'              => 'I',
    'year'              => '2026',
    'admission_number'  => '26/F/2668',
    'student_number'    => '1003123044',
    'identifier'        => '2',
    'identifier_label'  => 'Moderate',
    'class_teacher_comment' => 'Good performance, PRECIOUS BABRA need to aim higher for overall achievement',
    'headteacher_comment'   => 'Quite good results, PRECIOUS BABRA should aim higher for overall achievement',
    'next_term_begins'  => '17th May, 2026',
    'term_closes'       => '14th August, 2026',
    'fees_balance'      => '',
];

// Columns and marks transcribed from the supplied report image.
$subjects = [
    ['code'=>'527','subject'=>'Agriculture',          'aoi2'=>'1.6','aoi1'=>'2.7','total'=>'4.3','avg'=>'2.15','out20'=>'14','identifier'=>'2','out80'=>'78','final'=>'92','grade'=>'A','comment'=>'Very good results','initials'=>'BT'],
    ['code'=>'553','subject'=>'Biology',              'aoi2'=>'3.0','aoi1'=>'2.6','total'=>'5.6','avg'=>'2.80','out20'=>'19','identifier'=>'3','out80'=>'52','final'=>'71','grade'=>'B','comment'=>'Good results','initials'=>'GN'],
    ['code'=>'223','subject'=>'C.R.E',                'aoi2'=>'2.0','aoi1'=>'2.0','total'=>'4.0','avg'=>'2.00','out20'=>'13','identifier'=>'2','out80'=>'44','final'=>'57','grade'=>'D','comment'=>'Aim higher','initials'=>'WD'],
    ['code'=>'545','subject'=>'Chemistry',            'aoi2'=>'3.0','aoi1'=>'2.8','total'=>'5.8','avg'=>'2.90','out20'=>'19','identifier'=>'3','out80'=>'69','final'=>'88','grade'=>'A','comment'=>'Very good results','initials'=>'NG'],
    ['code'=>'840','subject'=>'Computer Studies',     'aoi2'=>'2.6','aoi1'=>'2.8','total'=>'5.4','avg'=>'2.70','out20'=>'18','identifier'=>'3','out80'=>'61','final'=>'79','grade'=>'B','comment'=>'Good results','initials'=>'TI'],
    ['code'=>'112','subject'=>'English',              'aoi2'=>'2.4','aoi1'=>'2.8','total'=>'5.2','avg'=>'2.60','out20'=>'17','identifier'=>'3','out80'=>'73','final'=>'90','grade'=>'A','comment'=>'Good results','initials'=>'AS'],
    ['code'=>'845','subject'=>'Entrepreneurship',     'aoi2'=>'2.7','aoi1'=>'2.7','total'=>'5.4','avg'=>'2.70','out20'=>'18','identifier'=>'3','out80'=>'46','final'=>'64','grade'=>'C','comment'=>'Fair results','initials'=>'MK'],
    ['code'=>'610','subject'=>'Fine Art',             'aoi2'=>'2.0','aoi1'=>'1.8','total'=>'3.8','avg'=>'1.90','out20'=>'13','identifier'=>'2','out80'=>'50','final'=>'63','grade'=>'C','comment'=>'Fair results','initials'=>'NC'],
    ['code'=>'273','subject'=>'Geography',            'aoi2'=>'1.2','aoi1'=>'2.4','total'=>'3.6','avg'=>'1.80','out20'=>'12','identifier'=>'2','out80'=>'67','final'=>'79','grade'=>'B','comment'=>'Good results','initials'=>'KC'],
    ['code'=>'241','subject'=>'History',              'aoi2'=>'2.0','aoi1'=>'1.7','total'=>'3.7','avg'=>'1.85','out20'=>'12','identifier'=>'2','out80'=>'58','final'=>'70','grade'=>'B','comment'=>'Good results','initials'=>'KH'],
    ['code'=>'','subject'=>'Kiswahili',               'aoi2'=>'1.8','aoi1'=>'1.9','total'=>'3.7','avg'=>'1.85','out20'=>'12','identifier'=>'2','out80'=>'80','final'=>'92','grade'=>'A','comment'=>'Very good results','initials'=>'WS'],
    ['code'=>'335','subject'=>'Luganda',              'aoi2'=>'1.8','aoi1'=>'1.8','total'=>'3.6','avg'=>'1.80','out20'=>'12','identifier'=>'2','out80'=>'63','final'=>'75','grade'=>'B','comment'=>'Good results','initials'=>'NS'],
    ['code'=>'456','subject'=>'Mathematics',          'aoi2'=>'2.4','aoi1'=>'2.4','total'=>'4.8','avg'=>'2.40','out20'=>'16','identifier'=>'2','out80'=>'45','final'=>'61','grade'=>'C','comment'=>'Fair results','initials'=>'HK'],
    ['code'=>'','subject'=>'Physical education',      'aoi2'=>'3.0','aoi1'=>'3.0','total'=>'6.0','avg'=>'3.00','out20'=>'20','identifier'=>'3','out80'=>'40','final'=>'60','grade'=>'C','comment'=>'Fair results','initials'=>'OL'],
    ['code'=>'535','subject'=>'Physics',              'aoi2'=>'2.7','aoi1'=>'2.7','total'=>'5.4','avg'=>'2.70','out20'=>'18','identifier'=>'3','out80'=>'66','final'=>'84','grade'=>'B','comment'=>'Good results','initials'=>'KJ'],
    ['code'=>'','subject'=>'Technical Drawing',       'aoi2'=>'1.9','aoi1'=>'1.7','total'=>'3.6','avg'=>'1.80','out20'=>'12','identifier'=>'2','out80'=>'50','final'=>'62','grade'=>'C','comment'=>'Fair results','initials'=>'NR'],
];

$totals = [
    'subject_total' => 'TOTAL',
    'total_scores' => '73.9',
    'out20' => '245',
    'out80' => '942',
    'final' => '1187',
    'avg_total_scores' => '4.6',
    'avg_avg' => '2.3',
    'avg_out20' => '15.31',
    'avg_identifier' => '2.2',
    'avg_out80' => '58.9',
    'avg_final' => '74.19',
];

function reportE($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= reportE($student['name']) ?> - Student Report</title>
<style>
    :root { --ink:#171717; --line:#555; --soft:#f3f3f3; }
    * { box-sizing:border-box; }
    html, body { margin:0; padding:0; color:var(--ink); font-family:Arial, Helvetica, sans-serif; }
    body { background:#e8e8e8; padding:18px; }
    .toolbar { max-width:210mm; margin:0 auto 12px; display:flex; gap:8px; justify-content:flex-end; }
    .toolbar button { border:0; background:#1d3557; color:#fff; border-radius:5px; padding:10px 15px; cursor:pointer; font-size:14px; }
    .toolbar .secondary { background:#5d6775; }
    .paper { width:210mm; min-height:297mm; max-width:100%; margin:0 auto; padding:9mm 9mm 8mm; background:#fff; box-shadow:0 2px 12px rgba(0,0,0,.17); }
    .school-header { display:grid; grid-template-columns:25mm 1fr; gap:5mm; align-items:center; min-height:30mm; }
    .crest { width:24mm; height:27mm; display:flex; align-items:center; justify-content:center; position:relative; }
    .crest svg { width:100%; height:100%; }
    .school-name { text-align:center; padding-right:15mm; }
    .school-name h1 { font-size:15pt; margin:0 0 1mm; letter-spacing:.25px; font-weight:800; }
    .school-name h2 { font-size:13pt; margin:0 0 1.5mm; font-weight:800; }
    .school-contact { font-size:7.4pt; line-height:1.35; }
    .motto { font-size:7pt; font-style:italic; }
    .report-title { text-align:center; font-size:13pt; margin:3mm 0 2mm; font-weight:500; }
    .student-details { font-size:8.4pt; line-height:1.5; }
    .student-details .line1 { display:flex; align-items:flex-end; justify-content:space-between; gap:4mm; }
    .student-details .name { flex:1; min-width:0; }
    .student-details .admission { white-space:nowrap; font-weight:bold; }
    .redacted-demo { display:inline-block; min-width:35mm; border-bottom:1px dotted #777; font-weight:bold; }
    .meta-row { display:flex; justify-content:center; gap:12mm; font-weight:bold; }
    .student-number { text-align:center; font-weight:bold; }
    .marks-wrap { margin-top:2mm; }
    table { border-collapse:collapse; width:100%; }
    .marks { table-layout:fixed; font-size:6.5pt; }
    .marks th, .marks td { border:1px solid #555; padding:1.15mm .65mm; vertical-align:middle; overflow-wrap:anywhere; }
    .marks thead th { height:22mm; font-size:6.2pt; font-weight:700; text-align:center; }
    .marks .subject-col { width:26.2%; text-align:left; }
    .marks .number-col { width:5.1%; text-align:center; }
    .marks .total-col { width:5.5%; }
    .marks .avg-col { width:5.2%; }
    .marks .out20-col { width:5.2%; }
    .marks .identifier-col { width:5.4%; }
    .marks .out80-col { width:6.1%; }
    .marks .final-col { width:5.2%; }
    .marks .grade-col { width:5.2%; }
    .marks .comment-col { width:16%; }
    .marks .initials-col { width:7.1%; }
    .vertical { writing-mode:vertical-rl; transform:rotate(180deg); margin:auto; line-height:1; }
    .subject-cell { white-space:nowrap; }
    .subject-cell .code { display:inline-block; width:9mm; margin-right:1mm; border-right:1px solid #aaa; padding-right:.7mm; }
    .numeric { text-align:center; white-space:nowrap; }
    .comment { white-space:nowrap; }
    .grade { text-align:center; font-weight:bold; }
    .summary-row td { font-weight:bold; text-align:center; background:#fafafa; }
    .summary-row .summary-label { text-align:center; }
    .average-row td { font-size:6.3pt; }
    .identifier-note { display:flex; align-items:center; justify-content:center; gap:2mm; font-size:7.3pt; margin:2mm 0 3mm; }
    .identifier-note strong { border:1px solid #555; padding:1.2mm 2mm; }
    .commentary { font-size:7.3pt; line-height:1.45; margin-top:2mm; }
    .commentary-row { display:grid; grid-template-columns:1fr; margin-bottom:2mm; }
    .commentary-label { font-weight:normal; }
    .signature-area { margin-top:1mm; padding-right:30mm; position:relative; min-height:24mm; }
    .signature-row { display:grid; grid-template-columns:1fr 40mm; gap:3mm; align-items:end; min-height:10mm; }
    .signature-row .sig-line { white-space:nowrap; }
    .signature-row .line { border-bottom:1px dotted #555; display:inline-block; min-width:24mm; height:4mm; }
    .stamp { position:absolute; right:0; top:1mm; width:29mm; height:29mm; border:2px solid #737373; outline:1px solid #9a9a9a; outline-offset:-4px; border-radius:50%; display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; font-size:6.2pt; font-weight:bold; line-height:1.35; transform:rotate(-11deg); color:#555; opacity:.82; }
    .stamp .stamp-inner { border-top:1px solid #777; border-bottom:1px solid #777; padding:2mm 1mm; margin:1mm; }
    .date-fees { display:flex; flex-direction:column; gap:1.5mm; font-size:7.2pt; margin-top:2mm; }
    .fees-line { border-bottom:1px dotted #555; display:inline-block; min-width:50mm; height:3mm; }
    .grading-key { margin-top:5mm; font-size:6.5pt; }
    .grading-key th, .grading-key td { border:1px solid #666; padding:1mm 1.3mm; text-align:center; }
    .grading-key th { font-weight:bold; }
    .grading-key .left { text-align:left; }
    .grading-key .key-heading { text-align:left; background:#f5f5f5; font-weight:bold; }
    .footer-motto { text-align:center; font-size:7pt; margin:3mm 0 0; }
    @media (max-width:760px) {
        body { padding:0; background:#fff; }
        .paper { width:100%; min-height:0; padding:12px; box-shadow:none; overflow-x:auto; }
        .marks-wrap { overflow-x:auto; }
        .marks { min-width:700px; }
        .school-name { padding-right:0; }
        .school-name h1 { font-size:15px; }
        .school-name h2 { font-size:13px; }
    }
    @page { size:A4 portrait; margin:7mm; }
    @media print {
        body { padding:0; background:#fff; }
        .toolbar { display:none !important; }
        .paper { width:auto; max-width:none; min-height:0; margin:0; padding:2mm 1mm 0; box-shadow:none; }
        .marks th, .marks td { padding:.95mm .45mm; }
        .marks { font-size:6.2pt; }
        .marks thead th { height:20mm; font-size:5.9pt; }
        .commentary { font-size:7pt; }
        .grading-key { margin-top:4mm; }
        thead { display:table-header-group; }
        tr { page-break-inside:avoid; }
    }
</style>
</head>
<body>
<div class="toolbar no-print">
    <button type="button" onclick="window.print()"><span aria-hidden="true">&#128438;</span> Print / Save PDF</button>
    <button type="button" class="secondary" onclick="window.location.reload()">Reset View</button>
</div>

<main class="paper">
    <header class="school-header">
        <div class="crest" aria-label="School crest illustration">
            <svg viewBox="0 0 120 135" role="img" aria-label="St John's school crest">
                <path d="M15 18 L60 5 L105 18 L100 74 Q90 103 60 119 Q30 103 20 74 Z" fill="#26352d" stroke="#101710" stroke-width="3"/>
                <path d="M60 8 L60 113 M19 50 L101 50" stroke="#eee" stroke-width="2"/>
                <path d="M24 22 L56 14 L56 46 L24 46 Z" fill="#e8e8e8"/>
                <path d="M64 14 L96 22 L96 46 L64 46 Z" fill="#25334a"/>
                <path d="M24 55 L56 55 L56 102 Q35 91 26 72 Z" fill="#26334b"/>
                <path d="M64 55 L96 55 L94 72 Q82 91 64 102 Z" fill="#e5e5e5"/>
                <text x="40" y="38" font-size="17" text-anchor="middle" fill="#222" font-weight="bold">SJ</text>
                <text x="80" y="37" font-size="19" text-anchor="middle" fill="#fff" font-weight="bold">✝</text>
                <text x="40" y="77" font-size="10" text-anchor="middle" fill="#fff">A</text>
                <text x="80" y="77" font-size="10" text-anchor="middle" fill="#222">J</text>
                <path d="M7 104 Q28 117 60 122 Q92 117 113 104 L105 122 Q80 136 60 134 Q40 136 15 122 Z" fill="#202b24" stroke="#555" stroke-width="1"/>
                <text x="60" y="122" font-size="7" text-anchor="middle" fill="#fff">QUANTUM POSSUM</text>
            </svg>
        </div>
        <div class="school-name">
            <h1><?= reportE($student['school_name']) ?></h1>
            <h2><?= reportE($student['school_location']) ?></h2>
            <div class="school-contact">
                <div><?= reportE($student['motto']) ?></div>
                <div><?= reportE($student['postal_address']) ?></div>
                <div><?= reportE($student['email']) ?></div>
                <div><?= reportE($student['website']) ?></div>
            </div>
        </div>
    </header>

    <h3 class="report-title"><?= reportE($student['report_title']) ?></h3>
    <section class="student-details">
        <div class="line1">
            <div class="name">NAME: <span class="redacted-demo"><?= reportE($student['name']) ?></span></div>
            <div class="admission">ADMISSION NUMBER: <?= reportE($student['admission_number']) ?></div>
        </div>
        <div class="meta-row">
            <span>CLASS: <?= reportE($student['class']) ?></span>
            <span>TERM: <?= reportE($student['term']) ?></span>
            <span>YEAR: <?= reportE($student['year']) ?></span>
        </div>
        <div class="student-number">STUDENT NUMBER: <?= reportE($student['student_number']) ?></div>
    </section>

    <div class="marks-wrap">
        <table class="marks" aria-label="Student marks and grades">
            <colgroup>
                <col class="subject-col"><col class="number-col"><col class="number-col"><col class="total-col"><col class="avg-col"><col class="out20-col"><col class="identifier-col"><col class="out80-col"><col class="final-col"><col class="grade-col"><col class="comment-col"><col class="initials-col">
            </colgroup>
            <thead>
                <tr>
                    <th>SUBJECT / UNIT</th>
                    <th><div class="vertical">AOI 2</div></th>
                    <th><div class="vertical">AOI 1</div></th>
                    <th><div class="vertical">TOTAL SCORES</div></th>
                    <th><div class="vertical">AVG</div></th>
                    <th><div class="vertical">Out of 20</div></th>
                    <th><div class="vertical">Identifier</div></th>
                    <th><div class="vertical">Out of 80</div></th>
                    <th><div class="vertical">FINAL</div></th>
                    <th><div class="vertical">GRADE</div></th>
                    <th>COMMENT</th>
                    <th>INITIALS</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($subjects as $subject): ?>
                <tr>
                    <td class="subject-cell"><span class="code"><?= reportE($subject['code']) ?></span><?= reportE($subject['subject']) ?></td>
                    <td class="numeric"><?= reportE($subject['aoi2']) ?></td>
                    <td class="numeric"><?= reportE($subject['aoi1']) ?></td>
                    <td class="numeric"><?= reportE($subject['total']) ?></td>
                    <td class="numeric"><?= reportE($subject['avg']) ?></td>
                    <td class="numeric"><strong><?= reportE($subject['out20']) ?></strong></td>
                    <td class="numeric"><?= reportE($subject['identifier']) ?></td>
                    <td class="numeric"><strong><?= reportE($subject['out80']) ?></strong></td>
                    <td class="numeric"><strong><?= reportE($subject['final']) ?></strong></td>
                    <td class="grade"><?= reportE($subject['grade']) ?></td>
                    <td class="comment"><?= reportE($subject['comment']) ?></td>
                    <td class="numeric"><?= reportE($subject['initials']) ?></td>
                </tr>
            <?php endforeach; ?>
                <tr class="summary-row">
                    <td class="summary-label">TOTAL</td><td></td><td></td><td><?= reportE($totals['total_scores']) ?></td><td></td><td><?= reportE($totals['out20']) ?></td><td></td><td><?= reportE($totals['out80']) ?></td><td><?= reportE($totals['final']) ?></td><td colspan="3"></td>
                </tr>
                <tr class="summary-row average-row">
                    <td class="summary-label">AVERAGE</td><td></td><td></td><td><?= reportE($totals['avg_total_scores']) ?></td><td><?= reportE($totals['avg_avg']) ?></td><td><?= reportE($totals['avg_out20']) ?></td><td><?= reportE($totals['avg_identifier']) ?></td><td><?= reportE($totals['avg_out80']) ?></td><td><?= reportE($totals['avg_final']) ?></td><td colspan="3"></td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="identifier-note"><strong>Identifier <?= reportE($student['identifier']) ?></strong><strong><?= reportE($student['identifier_label']) ?></strong><span>Many learning outcomes achieved, enough for overall achievement.</span></div>

    <section class="commentary">
        <div class="commentary-row"><div><span class="commentary-label">Class Teacher's comment:</span> <?= reportE($student['class_teacher_comment']) ?></div></div>
        <div class="signature-area">
            <div class="signature-row"><div class="sig-line">SIGNATURE: <span class="line"></span></div><div></div></div>
            <div class="stamp"><div>ST. JOHN'S</div><div class="stamp-inner">P.O. BOX 15166<br>KAMPALA</div><div>MUDUUMA</div><div>QUANTUM POSSUM</div></div>
        </div>
        <div class="commentary-row"><div><span class="commentary-label">Headteacher's comment:</span> <?= reportE($student['headteacher_comment']) ?></div></div>
        <div class="signature-area" style="min-height:12mm">
            <div class="signature-row"><div class="sig-line">SIGNATURE / STAMP: <span class="line"></span></div><div></div></div>
        </div>
        <div class="date-fees">
            <div>Next Term: <strong>BEGIN ON:</strong> <?= reportE($student['next_term_begins']) ?></div>
            <div><strong>CLOSE ON:</strong> <?= reportE($student['term_closes']) ?></div>
            <div>Fees balance <span class="fees-line"><?= reportE($student['fees_balance']) ?></span></div>
        </div>
    </section>

    <table class="grading-key" aria-label="Grade ranges">
        <tr><th>Mark Range</th><th>100 - 85</th><th>84 - 70</th><th>69 - 60</th><th>59 - 50</th><th>49 - 0</th></tr>
        <tr><th>Grade</th><td>A</td><td>B</td><td>C</td><td>D</td><td>E</td></tr>
        <tr><th colspan="6" class="key-heading">Keywords used / Description of terms</th></tr>
        <tr><th>Identifier</th><th>Score Range</th><th colspan="4">Descriptor</th></tr>
        <tr><td>3.</td><td>2.50 - 3.00</td><td colspan="4" class="left"><strong>Outstanding</strong> — All Learning Outcomes achieved for overall achievement</td></tr>
        <tr><td>2.</td><td>1.50 - 2.49</td><td colspan="4" class="left"><strong>Moderate</strong> — Many Learning Outcomes achieved for overall achievement</td></tr>
        <tr><td>1.</td><td>0.90 - 1.49</td><td colspan="4" class="left"><strong>Basic</strong> — A few Learning Outcomes achieved</td></tr>
    </table>
    <p class="footer-motto">Invalid without school stamp<br><em>Quantum Possum.....To The best of my Ability</em></p>
</main>
</body>
</html>
