<?php
/**
 * Student Projects and Submissions Management
 * Install at /admin/classes/projects.php
 * Works with config/database.php ($conn) and includes/auth.php.
 * Save as UTF-8 without BOM; the opening PHP tag must be the first bytes.
 */
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator', 'teacher', 'subject_teacher', 'headteacher', 'head_teacher', 'student', 'pupil', 'learner']);

if (!isset($conn) || !($conn instanceof mysqli)) {
    http_response_code(500);
    exit('Database connection is unavailable. Please check config/database.php.');
}
$conn->set_charset('utf8mb4');
$userId = (int)($_SESSION['user_id'] ?? $_SESSION['id'] ?? ($_SESSION['user']['id'] ?? 0));

const PROJECT_MAX_UPLOAD_BYTES = 26214400; // 25 MB
const PROJECT_RESOURCE_DIR = 'uploads/student_projects';
const PROJECT_SUBMISSION_DIR = 'uploads/project_submissions';

function projects_e($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}
function projects_ident(string $name): string {
    return '`' . str_replace('`', '``', $name) . '`';
}
function projects_table_map(mysqli $db): array {
    $map = [];
    $result = $db->query('SHOW TABLES');
    while ($row = $result->fetch_row()) $map[strtolower((string)$row[0])] = (string)$row[0];
    $result->free();
    return $map;
}
function projects_columns(mysqli $db, string $table): array {
    $columns = [];
    $result = $db->query('SHOW COLUMNS FROM ' . projects_ident($table));
    while ($row = $result->fetch_assoc()) $columns[strtolower((string)$row['Field'])] = $row;
    $result->free();
    return $columns;
}
function projects_pick(array $columns, array $candidates): ?string {
    foreach ($candidates as $candidate) {
        $key = strtolower((string)$candidate);
        if (isset($columns[$key])) return (string)$columns[$key]['Field'];
    }
    return null;
}
function projects_names(mysqli $db, array $tableMap, array $tableCandidates, array $nameCandidates): array {
    $table = null;
    foreach ($tableCandidates as $candidate) {
        if (isset($tableMap[strtolower($candidate)])) { $table = $tableMap[strtolower($candidate)]; break; }
    }
    if (!$table) return [];
    try {
        $cols = projects_columns($db, $table);
        $name = projects_pick($cols, $nameCandidates);
        if (!$name) return [];
        $sql = 'SELECT DISTINCT TRIM(CAST(' . projects_ident($name) . ' AS CHAR)) AS item_name FROM ' . projects_ident($table) .
            ' WHERE ' . projects_ident($name) . ' IS NOT NULL AND TRIM(CAST(' . projects_ident($name) . ' AS CHAR)) <> \'\' ORDER BY item_name';
        $result = $db->query($sql);
        $values = [];
        while ($row = $result->fetch_assoc()) $values[] = trim((string)$row['item_name']);
        $result->free();
        return array_values(array_unique($values));
    } catch (Throwable $e) {
        error_log('Projects lookup error (' . $table . '): ' . $e->getMessage());
        return [];
    }
}
function projects_flash(string $type, string $message): void {
    $_SESSION['student_projects_flash'] = ['type' => $type, 'message' => $message];
}
function projects_redirect(string $query = ''): void {
    header('Location: projects.php' . $query);
    exit;
}
function projects_user_role(): string {
    $values = [$_SESSION['role'] ?? '', $_SESSION['user_role'] ?? '', $_SESSION['account_type'] ?? '', $_SESSION['user']['role'] ?? '', $_SESSION['user']['user_role'] ?? ''];
    foreach ($values as $value) if (is_string($value) && trim($value) !== '') return strtolower(trim($value));
    return '';
}
function projects_is_active_person($status): bool {
    if ($status === null || $status === '') return true;
    if (is_numeric($status)) return (int)$status !== 0;
    return !in_array(strtolower(trim((string)$status)), ['inactive', 'disabled', 'deleted', 'withdrawn', 'graduated', 'left', '0'], true);
}
function projects_make_code(mysqli $db): string {
    for ($i = 0; $i < 12; $i++) {
        $code = 'PRJ-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
        $stmt = $db->prepare('SELECT 1 FROM student_projects WHERE project_code = ? LIMIT 1');
        $stmt->bind_param('s', $code);
        $stmt->execute();
        $exists = (bool)$stmt->get_result()->fetch_row();
        $stmt->close();
        if (!$exists) return $code;
    }
    throw new RuntimeException('A unique project code could not be generated. Please try again.');
}
function projects_valid_date(string $date): bool {
    if ($date === '') return true;
    $parsed = DateTime::createFromFormat('!Y-m-d', $date);
    $errors = DateTime::getLastErrors();
    return $parsed !== false && $parsed->format('Y-m-d') === $date &&
        ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0));
}
function projects_safe_delete(string $relativePath, string $allowedPrefix): void {
    if ($relativePath === '' || strpos($relativePath, $allowedPrefix . '/') !== 0) return;
    $base = realpath(__DIR__ . '/../../' . $allowedPrefix);
    $file = realpath(__DIR__ . '/../../' . $relativePath);
    if ($base && $file && strpos($file, $base . DIRECTORY_SEPARATOR) === 0 && is_file($file)) @unlink($file);
}
function projects_upload(string $field, string $relativeDir): ?array {
    if (!isset($_FILES[$field]) || (int)($_FILES[$field]['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return null;
    $file = $_FILES[$field];
    if ((int)($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) throw new RuntimeException('The selected file could not be uploaded. Check the hosting upload limits and try again.');
    if ((int)($file['size'] ?? 0) < 1 || (int)$file['size'] > PROJECT_MAX_UPLOAD_BYTES) throw new RuntimeException('Please select a file smaller than 25 MB.');
    $original = basename(str_replace('\\', '/', (string)$file['name']));
    $extension = strtolower(pathinfo($original, PATHINFO_EXTENSION));
    $allowed = ['pdf','doc','docx','ppt','pptx','xls','xlsx','txt','rtf','odt','ods','odp','jpg','jpeg','png','gif','webp','zip'];
    if (!in_array($extension, $allowed, true)) throw new RuntimeException('Unsupported file type. Allowed files include PDF, Word, PowerPoint, Excel, text, images and ZIP files.');
    $absoluteDir = __DIR__ . '/../../' . $relativeDir;
    if (!is_dir($absoluteDir) && !mkdir($absoluteDir, 0755, true) && !is_dir($absoluteDir)) throw new RuntimeException('Could not create the upload directory. Create public_html/' . $relativeDir . ' and give PHP write permission.');
    // Prevent direct web access to uploaded files; downloads are delivered by this authenticated PHP page.
    $htaccess = $absoluteDir . DIRECTORY_SEPARATOR . '.htaccess';
    if (!is_file($htaccess)) {
        $rules = "Options -Indexes\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n";
        @file_put_contents($htaccess, $rules, LOCK_EX);
    }
    $savedName = bin2hex(random_bytes(18)) . '.' . $extension;
    $destination = $absoluteDir . DIRECTORY_SEPARATOR . $savedName;
    if (!move_uploaded_file((string)$file['tmp_name'], $destination)) throw new RuntimeException('Could not save the uploaded file. Check write permissions on public_html/' . $relativeDir . '.');
    $mime = 'application/octet-stream';
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) { $mime = (string)(finfo_file($finfo, $destination) ?: $mime); finfo_close($finfo); }
    }
    return ['name' => $original, 'path' => $relativeDir . '/' . $savedName, 'mime' => $mime, 'size' => (int)filesize($destination), 'absolute' => $destination];
}
function projects_download(string $relativePath, string $allowedPrefix, string $downloadName, string $mime): void {
    if ($relativePath === '' || strpos($relativePath, $allowedPrefix . '/') !== 0) throw new RuntimeException('The requested file path is invalid.');
    $base = realpath(__DIR__ . '/../../' . $allowedPrefix);
    $file = realpath(__DIR__ . '/../../' . $relativePath);
    if (!$base || !$file || strpos($file, $base . DIRECTORY_SEPARATOR) !== 0 || !is_file($file)) throw new RuntimeException('The requested file could not be found on the server.');
    $name = basename(str_replace(["\r", "\n", '"'], '', $downloadName !== '' ? $downloadName : basename($file)));
    while (ob_get_level() > 0) { if (!@ob_end_clean()) break; }
    header('X-Content-Type-Options: nosniff');
    header('Content-Type: ' . ($mime !== '' ? $mime : 'application/octet-stream'));
    header('Content-Length: ' . (string)filesize($file));
    header('Content-Disposition: attachment; filename="' . $name . '"; filename*=UTF-8\'\'' . rawurlencode($name));
    readfile($file);
    exit;
}

if (empty($_SESSION['student_projects_csrf'])) $_SESSION['student_projects_csrf'] = bin2hex(random_bytes(32));
$csrfToken = (string)$_SESSION['student_projects_csrf'];
$flash = $_SESSION['student_projects_flash'] ?? null;
unset($_SESSION['student_projects_flash']);
$isStudent = in_array(projects_user_role(), ['student', 'pupil', 'learner'], true);
$isManager = !$isStudent;
$schemaError = '';
$pageError = '';
$createdTables = [];
$projectRows = [];
$studentRoster = [];
$classOptions = [];
$subjectOptions = [];
$submissionsByStudent = [];
$viewSubmissions = [];
$selectedProject = null;
$currentStudent = null;
$studentClass = '';
$studentId = 0;
$studentColumns = [];
$studentClassById = [];
$projectStatusOptions = ['draft', 'published', 'closed', 'archived'];
$search = trim((string)($_GET['q'] ?? ''));
$filterClass = trim((string)($_GET['class'] ?? ''));
$filterSubject = trim((string)($_GET['subject'] ?? ''));
$filterStatus = trim((string)($_GET['status'] ?? ''));
$filterYear = trim((string)($_GET['year'] ?? ''));
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 15;
$totalPages = 1;
$projectUploadDir = __DIR__ . '/../../' . PROJECT_RESOURCE_DIR;
$submissionUploadDir = __DIR__ . '/../../' . PROJECT_SUBMISSION_DIR;

try {
    $tables = projects_table_map($conn);
    if (!isset($tables['student_projects'])) {
        $conn->query("CREATE TABLE student_projects (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            project_code VARCHAR(40) NOT NULL,
            title VARCHAR(200) NOT NULL,
            subject_name VARCHAR(150) NOT NULL,
            class_name VARCHAR(100) NOT NULL,
            academic_year VARCHAR(20) DEFAULT NULL,
            term VARCHAR(30) DEFAULT NULL,
            description TEXT DEFAULT NULL,
            instructions LONGTEXT DEFAULT NULL,
            due_date DATE DEFAULT NULL,
            max_marks DECIMAL(8,2) NOT NULL DEFAULT 100.00,
            resource_name VARCHAR(255) DEFAULT NULL,
            resource_path VARCHAR(500) DEFAULT NULL,
            resource_mime VARCHAR(150) DEFAULT NULL,
            resource_size BIGINT UNSIGNED DEFAULT NULL,
            status ENUM('draft','published','closed','archived') NOT NULL DEFAULT 'draft',
            created_by INT DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id), UNIQUE KEY uq_student_projects_code (project_code),
            KEY idx_student_projects_class (class_name), KEY idx_student_projects_subject (subject_name),
            KEY idx_student_projects_status_due (status,due_date), KEY idx_student_projects_year_term (academic_year,term)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $createdTables[] = 'student_projects';
    }
    if (!isset($tables['student_project_submissions'])) {
        $conn->query("CREATE TABLE student_project_submissions (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            project_id INT UNSIGNED NOT NULL,
            student_id INT DEFAULT NULL,
            student_name VARCHAR(180) NOT NULL,
            admission_no VARCHAR(80) DEFAULT NULL,
            submission_text LONGTEXT DEFAULT NULL,
            file_name VARCHAR(255) DEFAULT NULL,
            file_path VARCHAR(500) DEFAULT NULL,
            file_mime VARCHAR(150) DEFAULT NULL,
            file_size BIGINT UNSIGNED DEFAULT NULL,
            status ENUM('submitted','late','reviewed','returned','missing') NOT NULL DEFAULT 'submitted',
            marks DECIMAL(8,2) DEFAULT NULL,
            feedback TEXT DEFAULT NULL,
            submitted_at DATETIME DEFAULT NULL,
            reviewed_by INT DEFAULT NULL,
            reviewed_at DATETIME DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id), UNIQUE KEY uq_project_student (project_id,student_id),
            KEY idx_project_submissions_project (project_id), KEY idx_project_submissions_student (student_id),
            KEY idx_project_submissions_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $createdTables[] = 'student_project_submissions';
    }

    $projectColumns = projects_columns($conn, 'student_projects');
    $submissionColumns = projects_columns($conn, 'student_project_submissions');
    foreach (['id','project_code','title','subject_name','class_name','academic_year','term','description','instructions','due_date','max_marks','resource_name','resource_path','resource_mime','resource_size','status','created_by','created_at','updated_at'] as $required) {
        if (!isset($projectColumns[$required])) throw new RuntimeException('The student_projects table is missing the required column `' . $required . '`. Please share its Structure tab so the page can be matched to your database.');
    }
    foreach (['id','project_id','student_id','student_name','admission_no','submission_text','file_name','file_path','file_mime','file_size','status','marks','feedback','submitted_at','reviewed_by','reviewed_at','created_at','updated_at'] as $required) {
        if (!isset($submissionColumns[$required])) throw new RuntimeException('The student_project_submissions table is missing the required column `' . $required . '`. Please share its Structure tab so the page can be matched to your database.');
    }

    $subjectOptions = projects_names($conn, $tables, ['subjects','school_subjects','academic_subjects','subject'], ['subject_name','name','title','subject','subject_title']);
    if (!$subjectOptions) $subjectOptions = ['English Language','Mathematics','Biology','Chemistry','Physics','History','Geography','Computer Studies','Kiswahili','Literature','Agriculture','Entrepreneurship'];

    // Resolve class names from the school's class table, then supplement from the student roster.
    $classTable = null;
    foreach (['classes','school_classes','class_levels','classrooms','streams','class'] as $candidate) {
        if (isset($tables[$candidate])) { $classTable = $tables[$candidate]; break; }
    }
    $classIdToName = [];
    if ($classTable) {
        try {
            $cc = projects_columns($conn, $classTable);
            $cid = projects_pick($cc, ['id','class_id','stream_id','classroom_id']);
            $cn = projects_pick($cc, ['class_name','class_level','name','title','stream_name','classroom_name']);
            if ($cid && $cn) {
                $cr = $conn->query('SELECT ' . projects_ident($cid) . ' AS cid, ' . projects_ident($cn) . ' AS cname FROM ' . projects_ident($classTable) . ' ORDER BY ' . projects_ident($cn));
                while ($crow = $cr->fetch_assoc()) {
                    $cidVal = (string)$crow['cid']; $cnameVal = trim((string)$crow['cname']);
                    if ($cnameVal !== '') { $classIdToName[$cidVal] = $cnameVal; $classOptions[] = $cnameVal; }
                }
                $cr->free();
            }
        } catch (Throwable $e) { error_log('Projects class lookup error: ' . $e->getMessage()); }
    }

    if (isset($tables['students'])) {
        $studentColumns = projects_columns($conn, $tables['students']);
        $sidCol = projects_pick($studentColumns, ['id','student_id']);
        $firstCol = projects_pick($studentColumns, ['first_name','given_name','firstname']);
        $lastCol = projects_pick($studentColumns, ['last_name','surname','family_name','lastname']);
        $otherCol = projects_pick($studentColumns, ['other_names','middle_name','other_name']);
        $fullCol = projects_pick($studentColumns, ['full_name','student_name','name']);
        $admissionCol = projects_pick($studentColumns, ['admission_no','admission_number','student_no','registration_no','student_number']);
        $classNameCol = projects_pick($studentColumns, ['class_name','class_level','current_class','stream_name','classroom_name','class','grade']);
        $classIdCol = projects_pick($studentColumns, ['class_id','stream_id','classroom_id']);
        $studentUserCol = projects_pick($studentColumns, ['user_id','login_user_id','account_id','user_account_id']);
        $studentStatusCol = projects_pick($studentColumns, ['status','student_status','is_active']);
        $studentLinCol = projects_pick($studentColumns, ['lin_no']);
        $studentPaymentCodeCol = projects_pick($studentColumns, ['student_payment_code']);
        $studentSectionCol = projects_pick($studentColumns, ['student_section']);
        if ($sidCol) {
            $sr = $conn->query('SELECT * FROM ' . projects_ident($tables['students']) . ' ORDER BY ' . projects_ident($sidCol) . ' ASC');
            while ($raw = $sr->fetch_assoc()) {
                $sid = (int)($raw[$sidCol] ?? 0);
                if ($sid < 1) continue;
                if ($studentStatusCol && !projects_is_active_person($raw[$studentStatusCol] ?? null)) continue;
                $name = $fullCol ? trim((string)($raw[$fullCol] ?? '')) : '';
                if ($name === '') $name = trim(implode(' ', array_filter([
                    $firstCol ? trim((string)($raw[$firstCol] ?? '')) : '',
                    $otherCol ? trim((string)($raw[$otherCol] ?? '')) : '',
                    $lastCol ? trim((string)($raw[$lastCol] ?? '')) : ''
                ])));
                if ($name === '') $name = 'Student #' . $sid;
                $className = $classNameCol ? trim((string)($raw[$classNameCol] ?? '')) : '';
                if ($className === '' && $classIdCol) $className = (string)($classIdToName[(string)($raw[$classIdCol] ?? '')] ?? '');
                $admission = $admissionCol ? trim((string)($raw[$admissionCol] ?? '')) : '';
                $linNo = $studentLinCol ? trim((string)($raw[$studentLinCol] ?? '')) : '';
                $studentPaymentCode = $studentPaymentCodeCol ? trim((string)($raw[$studentPaymentCodeCol] ?? '')) : '';
                $studentSection = $studentSectionCol ? trim((string)($raw[$studentSectionCol] ?? 'Day')) : 'Day';
                if (!in_array($studentSection, ['Day','Boarding'], true)) $studentSection = 'Day';
                $studentRoster[] = ['id'=>$sid,'name'=>$name,'admission_no'=>$admission,'lin_no'=>$linNo,'student_payment_code'=>$studentPaymentCode,'student_section'=>$studentSection,'class_name'=>$className,'raw'=>$raw,'user_id'=>$studentUserCol ? (int)($raw[$studentUserCol] ?? 0) : 0];
                if ($className !== '') $classOptions[] = $className;
            }
            $sr->free();
        }
    }
    $classOptions = array_values(array_unique(array_filter(array_map('trim', $classOptions), static fn($v) => $v !== '')));
    natcasesort($classOptions); $classOptions = array_values($classOptions);

    // A student login is associated with a student by session student_id or by a user_id link.
    if ($isStudent) {
        $sessionStudentId = (int)($_SESSION['student_id'] ?? $_SESSION['student']['id'] ?? $_SESSION['student']['student_id'] ?? 0);
        if ($sessionStudentId > 0) {
            foreach ($studentRoster as $s) if ((int)$s['id'] === $sessionStudentId) { $currentStudent = $s; break; }
        }
        if (!$currentStudent && $userId > 0) {
            foreach ($studentRoster as $s) if ((int)$s['user_id'] === $userId) { $currentStudent = $s; break; }
        }
        if (!$currentStudent && $userId > 0) {
            foreach ($studentRoster as $s) if ((int)$s['id'] === $userId) { $currentStudent = $s; break; }
        }
        if ($currentStudent) {
            $studentId = (int)$currentStudent['id'];
            $studentClass = (string)$currentStudent['class_name'];
        } else {
            $pageError = 'Your student account could not be matched to a record in the students table. Ask the school administrator to link your login to your student record.';
        }
    }

} catch (Throwable $e) {
    error_log('projects.php setup error: ' . $e->getMessage());
    $schemaError = $e instanceof RuntimeException ? $e->getMessage() : 'The projects page could not read the database. Check the PHP error log and database permissions.';
}

// Authenticated downloads: files are only served through this script.
if ($schemaError === '' && isset($_GET['download_project'])) {
    try {
        $id = max(0, (int)$_GET['download_project']);
        $stmt = $conn->prepare('SELECT * FROM student_projects WHERE id = ? LIMIT 1');
        $stmt->bind_param('i', $id); $stmt->execute(); $project = $stmt->get_result()->fetch_assoc(); $stmt->close();
        if (!$project || trim((string)$project['resource_path']) === '') throw new RuntimeException('The project resource was not found.');
        if ($isStudent && (!in_array(strtolower((string)$project['status']), ['published','closed'], true) || strcasecmp(trim((string)$project['class_name']), trim($studentClass)) !== 0)) throw new RuntimeException('You are not allowed to download this project resource.');
        projects_download((string)$project['resource_path'], PROJECT_RESOURCE_DIR, (string)$project['resource_name'], (string)$project['resource_mime']);
    } catch (Throwable $e) {
        projects_flash('danger', $e instanceof RuntimeException ? $e->getMessage() : 'The project resource could not be downloaded.');
        projects_redirect();
    }
}
if ($schemaError === '' && isset($_GET['download_submission'])) {
    try {
        $id = max(0, (int)$_GET['download_submission']);
        $stmt = $conn->prepare('SELECT s.*, p.class_name, p.status AS project_status FROM student_project_submissions s INNER JOIN student_projects p ON p.id=s.project_id WHERE s.id = ? LIMIT 1');
        $stmt->bind_param('i', $id); $stmt->execute(); $submission = $stmt->get_result()->fetch_assoc(); $stmt->close();
        if (!$submission || trim((string)$submission['file_path']) === '') throw new RuntimeException('The submitted file was not found.');
        if ($isStudent && ((int)$submission['student_id'] !== $studentId || strcasecmp(trim((string)$submission['class_name']), trim($studentClass)) !== 0)) throw new RuntimeException('You are not allowed to download this submission.');
        projects_download((string)$submission['file_path'], PROJECT_SUBMISSION_DIR, (string)$submission['file_name'], (string)$submission['file_mime']);
    } catch (Throwable $e) {
        projects_flash('danger', $e instanceof RuntimeException ? $e->getMessage() : 'The submitted file could not be downloaded.');
        projects_redirect();
    }
}

// POST actions.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $schemaError === '') {
    $newUpload = null;
    $oldPathToDelete = '';
    $oldPathPrefix = '';
    try {
        $postedToken = (string)($_POST['csrf_token'] ?? '');
        if (!hash_equals($csrfToken, $postedToken)) throw new RuntimeException('Your form session expired. Refresh the page and try again.');
        $action = trim((string)($_POST['action'] ?? ''));

        if ($action === 'save_project') {
            if (!$isManager) throw new RuntimeException('Only teachers and authorized school staff can create or edit projects.');
            $id = max(0, (int)($_POST['project_id'] ?? 0));
            $title = trim((string)($_POST['title'] ?? ''));
            $subject = trim((string)($_POST['subject_name'] ?? ''));
            $className = trim((string)($_POST['class_name'] ?? ''));
            $year = trim((string)($_POST['academic_year'] ?? date('Y')));
            $term = trim((string)($_POST['term'] ?? ''));
            $description = trim((string)($_POST['description'] ?? ''));
            $instructions = trim((string)($_POST['instructions'] ?? ''));
            $dueDate = trim((string)($_POST['due_date'] ?? ''));
            $maxMarksText = trim((string)($_POST['max_marks'] ?? '100'));
            $status = trim((string)($_POST['status'] ?? 'draft'));
            if ($title === '' || mb_strlen($title) > 200) throw new RuntimeException('Enter a project title of no more than 200 characters.');
            if ($subject === '' || mb_strlen($subject) > 150) throw new RuntimeException('Enter a valid subject name.');
            if ($className === '' || mb_strlen($className) > 100) throw new RuntimeException('Select or enter the class this project is assigned to.');
            if ($year !== '' && mb_strlen($year) > 20) throw new RuntimeException('The academic year cannot exceed 20 characters.');
            if ($term !== '' && mb_strlen($term) > 30) throw new RuntimeException('The term cannot exceed 30 characters.');
            if (!projects_valid_date($dueDate)) throw new RuntimeException('Choose a valid project deadline.');
            if ($maxMarksText === '' || !is_numeric($maxMarksText) || !is_finite((float)$maxMarksText) || (float)$maxMarksText <= 0 || (float)$maxMarksText > 100000) throw new RuntimeException('Maximum marks must be greater than zero and no more than 100,000.');
            if (!in_array($status, $projectStatusOptions, true)) throw new RuntimeException('Select a valid project status.');

            $old = null;
            if ($id > 0) {
                $stmt = $conn->prepare('SELECT * FROM student_projects WHERE id=? LIMIT 1'); $stmt->bind_param('i', $id); $stmt->execute(); $old = $stmt->get_result()->fetch_assoc(); $stmt->close();
                if (!$old) throw new RuntimeException('The project to edit was not found. Refresh and try again.');
            }
            $newUpload = projects_upload('resource_file', PROJECT_RESOURCE_DIR);
            $resourceName = $newUpload['name'] ?? (string)($old['resource_name'] ?? '');
            $resourcePath = $newUpload['path'] ?? (string)($old['resource_path'] ?? '');
            $resourceMime = $newUpload['mime'] ?? (string)($old['resource_mime'] ?? '');
            $resourceSize = $newUpload['size'] ?? (isset($old['resource_size']) ? (int)$old['resource_size'] : null);
            $year = $year !== '' ? $year : null;
            $term = $term !== '' ? $term : null;
            $description = $description !== '' ? $description : null;
            $instructions = $instructions !== '' ? $instructions : null;
            $dueDate = $dueDate !== '' ? $dueDate : null;
            $resourceName = $resourceName !== '' ? $resourceName : null;
            $resourcePath = $resourcePath !== '' ? $resourcePath : null;
            $resourceMime = $resourceMime !== '' ? $resourceMime : null;
            $maxMarks = round((float)$maxMarksText, 2);
            if ($id > 0) {
                $stmt = $conn->prepare('UPDATE student_projects SET title=?, subject_name=?, class_name=?, academic_year=?, term=?, description=?, instructions=?, due_date=?, max_marks=?, resource_name=?, resource_path=?, resource_mime=?, resource_size=?, status=?, updated_at=NOW() WHERE id=?');
                $stmt->bind_param('ssssssssdsssisi', $title, $subject, $className, $year, $term, $description, $instructions, $dueDate, $maxMarks, $resourceName, $resourcePath, $resourceMime, $resourceSize, $status, $id);
                $stmt->execute(); $stmt->close();
                if ($newUpload && !empty($old['resource_path'])) projects_safe_delete((string)$old['resource_path'], PROJECT_RESOURCE_DIR);
                $message = 'Project updated successfully.';
            } else {
                $code = projects_make_code($conn);
                $stmt = $conn->prepare('INSERT INTO student_projects (project_code,title,subject_name,class_name,academic_year,term,description,instructions,due_date,max_marks,resource_name,resource_path,resource_mime,resource_size,status,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
                $stmt->bind_param('sssssssssdsssisi', $code, $title, $subject, $className, $year, $term, $description, $instructions, $dueDate, $maxMarks, $resourceName, $resourcePath, $resourceMime, $resourceSize, $status, $userId);
                $stmt->execute(); $stmt->close();
                $message = 'Project created successfully. Project code: ' . $code . '.';
            }
            projects_flash('success', $message);
            projects_redirect($id > 0 ? '?view=' . $id : '');
        }

        if ($action === 'submit_work') {
            $projectId = max(0, (int)($_POST['project_id'] ?? 0));
            $stmt = $conn->prepare('SELECT * FROM student_projects WHERE id=? LIMIT 1'); $stmt->bind_param('i', $projectId); $stmt->execute(); $project = $stmt->get_result()->fetch_assoc(); $stmt->close();
            if (!$project) throw new RuntimeException('The selected project could not be found.');
            if ($isStudent) {
                if (!$currentStudent || $studentId < 1) throw new RuntimeException('Your student login is not linked to a student record. Ask the school administrator for help.');
                if (strtolower((string)$project['status']) !== 'published') throw new RuntimeException('This project is not currently open for student submissions.');
                if (strcasecmp(trim((string)$project['class_name']), trim($studentClass)) !== 0) throw new RuntimeException('This project is not assigned to your class.');
                $selectedStudentId = $studentId;
                $studentName = (string)$currentStudent['name'];
                $admissionNo = (string)$currentStudent['admission_no'];
            } else {
                $selectedStudentId = max(0, (int)($_POST['student_id'] ?? 0));
                $studentName = trim((string)($_POST['student_name'] ?? ''));
                $admissionNo = trim((string)($_POST['admission_no'] ?? ''));
                if (strtolower((string)$project['status']) === 'archived') throw new RuntimeException('An archived project cannot receive new submissions.');
                if ($selectedStudentId > 0) {
                    $matched = null;
                    foreach ($studentRoster as $s) if ((int)$s['id'] === $selectedStudentId) { $matched = $s; break; }
                    if (!$matched) throw new RuntimeException('Select a valid registered student.');
                    if ($matched['class_name'] !== '' && strcasecmp(trim($matched['class_name']), trim((string)$project['class_name'])) !== 0) throw new RuntimeException('The selected student is not in the class assigned to this project.');
                    $studentName = $matched['name']; $admissionNo = $matched['admission_no'];
                }
                if ($studentName === '') throw new RuntimeException('Select a student or enter the student name.');
                if (mb_strlen($studentName) > 180 || mb_strlen($admissionNo) > 80) throw new RuntimeException('The student name or admission number is too long.');
            }
            $submissionText = trim((string)($_POST['submission_text'] ?? ''));
            $newUpload = projects_upload('submission_file', PROJECT_SUBMISSION_DIR);
            if ($submissionText === '' && !$newUpload) {
                $existingStmt = $conn->prepare('SELECT id,file_path FROM student_project_submissions WHERE project_id=? AND student_id <=> ? LIMIT 1');
                $existingStudentId = $selectedStudentId > 0 ? $selectedStudentId : null;
                $existingStmt->bind_param('ii', $projectId, $existingStudentId);
                $existingStmt->execute(); $existingOld = $existingStmt->get_result()->fetch_assoc(); $existingStmt->close();
                if (!$existingOld || empty($existingOld['file_path'])) throw new RuntimeException('Enter a submission message or attach the student’s project file.');
            }
            // Preserve any existing attachment if the student resubmits text only.
            $existingStmt = $conn->prepare('SELECT * FROM student_project_submissions WHERE project_id=? AND student_id <=> ? LIMIT 1');
            $lookupStudentId = $selectedStudentId > 0 ? $selectedStudentId : null;
            $existingStmt->bind_param('ii', $projectId, $lookupStudentId);
            $existingStmt->execute(); $existingSubmission = $existingStmt->get_result()->fetch_assoc(); $existingStmt->close();
            $fileName = $newUpload['name'] ?? (string)($existingSubmission['file_name'] ?? '');
            $filePath = $newUpload['path'] ?? (string)($existingSubmission['file_path'] ?? '');
            $fileMime = $newUpload['mime'] ?? (string)($existingSubmission['file_mime'] ?? '');
            $fileSize = $newUpload['size'] ?? (isset($existingSubmission['file_size']) ? (int)$existingSubmission['file_size'] : null);
            $now = date('Y-m-d H:i:s');
            $isLate = !empty($project['due_date']) && date('Y-m-d') > (string)$project['due_date'];
            $submissionStatus = $isLate ? 'late' : 'submitted';
            if ($lookupStudentId === null && $existingSubmission) {
                // NULL values do not collide under a MySQL UNIQUE key, so update an existing manual record by ID.
                $manualSubmissionId = (int)$existingSubmission['id'];
                $stmt = $conn->prepare('UPDATE student_project_submissions SET student_name=?, admission_no=?, submission_text=?, file_name=?, file_path=?, file_mime=?, file_size=?, status=?, submitted_at=?, marks=NULL, feedback=NULL, reviewed_by=NULL, reviewed_at=NULL, updated_at=NOW() WHERE id=?');
                $stmt->bind_param('ssssssissi', $studentName, $admissionNo, $submissionText, $fileName, $filePath, $fileMime, $fileSize, $submissionStatus, $now, $manualSubmissionId);
                $stmt->execute(); $stmt->close();
            } else {
                $stmt = $conn->prepare("INSERT INTO student_project_submissions (project_id,student_id,student_name,admission_no,submission_text,file_name,file_path,file_mime,file_size,status,submitted_at) VALUES (?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE student_name=VALUES(student_name), admission_no=VALUES(admission_no), submission_text=VALUES(submission_text), file_name=VALUES(file_name), file_path=VALUES(file_path), file_mime=VALUES(file_mime), file_size=VALUES(file_size), status=VALUES(status), submitted_at=VALUES(submitted_at), marks=NULL, feedback=NULL, reviewed_by=NULL, reviewed_at=NULL, updated_at=NOW()");
                $stmt->bind_param('iissssssiss', $projectId, $lookupStudentId, $studentName, $admissionNo, $submissionText, $fileName, $filePath, $fileMime, $fileSize, $submissionStatus, $now);
                $stmt->execute(); $stmt->close();
            }
            if ($newUpload && !empty($existingSubmission['file_path'])) projects_safe_delete((string)$existingSubmission['file_path'], PROJECT_SUBMISSION_DIR);
            projects_flash('success', 'Project submission saved for ' . $studentName . '. Status: ' . ucfirst($submissionStatus) . '.');
            projects_redirect('?view=' . $projectId);
        }

        if ($action === 'review_submission') {
            if (!$isManager) throw new RuntimeException('Only authorized school staff can review project submissions.');
            $submissionId = max(0, (int)($_POST['submission_id'] ?? 0));
            $marksInput = trim((string)($_POST['marks'] ?? ''));
            $feedback = trim((string)($_POST['feedback'] ?? ''));
            $reviewStatus = trim((string)($_POST['review_status'] ?? 'reviewed'));
            if (!in_array($reviewStatus, ['reviewed','returned','missing'], true)) throw new RuntimeException('Select a valid review status.');
            $stmt = $conn->prepare('SELECT s.*, p.max_marks FROM student_project_submissions s INNER JOIN student_projects p ON p.id=s.project_id WHERE s.id=? LIMIT 1');
            $stmt->bind_param('i', $submissionId); $stmt->execute(); $sub = $stmt->get_result()->fetch_assoc(); $stmt->close();
            if (!$sub) throw new RuntimeException('Submission not found.');
            if ($marksInput !== '' && (!is_numeric($marksInput) || !is_finite((float)$marksInput) || (float)$marksInput < 0 || (float)$marksInput > (float)$sub['max_marks'])) throw new RuntimeException('Marks must be between 0 and ' . number_format((float)$sub['max_marks'], 2) . '.');
            $marks = $marksInput === '' ? null : round((float)$marksInput, 2);
            $reviewedAt = date('Y-m-d H:i:s');
            $reviewerId = $userId > 0 ? $userId : null;
            $stmt = $conn->prepare('UPDATE student_project_submissions SET marks=?, feedback=?, status=?, reviewed_by=?, reviewed_at=?, updated_at=NOW() WHERE id=?');
            $stmt->bind_param('dssisi', $marks, $feedback, $reviewStatus, $reviewerId, $reviewedAt, $submissionId);
            $stmt->execute(); $stmt->close();
            projects_flash('success', 'Submission review saved.');
            projects_redirect('?view=' . (int)$sub['project_id']);
        }

        if ($action === 'change_project_status') {
            if (!$isManager) throw new RuntimeException('Only authorized school staff can change project status.');
            $id = max(0, (int)($_POST['project_id'] ?? 0));
            $status = trim((string)($_POST['new_status'] ?? ''));
            if ($id < 1 || !in_array($status, $projectStatusOptions, true)) throw new RuntimeException('Select a valid project and status.');
            $stmt = $conn->prepare('UPDATE student_projects SET status=?, updated_at=NOW() WHERE id=?'); $stmt->bind_param('si', $status, $id); $stmt->execute(); $stmt->close();
            projects_flash('success', 'Project status changed to ' . ucfirst($status) . '.');
            projects_redirect('?view=' . $id);
        }

        if ($action === 'delete_project') {
            if (!$isManager) throw new RuntimeException('Only authorized school staff can delete projects.');
            $id = max(0, (int)($_POST['project_id'] ?? 0));
            $stmt = $conn->prepare('SELECT * FROM student_projects WHERE id=? LIMIT 1'); $stmt->bind_param('i', $id); $stmt->execute(); $project = $stmt->get_result()->fetch_assoc(); $stmt->close();
            if (!$project) throw new RuntimeException('Project not found.');
            $paths = [];
            $stmt = $conn->prepare('SELECT file_path FROM student_project_submissions WHERE project_id=?'); $stmt->bind_param('i', $id); $stmt->execute(); $rs = $stmt->get_result(); while ($r = $rs->fetch_assoc()) if (!empty($r['file_path'])) $paths[] = (string)$r['file_path']; $stmt->close();
            $conn->begin_transaction();
            try {
                $stmt = $conn->prepare('DELETE FROM student_project_submissions WHERE project_id=?'); $stmt->bind_param('i', $id); $stmt->execute(); $stmt->close();
                $stmt = $conn->prepare('DELETE FROM student_projects WHERE id=?'); $stmt->bind_param('i', $id); $stmt->execute(); $stmt->close();
                $conn->commit();
            } catch (Throwable $e) { $conn->rollback(); throw $e; }
            if (!empty($project['resource_path'])) projects_safe_delete((string)$project['resource_path'], PROJECT_RESOURCE_DIR);
            foreach ($paths as $path) projects_safe_delete($path, PROJECT_SUBMISSION_DIR);
            projects_flash('success', 'Project and its submissions were deleted.');
            projects_redirect();
        }

        throw new RuntimeException('Invalid form action. Refresh the page and try again.');
    } catch (Throwable $e) {
        if (is_array($newUpload) && !empty($newUpload['absolute']) && is_file($newUpload['absolute'])) @unlink($newUpload['absolute']);
        error_log('projects.php action error: ' . $e->getMessage());
        projects_flash('danger', $e instanceof RuntimeException ? $e->getMessage() : 'The requested action could not be completed. Check the hosting PHP error log.');
        $returnProjectId = max(0, (int)($_POST['project_id'] ?? 0));
        projects_redirect($returnProjectId > 0 ? '?view=' . $returnProjectId : '');
    }
}

$flash = $_SESSION['student_projects_flash'] ?? $flash;
unset($_SESSION['student_projects_flash']);

// Read projects and submission totals.
if ($schemaError === '') {
    try {
        $sql = 'SELECT p.*, (SELECT COUNT(*) FROM student_project_submissions ss WHERE ss.project_id=p.id AND ss.status <> \'missing\') AS submission_count, (SELECT COUNT(*) FROM student_project_submissions ss WHERE ss.project_id=p.id AND ss.status IN (\'reviewed\',\'returned\')) AS reviewed_count FROM student_projects p WHERE 1=1';
        $params = []; $types = '';
        if ($isStudent) {
            $sql .= " AND p.status IN ('published','closed') AND p.class_name = ?";
            $params[] = $studentClass; $types .= 's';
        } else {
            if ($search !== '') {
                $sql .= ' AND (p.title LIKE ? OR p.project_code LIKE ? OR p.subject_name LIKE ? OR p.class_name LIKE ? OR p.description LIKE ?)';
                $like = '%' . $search . '%';
                for ($i=0; $i<5; $i++) { $params[] = $like; $types .= 's'; }
            }
            if ($filterClass !== '') { $sql .= ' AND p.class_name = ?'; $params[] = $filterClass; $types .= 's'; }
            if ($filterSubject !== '') { $sql .= ' AND p.subject_name = ?'; $params[] = $filterSubject; $types .= 's'; }
            if ($filterStatus !== '' && in_array($filterStatus, $projectStatusOptions, true)) { $sql .= ' AND p.status = ?'; $params[] = $filterStatus; $types .= 's'; }
            if ($filterYear !== '') { $sql .= ' AND p.academic_year = ?'; $params[] = $filterYear; $types .= 's'; }
        }
        $sql .= ' ORDER BY p.created_at DESC, p.id DESC';
        $stmt = $conn->prepare($sql);
        if ($types !== '') { $bind = [$types]; foreach ($params as $k => &$val) $bind[] = &$val; call_user_func_array([$stmt,'bind_param'], $bind); }
        $stmt->execute(); $rs = $stmt->get_result(); while ($row = $rs->fetch_assoc()) $projectRows[] = $row; $stmt->close();
    } catch (Throwable $e) {
        $pageError = 'Projects could not be loaded. Please check the student_projects and student_project_submissions tables.';
        error_log('projects.php list error: ' . $e->getMessage());
    }
}

$editProject = null;
$editId = max(0, (int)($_GET['edit'] ?? 0));
if ($isManager && $editId > 0 && $schemaError === '') {
    $stmt = $conn->prepare('SELECT * FROM student_projects WHERE id=? LIMIT 1'); $stmt->bind_param('i', $editId); $stmt->execute(); $editProject = $stmt->get_result()->fetch_assoc(); $stmt->close();
}
$viewId = max(0, (int)($_GET['view'] ?? 0));
if ($viewId > 0 && $schemaError === '') {
    $stmt = $conn->prepare('SELECT p.*, (SELECT COUNT(*) FROM student_project_submissions ss WHERE ss.project_id=p.id AND ss.status <> \'missing\') AS submission_count, (SELECT COUNT(*) FROM student_project_submissions ss WHERE ss.project_id=p.id AND ss.status IN (\'reviewed\',\'returned\')) AS reviewed_count FROM student_projects p WHERE p.id=? LIMIT 1');
    $stmt->bind_param('i', $viewId); $stmt->execute(); $selectedProject = $stmt->get_result()->fetch_assoc(); $stmt->close();
    if ($selectedProject && $isStudent && (strcasecmp(trim((string)$selectedProject['class_name']), trim($studentClass)) !== 0 || !in_array((string)$selectedProject['status'], ['published','closed'], true))) $selectedProject = null;
    if ($selectedProject && !$isStudent) {
        $stmt = $conn->prepare('SELECT * FROM student_project_submissions WHERE project_id=? ORDER BY submitted_at DESC, id DESC'); $stmt->bind_param('i', $viewId); $stmt->execute(); $rs = $stmt->get_result(); while ($row = $rs->fetch_assoc()) $viewSubmissions[] = $row; $stmt->close();
        foreach ($viewSubmissions as $submission) if ((int)($submission['student_id'] ?? 0) > 0) $submissionsByStudent[(int)$submission['student_id']] = $submission;
    }
}

// Compute class/year options and page totals after reading projects.
$yearOptions = [];
foreach ($projectRows as $p) if (!empty($p['academic_year'])) $yearOptions[(string)$p['academic_year']] = true;
$yearOptions = array_keys($yearOptions); rsort($yearOptions, SORT_NATURAL);
$totalProjects = count($projectRows);
$publishedProjects = 0; $totalSubmissionRecords = 0; $overdueProjects = 0;
foreach ($projectRows as $p) {
    if ($p['status'] === 'published') $publishedProjects++;
    $totalSubmissionRecords += (int)$p['submission_count'];
    if (!empty($p['due_date']) && $p['due_date'] < date('Y-m-d') && $p['status'] === 'published') $overdueProjects++;
}
$totalPages = max(1, (int)ceil($totalProjects / $perPage));
if ($page > $totalPages) $page = $totalPages;
$shownProjects = array_slice($projectRows, ($page - 1) * $perPage, $perPage);

$studentCurrentSubmission = null;
if ($isStudent && $selectedProject && $studentId > 0) {
    $stmt = $conn->prepare('SELECT * FROM student_project_submissions WHERE project_id=? AND student_id=? LIMIT 1');
    $stmt->bind_param('ii', $viewId, $studentId); $stmt->execute(); $studentCurrentSubmission = $stmt->get_result()->fetch_assoc(); $stmt->close();
}
$rosterForView = [];
if ($isManager && $selectedProject) {
    foreach ($studentRoster as $s) if ($s['class_name'] !== '' && strcasecmp(trim($s['class_name']), trim((string)$selectedProject['class_name'])) === 0) $rosterForView[] = $s;
}
$viewedSubmissionIds = [];
foreach ($viewSubmissions as $s) if ((int)($s['student_id'] ?? 0) > 0) $viewedSubmissionIds[(int)$s['student_id']] = true;
$statuses = ['draft'=>'secondary','published'=>'success','closed'=>'warning','archived'=>'dark'];
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Student Projects | School Management System</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
:root{--navy:#17243a;--navy2:#243754;--bg:#f4f6fa;--blue:#2865cf;--muted:#778398;--accent:#70a7ff}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:#263348;font-family:Arial,Helvetica,sans-serif}.sidebar{position:fixed;top:0;left:0;bottom:0;width:250px;background:var(--navy);color:#fff;overflow-y:auto;z-index:1040;padding:20px 0}.brand{padding:0 22px 22px;border-bottom:1px solid rgba(255,255,255,.12);margin-bottom:16px}.brand h5{margin:0;font-weight:700}.brand small{color:#b8c5d8}.nav-label{color:#95a7c0;text-transform:uppercase;font-size:10px;letter-spacing:1.2px;padding:14px 22px 5px}.sidebar a{color:#d8e1ed;display:block;padding:10px 22px;text-decoration:none;font-size:13px;border-left:3px solid transparent}.sidebar a i{width:22px}.sidebar a:hover,.sidebar a.active{background:var(--navy2);color:#fff;border-left-color:var(--accent)}.main{margin-left:250px;min-height:100vh}.topbar{padding:18px 25px;background:#fff;border-bottom:1px solid #e7ebf2;display:flex;align-items:center;justify-content:space-between;gap:12px}.content{padding:24px}.page-head,.panel,.stat-card{background:#fff;border-radius:10px;box-shadow:0 3px 15px rgba(24,42,70,.05);border:1px solid #edf0f5}.page-head{padding:22px;margin-bottom:20px}.panel{padding:21px;margin-bottom:22px}.stat-card{padding:18px;height:100%;margin-bottom:18px}.stat-label{font-size:12px;color:var(--muted)}.stat-value{font-size:23px;font-weight:700;margin-top:6px;overflow-wrap:anywhere}.stat-icon{float:right;width:38px;height:38px;border-radius:9px;background:#eef4ff;color:#326bd1;text-align:center;line-height:38px}.panel-title{font-size:17px;font-weight:700;margin-bottom:17px;color:#1d2d44}.form-control,.custom-select,.btn{border-radius:6px}.form-control,.custom-select{font-size:13px;min-height:39px}label{font-size:12px;color:#4e5c70;font-weight:600}.table thead th{background:#f7f9fc;color:#68768a;font-size:10px;text-transform:uppercase;letter-spacing:.4px;border-top:0;white-space:nowrap}.table td{font-size:12px;vertical-align:middle}.btn{font-size:12px}.btn-primary{background:var(--blue);border-color:var(--blue)}.badge{font-size:10px;padding:6px 8px}.mobile-menu{display:none}.muted{color:#8490a1;font-size:11px}.project-title{font-weight:700;color:#243754}.project-description{max-width:320px;white-space:normal;overflow-wrap:anywhere}.empty-state{padding:35px 10px;text-align:center;color:#8290a4}.empty-state i{font-size:30px;margin-bottom:12px;color:#bec8d7}.alert{font-size:13px}.footer-note{text-align:center;color:#97a1b1;font-size:11px;padding:7px 0 0}.required{color:#dc3545}.progress{height:7px;min-width:70px}.small-muted{font-size:11px;color:#8490a1}.submission-file{max-width:220px;overflow-wrap:anywhere}@media(max-width:991px){.sidebar{transform:translateX(-100%);transition:transform .2s}.sidebar.show{transform:translateX(0)}.main{margin-left:0}.mobile-menu{display:inline-block!important}.content{padding:15px}.topbar{padding:14px 15px}.page-head,.panel{padding:16px}}@media print{.sidebar,.topbar,.no-print,.footer-note{display:none!important}.main{margin:0}.content{padding:0}body{background:#fff}.page-head,.panel,.stat-card{box-shadow:none;border:0}}
</style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<nav id="sidebar" class="sidebar no-print">
 <div class="brand"><h5><i class="fas fa-school mr-2"></i>School Management</h5><small>Teaching &amp; Learning</small></div>
 <div class="nav-label">Main</div><a href="/admin/dashboard.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
 <div class="nav-label">Classes &amp; Learning</div><a href="/admin/classes/notes.php"><i class="fas fa-book-open"></i>Subject Notes</a><a href="/admin/classes/projects.php" class="active"><i class="fas fa-project-diagram"></i>Student Projects</a><a href="/admin/classes/exams.php"><i class="fas fa-clipboard-list"></i>Examinations</a><a href="/admin/classes/student_reports.php"><i class="fas fa-file-alt"></i>Student Reports</a>
 <div class="nav-label">Account</div><a href="/admin/dashboard.php"><i class="fas fa-cog"></i>Admin Dashboard</a><a href="/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
</nav>
<main class="main">
 <header class="topbar"><div class="d-flex align-items-start"><button type="button" id="mobileMenuBtn" class="btn btn-outline-secondary mobile-menu mr-3" aria-label="Open navigation"><i class="fas fa-bars"></i></button><div><div class="text-uppercase text-primary small font-weight-bold">Teaching / learning</div><h2 class="mb-0" style="font-size:25px;font-weight:700;color:#192940">Student Projects</h2><div class="small text-muted mt-1">Create projects, assign them to classes, and monitor student submissions.</div></div></div><div class="no-print d-flex flex-wrap" style="gap:8px"><button type="button" onclick="window.print()" class="btn btn-outline-primary"><i class="fas fa-print mr-1"></i>Print</button><?php if ($isManager): ?><a href="projects.php#projectForm" class="btn btn-primary"><i class="fas fa-plus mr-1"></i>New Project</a><?php endif; ?></div></header>
 <?php if ($createdTables): ?><div class="alert alert-info"><i class="fas fa-info-circle mr-1"></i>Created database table(s): <?= projects_e(implode(', ', $createdTables)) ?>.</div><?php endif; ?>
 <?php if ($schemaError !== ''): ?><div class="alert alert-danger"><strong><i class="fas fa-exclamation-triangle mr-1"></i>Database setup error</strong><div><?= projects_e($schemaError) ?></div><div class="small mt-2">No project data was changed. Check the database permissions and table structure.</div></div><?php endif; ?>
 <?php if ($pageError !== ''): ?><div class="alert alert-warning"><i class="fas fa-exclamation-triangle mr-1"></i><?= projects_e($pageError) ?></div><?php endif; ?>
 <?php if (is_array($flash) && !empty($flash['message'])): ?><div class="alert alert-<?= projects_e($flash['type'] ?? 'info') ?> alert-dismissible fade show" role="alert"><?= projects_e($flash['message']) ?><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div><?php endif; ?>
 <?php if (!$isStudent && $schemaError === ''): ?>
 <div class="row">
  <div class="col-sm-6 col-xl-3"><div class="stat-card"><span class="stat-icon"><i class="fas fa-project-diagram"></i></span><div class="stat-label">Projects Listed</div><div class="stat-value text-primary"><?= number_format($totalProjects) ?></div></div></div>
  <div class="col-sm-6 col-xl-3"><div class="stat-card"><span class="stat-icon" style="background:#e1f7ef;color:#16845b"><i class="fas fa-globe"></i></span><div class="stat-label">Published</div><div class="stat-value text-success"><?= number_format($publishedProjects) ?></div></div></div>
  <div class="col-sm-6 col-xl-3"><div class="stat-card"><span class="stat-icon" style="background:#fff4df;color:#996c00"><i class="fas fa-file-upload"></i></span><div class="stat-label">Submission Records</div><div class="stat-value"><?= number_format($totalSubmissionRecords) ?></div></div></div>
  <div class="col-sm-6 col-xl-3"><div class="stat-card"><span class="stat-icon" style="background:#fff0f1;color:#c33d4b"><i class="fas fa-calendar-times"></i></span><div class="stat-label">Past-deadline Projects</div><div class="stat-value text-danger"><?= number_format($overdueProjects) ?></div></div></div>
 </div>
 <section class="panel" id="projectForm">
  <div class="panel-title"><i class="fas fa-edit text-primary mr-2"></i><?= $editProject ? 'Edit Project' : 'Create and Assign a Project' ?></div>
  <form method="post" action="projects.php<?= $editProject ? '?edit=' . (int)$editProject['id'] : '' ?>" enctype="multipart/form-data" id="projectEntryForm">
   <input type="hidden" name="csrf_token" value="<?= projects_e($csrfToken) ?>"><input type="hidden" name="action" value="save_project"><input type="hidden" name="project_id" value="<?= (int)($editProject['id'] ?? 0) ?>">
   <div class="form-row">
    <div class="form-group col-lg-5"><label for="title">Project title <span class="required">*</span></label><input class="form-control" id="title" name="title" maxlength="200" required value="<?= projects_e($editProject['title'] ?? '') ?>" placeholder="e.g. Water Conservation Research Project"></div>
    <div class="form-group col-lg-3 col-md-6"><label for="subject_name">Subject <span class="required">*</span></label><input class="form-control" list="subjectOptions" id="subject_name" name="subject_name" maxlength="150" required value="<?= projects_e($editProject['subject_name'] ?? '') ?>" placeholder="Select or enter a subject"><datalist id="subjectOptions"><?php foreach ($subjectOptions as $option): ?><option value="<?= projects_e($option) ?>"><?php endforeach; ?></datalist></div>
    <div class="form-group col-lg-4 col-md-6"><label for="class_name">Assigned class / stream <span class="required">*</span></label><input class="form-control" list="classOptions" id="class_name" name="class_name" maxlength="100" required value="<?= projects_e($editProject['class_name'] ?? '') ?>" placeholder="e.g. Senior 2"><datalist id="classOptions"><?php foreach ($classOptions as $option): ?><option value="<?= projects_e($option) ?>"><?php endforeach; ?></datalist></div>
   </div>
   <div class="form-row">
    <div class="form-group col-md-3"><label for="academic_year">Academic year</label><input class="form-control" id="academic_year" name="academic_year" maxlength="20" value="<?= projects_e($editProject['academic_year'] ?? date('Y')) ?>" placeholder="<?= date('Y') ?>"></div>
    <div class="form-group col-md-3"><label for="term">Term</label><select class="custom-select" id="term" name="term"><option value="">Select term</option><?php foreach (['Term 1','Term 2','Term 3'] as $t): ?><option value="<?= projects_e($t) ?>" <?= (($editProject['term'] ?? '') === $t) ? 'selected' : '' ?>><?= projects_e($t) ?></option><?php endforeach; ?></select></div>
    <div class="form-group col-md-3"><label for="due_date">Submission deadline</label><input type="date" class="form-control" id="due_date" name="due_date" value="<?= projects_e($editProject['due_date'] ?? '') ?>"></div>
    <div class="form-group col-md-3"><label for="max_marks">Maximum marks</label><input type="number" class="form-control" id="max_marks" name="max_marks" min="1" max="100000" step="0.01" required value="<?= projects_e($editProject['max_marks'] ?? '100') ?>"></div>
   </div>
   <div class="form-group"><label for="description">Project description / learning objectives</label><textarea class="form-control" id="description" name="description" rows="2" placeholder="Explain the purpose and expected learning outcomes."><?= projects_e($editProject['description'] ?? '') ?></textarea></div>
   <div class="form-group"><label for="instructions">Instructions and submission requirements</label><textarea class="form-control" id="instructions" name="instructions" rows="4" placeholder="List tasks, format, group-work rules, references and how students should submit."><?= projects_e($editProject['instructions'] ?? '') ?></textarea></div>
   <div class="form-row align-items-end">
    <div class="form-group col-md-8"><label for="resource_file">Project brief / attached resources</label><input class="form-control-file" type="file" id="resource_file" name="resource_file" accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.txt,.rtf,.odt,.ods,.odp,.jpg,.jpeg,.png,.gif,.webp,.zip"><small class="form-text text-muted">Maximum 25 MB. PDF, Word, PowerPoint, Excel, text, images and ZIP.<?php if ($editProject && !empty($editProject['resource_path'])): ?> Current file: <a href="projects.php?download_project=<?= (int)$editProject['id'] ?>"><?= projects_e($editProject['resource_name']) ?></a>. Upload another file to replace it.<?php endif; ?></small></div>
    <div class="form-group col-md-4"><label for="status">Project status</label><select class="custom-select" id="status" name="status"><?php foreach ($projectStatusOptions as $s): ?><option value="<?= projects_e($s) ?>" <?= (($editProject['status'] ?? 'draft') === $s) ? 'selected' : '' ?>><?= projects_e(ucfirst($s)) ?></option><?php endforeach; ?></select></div>
   </div>
   <button type="submit" class="btn btn-primary" id="saveProjectButton"><i class="fas fa-save mr-1"></i><?= $editProject ? 'Update Project' : 'Save Project' ?></button>
   <?php if ($editProject): ?> <a href="projects.php#projectForm" class="btn btn-outline-secondary">Cancel edit</a><?php else: ?> <button type="reset" class="btn btn-outline-secondary">Clear form</button><?php endif; ?>
  </form>
 </section>
 <?php endif; ?>

 <section class="panel" id="projectList">
  <div class="d-flex justify-content-between align-items-center flex-wrap mb-3"><div class="panel-title mb-1"><i class="fas fa-list text-primary mr-2"></i><?= $isStudent ? 'Projects Assigned to My Class' : 'Project Register' ?></div><span class="small text-muted mb-1"><?= number_format($totalProjects) ?> project(s)</span></div>
  <?php if (!$isStudent): ?>
  <form method="get" action="projects.php" class="form-row align-items-end mb-3 no-print">
   <div class="form-group col-xl-3 col-md-6"><label for="q">Search projects</label><input class="form-control" type="search" id="q" name="q" value="<?= projects_e($search) ?>" placeholder="Title, code, subject or class"></div>
   <div class="form-group col-xl-2 col-md-6"><label for="filterClass">Class</label><select class="custom-select" name="class" id="filterClass"><option value="">All classes</option><?php foreach ($classOptions as $c): ?><option value="<?= projects_e($c) ?>" <?= $filterClass === $c ? 'selected' : '' ?>><?= projects_e($c) ?></option><?php endforeach; ?></select></div>
   <div class="form-group col-xl-2 col-md-6"><label for="filterSubject">Subject</label><select class="custom-select" name="subject" id="filterSubject"><option value="">All subjects</option><?php foreach ($subjectOptions as $s): ?><option value="<?= projects_e($s) ?>" <?= $filterSubject === $s ? 'selected' : '' ?>><?= projects_e($s) ?></option><?php endforeach; ?></select></div>
   <div class="form-group col-xl-2 col-md-6"><label for="filterYear">Year</label><select class="custom-select" name="year" id="filterYear"><option value="">All years</option><?php foreach ($yearOptions as $y): ?><option value="<?= projects_e($y) ?>" <?= $filterYear === $y ? 'selected' : '' ?>><?= projects_e($y) ?></option><?php endforeach; ?></select></div>
   <div class="form-group col-xl-2 col-md-6"><label for="filterStatus">Status</label><select class="custom-select" name="status" id="filterStatus"><option value="">All statuses</option><?php foreach ($projectStatusOptions as $s): ?><option value="<?= projects_e($s) ?>" <?= $filterStatus === $s ? 'selected' : '' ?>><?= projects_e(ucfirst($s)) ?></option><?php endforeach; ?></select></div>
   <div class="form-group col-xl-1 col-md-6"><button class="btn btn-primary btn-block" type="submit" title="Filter"><i class="fas fa-search"></i></button></div>
  </form>
  <?php endif; ?>
  <div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Project</th><th>Subject / class</th><th>Year / term</th><th>Deadline</th><th>Marks</th><?php if (!$isStudent): ?><th>Submissions</th><?php endif; ?><th>Status</th><th class="no-print">Actions</th></tr></thead><tbody>
  <?php if (!$shownProjects): ?><tr><td colspan="<?= $isStudent ? 7 : 8 ?>"><div class="empty-state"><i class="fas fa-project-diagram d-block"></i><strong><?= $isStudent ? 'No projects are currently assigned to your class' : 'No projects found' ?></strong><div class="small mt-1"><?= $isStudent ? 'Check again later or contact your teacher.' : 'Create a project above or adjust the filters.' ?></div></div></td></tr><?php else: foreach ($shownProjects as $p): $st = strtolower((string)$p['status']); $badge = $statuses[$st] ?? 'secondary'; $isOverdue = !empty($p['due_date']) && $p['due_date'] < date('Y-m-d') && $st === 'published'; ?>
   <tr>
    <td><div class="project-title"><?= projects_e($p['title']) ?></div><div class="small-muted"><?= projects_e($p['project_code']) ?></div><?php if (!empty($p['resource_path'])): ?><div class="small mt-1"><a href="projects.php?download_project=<?= (int)$p['id'] ?>"><i class="fas fa-paperclip mr-1"></i>Project brief</a></div><?php endif; ?></td>
    <td><strong><?= projects_e($p['subject_name']) ?></strong><div class="small-muted"><?= projects_e($p['class_name']) ?></div></td>
    <td><?= projects_e($p['academic_year'] ?: '—') ?><div class="small-muted"><?= projects_e($p['term'] ?: '—') ?></div></td>
    <td><?= !empty($p['due_date']) ? projects_e(date('d M Y', strtotime($p['due_date']))) : 'No deadline' ?><?php if ($isOverdue): ?><div class="small text-danger">Deadline passed</div><?php endif; ?></td>
    <td><?= projects_e(rtrim(rtrim(number_format((float)$p['max_marks'],2,'.',''), '0'), '.')) ?></td>
    <?php if (!$isStudent): ?><td><strong><?= number_format((int)$p['submission_count']) ?></strong><div class="small-muted"><?= number_format((int)$p['reviewed_count']) ?> reviewed / returned</div></td><?php endif; ?>
    <td><span class="badge badge-<?= projects_e($badge) ?>"><?= projects_e(ucfirst($st)) ?></span></td>
    <td class="no-print text-nowrap"><a class="btn btn-sm btn-outline-primary" href="projects.php?view=<?= (int)$p['id'] ?>#projectDetails" title="<?= $isStudent ? 'Open project and submit work' : 'View submissions' ?>"><i class="fas <?= $isStudent ? 'fa-arrow-right' : 'fa-users' ?>"></i> <?= $isStudent ? 'Open' : 'Submissions' ?></a>
    <?php if (!$isStudent): ?><a class="btn btn-sm btn-outline-secondary" href="projects.php?edit=<?= (int)$p['id'] ?>#projectForm" title="Edit"><i class="fas fa-edit"></i></a>
    <div class="dropdown d-inline"><button class="btn btn-sm btn-outline-secondary dropdown-toggle" data-toggle="dropdown" type="button">Status</button><div class="dropdown-menu dropdown-menu-right"><?php foreach ($projectStatusOptions as $newStatus): if ($newStatus === $st) continue; ?><form method="post" action="projects.php" class="m-0"><input type="hidden" name="csrf_token" value="<?= projects_e($csrfToken) ?>"><input type="hidden" name="action" value="change_project_status"><input type="hidden" name="project_id" value="<?= (int)$p['id'] ?>"><input type="hidden" name="new_status" value="<?= projects_e($newStatus) ?>"><button class="dropdown-item" type="submit"><?= projects_e(ucfirst($newStatus)) ?></button></form><?php endforeach; ?></div></div>
    <form method="post" action="projects.php" class="d-inline" onsubmit="return confirm('Delete this project and its submission records and attachments? This cannot be undone.');"><input type="hidden" name="csrf_token" value="<?= projects_e($csrfToken) ?>"><input type="hidden" name="action" value="delete_project"><input type="hidden" name="project_id" value="<?= (int)$p['id'] ?>"><button class="btn btn-sm btn-outline-danger" type="submit" title="Delete"><i class="fas fa-trash"></i></button></form><?php endif; ?></td>
   </tr>
  <?php endforeach; endif; ?>
  </tbody></table></div>
  <?php if ($totalPages > 1): $pageQuery = $_GET; unset($pageQuery['view'],$pageQuery['edit'],$pageQuery['download_project'],$pageQuery['download_submission']); ?><nav class="no-print mt-3" aria-label="Project pages"><ul class="pagination flex-wrap mb-0"><?php $pageQuery['page']=max(1,$page-1); ?><li class="page-item <?= $page<=1?'disabled':'' ?>"><a class="page-link" href="?<?= projects_e(http_build_query($pageQuery)) ?>">Previous</a></li><?php for($p=max(1,$page-2);$p<=min($totalPages,$page+2);$p++):$pageQuery['page']=$p; ?><li class="page-item <?= $p===$page?'active':'' ?>"><a class="page-link" href="?<?= projects_e(http_build_query($pageQuery)) ?>"><?= $p ?></a></li><?php endfor; $pageQuery['page']=min($totalPages,$page+1); ?><li class="page-item <?= $page>=$totalPages?'disabled':'' ?>"><a class="page-link" href="?<?= projects_e(http_build_query($pageQuery)) ?>">Next</a></li></ul></nav><?php endif; ?>
 </section>

 <?php if ($selectedProject): ?>
 <section class="panel" id="projectDetails">
  <div class="d-flex justify-content-between flex-wrap align-items-start"><div><div class="panel-title mb-1"><i class="fas fa-project-diagram text-primary mr-2"></i><?= projects_e($selectedProject['title']) ?></div><div class="small text-muted"><?= projects_e($selectedProject['project_code']) ?> · <?= projects_e($selectedProject['subject_name']) ?> · <?= projects_e($selectedProject['class_name']) ?> · <?= projects_e($selectedProject['academic_year'] ?: '—') ?> <?= projects_e($selectedProject['term'] ?: '') ?></div></div><span class="badge badge-<?= projects_e($statuses[strtolower((string)$selectedProject['status'])] ?? 'secondary') ?>"><?= projects_e(ucfirst((string)$selectedProject['status'])) ?></span></div>
  <?php if (!empty($selectedProject['description'])): ?><div class="mt-3"><strong>Description / objectives</strong><p class="mb-2 mt-1"><?= nl2br(projects_e($selectedProject['description'])) ?></p></div><?php endif; ?>
  <?php if (!empty($selectedProject['instructions'])): ?><div class="mt-2"><strong>Instructions</strong><div class="mt-1"><?= nl2br(projects_e($selectedProject['instructions'])) ?></div></div><?php endif; ?>
  <div class="d-flex flex-wrap mt-3" style="gap:18px"><span><i class="far fa-calendar-alt text-primary mr-1"></i>Deadline: <strong><?= !empty($selectedProject['due_date']) ? projects_e(date('d M Y', strtotime($selectedProject['due_date']))) : 'Not set' ?></strong></span><span><i class="fas fa-star text-warning mr-1"></i>Maximum marks: <strong><?= projects_e(rtrim(rtrim(number_format((float)$selectedProject['max_marks'],2,'.',''),'0'),'.')) ?></strong></span><?php if (!empty($selectedProject['resource_path'])): ?><span><a href="projects.php?download_project=<?= (int)$selectedProject['id'] ?>"><i class="fas fa-download mr-1"></i>Download project brief</a></span><?php endif; ?></div>
 </section>
 <?php if ($isStudent): ?>
  <section class="panel">
   <div class="panel-title"><i class="fas fa-file-upload text-primary mr-2"></i><?= $studentCurrentSubmission ? 'Update My Submission' : 'Submit My Project' ?></div>
   <?php if ($selectedProject['status'] !== 'published'): ?><div class="alert alert-warning">This project is closed to new submissions. You may review your previously submitted work below.</div><?php else: ?>
   <form method="post" action="projects.php?view=<?= (int)$selectedProject['id'] ?>#projectDetails" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?= projects_e($csrfToken) ?>"><input type="hidden" name="action" value="submit_work"><input type="hidden" name="project_id" value="<?= (int)$selectedProject['id'] ?>">
    <div class="form-group"><label for="submission_text">Explanation / response</label><textarea class="form-control" rows="5" name="submission_text" id="submission_text" placeholder="Describe your work or enter your response."><?= projects_e($studentCurrentSubmission['submission_text'] ?? '') ?></textarea></div>
    <div class="form-group"><label for="submission_file">Attach your completed project</label><input class="form-control-file" type="file" name="submission_file" id="submission_file" accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.txt,.rtf,.odt,.ods,.odp,.jpg,.jpeg,.png,.gif,.webp,.zip"><small class="form-text text-muted">Maximum 25 MB. Upload another file to replace your previous attachment.</small><?php if (!empty($studentCurrentSubmission['file_path'])): ?><div class="small mt-2">Current attachment: <a href="projects.php?download_submission=<?= (int)$studentCurrentSubmission['id'] ?>"><?= projects_e($studentCurrentSubmission['file_name']) ?></a></div><?php endif; ?></div>
    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane mr-1"></i><?= $studentCurrentSubmission ? 'Update Submission' : 'Submit Project' ?></button>
   </form><?php endif; ?>
   <?php if ($studentCurrentSubmission): ?><hr><h6>Your submission status</h6><p class="mb-1">Status: <span class="badge badge-<?= $studentCurrentSubmission['status']==='reviewed'?'success':($studentCurrentSubmission['status']==='late'?'warning':'info') ?>"><?= projects_e(ucfirst((string)$studentCurrentSubmission['status'])) ?></span> · Submitted: <?= !empty($studentCurrentSubmission['submitted_at']) ? projects_e(date('d M Y H:i', strtotime($studentCurrentSubmission['submitted_at']))) : '—' ?></p><?php if ($studentCurrentSubmission['marks'] !== null): ?><p class="mb-1">Marks: <strong><?= projects_e($studentCurrentSubmission['marks']) ?> / <?= projects_e($selectedProject['max_marks']) ?></strong></p><?php endif; ?><?php if (!empty($studentCurrentSubmission['feedback'])): ?><div class="alert alert-light border mt-2"><strong>Teacher feedback:</strong><br><?= nl2br(projects_e($studentCurrentSubmission['feedback'])) ?></div><?php endif; ?><?php endif; ?>
  </section>
 <?php else: ?>
  <section class="panel">
   <div class="d-flex justify-content-between align-items-center flex-wrap mb-3"><div class="panel-title mb-1"><i class="fas fa-users text-primary mr-2"></i>Submission Tracker</div><span class="small text-muted"><?= count($viewSubmissions) ?> submission record(s)</span></div>
   <form method="post" action="projects.php?view=<?= (int)$selectedProject['id'] ?>#projectDetails" enctype="multipart/form-data" class="border rounded p-3 mb-4 bg-light"><h6 class="mb-3">Record / upload a student's submission</h6><input type="hidden" name="csrf_token" value="<?= projects_e($csrfToken) ?>"><input type="hidden" name="action" value="submit_work"><input type="hidden" name="project_id" value="<?= (int)$selectedProject['id'] ?>">
    <div class="form-row"><div class="form-group col-lg-5"><label for="student_id">Student in assigned class</label><select class="custom-select" name="student_id" id="student_id"><option value="0">Select a registered student (or enter name below)</option><?php foreach ($rosterForView as $s): ?><option value="<?= (int)$s['id'] ?>" data-student-name="<?= projects_e($s['name']) ?>" data-admission="<?= projects_e($s['admission_no']) ?>"><?= projects_e($s['name']) ?><?= $s['admission_no']!==''?' — Admission: '.projects_e($s['admission_no']):'' ?><?= $s['lin_no']!==''?' — LIN: '.projects_e($s['lin_no']):'' ?><?= $s['student_payment_code']!==''?' — Payment Code: '.projects_e($s['student_payment_code']):'' ?> — <?= projects_e($s['student_section']) ?></option><?php endforeach; ?></select><small class="form-text text-muted">If the roster is empty, check how the class is stored in your students table.</small></div><div class="form-group col-lg-4"><label for="student_name">Student name <span class="required">*</span></label><input class="form-control" id="student_name" name="student_name" required maxlength="180" placeholder="Student full name"></div><div class="form-group col-lg-3"><label for="admission_no">Admission number</label><input class="form-control" id="admission_no" name="admission_no" maxlength="80" placeholder="Admission No."></div></div>
    <div class="form-group"><label for="submission_text">Submission description / teacher note</label><textarea class="form-control" name="submission_text" id="submission_text" rows="2" placeholder="Brief description or notes about the submission."></textarea></div>
    <div class="form-group"><label for="submission_file">Student work attachment</label><input class="form-control-file" type="file" name="submission_file" id="submission_file" accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.txt,.rtf,.odt,.ods,.odp,.jpg,.jpeg,.png,.gif,.webp,.zip"><small class="form-text text-muted">Optional if the submission description is entered. Maximum 25 MB.</small></div><button type="submit" class="btn btn-primary"><i class="fas fa-save mr-1"></i>Save Submission Record</button>
   </form>
   <div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Student</th><th>Submission</th><th>Date</th><th>Status</th><th>Marks / <?= projects_e($selectedProject['max_marks']) ?></th><th class="no-print">Review / feedback</th></tr></thead><tbody>
   <?php if (!$rosterForView && !$viewSubmissions): ?><tr><td colspan="6"><div class="empty-state"><i class="fas fa-users d-block"></i><strong>No class roster or submissions found</strong><div class="small mt-1">You can still record submissions manually using the form above.</div></div></td></tr><?php else: ?>
    <?php foreach ($rosterForView as $s): $sub = $submissionsByStudent[(int)$s['id']] ?? null; $subStatus = $sub ? (string)$sub['status'] : 'missing'; ?>
    <tr><td><strong><?= projects_e($s['name']) ?></strong><div class="small-muted">Admission: <?= projects_e($s['admission_no'] ?: '—') ?></div><div class="small-muted">LIN: <?= projects_e($s['lin_no'] ?: '—') ?> | Payment Code: <?= projects_e($s['student_payment_code'] ?: '—') ?> | <?= projects_e($s['student_section'] ?: 'Day') ?></div></td><td><?php if ($sub): ?><?php if (!empty($sub['file_path'])): ?><a href="projects.php?download_submission=<?= (int)$sub['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-download mr-1"></i>File</a><?php endif; ?><?php if (!empty($sub['submission_text'])): ?><div class="small-muted mt-1"><?= projects_e(mb_strimwidth((string)$sub['submission_text'],0,100,'…')) ?></div><?php endif; ?><?php if (empty($sub['file_path']) && empty($sub['submission_text'])): ?>Recorded submission<?php endif; ?><?php else: ?><span class="text-muted">No submission received</span><?php endif; ?></td><td><?= $sub && !empty($sub['submitted_at']) ? projects_e(date('d M Y H:i',strtotime($sub['submitted_at']))) : '—' ?></td><td><span class="badge badge-<?= $subStatus==='reviewed'?'success':($subStatus==='late'?'warning':($subStatus==='missing'?'danger':($subStatus==='returned'?'info':'secondary'))) ?>"><?= projects_e($subStatus==='missing'?'Not submitted':ucfirst($subStatus)) ?></span></td><td><?= $sub && $sub['marks']!==null ? projects_e($sub['marks']) : '—' ?></td><td class="no-print"><?php if ($sub): ?><form method="post" action="projects.php?view=<?= (int)$selectedProject['id'] ?>#projectDetails" class="review-form"><input type="hidden" name="csrf_token" value="<?= projects_e($csrfToken) ?>"><input type="hidden" name="action" value="review_submission"><input type="hidden" name="submission_id" value="<?= (int)$sub['id'] ?>"><div class="form-row"><div class="col-4 mb-1"><input type="number" name="marks" class="form-control form-control-sm" min="0" max="<?= projects_e($selectedProject['max_marks']) ?>" step="0.01" value="<?= $sub['marks']!==null?projects_e($sub['marks']):'' ?>" placeholder="Marks"></div><div class="col-4 mb-1"><select name="review_status" class="custom-select custom-select-sm"><option value="reviewed" <?= $subStatus==='reviewed'?'selected':'' ?>>Reviewed</option><option value="returned" <?= $subStatus==='returned'?'selected':'' ?>>Return</option><option value="missing" <?= $subStatus==='missing'?'selected':'' ?>>Missing</option></select></div><div class="col-4 mb-1"><button class="btn btn-sm btn-primary btn-block" type="submit">Save</button></div></div><textarea class="form-control form-control-sm" name="feedback" rows="2" placeholder="Feedback"><?= projects_e($sub['feedback'] ?? '') ?></textarea></form><?php else: ?><span class="small-muted">Awaiting submission</span><?php endif; ?></td></tr>
    <?php endforeach; ?>
    <?php foreach ($viewSubmissions as $sub): if ((int)($sub['student_id'] ?? 0)>0 && isset($viewedSubmissionIds[(int)$sub['student_id']])) { $inRoster=false; foreach($rosterForView as $sx) if((int)$sx['id']===(int)$sub['student_id']){$inRoster=true;break;} if($inRoster) continue; } $subStatus=(string)$sub['status']; ?>
    <tr><td><strong><?= projects_e($sub['student_name']) ?></strong><div class="small-muted"><?= projects_e($sub['admission_no'] ?: 'Manual / external student record') ?></div></td><td><?php if (!empty($sub['file_path'])): ?><a href="projects.php?download_submission=<?= (int)$sub['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-download mr-1"></i>File</a><?php endif; ?><?php if (!empty($sub['submission_text'])): ?><div class="small-muted mt-1"><?= projects_e(mb_strimwidth((string)$sub['submission_text'],0,100,'…')) ?></div><?php endif; ?></td><td><?= !empty($sub['submitted_at'])?projects_e(date('d M Y H:i',strtotime($sub['submitted_at']))):'—' ?></td><td><span class="badge badge-<?= $subStatus==='reviewed'?'success':($subStatus==='late'?'warning':'secondary') ?>"><?= projects_e(ucfirst($subStatus)) ?></span></td><td><?= $sub['marks']!==null?projects_e($sub['marks']):'—' ?></td><td class="no-print"><form method="post" action="projects.php?view=<?= (int)$selectedProject['id'] ?>#projectDetails"><input type="hidden" name="csrf_token" value="<?= projects_e($csrfToken) ?>"><input type="hidden" name="action" value="review_submission"><input type="hidden" name="submission_id" value="<?= (int)$sub['id'] ?>"><div class="form-row"><div class="col-4 mb-1"><input type="number" name="marks" class="form-control form-control-sm" min="0" max="<?= projects_e($selectedProject['max_marks']) ?>" step="0.01" value="<?= $sub['marks']!==null?projects_e($sub['marks']):'' ?>" placeholder="Marks"></div><div class="col-4 mb-1"><select name="review_status" class="custom-select custom-select-sm"><option value="reviewed">Reviewed</option><option value="returned">Return</option><option value="missing">Missing</option></select></div><div class="col-4 mb-1"><button class="btn btn-sm btn-primary btn-block" type="submit">Save</button></div></div><textarea class="form-control form-control-sm" name="feedback" rows="2" placeholder="Feedback"><?= projects_e($sub['feedback'] ?? '') ?></textarea></form></td></tr>
    <?php endforeach; ?>
   <?php endif; ?>
   </tbody></table></div>
  </section>
 <?php endif; ?>
 <?php elseif ($viewId > 0 && !$selectedProject && $schemaError === ''): ?><div class="alert alert-warning">The selected project could not be found, or it is not assigned to your class.</div><?php endif; ?>
 <div class="footer-note">School Management System — Student Projects and Submission Tracking</div>
</div>
</main>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function(){
 var sidebar=document.getElementById('sidebar'),menu=document.getElementById('mobileMenuBtn');
 if(menu&&sidebar)menu.addEventListener('click',function(){sidebar.classList.toggle('show');});
 document.addEventListener('click',function(e){if(window.innerWidth<=991&&sidebar&&sidebar.classList.contains('show')&&!sidebar.contains(e.target)&&menu&&!menu.contains(e.target))sidebar.classList.remove('show');});
 var projectForm=document.getElementById('projectEntryForm');if(projectForm)projectForm.addEventListener('submit',function(){var b=document.getElementById('saveProjectButton');if(b){b.disabled=true;b.innerHTML='<i class="fas fa-spinner fa-spin mr-1"></i>Saving project...';}});
 var studentSelect=document.getElementById('student_id'),studentName=document.getElementById('student_name'),admission=document.getElementById('admission_no');
 if(studentSelect&&studentName&&admission)studentSelect.addEventListener('change',function(){var o=studentSelect.options[studentSelect.selectedIndex];if(o&&o.value!=='0'){studentName.value=o.getAttribute('data-student-name')||studentName.value;admission.value=o.getAttribute('data-admission')||admission.value;}});
})();
</script>
</body>
</html>
