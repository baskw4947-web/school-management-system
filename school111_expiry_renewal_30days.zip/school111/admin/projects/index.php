<?php
/**
 * School Management System - School Development Projects
 * Install at: /admin/projects/index.php
 * Uses existing config/database.php ($conn) and includes/auth.php.
 * Save as UTF-8 without BOM; PHP opening tag must be first bytes.
 */

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/auth.php';
requireRole(['administrator', 'assistant_administrator', 'bursar']);

if (!isset($conn) || !($conn instanceof mysqli)) {
    http_response_code(500);
    exit('Database connection is unavailable. Please check config/database.php.');
}
$conn->set_charset('utf8mb4');

function devProjectE($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}
function devProjectUserId(): int {
    foreach (['user_id', 'id'] as $key) {
        if (isset($_SESSION[$key]) && is_numeric($_SESSION[$key])) return (int)$_SESSION[$key];
    }
    if (isset($_SESSION['user']) && is_array($_SESSION['user']) && isset($_SESSION['user']['id']) && is_numeric($_SESSION['user']['id'])) return (int)$_SESSION['user']['id'];
    return 0;
}
function devProjectFlash(string $type, string $message): void {
    $_SESSION['dev_projects_flash'] = ['type' => $type, 'message' => $message];
}
function devProjectRedirect(string $url = 'index.php'): void {
    header('Location: ' . $url);
    exit;
}
function devProjectValidDate(string $date, bool $allowBlank = false): bool {
    if ($date === '' && $allowBlank) return true;
    $dt = DateTime::createFromFormat('!Y-m-d', $date);
    $errors = DateTime::getLastErrors();
    return $dt !== false && $dt->format('Y-m-d') === $date && ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0));
}
function devProjectCreateNumber(mysqli $conn, string $table, string $column, string $prefix): string {
    for ($i = 0; $i < 20; $i++) {
        $number = $prefix . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
        $stmt = $conn->prepare("SELECT 1 FROM `{$table}` WHERE `{$column}` = ? LIMIT 1");
        $stmt->bind_param('s', $number);
        $stmt->execute();
        $found = (bool)$stmt->get_result()->fetch_row();
        $stmt->close();
        if (!$found) return $number;
    }
    throw new RuntimeException('Could not generate a unique reference number. Please try again.');
}
function devProjectTableExists(mysqli $conn, string $table): bool {
    $safe = $conn->real_escape_string($table);
    $result = $conn->query("SHOW TABLES LIKE '{$safe}'");
    return $result && $result->num_rows > 0;
}

$userId = devProjectUserId();
$csrfKey = 'dev_projects_csrf';
if (empty($_SESSION[$csrfKey])) $_SESSION[$csrfKey] = bin2hex(random_bytes(32));
$csrfToken = (string)$_SESSION[$csrfKey];
$flash = $_SESSION['dev_projects_flash'] ?? null;
unset($_SESSION['dev_projects_flash']);
$schemaError = '';
$pageError = '';
$createdTables = [];
$projects = [];
$expenses = [];
$projectFormRecord = null;
$expenseFormRecord = null;
$projectTotals = [];
$filterSearch = trim((string)($_GET['q'] ?? ''));
$filterStatus = trim((string)($_GET['status'] ?? ''));
$filterYear = trim((string)($_GET['year'] ?? ''));
$expenseSearch = trim((string)($_GET['expense_q'] ?? ''));
$expenseProjectFilter = max(0, (int)($_GET['expense_project'] ?? 0));
$expenseStatusFilter = trim((string)($_GET['expense_status'] ?? ''));
$projectPage = max(1, (int)($_GET['p'] ?? 1));
$expensePage = max(1, (int)($_GET['ep'] ?? 1));
$perPage = 12;
$projectCount = 0;
$ongoingCount = 0;
$completedCount = 0;
$totalBudgetAll = 0.0;
$totalPaidAll = 0.0;
$totalPendingAll = 0.0;
$projectPages = 1;
$expensePages = 1;
$shownProjects = [];
$shownExpenses = [];

try {
    if (!devProjectTableExists($conn, 'development_projects')) {
        $conn->query("CREATE TABLE `development_projects` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `project_no` VARCHAR(50) NOT NULL,
            `project_name` VARCHAR(180) NOT NULL,
            `category` VARCHAR(100) DEFAULT NULL,
            `location` VARCHAR(180) DEFAULT NULL,
            `description` TEXT DEFAULT NULL,
            `contractor` VARCHAR(180) DEFAULT NULL,
            `project_manager` VARCHAR(150) DEFAULT NULL,
            `funding_source` VARCHAR(150) DEFAULT NULL,
            `start_date` DATE DEFAULT NULL,
            `end_date` DATE DEFAULT NULL,
            `budget_amount` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
            `status` ENUM('planned','ongoing','on_hold','completed','cancelled') NOT NULL DEFAULT 'planned',
            `created_by` INT DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`), UNIQUE KEY `uq_development_project_no` (`project_no`),
            KEY `idx_development_project_status` (`status`), KEY `idx_development_project_dates` (`start_date`,`end_date`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $createdTables[] = 'development_projects';
    }
    if (!devProjectTableExists($conn, 'development_project_expenses')) {
        $conn->query("CREATE TABLE `development_project_expenses` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `expense_no` VARCHAR(50) NOT NULL,
            `project_id` INT UNSIGNED NOT NULL,
            `expense_date` DATE NOT NULL,
            `description` VARCHAR(220) NOT NULL,
            `supplier` VARCHAR(180) DEFAULT NULL,
            `reference_no` VARCHAR(100) DEFAULT NULL,
            `payment_method` VARCHAR(80) DEFAULT NULL,
            `amount` DECIMAL(14,2) NOT NULL,
            `status` ENUM('paid','pending','cancelled') NOT NULL DEFAULT 'paid',
            `recorded_by` INT DEFAULT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`), UNIQUE KEY `uq_development_project_expense_no` (`expense_no`),
            KEY `idx_project_expense_project` (`project_id`), KEY `idx_project_expense_date` (`expense_date`), KEY `idx_project_expense_status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $createdTables[] = 'development_project_expenses';
    }
} catch (Throwable $e) {
    error_log('Development projects schema setup error: ' . $e->getMessage());
    $schemaError = 'The development projects tables could not be prepared. Check database permissions and the PHP error log. Details: ' . $e->getMessage();
}

// Record creation, updates and delete/status actions. All writes require a valid CSRF token.
if ($schemaError === '' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $postedToken = (string)($_POST['csrf_token'] ?? '');
    if (!hash_equals($csrfToken, $postedToken)) {
        devProjectFlash('danger', 'Your form session expired. Refresh the page and try again.');
        devProjectRedirect();
    }
    $action = (string)($_POST['action'] ?? '');
    try {
        if ($action === 'save_project') {
            $id = max(0, (int)($_POST['id'] ?? 0));
            $name = trim((string)($_POST['project_name'] ?? ''));
            $category = trim((string)($_POST['category'] ?? ''));
            $location = trim((string)($_POST['location'] ?? ''));
            $description = trim((string)($_POST['description'] ?? ''));
            $contractor = trim((string)($_POST['contractor'] ?? ''));
            $manager = trim((string)($_POST['project_manager'] ?? ''));
            $funding = trim((string)($_POST['funding_source'] ?? ''));
            $start = trim((string)($_POST['start_date'] ?? ''));
            $end = trim((string)($_POST['end_date'] ?? ''));
            $budgetInput = trim((string)($_POST['budget_amount'] ?? ''));
            $status = trim((string)($_POST['status'] ?? 'planned'));
            $validStatuses = ['planned','ongoing','on_hold','completed','cancelled'];

            if ($name === '') throw new RuntimeException('Enter the development project name.');
            if (mb_strlen($name) > 180) throw new RuntimeException('Project name cannot exceed 180 characters.');
            if (!in_array($status, $validStatuses, true)) throw new RuntimeException('Select a valid project status.');
            if ($start !== '' && !devProjectValidDate($start)) throw new RuntimeException('Enter a valid project start date.');
            if ($end !== '' && !devProjectValidDate($end)) throw new RuntimeException('Enter a valid project end date.');
            if ($start !== '' && $end !== '' && $end < $start) throw new RuntimeException('The project end date cannot be before its start date.');
            if ($budgetInput === '' || !is_numeric($budgetInput) || !is_finite((float)$budgetInput) || (float)$budgetInput < 0) throw new RuntimeException('Enter a valid project budget of zero or more.');
            $budget = round((float)$budgetInput, 2);

            if ($id > 0) {
                $stmt = $conn->prepare("UPDATE development_projects SET project_name=?, category=?, location=?, description=?, contractor=?, project_manager=?, funding_source=?, start_date=NULLIF(?,''), end_date=NULLIF(?,''), budget_amount=?, status=? WHERE id=?");
                $stmt->bind_param('sssssssssdsi', $name, $category, $location, $description, $contractor, $manager, $funding, $start, $end, $budget, $status, $id);
                $stmt->execute();
                $stmt->close();
                devProjectFlash('success', 'Development project updated successfully.');
            } else {
                $projectNo = devProjectCreateNumber($conn, 'development_projects', 'project_no', 'DEV-');
                $stmt = $conn->prepare("INSERT INTO development_projects (project_no, project_name, category, location, description, contractor, project_manager, funding_source, start_date, end_date, budget_amount, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULLIF(?,''), NULLIF(?,''), ?, ?, ?)");
                $stmt->bind_param('ssssssssssdsi', $projectNo, $name, $category, $location, $description, $contractor, $manager, $funding, $start, $end, $budget, $status, $userId);
                $stmt->execute();
                $stmt->close();
                devProjectFlash('success', 'Development project created. Project number: ' . $projectNo);
            }
            devProjectRedirect();
        }

        if ($action === 'save_expense') {
            $id = max(0, (int)($_POST['id'] ?? 0));
            $projectId = max(0, (int)($_POST['project_id'] ?? 0));
            $date = trim((string)($_POST['expense_date'] ?? date('Y-m-d')));
            $description = trim((string)($_POST['description'] ?? ''));
            $supplier = trim((string)($_POST['supplier'] ?? ''));
            $reference = trim((string)($_POST['reference_no'] ?? ''));
            $method = trim((string)($_POST['payment_method'] ?? ''));
            $amountInput = trim((string)($_POST['amount'] ?? ''));
            $status = trim((string)($_POST['status'] ?? 'paid'));
            if ($projectId < 1) throw new RuntimeException('Select a development project for this expense.');
            $check = $conn->prepare('SELECT id FROM development_projects WHERE id=? LIMIT 1');
            $check->bind_param('i', $projectId);
            $check->execute();
            $hasProject = (bool)$check->get_result()->fetch_row();
            $check->close();
            if (!$hasProject) throw new RuntimeException('The selected development project could not be found.');
            if (!devProjectValidDate($date)) throw new RuntimeException('Enter a valid expense date.');
            if ($description === '') throw new RuntimeException('Enter a description for the project expense.');
            if ($amountInput === '' || !is_numeric($amountInput) || !is_finite((float)$amountInput) || (float)$amountInput <= 0) throw new RuntimeException('Enter an expense amount greater than zero.');
            if (!in_array($status, ['paid','pending','cancelled'], true)) throw new RuntimeException('Select a valid expense status.');
            $amount = round((float)$amountInput, 2);
            if ($id > 0) {
                $stmt = $conn->prepare('UPDATE development_project_expenses SET project_id=?, expense_date=?, description=?, supplier=?, reference_no=?, payment_method=?, amount=?, status=? WHERE id=?');
                $stmt->bind_param('isssssdsi', $projectId, $date, $description, $supplier, $reference, $method, $amount, $status, $id);
                $stmt->execute();
                $stmt->close();
                devProjectFlash('success', 'Project expense updated successfully.');
            } else {
                $expenseNo = devProjectCreateNumber($conn, 'development_project_expenses', 'expense_no', 'PEXP-');
                $stmt = $conn->prepare('INSERT INTO development_project_expenses (expense_no, project_id, expense_date, description, supplier, reference_no, payment_method, amount, status, recorded_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
                $stmt->bind_param('sisssssdsi', $expenseNo, $projectId, $date, $description, $supplier, $reference, $method, $amount, $status, $userId);
                $stmt->execute();
                $stmt->close();
                devProjectFlash('success', 'Project expense recorded. Expense number: ' . $expenseNo);
            }
            devProjectRedirect();
        }

        if ($action === 'delete_expense') {
            $id = max(0, (int)($_POST['id'] ?? 0));
            if ($id < 1) throw new RuntimeException('Select a valid project expense.');
            $stmt = $conn->prepare('DELETE FROM development_project_expenses WHERE id=?');
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $deleted = $stmt->affected_rows;
            $stmt->close();
            devProjectFlash($deleted ? 'success' : 'warning', $deleted ? 'Project expense deleted.' : 'No project expense was deleted.');
            devProjectRedirect();
        }

        if ($action === 'change_project_status') {
            $id = max(0, (int)($_POST['id'] ?? 0));
            $status = trim((string)($_POST['status'] ?? ''));
            if ($id < 1 || !in_array($status, ['planned','ongoing','on_hold','completed','cancelled'], true)) throw new RuntimeException('Select a valid project and status.');
            $stmt = $conn->prepare('UPDATE development_projects SET status=? WHERE id=?');
            $stmt->bind_param('si', $status, $id);
            $stmt->execute();
            $stmt->close();
            devProjectFlash('success', 'Project status updated.');
            devProjectRedirect();
        }

        if ($action === 'delete_project') {
            $id = max(0, (int)($_POST['id'] ?? 0));
            if ($id < 1) throw new RuntimeException('Select a valid project to delete.');
            $check = $conn->prepare('SELECT COUNT(*) AS n FROM development_project_expenses WHERE project_id=?');
            $check->bind_param('i', $id);
            $check->execute();
            $count = (int)($check->get_result()->fetch_assoc()['n'] ?? 0);
            $check->close();
            if ($count > 0) throw new RuntimeException('This project has expense records. Delete or reassign its expenses before deleting the project, or change its status to cancelled/completed.');
            $stmt = $conn->prepare('DELETE FROM development_projects WHERE id=?');
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $deleted = $stmt->affected_rows;
            $stmt->close();
            devProjectFlash($deleted ? 'success' : 'warning', $deleted ? 'Development project deleted.' : 'No project was deleted.');
            devProjectRedirect();
        }

        throw new RuntimeException('Invalid action. Please refresh the page and try again.');
    } catch (Throwable $e) {
        error_log('School development projects action error: ' . $e->getMessage());
        devProjectFlash('danger', $e instanceof RuntimeException ? $e->getMessage() : 'The request could not be completed. Check the PHP error log.');
        devProjectRedirect();
    }
}

// Load projects, roll-up expense totals, and the expense register.
try {
    $projectSql = "SELECT p.*, COALESCE(x.paid_amount,0) AS paid_amount, COALESCE(x.pending_amount,0) AS pending_amount, COALESCE(x.expense_count,0) AS expense_count FROM development_projects p LEFT JOIN (SELECT project_id, SUM(CASE WHEN status='paid' THEN amount ELSE 0 END) AS paid_amount, SUM(CASE WHEN status='pending' THEN amount ELSE 0 END) AS pending_amount, COUNT(*) AS expense_count FROM development_project_expenses GROUP BY project_id) x ON x.project_id=p.id WHERE 1=1";
    $params = [];
    $types = '';
    if ($filterSearch !== '') {
        $projectSql .= ' AND (p.project_no LIKE ? OR p.project_name LIKE ? OR p.category LIKE ? OR p.location LIKE ? OR p.contractor LIKE ?)';
        $like = '%' . $filterSearch . '%';
        for ($i = 0; $i < 5; $i++) $params[] = $like;
        $types .= 'sssss';
    }
    if ($filterStatus !== '' && in_array($filterStatus, ['planned','ongoing','on_hold','completed','cancelled'], true)) {
        $projectSql .= ' AND p.status=?'; $params[] = $filterStatus; $types .= 's';
    }
    if ($filterYear !== '' && preg_match('/^\d{4}$/', $filterYear)) {
        $projectSql .= ' AND (YEAR(p.start_date)=? OR YEAR(p.end_date)=? OR YEAR(p.created_at)=?)';
        $yearInt = (int)$filterYear; $params[] = $yearInt; $params[] = $yearInt; $params[] = $yearInt; $types .= 'iii';
    }
    $projectSql .= ' ORDER BY p.created_at DESC, p.id DESC';
    $stmt = $conn->prepare($projectSql);
    if ($types !== '') { $bind = [$types]; foreach ($params as $k => &$v) $bind[] = &$v; call_user_func_array([$stmt, 'bind_param'], $bind); }
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $row['_spent'] = (float)$row['paid_amount'];
        $row['_pending'] = (float)$row['pending_amount'];
        $row['_remaining'] = (float)$row['budget_amount'] - (float)$row['paid_amount'];
        $projects[] = $row;
        $totalBudgetAll += (float)$row['budget_amount'];
        $totalPaidAll += (float)$row['paid_amount'];
        $totalPendingAll += (float)$row['pending_amount'];
        if ($row['status'] === 'ongoing') $ongoingCount++;
        if ($row['status'] === 'completed') $completedCount++;
    }
    $stmt->close();
    $projectCount = count($projects);
    $projectPages = max(1, (int)ceil($projectCount / $perPage));
    if ($projectPage > $projectPages) $projectPage = $projectPages;
    $shownProjects = array_slice($projects, ($projectPage - 1) * $perPage, $perPage);

    $expenseSql = 'SELECT e.*, p.project_no, p.project_name FROM development_project_expenses e INNER JOIN development_projects p ON p.id=e.project_id WHERE 1=1';
    $expenseParams = [];
    $expenseTypes = '';
    if ($expenseSearch !== '') {
        $expenseSql .= ' AND (e.expense_no LIKE ? OR e.description LIKE ? OR e.supplier LIKE ? OR e.reference_no LIKE ? OR p.project_name LIKE ? OR p.project_no LIKE ?)';
        $el = '%' . $expenseSearch . '%';
        for ($i = 0; $i < 6; $i++) $expenseParams[] = $el;
        $expenseTypes .= 'ssssss';
    }
    if ($expenseProjectFilter > 0) { $expenseSql .= ' AND e.project_id=?'; $expenseParams[] = $expenseProjectFilter; $expenseTypes .= 'i'; }
    if ($expenseStatusFilter !== '' && in_array($expenseStatusFilter, ['paid','pending','cancelled'], true)) { $expenseSql .= ' AND e.status=?'; $expenseParams[] = $expenseStatusFilter; $expenseTypes .= 's'; }
    $expenseSql .= ' ORDER BY e.expense_date DESC, e.id DESC';
    $stmt = $conn->prepare($expenseSql);
    if ($expenseTypes !== '') { $bind = [$expenseTypes]; foreach ($expenseParams as $k => &$v) $bind[] = &$v; call_user_func_array([$stmt, 'bind_param'], $bind); }
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) $expenses[] = $row;
    $stmt->close();
    $expensePages = max(1, (int)ceil(count($expenses) / $perPage));
    if ($expensePage > $expensePages) $expensePage = $expensePages;
    $shownExpenses = array_slice($expenses, ($expensePage - 1) * $perPage, $perPage);
} catch (Throwable $e) {
    error_log('School development projects load error: ' . $e->getMessage());
    $pageError = 'Project information could not be loaded. Check the PHP error log. Details: ' . $e->getMessage();
}

$editId = max(0, (int)($_GET['edit'] ?? 0));
if ($editId > 0 && $schemaError === '') {
    foreach ($projects as $record) if ((int)$record['id'] === $editId) { $projectFormRecord = $record; break; }
}
$editExpenseId = max(0, (int)($_GET['edit_expense'] ?? 0));
if ($editExpenseId > 0 && $schemaError === '') {
    foreach ($expenses as $record) if ((int)$record['id'] === $editExpenseId) { $expenseFormRecord = $record; break; }
}
$yearOptions = [];
foreach ($projects as $p) {
    foreach (['start_date','end_date','created_at'] as $dateCol) if (!empty($p[$dateCol])) { $yr = date('Y', strtotime((string)$p[$dateCol])); $yearOptions[$yr] = $yr; }
}
if (!$yearOptions) $yearOptions[date('Y')] = date('Y');
uksort($yearOptions, static function($a,$b) { return (int)$b <=> (int)$a; });
$displayName = $_SESSION['full_name'] ?? $_SESSION['name'] ?? 'Administrator';
if (isset($_GET['export']) && $_GET['export'] === 'csv' && $schemaError === '' && $pageError === '') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="development_projects_' . date('Ymd') . '.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Project No.','Project Name','Category','Location','Contractor','Project Manager','Funding Source','Start Date','End Date','Budget UGX','Paid Expenses UGX','Pending Expenses UGX','Remaining UGX','Status']);
    foreach ($projects as $p) fputcsv($out, [$p['project_no'],$p['project_name'],$p['category'],$p['location'],$p['contractor'],$p['project_manager'],$p['funding_source'],$p['start_date'],$p['end_date'],number_format((float)$p['budget_amount'],2,'.',''),number_format((float)$p['_spent'],2,'.',''),number_format((float)$p['_pending'],2,'.',''),number_format((float)$p['_remaining'],2,'.',''),$p['status']]);
    fclose($out);
    exit;
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Development Projects | School Management System</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
:root{--navy:#17243a;--navy2:#243754;--bg:#f4f6fa;--blue:#2865cf;--muted:#778398}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:#263348;font-family:Arial,Helvetica,sans-serif}.sidebar{position:fixed;top:0;left:0;bottom:0;width:250px;background:var(--navy);color:#fff;overflow-y:auto;z-index:1040;padding:20px 0}.brand{padding:0 22px 22px;border-bottom:1px solid rgba(255,255,255,.12);margin-bottom:16px}.brand h5{margin:0;font-weight:700}.brand small{color:#b8c5d8}.nav-label{color:#95a7c0;text-transform:uppercase;font-size:10px;letter-spacing:1.2px;padding:14px 22px 5px}.sidebar a{color:#d8e1ed;display:block;padding:10px 22px;text-decoration:none;font-size:13px;border-left:3px solid transparent}.sidebar a i{width:22px}.sidebar a:hover,.sidebar a.active{background:var(--navy2);color:#fff;border-left-color:#70a7ff}.main{margin-left:250px;padding:26px;min-height:100vh}.topbar{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:22px}.topbar h2{font-size:25px;margin:0;font-weight:700;color:#192940}.subheading{color:var(--muted);font-size:13px;margin-top:5px}.panel{background:#fff;border-radius:10px;box-shadow:0 3px 15px rgba(24,42,70,.055);padding:22px;margin-bottom:22px;border:1px solid #edf0f5}.panel-title{font-size:17px;font-weight:700;margin-bottom:17px;color:#1d2d44}.stat-card{background:#fff;border:1px solid #edf0f5;border-radius:10px;padding:17px 19px;box-shadow:0 3px 15px rgba(24,42,70,.04);height:100%;min-height:112px}.stat-card .label{color:var(--muted);font-size:12px}.stat-card .value{font-size:22px;font-weight:700;margin-top:8px;overflow-wrap:anywhere}.stat-card .symbol{float:right;width:38px;height:38px;line-height:38px;text-align:center;border-radius:9px;background:#eef4ff;color:#326bd1}.form-control,.custom-select{font-size:13px;min-height:38px;border-radius:6px}label{font-size:12px;color:#4e5c70;font-weight:600}.table thead th{background:#f7f9fc;color:#68768a;font-size:10px;text-transform:uppercase;letter-spacing:.4px;border-top:0;white-space:nowrap}.table td{font-size:12px;vertical-align:middle}.btn{font-size:12px;border-radius:6px}.btn-primary{background:var(--blue);border-color:var(--blue)}.badge{font-size:10px;padding:6px 8px}.mobile-menu{display:none}.small-muted{font-size:11px;color:#8490a1}.money{white-space:nowrap;font-weight:700}.alert{font-size:13px}.progress{height:7px;min-width:70px}.project-name{font-size:13px;font-weight:700}.footer-note{text-align:center;color:#97a1b1;font-size:11px;padding:7px 0 0}.table td.detail{min-width:160px;max-width:260px;overflow-wrap:anywhere}.section-anchor{scroll-margin-top:20px}@media(max-width:991px){.sidebar{transform:translateX(-100%);transition:transform .2s}.sidebar.show{transform:translateX(0)}.main{margin-left:0;padding:18px}.mobile-menu{display:inline-block!important}.topbar h2{font-size:22px}.panel{padding:16px}}@media print{.sidebar,.no-print,.footer-note{display:none!important}.main{margin:0;padding:0}body{background:#fff}.panel,.stat-card{box-shadow:none;border:0}.topbar h2{font-size:18px}}
</style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<nav id="sidebar" class="sidebar no-print">
 <div class="brand"><h5><i class="fas fa-school mr-2"></i>School Management</h5><small>Administration &amp; Development</small></div>
 <div class="nav-label">Main</div><a href="/admin/dashboard.php"><i class="fas fa-tachometer-alt"></i>Admin Dashboard</a><a href="/admin/dashboard.php"><i class="fas fa-th-large"></i>Administration Home</a>
 <div class="nav-label">School Operations</div><a href="/admin/staff/index.php"><i class="fas fa-users"></i>Other Staff Members</a><a href="/admin/classes/notes.php"><i class="fas fa-book-open"></i>Subject Notes</a><a href="/admin/classes/projects.php"><i class="fas fa-tasks"></i>Student Projects</a><a href="/admin/classes/timetable.php"><i class="fas fa-calendar-alt"></i>Timetable</a>
 <div class="nav-label">Development &amp; Finance</div><a class="active" href="/admin/projects/index.php"><i class="fas fa-hard-hat"></i>Development Projects</a><a href="/admin/bursar/budgets.php"><i class="fas fa-wallet"></i>Budgets</a><a href="/admin/bursar/expenses.php"><i class="fas fa-file-invoice-dollar"></i>Expenses</a><a href="/admin/bursar/suppliers.php"><i class="fas fa-truck"></i>Suppliers</a><a href="/admin/bursar/cashbook.php"><i class="fas fa-book"></i>Cashbook</a>
 <div class="nav-label">Account</div><a href="/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
</nav>
<main class="main">
 <header class="topbar"><div class="d-flex align-items-start"><button type="button" id="mobileMenuBtn" class="btn btn-outline-secondary mobile-menu mr-3" aria-label="Open navigation"><i class="fas fa-bars"></i></button><div><div class="text-uppercase text-primary small font-weight-bold">Administration / development</div><h2>School Development Projects</h2><div class="subheading">Manage school construction, repairs, improvements, budgets and project expenses.</div></div></div><div class="no-print d-flex flex-wrap" style="gap:8px"><button type="button" onclick="window.print()" class="btn btn-outline-primary"><i class="fas fa-print mr-1"></i>Print</button><a class="btn btn-outline-success" href="?export=csv"><i class="fas fa-file-csv mr-1"></i>Export projects</a></div></header>
 <?php if ($createdTables): ?><div class="alert alert-info"><i class="fas fa-info-circle mr-1"></i>Created database table(s): <?= devProjectE(implode(', ', $createdTables)) ?>.</div><?php endif; ?>
 <?php if ($schemaError !== ''): ?><div class="alert alert-danger"><strong>Database setup error</strong><br><?= devProjectE($schemaError) ?></div><?php endif; ?>
 <?php if ($pageError !== ''): ?><div class="alert alert-warning"><?= devProjectE($pageError) ?></div><?php endif; ?>
 <?php if (is_array($flash) && !empty($flash['message'])): ?><div class="alert alert-<?= devProjectE($flash['type'] ?? 'info') ?> alert-dismissible fade show" role="alert"><?= devProjectE($flash['message']) ?><button type="button" class="close" data-dismiss="alert"><span>&times;</span></button></div><?php endif; ?>
 <div class="row mb-2">
  <div class="col-sm-6 col-xl-3 mb-3"><div class="stat-card"><span class="symbol"><i class="fas fa-project-diagram"></i></span><div class="label">Projects matching filters</div><div class="value text-primary"><?= number_format($projectCount) ?></div></div></div>
  <div class="col-sm-6 col-xl-3 mb-3"><div class="stat-card"><span class="symbol" style="background:#e1f7ef;color:#16845b"><i class="fas fa-play-circle"></i></span><div class="label">Ongoing projects</div><div class="value text-success"><?= number_format($ongoingCount) ?></div></div></div>
  <div class="col-sm-6 col-xl-3 mb-3"><div class="stat-card"><span class="symbol" style="background:#eef4ff;color:#326bd1"><i class="fas fa-wallet"></i></span><div class="label">Total allocated budgets</div><div class="value">UGX <?= number_format($totalBudgetAll, 2) ?></div></div></div>
  <div class="col-sm-6 col-xl-3 mb-3"><div class="stat-card"><span class="symbol" style="background:#fff0f1;color:#c33d4b"><i class="fas fa-money-bill-wave"></i></span><div class="label">Paid project expenses</div><div class="value text-danger">UGX <?= number_format($totalPaidAll, 2) ?></div><div class="small-muted">Pending: UGX <?= number_format($totalPendingAll, 2) ?></div></div></div>
 </div>
 <?php if ($schemaError === ''): ?>
 <section class="panel section-anchor no-print" id="projectForm"><div class="panel-title"><i class="fas fa-hard-hat text-primary mr-2"></i><?= $projectFormRecord ? 'Edit Development Project' : 'Register Development Project' ?></div>
  <form method="post" action="index.php#projectForm" id="projectEntryForm"><input type="hidden" name="csrf_token" value="<?= devProjectE($csrfToken) ?>"><input type="hidden" name="action" value="save_project"><input type="hidden" name="id" value="<?= (int)($projectFormRecord['id'] ?? 0) ?>">
   <div class="form-row"><div class="form-group col-lg-6"><label for="project_name">Project name <span class="text-danger">*</span></label><input required maxlength="180" class="form-control" id="project_name" name="project_name" value="<?= devProjectE($projectFormRecord['project_name'] ?? '') ?>" placeholder="e.g. Construction of a new classroom block"></div><div class="form-group col-lg-3 col-md-6"><label for="category">Category</label><select class="custom-select" id="category" name="category"><option value="">Choose category</option><?php foreach (['Construction','Renovation','Repairs and maintenance','Furniture and equipment','Water and sanitation','Electricity','ICT and connectivity','Sports facilities','Transport','Other'] as $cat): ?><option value="<?= devProjectE($cat) ?>" <?= ($projectFormRecord['category'] ?? '') === $cat ? 'selected' : '' ?>><?= devProjectE($cat) ?></option><?php endforeach; ?></select></div><div class="form-group col-lg-3 col-md-6"><label for="status">Project status</label><select class="custom-select" id="status" name="status"><?php foreach (['planned'=>'Planned','ongoing'=>'Ongoing','on_hold'=>'On hold','completed'=>'Completed','cancelled'=>'Cancelled'] as $value=>$label): ?><option value="<?= $value ?>" <?= ($projectFormRecord['status'] ?? 'planned') === $value ? 'selected' : '' ?>><?= $label ?></option><?php endforeach; ?></select></div></div>
   <div class="form-row"><div class="form-group col-lg-4 col-md-6"><label for="location">Project location / site</label><input class="form-control" id="location" name="location" value="<?= devProjectE($projectFormRecord['location'] ?? '') ?>" placeholder="e.g. Main campus, Block B"></div><div class="form-group col-lg-4 col-md-6"><label for="contractor">Contractor / supplier</label><input class="form-control" id="contractor" name="contractor" value="<?= devProjectE($projectFormRecord['contractor'] ?? '') ?>" placeholder="Company or individual"></div><div class="form-group col-lg-4 col-md-6"><label for="project_manager">Project manager / responsible person</label><input class="form-control" id="project_manager" name="project_manager" value="<?= devProjectE($projectFormRecord['project_manager'] ?? '') ?>" placeholder="Name of responsible person"></div></div>
   <div class="form-row"><div class="form-group col-md-3"><label for="start_date">Start date</label><input class="form-control" type="date" id="start_date" name="start_date" value="<?= devProjectE(isset($projectFormRecord['start_date']) ? substr((string)$projectFormRecord['start_date'],0,10) : '') ?>"></div><div class="form-group col-md-3"><label for="end_date">Expected completion</label><input class="form-control" type="date" id="end_date" name="end_date" value="<?= devProjectE(isset($projectFormRecord['end_date']) ? substr((string)$projectFormRecord['end_date'],0,10) : '') ?>"></div><div class="form-group col-md-3"><label for="budget_amount">Approved budget (UGX) <span class="text-danger">*</span></label><input class="form-control" type="number" min="0" step="0.01" required id="budget_amount" name="budget_amount" value="<?= isset($projectFormRecord['budget_amount']) ? devProjectE(number_format((float)$projectFormRecord['budget_amount'],2,'.','')) : '' ?>" placeholder="0.00"></div><div class="form-group col-md-3"><label for="funding_source">Funding source</label><input class="form-control" id="funding_source" name="funding_source" value="<?= devProjectE($projectFormRecord['funding_source'] ?? '') ?>" placeholder="School funds, grant, donor"></div></div>
   <div class="form-group"><label for="description">Project description / scope</label><textarea class="form-control" rows="2" id="description" name="description" placeholder="Objectives, work to be done, deliverables and notes"><?= devProjectE($projectFormRecord['description'] ?? '') ?></textarea></div>
   <button type="submit" class="btn btn-primary"><i class="fas fa-save mr-1"></i><?= $projectFormRecord ? 'Update project' : 'Save project' ?></button> <?php if ($projectFormRecord): ?><a class="btn btn-outline-secondary" href="index.php#projectForm">Cancel edit</a><?php else: ?><button type="reset" class="btn btn-outline-secondary">Clear form</button><?php endif; ?>
  </form>
 </section>
 <section class="panel section-anchor no-print" id="expenseForm"><div class="panel-title"><i class="fas fa-receipt text-danger mr-2"></i><?= $expenseFormRecord ? 'Edit Project Expense' : 'Record Project Expense' ?></div>
  <form method="post" action="index.php#expenseForm" id="expenseEntryForm"><input type="hidden" name="csrf_token" value="<?= devProjectE($csrfToken) ?>"><input type="hidden" name="action" value="save_expense"><input type="hidden" name="id" value="<?= (int)($expenseFormRecord['id'] ?? 0) ?>">
   <div class="form-row"><div class="form-group col-lg-4 col-md-6"><label for="expense_project_id">Development project <span class="text-danger">*</span></label><select required class="custom-select" name="project_id" id="expense_project_id"><option value="">Select project</option><?php foreach ($projects as $p): ?><option value="<?= (int)$p['id'] ?>" <?= (int)($expenseFormRecord['project_id'] ?? ($_GET['project_id'] ?? 0)) === (int)$p['id'] ? 'selected' : '' ?>><?= devProjectE($p['project_no'] . ' — ' . $p['project_name']) ?></option><?php endforeach; ?></select></div><div class="form-group col-lg-2 col-md-6"><label for="expense_date">Expense date <span class="text-danger">*</span></label><input required type="date" class="form-control" id="expense_date" name="expense_date" value="<?= devProjectE(isset($expenseFormRecord['expense_date']) ? substr((string)$expenseFormRecord['expense_date'],0,10) : date('Y-m-d')) ?>"></div><div class="form-group col-lg-3 col-md-6"><label for="expense_description">Description <span class="text-danger">*</span></label><input required maxlength="220" class="form-control" id="expense_description" name="description" value="<?= devProjectE($expenseFormRecord['description'] ?? '') ?>" placeholder="e.g. Cement and sand"></div><div class="form-group col-lg-3 col-md-6"><label for="expense_amount">Amount (UGX) <span class="text-danger">*</span></label><input required type="number" min="0.01" step="0.01" class="form-control" id="expense_amount" name="amount" value="<?= isset($expenseFormRecord['amount']) ? devProjectE(number_format((float)$expenseFormRecord['amount'],2,'.','')) : '' ?>" placeholder="0.00"></div></div>
   <div class="form-row"><div class="form-group col-lg-3 col-md-6"><label for="supplier">Supplier / payee</label><input class="form-control" id="supplier" name="supplier" value="<?= devProjectE($expenseFormRecord['supplier'] ?? '') ?>" placeholder="Supplier or payee"></div><div class="form-group col-lg-3 col-md-6"><label for="reference_no">Receipt / reference number</label><input class="form-control" id="reference_no" name="reference_no" value="<?= devProjectE($expenseFormRecord['reference_no'] ?? '') ?>" placeholder="Receipt or transaction ID"></div><div class="form-group col-lg-3 col-md-6"><label for="payment_method">Payment method</label><select class="custom-select" id="payment_method" name="payment_method"><?php foreach ([''=>'Choose method','Cash'=>'Cash','Bank transfer'=>'Bank transfer','Cheque'=>'Cheque','Mobile money'=>'Mobile money','Card / POS'=>'Card / POS','Other'=>'Other'] as $val=>$label): ?><option value="<?= devProjectE($val) ?>" <?= ($expenseFormRecord['payment_method'] ?? '') === $val ? 'selected' : '' ?>><?= devProjectE($label) ?></option><?php endforeach; ?></select></div><div class="form-group col-lg-3 col-md-6"><label for="expense_status">Expense status</label><select class="custom-select" id="expense_status" name="status"><?php foreach (['paid'=>'Paid','pending'=>'Pending','cancelled'=>'Cancelled'] as $val=>$label): ?><option value="<?= $val ?>" <?= ($expenseFormRecord['status'] ?? 'paid') === $val ? 'selected' : '' ?>><?= $label ?></option><?php endforeach; ?></select></div></div>
   <button type="submit" class="btn btn-danger"><i class="fas fa-save mr-1"></i><?= $expenseFormRecord ? 'Update expense' : 'Record expense' ?></button> <?php if ($expenseFormRecord): ?><a href="index.php#expenseForm" class="btn btn-outline-secondary">Cancel edit</a><?php endif; ?>
  </form>
 </section>
 <?php endif; ?>
 <section class="panel"><div class="d-flex flex-wrap justify-content-between align-items-center mb-3"><div class="panel-title mb-1"><i class="fas fa-list text-primary mr-2"></i>Development Project Register</div><span class="small text-muted mb-2"><?= number_format($projectCount) ?> project(s)</span></div>
  <form method="get" action="index.php" class="form-row align-items-end mb-3 no-print"><div class="form-group col-lg-5 col-md-6 mb-2"><label for="q">Search projects</label><input class="form-control" type="search" name="q" id="q" value="<?= devProjectE($filterSearch) ?>" placeholder="Project number, name, site, contractor"></div><div class="form-group col-lg-2 col-md-3 mb-2"><label for="status_filter">Status</label><select class="custom-select" name="status" id="status_filter"><option value="">All statuses</option><?php foreach (['planned'=>'Planned','ongoing'=>'Ongoing','on_hold'=>'On hold','completed'=>'Completed','cancelled'=>'Cancelled'] as $value=>$label): ?><option value="<?= $value ?>" <?= $filterStatus===$value?'selected':'' ?>><?= $label ?></option><?php endforeach; ?></select></div><div class="form-group col-lg-2 col-md-3 mb-2"><label for="year">Year</label><select class="custom-select" name="year" id="year"><option value="">All years</option><?php foreach ($yearOptions as $year): ?><option value="<?= devProjectE($year) ?>" <?= $filterYear===$year?'selected':'' ?>><?= devProjectE($year) ?></option><?php endforeach; ?></select></div><div class="form-group col-lg-3 mb-2"><button class="btn btn-primary" type="submit"><i class="fas fa-search mr-1"></i>Filter</button> <a class="btn btn-outline-secondary" href="index.php">Reset</a></div></form>
  <div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Project</th><th>Site / responsible person</th><th>Period</th><th class="text-right">Budget (UGX)</th><th class="text-right">Paid (UGX)</th><th class="text-right">Remaining (UGX)</th><th>Status</th><th class="no-print">Actions</th></tr></thead><tbody>
  <?php if (!$shownProjects): ?><tr><td colspan="8" class="text-center text-muted py-4"><i class="fas fa-hard-hat fa-2x mb-2"></i><br>No development projects found. Add your first project using the form above.</td></tr><?php else: foreach ($shownProjects as $p): $spentPct=(float)$p['budget_amount']>0?min(100,max(0,((float)$p['_spent']/(float)$p['budget_amount'])*100)):0; $badge=in_array($p['status'],['ongoing'],true)?'success':(in_array($p['status'],['completed'],true)?'primary':(in_array($p['status'],['cancelled'],true)?'danger':(in_array($p['status'],['on_hold'],true)?'secondary':'warning'))); ?>
   <tr><td class="detail"><div class="project-name"><?= devProjectE($p['project_name']) ?></div><div class="small-muted"><?= devProjectE($p['project_no']) ?><?= $p['category'] ? ' · '.devProjectE($p['category']) : '' ?></div><?php if ($p['description']): ?><div class="small-muted mt-1"><?= devProjectE(mb_strimwidth((string)$p['description'],0,100,'…')) ?></div><?php endif; ?><div class="progress mt-2"><div class="progress-bar <?= $spentPct>=100?'bg-danger':'bg-info' ?>" style="width:<?= $spentPct ?>%" role="progressbar" aria-valuenow="<?= (int)$spentPct ?>" aria-valuemin="0" aria-valuemax="100"></div></div><div class="small-muted"><?= number_format($spentPct,1) ?>% of budget spent · <?= (int)$p['expense_count'] ?> expense(s)</div></td><td><?= devProjectE($p['location'] ?: '—') ?><div class="small-muted"><?= devProjectE($p['project_manager'] ?: 'No manager assigned') ?></div><?php if ($p['contractor']): ?><div class="small-muted">Contractor: <?= devProjectE($p['contractor']) ?></div><?php endif; ?></td><td class="text-nowrap"><?= $p['start_date'] ? devProjectE(date('d M Y',strtotime($p['start_date']))) : 'Not set' ?><div class="small-muted">to <?= $p['end_date'] ? devProjectE(date('d M Y',strtotime($p['end_date']))) : 'Not set' ?></div></td><td class="text-right money"><?= number_format((float)$p['budget_amount'],2) ?></td><td class="text-right money text-danger"><?= number_format((float)$p['_spent'],2) ?><?php if ((float)$p['_pending']>0): ?><div class="small-muted">Pending: <?= number_format((float)$p['_pending'],2) ?></div><?php endif; ?></td><td class="text-right money <?= (float)$p['_remaining']<0?'text-danger':'text-success' ?>"><?= number_format((float)$p['_remaining'],2) ?></td><td><span class="badge badge-<?= $badge ?>"><?= devProjectE(ucwords(str_replace('_',' ',$p['status']))) ?></span></td><td class="no-print text-nowrap"><a class="btn btn-sm btn-outline-primary mb-1" href="?edit=<?= (int)$p['id'] ?>#projectForm" title="Edit project"><i class="fas fa-edit"></i></a> <a class="btn btn-sm btn-outline-danger mb-1" href="?project_id=<?= (int)$p['id'] ?>#expenseForm" title="Record expense"><i class="fas fa-receipt"></i></a><div class="dropdown d-inline"><button class="btn btn-sm btn-outline-secondary dropdown-toggle mb-1" type="button" data-toggle="dropdown">Status</button><div class="dropdown-menu dropdown-menu-right"><?php foreach (['planned'=>'Planned','ongoing'=>'Ongoing','on_hold'=>'On hold','completed'=>'Completed','cancelled'=>'Cancelled'] as $sv=>$sl): if ($sv===$p['status']) continue; ?><form method="post" action="index.php"><input type="hidden" name="csrf_token" value="<?= devProjectE($csrfToken) ?>"><input type="hidden" name="action" value="change_project_status"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><input type="hidden" name="status" value="<?= $sv ?>"><button type="submit" class="dropdown-item"><?= devProjectE($sl) ?></button></form><?php endforeach; ?></div></div><form method="post" action="index.php" class="d-inline" onsubmit="return confirm('Delete this project? Projects with expense records cannot be deleted.');"><input type="hidden" name="csrf_token" value="<?= devProjectE($csrfToken) ?>"><input type="hidden" name="action" value="delete_project"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button type="submit" class="btn btn-sm btn-outline-dark mb-1" title="Delete"><i class="fas fa-trash"></i></button></form></td></tr>
  <?php endforeach; endif; ?></tbody></table></div>
  <?php if ($projectPages>1): $query=$_GET; unset($query['export']); ?><nav class="no-print mt-3"><ul class="pagination mb-0 flex-wrap"><?php $query['p']=max(1,$projectPage-1); ?><li class="page-item <?= $projectPage<=1?'disabled':'' ?>"><a class="page-link" href="?<?= devProjectE(http_build_query($query)) ?>">Previous</a></li><?php for($i=max(1,$projectPage-2);$i<=min($projectPages,$projectPage+2);$i++):$query['p']=$i; ?><li class="page-item <?= $i===$projectPage?'active':'' ?>"><a class="page-link" href="?<?= devProjectE(http_build_query($query)) ?>"><?= $i ?></a></li><?php endfor; $query['p']=min($projectPages,$projectPage+1); ?><li class="page-item <?= $projectPage>=$projectPages?'disabled':'' ?>"><a class="page-link" href="?<?= devProjectE(http_build_query($query)) ?>">Next</a></li></ul></nav><?php endif; ?>
 </section>
 <section class="panel"><div class="d-flex flex-wrap justify-content-between align-items-center mb-3"><div><div class="panel-title mb-1"><i class="fas fa-receipt text-danger mr-2"></i>Project Expense Register</div><div class="small text-muted"><?= number_format(count($expenses)) ?> matching expense record(s)</div></div><a class="btn btn-outline-secondary btn-sm no-print" href="index.php#expenseForm"><i class="fas fa-plus mr-1"></i>New expense</a></div>
  <form method="get" action="index.php" class="form-row align-items-end mb-3 no-print"><div class="form-group col-lg-4 col-md-6"><label for="expense_q">Search expenses</label><input class="form-control" type="search" name="expense_q" id="expense_q" value="<?= devProjectE($expenseSearch) ?>" placeholder="Expense no., project, payee, reference"></div><div class="form-group col-lg-4 col-md-6"><label for="expense_project">Project</label><select class="custom-select" name="expense_project" id="expense_project"><option value="">All projects</option><?php foreach ($projects as $p): ?><option value="<?= (int)$p['id'] ?>" <?= $expenseProjectFilter===(int)$p['id']?'selected':'' ?>><?= devProjectE($p['project_no'].' — '.$p['project_name']) ?></option><?php endforeach; ?></select></div><div class="form-group col-lg-2 col-md-6"><label for="expense_status_filter">Status</label><select class="custom-select" name="expense_status" id="expense_status_filter"><option value="">All</option><?php foreach (['paid'=>'Paid','pending'=>'Pending','cancelled'=>'Cancelled'] as $v=>$l): ?><option value="<?= $v ?>" <?= $expenseStatusFilter===$v?'selected':'' ?>><?= $l ?></option><?php endforeach; ?></select></div><div class="form-group col-lg-2 col-md-6"><button class="btn btn-primary" type="submit"><i class="fas fa-search mr-1"></i>Filter</button> <a class="btn btn-outline-secondary" href="index.php#expenseForm">Reset</a></div></form>
  <div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Date</th><th>Expense / Description</th><th>Project</th><th>Supplier / Reference</th><th>Method</th><th class="text-right">Amount (UGX)</th><th>Status</th><th class="no-print">Actions</th></tr></thead><tbody><?php if (!$shownExpenses): ?><tr><td colspan="8" class="text-center text-muted py-4">No project expenses found.</td></tr><?php else: foreach ($shownExpenses as $e): ?><tr><td class="text-nowrap"><?= devProjectE(date('d M Y',strtotime($e['expense_date']))) ?></td><td class="detail"><strong><?= devProjectE($e['description']) ?></strong><div class="small-muted"><?= devProjectE($e['expense_no']) ?></div></td><td class="detail"><?= devProjectE($e['project_name']) ?><div class="small-muted"><?= devProjectE($e['project_no']) ?></div></td><td><?= devProjectE($e['supplier'] ?: '—') ?><?php if ($e['reference_no']): ?><div class="small-muted">Ref: <?= devProjectE($e['reference_no']) ?></div><?php endif; ?></td><td><?= devProjectE($e['payment_method'] ?: '—') ?></td><td class="text-right money"> <?= number_format((float)$e['amount'],2) ?></td><td><span class="badge badge-<?= $e['status']==='paid'?'success':($e['status']==='cancelled'?'secondary':'warning') ?>"><?= devProjectE(ucfirst($e['status'])) ?></span></td><td class="no-print text-nowrap"><a class="btn btn-sm btn-outline-primary" href="?edit_expense=<?= (int)$e['id'] ?>#expenseForm" title="Edit expense"><i class="fas fa-edit"></i></a> <form class="d-inline" method="post" action="index.php" onsubmit="return confirm('Delete this expense record?');"><input type="hidden" name="csrf_token" value="<?= devProjectE($csrfToken) ?>"><input type="hidden" name="action" value="delete_expense"><input type="hidden" name="id" value="<?= (int)$e['id'] ?>"><button class="btn btn-sm btn-outline-danger" title="Delete expense"><i class="fas fa-trash"></i></button></form></td></tr><?php endforeach; endif; ?></tbody></table></div>
  <?php if($expensePages>1):$query=$_GET;unset($query['export']);?><nav class="no-print mt-3"><ul class="pagination mb-0 flex-wrap"><?php $query['ep']=max(1,$expensePage-1);?><li class="page-item <?= $expensePage<=1?'disabled':'' ?>"><a class="page-link" href="?<?= devProjectE(http_build_query($query)) ?>#expenses">Previous</a></li><?php for($i=max(1,$expensePage-2);$i<=min($expensePages,$expensePage+2);$i++):$query['ep']=$i;?><li class="page-item <?= $i===$expensePage?'active':'' ?>"><a class="page-link" href="?<?= devProjectE(http_build_query($query)) ?>#expenses"><?= $i ?></a></li><?php endfor;$query['ep']=min($expensePages,$expensePage+1);?><li class="page-item <?= $expensePage>=$expensePages?'disabled':'' ?>"><a class="page-link" href="?<?= devProjectE(http_build_query($query)) ?>#expenses">Next</a></li></ul></nav><?php endif; ?>
 </section>
 <div class="footer-note">School Management System — Development Projects &amp; Project Expenses</div>
</main>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function(){var sidebar=document.getElementById('sidebar'),button=document.getElementById('mobileMenuBtn');if(button&&sidebar)button.addEventListener('click',function(){sidebar.classList.toggle('show');});document.addEventListener('click',function(e){if(window.innerWidth<=991&&sidebar&&sidebar.classList.contains('show')&&!sidebar.contains(e.target)&&button&&!button.contains(e.target))sidebar.classList.remove('show');});var form=document.getElementById('projectEntryForm');if(form)form.addEventListener('submit',function(){var b=form.querySelector('button[type="submit"]');if(b){b.disabled=true;b.innerHTML='<i class="fas fa-spinner fa-spin mr-1"></i>Saving...';}});})();
</script>
</body>
</html>
