<?php
$_GET['id']=0;
require __DIR__ . '/book_form.php';
?>
