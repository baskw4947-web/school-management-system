<?php
require_once __DIR__ . '/_bootstrap.php';
lib_require_management();

function lib_count(mysqli $db, string $sql): int {
    $r = $db->query($sql);
    if (!$r) return 0;
    return (int)($r->fetch_row()[0] ?? 0);
}
$stats = [
 'books'=>lib_count($libDb,"SELECT COUNT(*) FROM library_books WHERE status='active'"),
 'copies'=>lib_count($libDb,"SELECT COUNT(*) FROM library_book_copies"),
 'available'=>lib_count($libDb,"SELECT COUNT(*) FROM library_book_copies WHERE availability_status='available'"),
 'borrowed'=>lib_count($libDb,"SELECT COUNT(*) FROM library_loans WHERE loan_status='borrowed'"),
 'overdue'=>lib_count($libDb,"SELECT COUNT(*) FROM library_loans WHERE loan_status IN ('borrowed','overdue') AND due_date<CURDATE()"),
 'members'=>lib_count($libDb,"SELECT COUNT(*) FROM library_members WHERE status='active'")
];
$recent = lib_fetch_all($libDb,"SELECT l.id,l.issue_date,l.due_date,l.loan_status,b.book_title,c.accession_number,m.membership_number,m.member_type,m.member_id FROM library_loans l JOIN library_book_copies c ON c.id=l.copy_id JOIN library_books b ON b.id=c.book_id JOIN library_members m ON m.id=l.member_id ORDER BY l.id DESC LIMIT 8");
lib_page_start('Library Dashboard','index');
?>
<div class="row">
<?php foreach (['books'=>'Active book titles','copies'=>'Physical copies','available'=>'Available copies','borrowed'=>'Currently borrowed','overdue'=>'Overdue loans','members'=>'Active members'] as $key=>$label): ?>
<div class="col-sm-6 col-lg-4 mb-3"><div class="lib-stat"><i class="fas fa-book lib-icon"></i><strong><?= number_format($stats[$key]) ?></strong><span><?= lib_h($label) ?></span></div></div>
<?php endforeach; ?>
</div>
<div class="lib-panel">
 <div class="d-flex justify-content-between align-items-center flex-wrap mb-3"><h5 class="mb-2">Quick actions</h5><div class="no-print"><a class="btn btn-primary btn-sm" href="add_book.php"><i class="fas fa-plus"></i> Add book</a> <a class="btn btn-success btn-sm" href="issue_book.php"><i class="fas fa-hand-holding"></i> Issue book</a></div></div>
 <div class="row">
 <?php foreach ([['books.php','Books','fa-book'],['categories.php','Categories','fa-list'],['copies.php','Book copies','fa-copy'],['members.php','Members','fa-users'],['borrowed_books.php','Borrowed books','fa-book-open'],['reports.php','Library reports','fa-chart-bar']] as $item): ?>
 <div class="col-md-4 col-lg-2 mb-2"><a href="<?= lib_h($item[0]) ?>" class="btn btn-outline-primary btn-block h-100"><i class="fas <?= lib_h($item[2]) ?> d-block mb-2"></i><?= lib_h($item[1]) ?></a></div>
 <?php endforeach; ?>
 </div>
</div>
<div class="lib-panel"><h5>Recent borrowing activity</h5><div class="table-responsive"><table class="table table-bordered table-hover"><thead><tr><th>Book</th><th>Copy</th><th>Member</th><th>Issued</th><th>Due</th><th>Status</th></tr></thead><tbody>
<?php if (!$recent): ?><tr><td colspan="6" class="text-center text-muted">No borrowing records yet.</td></tr><?php endif; ?>
<?php foreach($recent as $r): ?><tr><td><?= lib_h($r['book_title']) ?></td><td><?= lib_h($r['accession_number']) ?></td><td><?= lib_h(ucfirst($r['member_type']).' #'.$r['member_id']) ?></td><td><?= lib_h($r['issue_date']) ?></td><td><?= lib_h($r['due_date']) ?></td><td><?= lib_h(ucfirst($r['loan_status'])) ?></td></tr><?php endforeach; ?>
</tbody></table></div></div>
<?php lib_page_end(); ?>
