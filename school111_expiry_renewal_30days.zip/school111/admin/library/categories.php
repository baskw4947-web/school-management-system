<?php
require_once __DIR__ . '/_bootstrap.php'; lib_require_management();
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){lib_check_csrf();$name=trim($_POST['category_name']??'');$desc=trim($_POST['description']??'');if($name==='')$error='Category name is required.';else{$st=$libDb->prepare("INSERT INTO library_categories(category_name,description) VALUES(?,?)");$st->bind_param('ss',$name,$desc);if($st->execute()){ $st->close();lib_flash('success','Category added.');lib_redirect('categories.php');}$error='Could not add category: '.$st->error;$st->close();}}
$rows=lib_fetch_all($libDb,"SELECT c.*, (SELECT COUNT(*) FROM library_books b WHERE b.category_id=c.id) book_count FROM library_categories c ORDER BY category_name");
lib_page_start('Book Categories','categories');
?>
<div class="lib-panel"><h5>Add category</h5><?php if($error): ?><div class="alert alert-danger"><?= lib_h($error) ?></div><?php endif; ?><form method="post" class="form-row"><input type="hidden" name="csrf_token" value="<?= lib_h(lib_csrf_token()) ?>"><div class="form-group col-md-4"><input class="form-control" name="category_name" required placeholder="e.g. Mathematics"></div><div class="form-group col-md-6"><input class="form-control" name="description" placeholder="Description"></div><div class="form-group col-md-2"><button class="btn btn-primary btn-block">Add</button></div></form></div>
<div class="lib-panel"><h5>Categories</h5><div class="table-responsive"><table class="table table-bordered"><thead><tr><th>Category</th><th>Description</th><th>Books</th><th>Status</th></tr></thead><tbody><?php foreach($rows as $r): ?><tr><td><?= lib_h($r['category_name']) ?></td><td><?= lib_h($r['description']) ?></td><td><?= (int)$r['book_count'] ?></td><td><?= lib_h($r['status']) ?></td></tr><?php endforeach; ?><?php if(!$rows): ?><tr><td colspan="4">No categories added.</td></tr><?php endif; ?></tbody></table></div></div>
<?php lib_page_end(); ?>
