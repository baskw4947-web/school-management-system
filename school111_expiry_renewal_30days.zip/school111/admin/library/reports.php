<?php
require_once __DIR__ . '/_bootstrap.php';lib_require_management();
$summary=lib_fetch_all($libDb,"SELECT COUNT(*) AS titles FROM library_books");
$categories=lib_fetch_all($libDb,"SELECT c.category_name,COUNT(b.id) AS titles FROM library_categories c LEFT JOIN library_books b ON b.category_id=c.id GROUP BY c.id ORDER BY c.category_name");
$loans=lib_fetch_all($libDb,"SELECT COUNT(*) AS total_loans, SUM(loan_status='returned') AS returned_count, SUM(loan_status IN ('borrowed','overdue')) AS open_count FROM library_loans");
$fines=lib_fetch_all($libDb,"SELECT COALESCE(SUM(amount),0) AS charged,COALESCE(SUM(amount_paid),0) AS paid FROM library_fines");
lib_page_start('Library Reports','reports');
?>
<div class="lib-panel"><div class="d-flex justify-content-between"><h5>Library summary report</h5><button onclick="window.print()" class="btn btn-outline-primary btn-sm no-print"><i class="fas fa-print"></i> Print</button></div>
<?php $l=$loans[0]??[];$f=$fines[0]??[]; ?>
<div class="row mt-3">
<div class="col-md-3 mb-3"><div class="lib-stat"><strong><?= (int)($summary[0]['titles']??0) ?></strong><span>Book titles</span></div></div>
<div class="col-md-3 mb-3"><div class="lib-stat"><strong><?= (int)($l['total_loans']??0) ?></strong><span>Total loans</span></div></div>
<div class="col-md-3 mb-3"><div class="lib-stat"><strong><?= (int)($l['returned_count']??0) ?></strong><span>Returned loans</span></div></div>
<div class="col-md-3 mb-3"><div class="lib-stat"><strong><?= (int)($l['open_count']??0) ?></strong><span>Open loans</span></div></div>
</div>
<h6 class="mt-3">Fines summary (UGX)</h6><p>Charged: <strong><?= number_format((float)($f['charged']??0)) ?></strong> &nbsp; Paid: <strong><?= number_format((float)($f['paid']??0)) ?></strong> &nbsp; Outstanding: <strong><?= number_format((float)($f['charged']??0)-(float)($f['paid']??0)) ?></strong></p>
<h6 class="mt-4">Books by category</h6><div class="table-responsive"><table class="table table-bordered"><thead><tr><th>Category</th><th>Book titles</th></tr></thead><tbody><?php foreach($categories as $c): ?><tr><td><?= lib_h($c['category_name']) ?></td><td><?= (int)$c['titles'] ?></td></tr><?php endforeach; ?><?php if(!$categories): ?><tr><td colspan="2">No categories recorded.</td></tr><?php endif; ?></tbody></table></div></div>
<?php lib_page_end(); ?>
