<?php
require_once __DIR__ . '/_bootstrap.php';
lib_require_management();
$search=trim((string)($_GET['search']??''));
$sql="SELECT b.*,c.category_name,(SELECT COUNT(*) FROM library_book_copies cp WHERE cp.book_id=b.id) AS total_copies,(SELECT COUNT(*) FROM library_book_copies cp WHERE cp.book_id=b.id AND cp.availability_status='available') AS available_copies FROM library_books b LEFT JOIN library_categories c ON c.id=b.category_id";
if($search!==''){
 $like='%'.$libDb->real_escape_string($search).'%';
 $sql.=" WHERE b.book_title LIKE '$like' OR b.author LIKE '$like' OR b.isbn LIKE '$like' OR c.category_name LIKE '$like'";
}
$sql.=" ORDER BY b.book_title";
$books=lib_fetch_all($libDb,$sql);
lib_page_start('Books','books');
?>
<div class="lib-panel">
<div class="d-flex justify-content-between flex-wrap mb-3"><h5>Book catalogue</h5><a href="add_book.php" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Add book</a></div>
<form class="form-inline mb-3"><input class="form-control mr-2 mb-2" name="search" value="<?= lib_h($search) ?>" placeholder="Search title, author, ISBN or category"><button class="btn btn-outline-primary mb-2">Search</button><a class="btn btn-light ml-2 mb-2" href="books.php">Reset</a></form>
<div class="table-responsive"><table class="table table-bordered table-hover"><thead><tr><th>Title</th><th>Author</th><th>ISBN</th><th>Category</th><th>Copies</th><th>Available</th><th>Status</th><th>Actions</th></tr></thead><tbody>
<?php if(!$books): ?><tr><td colspan="8" class="text-center">No books found.</td></tr><?php endif; ?>
<?php foreach($books as $b): ?><tr><td><?= lib_h($b['book_title']) ?></td><td><?= lib_h($b['author']) ?></td><td><?= lib_h($b['isbn']) ?></td><td><?= lib_h($b['category_name']??'Uncategorised') ?></td><td><?= (int)$b['total_copies'] ?></td><td><?= (int)$b['available_copies'] ?></td><td><?= lib_h($b['status']) ?></td><td class="text-nowrap"><a class="btn btn-sm btn-info" href="edit_book.php?id=<?= (int)$b['id'] ?>">Edit</a> <a class="btn btn-sm btn-secondary" href="copies.php?book_id=<?= (int)$b['id'] ?>">Copies</a></td></tr><?php endforeach; ?>
</tbody></table></div></div>
<?php lib_page_end(); ?>
