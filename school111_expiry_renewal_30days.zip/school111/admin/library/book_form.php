<?php
require_once __DIR__ . '/_bootstrap.php';
lib_require_management();
$id=(int)($_GET['id']??0);
$book=['category_id'=>'','isbn'=>'','book_title'=>'','author'=>'','publisher'=>'','publication_year'=>'','edition'=>'','language'=>'English','description'=>'','shelf_location'=>'','status'=>'active'];
if($id){$st=$libDb->prepare("SELECT category_id,isbn,book_title,author,publisher,publication_year,edition,language,description,shelf_location,status FROM library_books WHERE id=?");$st->bind_param('i',$id);$st->execute();$row=$st->get_result()->fetch_assoc();$st->close();if(!$row){http_response_code(404);exit('Book not found.');}$book=$row;}
$categories=lib_fetch_all($libDb,"SELECT id,category_name FROM library_categories WHERE status='active' ORDER BY category_name");
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 lib_check_csrf();
 $category=(int)($_POST['category_id']??0);$isbn=trim($_POST['isbn']??'');$title=trim($_POST['book_title']??'');$author=trim($_POST['author']??'');$publisher=trim($_POST['publisher']??'');$year=trim($_POST['publication_year']??'');$edition=trim($_POST['edition']??'');$language=trim($_POST['language']??'English');$description=trim($_POST['description']??'');$shelf=trim($_POST['shelf_location']??'');$status=$_POST['status']??'active';
 if($title===''){$error='Book title is required.';}
 elseif(!in_array($status,['active','inactive'],true)){$error='Invalid status.';}
 else{
  $catVal=$category?:null;$isbnVal=$isbn?:null;$yearVal=($year!=='' && ctype_digit($year) && (int)$year>=1901 && (int)$year<=2155)?(int)$year:null;
  if($id){$st=$libDb->prepare("UPDATE library_books SET category_id=?,isbn=?,book_title=?,author=?,publisher=?,publication_year=?,edition=?,language=?,description=?,shelf_location=?,status=? WHERE id=?");$st->bind_param('issssisssssi',$catVal,$isbnVal,$title,$author,$publisher,$yearVal,$edition,$language,$description,$shelf,$status,$id);}
  else{$st=$libDb->prepare("INSERT INTO library_books(category_id,isbn,book_title,author,publisher,publication_year,edition,language,description,shelf_location,status) VALUES(?,?,?,?,?,?,?,?,?,?,?)");$st->bind_param('issssisssss',$catVal,$isbnVal,$title,$author,$publisher,$yearVal,$edition,$language,$description,$shelf,$status);}
  if($st->execute()){$st->close();lib_flash('success','Book saved successfully.');lib_redirect('books.php');}
  $error='Could not save book: '.$st->error;$st->close();
 }
 $book=compact('category','isbn','title','author','publisher','year','edition','language','description','shelf','status');
 $book=array_merge(['category_id'=>$category??'','isbn'=>$isbn??'','book_title'=>$title??'','author'=>$author??'','publisher'=>$publisher??'','publication_year'=>$year??'','edition'=>$edition??'','language'=>$language??'','description'=>$description??'','shelf_location'=>$shelf??'','status'=>$status??'active'],$book);
}
lib_page_start($id?'Edit Book':'Add Book','books');
?>
<div class="lib-panel"><h5><?= $id?'Edit book':'Register a new book' ?></h5>
<?php if($error): ?><div class="alert alert-danger"><?= lib_h($error) ?></div><?php endif; ?>
<form method="post"><input type="hidden" name="csrf_token" value="<?= lib_h(lib_csrf_token()) ?>">
<div class="form-row">
<div class="form-group col-md-8"><label>Book title *</label><input required name="book_title" class="form-control" value="<?= lib_h($book['book_title']) ?>"></div>
<div class="form-group col-md-4"><label>Category</label><select name="category_id" class="form-control"><option value="">Uncategorised</option><?php foreach($categories as $c): ?><option value="<?= (int)$c['id'] ?>" <?= (string)$book['category_id']===(string)$c['id']?'selected':'' ?>><?= lib_h($c['category_name']) ?></option><?php endforeach; ?></select></div>
<div class="form-group col-md-4"><label>ISBN</label><input name="isbn" class="form-control" value="<?= lib_h($book['isbn']) ?>"></div>
<div class="form-group col-md-4"><label>Author</label><input name="author" class="form-control" value="<?= lib_h($book['author']) ?>"></div>
<div class="form-group col-md-4"><label>Publisher</label><input name="publisher" class="form-control" value="<?= lib_h($book['publisher']) ?>"></div>
<div class="form-group col-md-3"><label>Publication year</label><input type="number" min="1901" max="2155" name="publication_year" class="form-control" value="<?= lib_h($book['publication_year']) ?>"></div>
<div class="form-group col-md-3"><label>Edition</label><input name="edition" class="form-control" value="<?= lib_h($book['edition']) ?>"></div>
<div class="form-group col-md-3"><label>Language</label><input name="language" class="form-control" value="<?= lib_h($book['language']) ?>"></div>
<div class="form-group col-md-3"><label>Shelf location</label><input name="shelf_location" class="form-control" value="<?= lib_h($book['shelf_location']) ?>"></div>
<div class="form-group col-md-6"><label>Status</label><select name="status" class="form-control"><option value="active" <?= $book['status']==='active'?'selected':'' ?>>Active</option><option value="inactive" <?= $book['status']==='inactive'?'selected':'' ?>>Inactive</option></select></div>
<div class="form-group col-12"><label>Description</label><textarea name="description" class="form-control" rows="3"><?= lib_h($book['description']) ?></textarea></div>
</div><button class="btn btn-primary">Save book</button> <a href="books.php" class="btn btn-secondary">Cancel</a></form></div>
<?php lib_page_end(); ?>
