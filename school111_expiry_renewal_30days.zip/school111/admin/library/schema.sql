-- Run this SQL once in the School Management database using phpMyAdmin.
CREATE TABLE IF NOT EXISTS library_categories (
 id INT AUTO_INCREMENT PRIMARY KEY,
 category_name VARCHAR(150) NOT NULL UNIQUE,
 description TEXT NULL,
 status ENUM('active','inactive') DEFAULT 'active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS library_books (
 id INT AUTO_INCREMENT PRIMARY KEY,
 category_id INT NULL,
 isbn VARCHAR(50) NULL UNIQUE,
 book_title VARCHAR(255) NOT NULL,
 author VARCHAR(180) NULL,
 publisher VARCHAR(180) NULL,
 publication_year YEAR NULL,
 edition VARCHAR(100) NULL,
 language VARCHAR(80) DEFAULT 'English',
 description TEXT NULL,
 shelf_location VARCHAR(100) NULL,
 cover_image VARCHAR(255) NULL,
 status ENUM('active','inactive') DEFAULT 'active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_book_title (book_title),
 INDEX idx_book_category (category_id),
 CONSTRAINT fk_library_book_category FOREIGN KEY (category_id) REFERENCES library_categories(id) ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS library_book_copies (
 id INT AUTO_INCREMENT PRIMARY KEY,
 book_id INT NOT NULL,
 accession_number VARCHAR(100) NOT NULL UNIQUE,
 purchase_date DATE NULL,
 purchase_price DECIMAL(12,2) DEFAULT 0.00,
 condition_status ENUM('new','good','fair','damaged','lost') DEFAULT 'good',
 availability_status ENUM('available','borrowed','reserved','lost','damaged') DEFAULT 'available',
 notes TEXT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_copy_book (book_id),
 INDEX idx_copy_status (availability_status),
 CONSTRAINT fk_library_copy_book FOREIGN KEY (book_id) REFERENCES library_books(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS library_members (
 id INT AUTO_INCREMENT PRIMARY KEY,
 member_type ENUM('student','teacher','staff') NOT NULL,
 member_id INT NOT NULL,
 membership_number VARCHAR(100) NOT NULL UNIQUE,
 registration_date DATE NULL,
 status ENUM('active','inactive','suspended') DEFAULT 'active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY unique_library_member (member_type,member_id),
 INDEX idx_membership_type (member_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS library_loans (
 id INT AUTO_INCREMENT PRIMARY KEY,
 copy_id INT NOT NULL,
 member_id INT NOT NULL,
 issue_date DATE NOT NULL,
 due_date DATE NOT NULL,
 return_date DATE NULL,
 loan_status ENUM('borrowed','returned','overdue','lost') DEFAULT 'borrowed',
 fine_amount DECIMAL(12,2) DEFAULT 0.00,
 fine_paid DECIMAL(12,2) DEFAULT 0.00,
 issued_by INT NULL,
 received_by INT NULL,
 issue_notes TEXT NULL,
 return_notes TEXT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_loan_copy (copy_id),
 INDEX idx_loan_member (member_id),
 INDEX idx_loan_status (loan_status),
 INDEX idx_loan_due_date (due_date),
 CONSTRAINT fk_library_loan_copy FOREIGN KEY (copy_id) REFERENCES library_book_copies(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 CONSTRAINT fk_library_loan_member FOREIGN KEY (member_id) REFERENCES library_members(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS library_fines (
 id INT AUTO_INCREMENT PRIMARY KEY,
 loan_id INT NOT NULL,
 amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
 amount_paid DECIMAL(12,2) NOT NULL DEFAULT 0.00,
 reason VARCHAR(255) NOT NULL,
 payment_date DATE NULL,
 payment_method VARCHAR(100) NULL,
 recorded_by INT NULL,
 notes TEXT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_fine_loan (loan_id),
 CONSTRAINT fk_library_fine_loan FOREIGN KEY (loan_id) REFERENCES library_loans(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
