<?php
/**
 * Shared library module bootstrap.
 * Path: /public_html/admin/library/_bootstrap.php
 */
if (session_status() === PHP_SESSION_NONE) {
    // Authentication include should start the session in the existing project.
}

require_once __DIR__ . '/../../includes/auth.php';
requireLogin();
require_once __DIR__ . '/../../config/database.php';

$libDb = $conn ?? ($mysqli ?? ($connection ?? null));
if (!$libDb instanceof mysqli) {
    http_response_code(500);
    exit('Database connection is not available. Check config/database.php.');
}
$libDb->set_charset('utf8mb4');

if (!function_exists('lib_h')) {
    function lib_h($value): string {
        return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
    }
}
if (!function_exists('lib_redirect')) {
    function lib_redirect(string $url): never {
        header('Location: ' . $url);
        exit;
    }
}
if (!function_exists('lib_flash')) {
    function lib_flash(string $type, string $message): void {
        $_SESSION['library_flash'] = ['type' => $type, 'message' => $message];
    }
}
if (!function_exists('lib_take_flash')) {
    function lib_take_flash(): ?array {
        $flash = $_SESSION['library_flash'] ?? null;
        unset($_SESSION['library_flash']);
        return is_array($flash) ? $flash : null;
    }
}
if (!function_exists('lib_csrf_token')) {
    function lib_csrf_token(): string {
        if (empty($_SESSION['library_csrf'])) {
            $_SESSION['library_csrf'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['library_csrf'];
    }
}
if (!function_exists('lib_check_csrf')) {
    function lib_check_csrf(): void {
        $sent = (string)($_POST['csrf_token'] ?? '');
        $saved = (string)($_SESSION['library_csrf'] ?? '');
        if ($sent === '' || $saved === '' || !hash_equals($saved, $sent)) {
            http_response_code(419);
            exit('Your form session expired. Go back, refresh the page and try again.');
        }
    }
}
if (!function_exists('lib_is_management_role')) {
    function lib_is_management_role(): bool {
        $role = strtolower(trim((string)($_SESSION['role'] ?? '')));
        return in_array($role, ['administrator', 'assistant_administrator', 'librarian'], true);
    }
}
if (!function_exists('lib_require_management')) {
    function lib_require_management(): void {
        if (!lib_is_management_role()) {
            http_response_code(403);
            exit('Access denied. Library management is restricted to administrators and librarians.');
        }
    }
}
if (!function_exists('lib_current_user_id')) {
    function lib_current_user_id(): ?int {
        $id = (int)($_SESSION['user_id'] ?? 0);
        return $id > 0 ? $id : null;
    }
}
if (!function_exists('lib_page_start')) {
    function lib_page_start(string $title, string $active = ''): void {
        $flash = lib_take_flash();
        $name = (string)($_SESSION['full_name'] ?? $_SESSION['name'] ?? 'Library user');
        ?>
        <!doctype html><html lang="en"><head>
        <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?= lib_h($title) ?> | School Library</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.6.2/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
        <link rel="stylesheet" href="library-style.css">
        <style>
        body{background:#f4f6f9;font-family:Arial,sans-serif;color:#343a40}
        .lib-sidebar{position:fixed;left:0;top:0;bottom:0;width:245px;background:#172b4d;color:#fff;overflow-y:auto;z-index:1000;transition:.25s}
        .lib-brand{padding:23px 15px;background:#10213d;text-align:center;font-weight:bold;font-size:19px}
        .lib-nav{padding:14px 10px}.lib-nav a{display:block;color:#dce4f2;padding:11px 13px;margin:3px 0;border-radius:5px;text-decoration:none;font-size:14px}
        .lib-nav a i{width:23px}.lib-nav a:hover,.lib-nav a.active{background:#007bff;color:#fff}
        .lib-main{margin-left:245px;padding:24px;min-height:100vh}
        .lib-top{background:#fff;padding:15px 20px;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,.05);display:flex;justify-content:space-between;align-items:center;margin-bottom:22px}
        .lib-top h5{margin:0;color:#172b4d;font-weight:bold}.lib-panel{background:#fff;border-radius:8px;padding:20px;margin-bottom:22px;box-shadow:0 2px 8px rgba(0,0,0,.05)}
        .lib-stat{background:#fff;border-radius:8px;padding:18px;box-shadow:0 2px 8px rgba(0,0,0,.05);height:100%}
        .lib-stat strong{font-size:25px;color:#172b4d}.lib-stat span{display:block;color:#6c757d;font-size:13px}
        .lib-icon{float:right;font-size:24px;color:#007bff}.table td,.table th{vertical-align:middle;font-size:13px}
        .lib-mobile{display:none;border:0;background:#172b4d;color:white;padding:8px 12px;border-radius:5px}
        @media(max-width:768px){.lib-sidebar{left:-245px}.lib-sidebar.show{left:0}.lib-main{margin-left:0;padding:14px}.lib-mobile{display:inline-block}.lib-top{padding:12px}}
        @media print{.lib-sidebar,.lib-top,.no-print{display:none!important}.lib-main{margin:0;padding:0}.lib-panel{box-shadow:none}}
        </style>
        <link rel="stylesheet" href="/assets/css/admin-theme.css?v=20261114">
        </head><body>
        <aside class="lib-sidebar" id="libSidebar">
          <div class="lib-brand"><i class="fas fa-book-reader"></i> School Library</div>
          <nav class="lib-nav">
            <a class="<?= $active==='index'?'active':'' ?>" href="index.php"><i class="fas fa-tachometer-alt"></i> Library Dashboard</a>
            <a class="<?= $active==='books'?'active':'' ?>" href="books.php"><i class="fas fa-book"></i> Books</a>
            <a class="<?= $active==='categories'?'active':'' ?>" href="categories.php"><i class="fas fa-list"></i> Categories</a>
            <a class="<?= $active==='copies'?'active':'' ?>" href="copies.php"><i class="fas fa-copy"></i> Book Copies</a>
            <a class="<?= $active==='members'?'active':'' ?>" href="members.php"><i class="fas fa-users"></i> Members</a>
            <a class="<?= $active==='issue'?'active':'' ?>" href="issue_book.php"><i class="fas fa-hand-holding"></i> Issue Book</a>
            <a class="<?= $active==='borrowed'?'active':'' ?>" href="borrowed_books.php"><i class="fas fa-book-open"></i> Borrowed Books</a>
            <a class="<?= $active==='overdue'?'active':'' ?>" href="overdue_books.php"><i class="fas fa-exclamation-circle"></i> Overdue Books</a>
            <a class="<?= $active==='fines'?'active':'' ?>" href="fines.php"><i class="fas fa-money-bill-wave"></i> Fines</a>
            <a class="<?= $active==='reports'?'active':'' ?>" href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a>
            <hr style="border-color:#405474">
            <a href="/admin/dashboard.php"><i class="fas fa-arrow-left"></i> Admin Dashboard</a>
            <a href="/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
          </nav>
        </aside>
        <main class="lib-main">
          <div class="lib-top">
            <div><button class="lib-mobile" onclick="document.getElementById('libSidebar').classList.toggle('show')" aria-label="Toggle menu"><i class="fas fa-bars"></i></button>
            <h5 class="d-inline ml-2"><?= lib_h($title) ?></h5></div>
            <span class="text-muted"><i class="fas fa-user-circle"></i> <?= lib_h($name) ?></span>
          </div>
          <?php if ($flash): ?><div class="alert alert-<?= lib_h($flash['type']) ?>"><?= lib_h($flash['message']) ?></div><?php endif; ?>
        <?php
    }
}
if (!function_exists('lib_page_end')) {
    function lib_page_end(): void {
        echo '<div class="text-center text-muted small mt-4 mb-3">School Management System &copy; '.date('Y').'</div></main></body></html>';
    }
}
if (!function_exists('lib_fetch_all')) {
    function lib_fetch_all(mysqli $db, string $sql): array {
        $result = $db->query($sql);
        if (!$result) throw new RuntimeException($db->error);
        return $result->fetch_all(MYSQLI_ASSOC);
    }
}
