<?php

require_once "../../config/database.php";
require_once "../../includes/auth.php";

requireRole([
    'administrator',
    'assistant_administrator'
]);

function e($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| Get Teacher ID
|--------------------------------------------------------------------------
*/

$teacher_id = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$teacher_id || $teacher_id <= 0) {
    exit("Invalid teacher ID.");
}

/*
|--------------------------------------------------------------------------
| Load Teacher
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT
        t.id,
        t.teacher_no,
        t.first_name,
        t.last_name,
        t.other_names,
        t.gender,
        t.date_of_birth,
        t.phone,
        t.email,
        t.nin_no,
        t.address,
        t.department,
        t.specialization,
        t.employment_date,
        t.salary,
        t.photo,
        t.status,
        t.created_at,
        u.full_name AS created_by_name
    FROM teachers t
    LEFT JOIN users u
        ON u.id = t.created_by
    WHERE t.id = ?
    LIMIT 1
");

if (!$stmt) {
    exit(
        "Failed to prepare teacher query: " .
        $conn->error
    );
}

$stmt->bind_param(
    "i",
    $teacher_id
);

$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $stmt->close();
    exit("Teacher not found.");
}

$teacher = $result->fetch_assoc();

$stmt->close();

/*
|--------------------------------------------------------------------------
| Teacher Name
|--------------------------------------------------------------------------
*/

$teacherName = trim(
    $teacher['first_name'] . ' ' .
    $teacher['other_names'] . ' ' .
    $teacher['last_name']
);

/*
|--------------------------------------------------------------------------
| Success Message
|--------------------------------------------------------------------------
*/

$success = trim(
    $_GET['success'] ?? ''
);

/*
|--------------------------------------------------------------------------
| Helper Functions
|--------------------------------------------------------------------------
*/

function formatDate($date)
{
    if (empty($date)) {
        return 'Not provided';
    }

    $timestamp = strtotime($date);

    if (!$timestamp) {
        return e($date);
    }

    return date('d M Y', $timestamp);
}

function formatMoney($amount)
{
    if ($amount === null || $amount === '') {
        return 'UGX 0';
    }

    return 'UGX ' . number_format(
        (float)$amount,
        0
    );
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
    View Teacher - <?= e($teacherName) ?>
</title>

<link
    rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: #f4f6f9;
    font-family: Arial, sans-serif;
}

/*
|--------------------------------------------------------------------------
| Sidebar
|--------------------------------------------------------------------------
*/

.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 250px;
    height: 100vh;
    background: #343a40;
    color: white;
    transition: all .3s ease;
    z-index: 1050;
    overflow-y: auto;
}

.sidebar-header {
    height: 65px;
    display: flex;
    align-items: center;
    padding: 0 20px;
    background: #212529;
    font-size: 18px;
    font-weight: bold;
}

.sidebar-header i {
    margin-right: 10px;
}

.sidebar-menu {
    list-style: none;
    padding: 15px 0;
    margin: 0;
}

.sidebar-menu li {
    margin: 2px 10px;
}

.sidebar-menu a {
    display: flex;
    align-items: center;
    padding: 12px 15px;
    color: #ced4da;
    text-decoration: none;
    border-radius: 5px;
}

.sidebar-menu a:hover {
    background: #495057;
    color: white;
}

.sidebar-menu a.active {
    background: #007bff;
    color: white;
}

.sidebar-menu i {
    width: 25px;
    margin-right: 10px;
    text-align: center;
}

/*
|--------------------------------------------------------------------------
| Main Content
|--------------------------------------------------------------------------
*/

.main-content {
    margin-left: 250px;
    min-height: 100vh;
    transition: all .3s ease;
}

/*
|--------------------------------------------------------------------------
| Topbar
|--------------------------------------------------------------------------
*/

.topbar {
    height: 65px;
    background: white;
    border-bottom: 1px solid #dee2e6;
    display: flex;
    align-items: center;
    padding: 0 25px;
}

.sidebar-toggle {
    border: none;
    background: none;
    font-size: 22px;
    cursor: pointer;
    margin-right: 15px;
    color: #343a40;
}

.page-title {
    margin: 0;
    font-size: 22px;
    font-weight: 600;
}

/*
|--------------------------------------------------------------------------
| Content
|--------------------------------------------------------------------------
*/

.content {
    padding: 25px;
}

.card {
    border: none;
    border-radius: 10px;
    box-shadow: 0 2px 8px rgba(0,0,0,.06);
}

.card-header {
    background: white;
    border-bottom: 1px solid #eee;
    padding: 18px 20px;
    font-weight: 600;
}

.section-title {
    font-size: 17px;
    font-weight: 600;
    color: #343a40;
}

.section-title i {
    color: #007bff;
    margin-right: 8px;
}

/*
|--------------------------------------------------------------------------
| Teacher Profile Header
|--------------------------------------------------------------------------
*/

.teacher-profile-card {
    overflow: hidden;
}

.teacher-profile-header {
    background: linear-gradient(
        135deg,
        #007bff,
        #0056b3
    );

    color: white;
    padding: 30px;
}

.teacher-profile-header-content {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
}

.teacher-photo-wrapper {
    margin-right: 25px;
}

.teacher-photo {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    object-fit: cover;
    border: 5px solid rgba(255,255,255,.8);
    background: white;
}

.teacher-photo-placeholder {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    background: white;
    color: #007bff;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 60px;
    border: 5px solid rgba(255,255,255,.8);
}

.teacher-name {
    font-size: 30px;
    font-weight: 700;
    margin-bottom: 8px;
}

.teacher-number {
    font-size: 16px;
    opacity: .9;
}

.profile-status {
    margin-top: 12px;
}

.profile-status .badge {
    font-size: 13px;
    padding: 7px 12px;
}

/*
|--------------------------------------------------------------------------
| Information Rows
|--------------------------------------------------------------------------
*/

.info-row {
    display: flex;
    flex-wrap: wrap;
    padding: 13px 0;
    border-bottom: 1px solid #eee;
}

.info-row:last-child {
    border-bottom: none;
}

.info-label {
    width: 35%;
    color: #6c757d;
    font-weight: 600;
}

.info-value {
    width: 65%;
    color: #212529;
    word-break: break-word;
}

.info-value a {
    color: #007bff;
}

/*
|--------------------------------------------------------------------------
| Action Buttons
|--------------------------------------------------------------------------
*/

.action-buttons {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

.action-buttons .btn {
    margin-bottom: 5px;
}

/*
|--------------------------------------------------------------------------
| Sidebar Collapsed
|--------------------------------------------------------------------------
*/

.sidebar.collapsed {
    width: 75px;
}

.sidebar.collapsed .sidebar-header span,
.sidebar.collapsed .sidebar-menu span {
    display: none;
}

.sidebar.collapsed .sidebar-header {
    justify-content: center;
    padding: 0;
}

.sidebar.collapsed .sidebar-header i {
    margin: 0;
}

.sidebar.collapsed .sidebar-menu a {
    justify-content: center;
    padding: 12px 0;
}

.sidebar.collapsed .sidebar-menu i {
    margin: 0;
}

.main-content.expanded {
    margin-left: 75px;
}

/*
|--------------------------------------------------------------------------
| Mobile
|--------------------------------------------------------------------------
*/

.mobile-topbar {
    display: none;
}

.sidebar-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,.5);
    z-index: 1040;
}

/*
|--------------------------------------------------------------------------
| Responsive
|--------------------------------------------------------------------------
*/

@media (max-width: 767px) {

    .sidebar {
        left: -250px;
        width: 250px;
    }

    .sidebar.mobile-open {
        left: 0;
    }

    .main-content {
        margin-left: 0;
    }

    .topbar {
        display: none;
    }

    .mobile-topbar {
        display: flex;
        height: 60px;
        background: #343a40;
        color: white;
        align-items: center;
        padding: 0 15px;
    }

    .mobile-menu-button {
        border: none;
        background: none;
        color: white;
        font-size: 22px;
        margin-right: 15px;
    }

    .content {
        padding: 15px;
    }

    .teacher-profile-header {
        padding: 25px 20px;
    }

    .teacher-profile-header-content {
        display: block;
        text-align: center;
    }

    .teacher-photo-wrapper {
        margin-right: 0;
        margin-bottom: 20px;
    }

    .teacher-name {
        font-size: 24px;
    }

    .info-label {
        width: 100%;
        margin-bottom: 4px;
    }

    .info-value {
        width: 100%;
    }

    .action-buttons {
        display: block;
    }

    .action-buttons .btn {
        width: 100%;
        margin-right: 0 !important;
    }

    .page-actions {
        width: 100%;
        margin-top: 15px;
    }

    .page-actions .btn {
        width: 100%;
        margin-bottom: 8px;
    }

    .sidebar-overlay.active {
        display: block;
    }
}

</style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>

<body>


<!-- ==========================================================
     SIDEBAR
=========================================================== -->

<div
    class="sidebar"
    id="sidebar"
>

    <div class="sidebar-header">

        <i class="fas fa-school"></i>

        <span>School System</span>

    </div>


    <ul class="sidebar-menu">

        <li>

            <a href="/admin/dashboard.php">

                <i class="fas fa-tachometer-alt"></i>

                <span>Dashboard</span>

            </a>

        </li>


        <li>

            <a href="/admin/classes/index.php">

                <i class="fas fa-chalkboard"></i>

                <span>Classes</span>

            </a>

        </li>


        <li>

            <a href="/admin/students/list.php">

                <i class="fas fa-user-graduate"></i>

                <span>Students</span>

            </a>

        </li>


        <li>

            <a
                href="/admin/teachers/index.php"
                class="active"
            >

                <i class="fas fa-chalkboard-teacher"></i>

                <span>Teachers</span>

            </a>

        </li>


        <li>

            <a href="/admin/bursar/index.php">

                <i class="fas fa-money-bill-wave"></i>

                <span>Bursar</span>

            </a>

        </li>


        <li>

            <a href="/admin/assets/index.php">

                <i class="fas fa-boxes"></i>

                <span>Assets</span>

            </a>

        </li>


        <li>

            <a href="/admin/staff/index.php">

                <i class="fas fa-users"></i>

                <span>Other Staff</span>

            </a>

        </li>


        <li>

            <a href="/admin/projects/index.php">

                <i class="fas fa-project-diagram"></i>

                <span>School Projects</span>

            </a>

        </li>


        <li>

            <a href="/admin/users/index.php">

                <i class="fas fa-user-cog"></i>

                <span>Users</span>

            </a>

        </li>


        <li>

            <a href="/logout.php">

                <i class="fas fa-sign-out-alt"></i>

                <span>Logout</span>

            </a>

        </li>

    </ul>

</div>


<!-- ==========================================================
     SIDEBAR OVERLAY
=========================================================== -->

<div
    class="sidebar-overlay"
    id="sidebarOverlay"
></div>


<!-- ==========================================================
     MAIN CONTENT
=========================================================== -->

<div
    class="main-content"
    id="mainContent"
>


    <!-- DESKTOP TOPBAR -->

    <div class="topbar">

        <button
            class="sidebar-toggle"
            id="sidebarToggle"
            type="button"
        >

            <i class="fas fa-bars"></i>

        </button>


        <h1 class="page-title">

            View Teacher

        </h1>

    </div>


    <!-- MOBILE TOPBAR -->

    <div class="mobile-topbar">

        <button
            class="mobile-menu-button"
            id="mobileMenuButton"
            type="button"
        >

            <i class="fas fa-bars"></i>

        </button>


        <strong>
            View Teacher
        </strong>

    </div>


    <!-- CONTENT -->

    <div class="content">


        <!-- PAGE HEADER -->

        <div
            class="d-flex flex-wrap justify-content-between align-items-center mb-4"
        >

            <div>

                <h2 class="mb-1">

                    Teacher Profile

                </h2>

                <p class="text-muted mb-0">

                    View complete teacher information.

                </p>

            </div>


            <div class="page-actions">

                <a
                    href="index.php"
                    class="btn btn-secondary mr-2"
                >

                    <i class="fas fa-arrow-left"></i>

                    Back to Teachers

                </a>


                <a
                    href="edit.php?id=<?= (int)$teacher['id'] ?>"
                    class="btn btn-primary"
                >

                    <i class="fas fa-edit"></i>

                    Edit Teacher

                </a>

            </div>

        </div>


        <!-- SUCCESS MESSAGE -->

        <?php if ($success !== ''): ?>

            <div
                class="alert alert-success alert-dismissible fade show"
                role="alert"
            >

                <i class="fas fa-check-circle"></i>

                <?= e($success) ?>


                <button
                    type="button"
                    class="close"
                    data-dismiss="alert"
                >

                    <span>&times;</span>

                </button>

            </div>

        <?php endif; ?>


        <!-- ==================================================
             TEACHER PROFILE HEADER
        =================================================== -->

        <div class="card teacher-profile-card mb-4">

            <div class="teacher-profile-header">

                <div class="teacher-profile-header-content">


                    <!-- PHOTO -->

                    <div class="teacher-photo-wrapper">

                        <?php if (!empty($teacher['photo'])): ?>

                            <img
                                src="/uploads/teachers/<?= e($teacher['photo']) ?>"
                                class="teacher-photo"
                                alt="<?= e($teacherName) ?>"
                                onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"
                            >

                            <div
                                class="teacher-photo-placeholder"
                                style="display:none;"
                            >

                                <i class="fas fa-user"></i>

                            </div>

                        <?php else: ?>

                            <div class="teacher-photo-placeholder">

                                <i class="fas fa-user"></i>

                            </div>

                        <?php endif; ?>

                    </div>


                    <!-- BASIC INFORMATION -->

                    <div>

                        <div class="teacher-name">

                            <?= e($teacherName) ?>

                        </div>


                        <div class="teacher-number">

                            <i class="fas fa-id-card mr-1"></i>

                            Teacher No:
                            <strong>
                                <?= e($teacher['teacher_no']) ?>
                            </strong>

                        </div>


                        <div class="profile-status">

                            <?php if ($teacher['status'] === 'active'): ?>

                                <span class="badge badge-success">

                                    <i class="fas fa-check-circle"></i>

                                    Active

                                </span>

                            <?php else: ?>

                                <span class="badge badge-secondary">

                                    <i class="fas fa-times-circle"></i>

                                    Inactive

                                </span>

                            <?php endif; ?>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- ==================================================
             PERSONAL INFORMATION
        =================================================== -->

        <div class="card mb-4">

            <div class="card-header">

                <div class="section-title">

                    <i class="fas fa-user"></i>

                    Personal Information

                </div>

            </div>


            <div class="card-body">


                <div class="row">

                    <div class="col-md-6">


                        <div class="info-row">

                            <div class="info-label">
                                Teacher Number
                            </div>

                            <div class="info-value">

                                <?= e($teacher['teacher_no']) ?>

                            </div>

                        </div>


                        <div class="info-row">

                            <div class="info-label">
                                First Name
                            </div>

                            <div class="info-value">

                                <?= e($teacher['first_name']) ?>

                            </div>

                        </div>


                        <div class="info-row">

                            <div class="info-label">
                                Last Name
                            </div>

                            <div class="info-value">

                                <?= e($teacher['last_name']) ?>

                            </div>

                        </div>


                    </div>


                    <div class="col-md-6">


                        <div class="info-row">

                            <div class="info-label">
                                Other Names
                            </div>

                            <div class="info-value">

                                <?=
                                    !empty($teacher['other_names'])
                                    ? e($teacher['other_names'])
                                    : 'Not provided'
                                ?>

                            </div>

                        </div>


                        <div class="info-row">

                            <div class="info-label">
                                Gender
                            </div>

                            <div class="info-value">

                                <?= e($teacher['gender']) ?>

                            </div>

                        </div>


                        <div class="info-row">

                            <div class="info-label">
                                Date of Birth
                            </div>

                            <div class="info-value">

                                <?= formatDate($teacher['date_of_birth']) ?>

                            </div>

                        </div>


                    </div>

                </div>

            </div>

        </div>


        <!-- ==================================================
             CONTACT INFORMATION
        =================================================== -->

        <div class="card mb-4">

            <div class="card-header">

                <div class="section-title">

                    <i class="fas fa-address-book"></i>

                    Contact Information

                </div>

            </div>


            <div class="card-body">


                <div class="row">

                    <div class="col-md-6">


                        <div class="info-row">

                            <div class="info-label">
                                Phone
                            </div>

                            <div class="info-value">

                                <?php if (!empty($teacher['phone'])): ?>

                                    <a
                                        href="tel:<?= e($teacher['phone']) ?>"
                                    >

                                        <i class="fas fa-phone mr-1"></i>

                                        <?= e($teacher['phone']) ?>

                                    </a>

                                <?php else: ?>

                                    Not provided

                                <?php endif; ?>

                            </div>

                        </div>


                        <div class="info-row">

                            <div class="info-label">
                                Email
                            </div>

                            <div class="info-value">

                                <?php if (!empty($teacher['email'])): ?>

                                    <a
                                        href="mailto:<?= e($teacher['email']) ?>"
                                    >

                                        <i class="fas fa-envelope mr-1"></i>

                                        <?= e($teacher['email']) ?>

                                    </a>

                                <?php else: ?>

                                    Not provided

                                <?php endif; ?>

                            </div>

                        </div>


                    </div>


                    <div class="col-md-6">


                        <div class="info-row">

                            <div class="info-label">
                                National ID / NIN
                            </div>

                            <div class="info-value">

                                <?=
                                    !empty($teacher['nin_no'])
                                    ? e($teacher['nin_no'])
                                    : 'Not provided'
                                ?>

                            </div>

                        </div>


                        <div class="info-row">

                            <div class="info-label">
                                Address
                            </div>

                            <div class="info-value">

                                <?=
                                    !empty($teacher['address'])
                                    ? nl2br(e($teacher['address']))
                                    : 'Not provided'
                                ?>

                            </div>

                        </div>


                    </div>

                </div>

            </div>

        </div>


        <!-- ==================================================
             EMPLOYMENT INFORMATION
        =================================================== -->

        <div class="card mb-4">

            <div class="card-header">

                <div class="section-title">

                    <i class="fas fa-briefcase"></i>

                    Employment Information

                </div>

            </div>


            <div class="card-body">


                <div class="row">

                    <div class="col-md-6">


                        <div class="info-row">

                            <div class="info-label">
                                Department
                            </div>

                            <div class="info-value">

                                <?=
                                    !empty($teacher['department'])
                                    ? e($teacher['department'])
                                    : 'Not provided'
                                ?>

                            </div>

                        </div>


                        <div class="info-row">

                            <div class="info-label">
                                Specialization / Subject
                            </div>

                            <div class="info-value">

                                <?=
                                    !empty($teacher['specialization'])
                                    ? e($teacher['specialization'])
                                    : 'Not provided'
                                ?>

                            </div>

                        </div>


                    </div>


                    <div class="col-md-6">


                        <div class="info-row">

                            <div class="info-label">
                                Employment Date
                            </div>

                            <div class="info-value">

                                <?= formatDate($teacher['employment_date']) ?>

                            </div>

                        </div>


                        <div class="info-row">

                            <div class="info-label">
                                Monthly Salary
                            </div>

                            <div class="info-value">

                                <strong>

                                    <?= formatMoney($teacher['salary']) ?>

                                </strong>

                            </div>

                        </div>


                    </div>

                </div>

            </div>

        </div>


        <!-- ==================================================
             RECORD INFORMATION
        =================================================== -->

        <div class="card mb-4">

            <div class="card-header">

                <div class="section-title">

                    <i class="fas fa-info-circle"></i>

                    Record Information

                </div>

            </div>


            <div class="card-body">


                <div class="row">

                    <div class="col-md-6">


                        <div class="info-row">

                            <div class="info-label">
                                Status
                            </div>

                            <div class="info-value">

                                <?php if ($teacher['status'] === 'active'): ?>

                                    <span class="badge badge-success">

                                        Active

                                    </span>

                                <?php else: ?>

                                    <span class="badge badge-secondary">

                                        Inactive

                                    </span>

                                <?php endif; ?>

                            </div>

                        </div>


                    </div>


                    <div class="col-md-6">


                        <div class="info-row">

                            <div class="info-label">
                                Added By
                            </div>

                            <div class="info-value">

                                <?=
                                    !empty($teacher['created_by_name'])
                                    ? e($teacher['created_by_name'])
                                    : 'System'
                                ?>

                            </div>

                        </div>


                        <div class="info-row">

                            <div class="info-label">
                                Date Added
                            </div>

                            <div class="info-value">

                                <?= formatDate($teacher['created_at']) ?>

                            </div>

                        </div>


                    </div>

                </div>

            </div>

        </div>


        <!-- ==================================================
             ACTIONS
        =================================================== -->

        <div class="card mb-4">

            <div class="card-body">

                <div
                    class="d-flex flex-wrap justify-content-between align-items-center"
                >

                    <div>

                        <h5 class="mb-1">

                            Teacher Actions

                        </h5>

                        <p class="text-muted mb-0">

                            Manage this teacher's record.

                        </p>

                    </div>


                    <div class="action-buttons mt-2 mt-md-0">


                        <a
                            href="index.php"
                            class="btn btn-secondary mr-2"
                        >

                            <i class="fas fa-arrow-left"></i>

                            Back to Teachers

                        </a>


                        <a
                            href="edit.php?id=<?= (int)$teacher['id'] ?>"
                            class="btn btn-primary mr-2"
                        >

                            <i class="fas fa-edit"></i>

                            Edit Teacher

                        </a>


                        <a
                            href="delete.php?id=<?= (int)$teacher['id'] ?>"
                            class="btn btn-danger"
                            onclick="return confirm('Are you sure you want to delete this teacher?');"
                        >

                            <i class="fas fa-trash"></i>

                            Delete Teacher

                        </a>


                    </div>

                </div>

            </div>

        </div>

    </div>

</div>


<!-- ==========================================================
     JAVASCRIPT
=========================================================== -->

<script>

const sidebar =
    document.getElementById('sidebar');

const mainContent =
    document.getElementById('mainContent');

const sidebarToggle =
    document.getElementById('sidebarToggle');

const mobileMenuButton =
    document.getElementById('mobileMenuButton');

const sidebarOverlay =
    document.getElementById('sidebarOverlay');


/*
|--------------------------------------------------------------------------
| Desktop Sidebar Toggle
|--------------------------------------------------------------------------
*/

if (sidebarToggle) {

    sidebarToggle.addEventListener(
        'click',
        function () {

            if (window.innerWidth > 767) {

                sidebar.classList.toggle(
                    'collapsed'
                );

                mainContent.classList.toggle(
                    'expanded'
                );

            }

        }
    );

}


/*
|--------------------------------------------------------------------------
| Mobile Sidebar
|--------------------------------------------------------------------------
*/

if (mobileMenuButton) {

    mobileMenuButton.addEventListener(
        'click',
        function () {

            sidebar.classList.add(
                'mobile-open'
            );

            sidebarOverlay.classList.add(
                'active'
            );

        }
    );

}


/*
|--------------------------------------------------------------------------
| Close Mobile Sidebar
|--------------------------------------------------------------------------
*/

function closeMobileSidebar()
{
    sidebar.classList.remove(
        'mobile-open'
    );

    sidebarOverlay.classList.remove(
        'active'
    );
}


if (sidebarOverlay) {

    sidebarOverlay.addEventListener(
        'click',
        closeMobileSidebar
    );

}


/*
|--------------------------------------------------------------------------
| Close Sidebar When Link Is Clicked
|--------------------------------------------------------------------------
*/

sidebar.querySelectorAll('a').forEach(
    function (link) {

        link.addEventListener(
            'click',
            function () {

                if (window.innerWidth <= 767) {

                    closeMobileSidebar();

                }

            }
        );

    }
);


/*
|--------------------------------------------------------------------------
| Escape Key
|--------------------------------------------------------------------------
*/

document.addEventListener(
    'keydown',
    function (event) {

        if (event.key === 'Escape') {

            closeMobileSidebar();

        }

    }
);

</script>


<script
    src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
></script>

<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
></script>

</body>

</html>