<?php

require_once "../../config/database.php";
require_once "../../includes/auth.php";

requireRole([
    'administrator',
    'assistant_administrator'
]);

function e($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| Teacher ID
|--------------------------------------------------------------------------
*/

$teacher_id = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$teacher_id || $teacher_id <= 0) {
    exit("Invalid teacher ID.");
}

/*
|--------------------------------------------------------------------------
| Success message
|--------------------------------------------------------------------------
*/

$success = trim(
    $_GET['success'] ?? ''
);

/*
|--------------------------------------------------------------------------
| Load teacher
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT
        t.id,
        t.teacher_no,
        t.first_name,
        t.last_name,
        t.other_names,
        t.gender,
        t.date_of_birth,
        t.phone,
        t.email,
        t.nin_no,
        t.address,
        t.department,
        t.specialization,
        t.employment_date,
        t.salary,
        t.photo,
        t.status,
        t.created_at,
        u.full_name AS created_by_name
    FROM teachers t
    LEFT JOIN users u
        ON u.id = t.created_by
    WHERE t.id = ?
    LIMIT 1
");

if (!$stmt) {
    exit("Failed to prepare teacher query: " . $conn->error);
}

$stmt->bind_param(
    "i",
    $teacher_id
);

$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {
    exit("Teacher not found.");
}

$teacher = $result->fetch_assoc();

$stmt->close();

/*
|--------------------------------------------------------------------------
| Full name
|--------------------------------------------------------------------------
*/

$fullName = trim(
    $teacher['first_name'] . ' ' .
    ($teacher['other_names'] ?? '') . ' ' .
    $teacher['last_name']
);

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
    <?= e($fullName) ?> - Teacher Profile
</title>

<link
    rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: #f4f6f9;
    font-family: Arial, sans-serif;
}

.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 250px;
    height: 100vh;
    background: #343a40;
    color: white;
    transition: all .3s ease;
    z-index: 1050;
    overflow-y: auto;
}

.sidebar-header {
    height: 65px;
    display: flex;
    align-items: center;
    padding: 0 20px;
    background: #212529;
    font-size: 18px;
    font-weight: bold;
}

.sidebar-header i {
    margin-right: 10px;
}

.sidebar-menu {
    list-style: none;
    padding: 15px 0;
    margin: 0;
}

.sidebar-menu li {
    margin: 2px 10px;
}

.sidebar-menu a {
    display: flex;
    align-items: center;
    padding: 12px 15px;
    color: #ced4da;
    text-decoration: none;
    border-radius: 5px;
}

.sidebar-menu a:hover {
    background: #495057;
    color: white;
}

.sidebar-menu a.active {
    background: #007bff;
    color: white;
}

.sidebar-menu i {
    width: 25px;
    margin-right: 10px;
    text-align: center;
}

.main-content {
    margin-left: 250px;
    min-height: 100vh;
    transition: all .3s ease;
}

.topbar {
    height: 65px;
    background: white;
    border-bottom: 1px solid #dee2e6;
    display: flex;
    align-items: center;
    padding: 0 25px;
}

.sidebar-toggle {
    border: none;
    background: none;
    font-size: 22px;
    cursor: pointer;
    margin-right: 15px;
    color: #343a40;
}

.page-title {
    margin: 0;
    font-size: 22px;
    font-weight: 600;
}

.content {
    padding: 25px;
}

.card {
    border: none;
    border-radius: 10px;
    box-shadow: 0 2px 8px rgba(0,0,0,.06);
}

.profile-photo {
    width: 190px;
    height: 190px;
    object-fit: cover;
    border-radius: 12px;
    border: 3px solid #e9ecef;
}

.profile-placeholder {
    width: 190px;
    height: 190px;
    border-radius: 12px;
    background: #e9ecef;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    font-size: 70px;
}

.profile-name {
    font-size: 28px;
    font-weight: 600;
}

.detail-label {
    font-size: 12px;
    color: #6c757d;
    text-transform: uppercase;
    font-weight: 600;
    margin-bottom: 3px;
}

.detail-value {
    font-size: 16px;
    color: #212529;
    margin-bottom: 20px;
}

.section-title {
    font-size: 17px;
    font-weight: 600;
    border-bottom: 1px solid #e9ecef;
    padding-bottom: 12px;
    margin-bottom: 20px;
}

.section-title i {
    color: #007bff;
    margin-right: 8px;
}

.mobile-topbar {
    display: none;
}

.sidebar-overlay {
    display: none;
}

.sidebar.collapsed {
    width: 75px;
}

.sidebar.collapsed .sidebar-header span,
.sidebar.collapsed .sidebar-menu span {
    display: none;
}

.sidebar.collapsed .sidebar-header {
    justify-content: center;
    padding: 0;
}

.sidebar.collapsed .sidebar-header i {
    margin: 0;
}

.sidebar.collapsed .sidebar-menu a {
    justify-content: center;
    padding: 12px 0;
}

.sidebar.collapsed .sidebar-menu i {
    margin: 0;
}

.main-content.expanded {
    margin-left: 75px;
}

@media (max-width: 767px) {

    .sidebar {
        left: -250px;
        width: 250px;
    }

    .sidebar.mobile-open {
        left: 0;
    }

    .main-content {
        margin-left: 0;
    }

    .topbar {
        display: none;
    }

    .mobile-topbar {
        display: flex;
        height: 60px;
        background: #343a40;
        color: white;
        align-items: center;
        padding: 0 15px;
    }

    .mobile-menu-button {
        border: none;
        background: none;
        color: white;
        font-size: 22px;
        margin-right: 15px;
    }

    .content {
        padding: 15px;
    }

    .sidebar-overlay.active {
        display: block;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,.5);
        z-index: 1040;
    }

    .profile-photo,
    .profile-placeholder {
        width: 140px;
        height: 140px;
    }

}

</style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar" id="sidebar">

    <div class="sidebar-header">

        <i class="fas fa-school"></i>

        <span>School System</span>

    </div>

    <ul class="sidebar-menu">

        <li>
            <a href="/admin/dashboard.php">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
        </li>

        <li>
            <a href="/admin/classes/index.php">
                <i class="fas fa-chalkboard"></i>
                <span>Classes</span>
            </a>
        </li>

        <li>
            <a href="/admin/students/list.php">
                <i class="fas fa-user-graduate"></i>
                <span>Students</span>
            </a>
        </li>

        <li>
            <a href="/admin/teachers/index.php" class="active">
                <i class="fas fa-chalkboard-teacher"></i>
                <span>Teachers</span>
            </a>
        </li>

        <li>
            <a href="/admin/bursar/index.php">
                <i class="fas fa-money-bill-wave"></i>
                <span>Bursar</span>
            </a>
        </li>

        <li>
            <a href="/admin/assets/index.php">
                <i class="fas fa-boxes"></i>
                <span>Assets</span>
            </a>
        </li>

        <li>
            <a href="/admin/staff/index.php">
                <i class="fas fa-users"></i>
                <span>Other Staff</span>
            </a>
        </li>

        <li>
            <a href="/admin/projects/index.php">
                <i class="fas fa-project-diagram"></i>
                <span>School Projects</span>
            </a>
        </li>

        <li>
            <a href="/admin/users/index.php">
                <i class="fas fa-user-cog"></i>
                <span>Users</span>
            </a>
        </li>

        <li>
            <a href="/logout.php">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </li>

    </ul>

</div>

<div
    class="sidebar-overlay"
    id="sidebarOverlay"
></div>


<!-- MAIN -->

<div
    class="main-content"
    id="mainContent"
>

    <div class="topbar">

        <button
            class="sidebar-toggle"
            id="sidebarToggle"
        >
            <i class="fas fa-bars"></i>
        </button>

        <h1 class="page-title">
            Teacher Profile
        </h1>

    </div>


    <div class="mobile-topbar">

        <button
            class="mobile-menu-button"
            id="mobileMenuButton"
        >
            <i class="fas fa-bars"></i>
        </button>

        <strong>
            Teacher Profile
        </strong>

    </div>


    <div class="content">

        <!-- HEADER -->

        <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

            <div>

                <h2 class="mb-1">
                    Teacher Profile
                </h2>

                <p class="text-muted mb-0">
                    View teacher information.
                </p>

            </div>

            <div class="mt-2 mt-md-0">

                <a
                    href="index.php"
                    class="btn btn-secondary"
                >
                    <i class="fas fa-arrow-left"></i>
                    Back
                </a>

                <a
                    href="edit.php?id=<?= (int)$teacher['id'] ?>"
                    class="btn btn-warning"
                >
                    <i class="fas fa-edit"></i>
                    Edit
                </a>

            </div>

        </div>


        <?php if ($success !== ''): ?>

            <div class="alert alert-success">

                <i class="fas fa-check-circle"></i>

                <?= e($success) ?>

            </div>

        <?php endif; ?>


        <!-- PROFILE -->

        <div class="card mb-4">

            <div class="card-body">

                <div class="row align-items-center">

                    <div class="col-md-3 text-center mb-4 mb-md-0">

                        <?php if (!empty($teacher['photo'])): ?>

                            <img
                                src="/uploads/teachers/<?= e($teacher['photo']) ?>"
                                class="profile-photo"
                                alt="<?= e($fullName) ?>"
                            >

                        <?php else: ?>

                            <div class="profile-placeholder mx-auto">

                                <i class="fas fa-user"></i>

                            </div>

                        <?php endif; ?>

                    </div>


                    <div class="col-md-9">

                        <div class="profile-name mb-2">

                            <?= e($fullName) ?>

                        </div>

                        <div class="mb-3">

                            <span class="badge badge-primary">

                                <?= e($teacher['teacher_no']) ?>

                            </span>

                            <?php if ($teacher['status'] === 'active'): ?>

                                <span class="badge badge-success">
                                    Active
                                </span>

                            <?php else: ?>

                                <span class="badge badge-secondary">
                                    Inactive
                                </span>

                            <?php endif; ?>

                        </div>


                        <div class="row">

                            <div class="col-md-4">

                                <div class="detail-label">
                                    Department
                                </div>

                                <div class="detail-value">

                                    <?= !empty($teacher['department'])
                                        ? e($teacher['department'])
                                        : '—'
                                    ?>

                                </div>

                            </div>


                            <div class="col-md-4">

                                <div class="detail-label">
                                    Specialization
                                </div>

                                <div class="detail-value">

                                    <?= !empty($teacher['specialization'])
                                        ? e($teacher['specialization'])
                                        : '—'
                                    ?>

                                </div>

                            </div>


                            <div class="col-md-4">

                                <div class="detail-label">
                                    Gender
                                </div>

                                <div class="detail-value">
                                    <?= e($teacher['gender']) ?>
                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- PERSONAL INFORMATION -->

        <div class="card mb-4">

            <div class="card-body">

                <div class="section-title">

                    <i class="fas fa-user"></i>

                    Personal Information

                </div>


                <div class="row">

                    <div class="col-md-4">

                        <div class="detail-label">
                            First Name
                        </div>

                        <div class="detail-value">
                            <?= e($teacher['first_name']) ?>
                        </div>

                    </div>


                    <div class="col-md-4">

                        <div class="detail-label">
                            Last Name
                        </div>

                        <div class="detail-value">
                            <?= e($teacher['last_name']) ?>
                        </div>

                    </div>


                    <div class="col-md-4">

                        <div class="detail-label">
                            Other Names
                        </div>

                        <div class="detail-value">

                            <?= !empty($teacher['other_names'])
                                ? e($teacher['other_names'])
                                : '—'
                            ?>

                        </div>

                    </div>


                    <div class="col-md-4">

                        <div class="detail-label">
                            Date of Birth
                        </div>

                        <div class="detail-value">

                            <?= !empty($teacher['date_of_birth'])
                                ? e($teacher['date_of_birth'])
                                : '—'
                            ?>

                        </div>

                    </div>


                    <div class="col-md-4">

                        <div class="detail-label">
                            Gender
                        </div>

                        <div class="detail-value">
                            <?= e($teacher['gender']) ?>
                        </div>

                    </div>


                    <div class="col-md-4">

                        <div class="detail-label">
                            NIN
                        </div>

                        <div class="detail-value">

                            <?= !empty($teacher['nin_no'])
                                ? e($teacher['nin_no'])
                                : '—'
                            ?>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- CONTACT -->

        <div class="card mb-4">

            <div class="card-body">

                <div class="section-title">

                    <i class="fas fa-address-book"></i>

                    Contact Information

                </div>


                <div class="row">

                    <div class="col-md-4">

                        <div class="detail-label">
                            Phone
                        </div>

                        <div class="detail-value">

                            <?= !empty($teacher['phone'])
                                ? e($teacher['phone'])
                                : '—'
                            ?>

                        </div>

                    </div>


                    <div class="col-md-4">

                        <div class="detail-label">
                            Email
                        </div>

                        <div class="detail-value">

                            <?= !empty($teacher['email'])
                                ? e($teacher['email'])
                                : '—'
                            ?>

                        </div>

                    </div>


                    <div class="col-md-12">

                        <div class="detail-label">
                            Address
                        </div>

                        <div class="detail-value">

                            <?= !empty($teacher['address'])
                                ? nl2br(e($teacher['address']))
                                : '—'
                            ?>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- EMPLOYMENT -->

        <div class="card mb-4">

            <div class="card-body">

                <div class="section-title">

                    <i class="fas fa-briefcase"></i>

                    Employment Information

                </div>


                <div class="row">

                    <div class="col-md-4">

                        <div class="detail-label">
                            Department
                        </div>

                        <div class="detail-value">

                            <?= !empty($teacher['department'])
                                ? e($teacher['department'])
                                : '—'
                            ?>

                        </div>

                    </div>


                    <div class="col-md-4">

                        <div class="detail-label">
                            Specialization
                        </div>

                        <div class="detail-value">

                            <?= !empty($teacher['specialization'])
                                ? e($teacher['specialization'])
                                : '—'
                            ?>

                        </div>

                    </div>


                    <div class="col-md-4">

                        <div class="detail-label">
                            Employment Date
                        </div>

                        <div class="detail-value">

                            <?= !empty($teacher['employment_date'])
                                ? e($teacher['employment_date'])
                                : '—'
                            ?>

                        </div>

                    </div>


                    <div class="col-md-4">

                        <div class="detail-label">
                            Monthly Salary
                        </div>

                        <div class="detail-value">

                            UGX
                            <?= number_format(
                                (float)$teacher['salary'],
                                2
                            ) ?>

                        </div>

                    </div>


                    <div class="col-md-4">

                        <div class="detail-label">
                            Registered By
                        </div>

                        <div class="detail-value">

                            <?= !empty($teacher['created_by_name'])
                                ? e($teacher['created_by_name'])
                                : '—'
                            ?>

                        </div>

                    </div>


                    <div class="col-md-4">

                        <div class="detail-label">
                            Registered On
                        </div>

                        <div class="detail-value">

                            <?= !empty($teacher['created_at'])
                                ? e($teacher['created_at'])
                                : '—'
                            ?>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- ACTIONS -->

        <div class="card">

            <div class="card-body text-right">

                <a
                    href="edit.php?id=<?= (int)$teacher['id'] ?>"
                    class="btn btn-warning"
                >
                    <i class="fas fa-edit"></i>
                    Edit Teacher
                </a>

                <a
                    href="delete.php?id=<?= (int)$teacher['id'] ?>"
                    class="btn btn-danger"
                    onclick="return confirm('Are you sure you want to delete this teacher?');"
                >
                    <i class="fas fa-trash"></i>
                    Delete Teacher
                </a>

            </div>

        </div>

    </div>

</div>


<script>

const sidebar =
    document.getElementById('sidebar');

const mainContent =
    document.getElementById('mainContent');

const sidebarToggle =
    document.getElementById('sidebarToggle');

const mobileMenuButton =
    document.getElementById('mobileMenuButton');

const sidebarOverlay =
    document.getElementById('sidebarOverlay');


sidebarToggle.addEventListener(
    'click',
    function () {

        if (window.innerWidth > 767) {

            sidebar.classList.toggle('collapsed');

            mainContent.classList.toggle('expanded');

        }

    }
);


mobileMenuButton.addEventListener(
    'click',
    function () {

        sidebar.classList.add('mobile-open');

        sidebarOverlay.classList.add('active');

    }
);


function closeMobileSidebar()
{
    sidebar.classList.remove('mobile-open');

    sidebarOverlay.classList.remove('active');
}


sidebarOverlay.addEventListener(
    'click',
    closeMobileSidebar
);


sidebar.querySelectorAll('a').forEach(
    function (link) {

        link.addEventListener(
            'click',
            function () {

                if (window.innerWidth <= 767) {
                    closeMobileSidebar();
                }

            }
        );

    }
);


document.addEventListener(
    'keydown',
    function (event) {

        if (event.key === 'Escape') {
            closeMobileSidebar();
        }

    }
);

</script>

</body>
</html>