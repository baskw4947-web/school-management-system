<?php

require_once "../../config/database.php";
require_once "../../includes/auth.php";

requireRole([
    'administrator',
    'assistant_administrator'
]);

function e($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| Search and filters
|--------------------------------------------------------------------------
*/

$search = trim($_GET['search'] ?? '');
$status = trim($_GET['status'] ?? '');

/*
|--------------------------------------------------------------------------
| Build query
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        t.id,
        t.teacher_no,
        t.first_name,
        t.last_name,
        t.other_names,
        t.gender,
        t.phone,
        t.email,
        t.department,
        t.specialization,
        t.photo,
        t.status
    FROM teachers t
    WHERE 1=1
";

$params = [];
$types = "";

/*
|--------------------------------------------------------------------------
| Search
|--------------------------------------------------------------------------
*/

if ($search !== '') {

    $sql .= "
        AND (
            t.teacher_no LIKE ?
            OR t.first_name LIKE ?
            OR t.last_name LIKE ?
            OR t.other_names LIKE ?
            OR t.phone LIKE ?
            OR t.email LIKE ?
            OR t.nin_no LIKE ?
            OR t.department LIKE ?
            OR t.specialization LIKE ?
            OR CONCAT(
                t.first_name,
                ' ',
                t.last_name
            ) LIKE ?
        )
    ";

    $searchValue = "%" . $search . "%";

    for ($i = 0; $i < 10; $i++) {
        $params[] = $searchValue;
        $types .= "s";
    }
}

/*
|--------------------------------------------------------------------------
| Status filter
|--------------------------------------------------------------------------
*/

if (
    $status !== '' &&
    in_array($status, ['active', 'inactive'], true)
) {

    $sql .= " AND t.status = ?";

    $params[] = $status;
    $types .= "s";
}

/*
|--------------------------------------------------------------------------
| Ordering
|--------------------------------------------------------------------------
*/

$sql .= "
    ORDER BY
        t.last_name ASC,
        t.first_name ASC
";

/*
|--------------------------------------------------------------------------
| Execute query
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Failed to prepare teacher query: " . $conn->error);
}

if (!empty($params)) {

    $stmt->bind_param(
        $types,
        ...$params
    );
}

$stmt->execute();

$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Teachers - School Management System</title>

    <!-- Bootstrap -->
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
    >

    <!-- Font Awesome -->
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
    >

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: #f4f6f9;
            font-family: Arial, sans-serif;
        }

        /*
        |--------------------------------------------------------------------------
        | Sidebar
        |--------------------------------------------------------------------------
        */

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;

            width: 250px;
            height: 100vh;

            background: #343a40;

            color: white;

            transition: all 0.3s ease;

            z-index: 1050;

            overflow-y: auto;
        }

        .sidebar-header {
            height: 65px;

            display: flex;
            align-items: center;

            padding: 0 20px;

            background: #212529;

            font-size: 18px;
            font-weight: bold;
        }

        .sidebar-header i {
            margin-right: 10px;
        }

        .sidebar-menu {
            list-style: none;

            padding: 15px 0;
            margin: 0;
        }

        .sidebar-menu li {
            margin: 2px 10px;
        }

        .sidebar-menu a {
            display: flex;

            align-items: center;

            padding: 12px 15px;

            color: #ced4da;

            text-decoration: none;

            border-radius: 5px;

            transition: 0.2s;
        }

        .sidebar-menu a:hover {
            background: #495057;
            color: white;
        }

        .sidebar-menu a.active {
            background: #007bff;
            color: white;
        }

        .sidebar-menu i {
            width: 25px;

            margin-right: 10px;

            text-align: center;
        }

        /*
        |--------------------------------------------------------------------------
        | Main content
        |--------------------------------------------------------------------------
        */

        .main-content {
            margin-left: 250px;

            min-height: 100vh;

            transition: all 0.3s ease;
        }

        /*
        |--------------------------------------------------------------------------
        | Top bar
        |--------------------------------------------------------------------------
        */

        .topbar {
            height: 65px;

            background: white;

            border-bottom: 1px solid #dee2e6;

            display: flex;

            align-items: center;

            padding: 0 25px;
        }

        .sidebar-toggle {
            border: none;

            background: none;

            font-size: 22px;

            cursor: pointer;

            margin-right: 15px;

            color: #343a40;
        }

        .page-title {
            margin: 0;

            font-size: 22px;

            font-weight: 600;
        }

        /*
        |--------------------------------------------------------------------------
        | Content
        |--------------------------------------------------------------------------
        */

        .content {
            padding: 25px;
        }

        .card {
            border: none;

            border-radius: 10px;

            box-shadow:
                0 2px 8px rgba(0, 0, 0, 0.06);
        }

        .card-header {
            background: white;

            border-bottom: 1px solid #eee;

            padding: 18px 20px;

            font-weight: 600;
        }

        /*
        |--------------------------------------------------------------------------
        | Teacher photo
        |--------------------------------------------------------------------------
        */

        .teacher-photo {
            width: 45px;
            height: 45px;

            object-fit: cover;

            border-radius: 50%;

            border: 2px solid #e9ecef;
        }

        .teacher-photo-placeholder {
            width: 45px;
            height: 45px;

            border-radius: 50%;

            background: #e9ecef;

            display: flex;

            align-items: center;
            justify-content: center;

            color: #6c757d;
        }

        /*
        |--------------------------------------------------------------------------
        | Table
        |--------------------------------------------------------------------------
        */

        .table th {
            white-space: nowrap;

            font-size: 13px;

            text-transform: uppercase;

            color: #6c757d;
        }

        .table td {
            vertical-align: middle;
        }

        /*
        |--------------------------------------------------------------------------
        | Mobile
        |--------------------------------------------------------------------------
        */

        .mobile-topbar {
            display: none;
        }

        .sidebar-overlay {
            display: none;

            position: fixed;

            top: 0;
            left: 0;

            width: 100%;
            height: 100%;

            background: rgba(0, 0, 0, 0.5);

            z-index: 1040;
        }

        /*
        |--------------------------------------------------------------------------
        | Collapsed sidebar
        |--------------------------------------------------------------------------
        */

        .sidebar.collapsed {
            width: 75px;
        }

        .sidebar.collapsed .sidebar-header span,
        .sidebar.collapsed .sidebar-menu span {
            display: none;
        }

        .sidebar.collapsed .sidebar-header {
            justify-content: center;

            padding: 0;
        }

        .sidebar.collapsed .sidebar-header i {
            margin: 0;
        }

        .sidebar.collapsed .sidebar-menu a {
            justify-content: center;

            padding: 12px 0;
        }

        .sidebar.collapsed .sidebar-menu i {
            margin: 0;
        }

        .main-content.expanded {
            margin-left: 75px;
        }

        /*
        |--------------------------------------------------------------------------
        | Responsive
        |--------------------------------------------------------------------------
        */

        @media (max-width: 767px) {

            .sidebar {
                left: -250px;

                width: 250px;
            }

            .sidebar.mobile-open {
                left: 0;
            }

            .main-content {
                margin-left: 0;
            }

            .mobile-topbar {
                display: flex;

                height: 60px;

                background: #343a40;

                color: white;

                align-items: center;

                padding: 0 15px;
            }

            .mobile-menu-button {
                border: none;

                background: none;

                color: white;

                font-size: 22px;

                margin-right: 15px;
            }

            .content {
                padding: 15px;
            }

            .topbar {
                display: none;
            }

            .sidebar-overlay.active {
                display: block;
            }

            .table-responsive {
                overflow-x: auto;
            }
        }

    </style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>

<body>

<!-- =========================================================
     SIDEBAR
========================================================= -->

<div
    class="sidebar"
    id="sidebar"
>

    <div class="sidebar-header">

        <i class="fas fa-school"></i>

        <span>School System</span>

    </div>

    <ul class="sidebar-menu">

        <li>
            <a href="/admin/dashboard.php">

                <i class="fas fa-tachometer-alt"></i>

                <span>Dashboard</span>

            </a>
        </li>

        <li>
            <a href="/admin/classes/index.php">

                <i class="fas fa-chalkboard"></i>

                <span>Classes</span>

            </a>
        </li>

        <li>
            <a href="/admin/students/list.php">

                <i class="fas fa-user-graduate"></i>

                <span>Students</span>

            </a>
        </li>

        <li>
            <a
                href="/admin/teachers/index.php"
                class="active"
            >

                <i class="fas fa-chalkboard-teacher"></i>

                <span>Teachers</span>

            </a>
        </li>

        <li>
            <a href="/admin/bursar/index.php">

                <i class="fas fa-money-bill-wave"></i>

                <span>Bursar</span>

            </a>
        </li>

        <li>
            <a href="/admin/assets/index.php">

                <i class="fas fa-boxes"></i>

                <span>Assets</span>

            </a>
        </li>

        <li>
            <a href="/admin/staff/index.php">

                <i class="fas fa-users"></i>

                <span>Other Staff</span>

            </a>
        </li>

        <li>
            <a href="/admin/projects/index.php">

                <i class="fas fa-project-diagram"></i>

                <span>School Projects</span>

            </a>
        </li>

        <li>
            <a href="/admin/users/index.php">

                <i class="fas fa-user-cog"></i>

                <span>Users</span>

            </a>
        </li>

        <li>
            <a href="/logout.php">

                <i class="fas fa-sign-out-alt"></i>

                <span>Logout</span>

            </a>
        </li>

    </ul>

</div>

<div
    class="sidebar-overlay"
    id="sidebarOverlay"
></div>


<!-- =========================================================
     MAIN CONTENT
========================================================= -->

<div
    class="main-content"
    id="mainContent"
>

    <!-- Desktop topbar -->

    <div class="topbar">

        <button
            class="sidebar-toggle"
            id="sidebarToggle"
            type="button"
        >
            <i class="fas fa-bars"></i>
        </button>

        <h1 class="page-title">
            Teachers
        </h1>

    </div>


    <!-- Mobile topbar -->

    <div class="mobile-topbar">

        <button
            class="mobile-menu-button"
            id="mobileMenuButton"
            type="button"
        >

            <i class="fas fa-bars"></i>

        </button>

        <strong>
            Teachers
        </strong>

    </div>


    <!-- Page content -->

    <div class="content">

        <!-- Page heading -->

        <div
            class="d-flex justify-content-between align-items-center mb-4"
        >

            <div>

                <h2 class="mb-1">
                    Teachers
                </h2>

                <p class="text-muted mb-0">
                    Manage school teachers and teaching staff.
                </p>

            </div>

            <a
                href="add.php"
                class="btn btn-primary"
            >

                <i class="fas fa-plus"></i>

                Add Teacher

            </a>

        </div>


        <!-- Search/filter card -->

        <div class="card mb-4">

            <div class="card-body">

                <form
                    method="GET"
                    action="index.php"
                >

                    <div class="form-row">

                        <div class="col-md-8 mb-2">

                            <label>
                                Search Teacher
                            </label>

                            <div class="input-group">

                                <div class="input-group-prepend">

                                    <span class="input-group-text">
                                        <i class="fas fa-search"></i>
                                    </span>

                                </div>

                                <input
                                    type="text"
                                    name="search"
                                    class="form-control"
                                    placeholder="Teacher number, name, phone, department, subject..."
                                    value="<?= e($search) ?>"
                                >

                            </div>

                        </div>


                        <div class="col-md-3 mb-2">

                            <label>
                                Status
                            </label>

                            <select
                                name="status"
                                class="form-control"
                            >

                                <option value="">
                                    All Teachers
                                </option>

                                <option
                                    value="active"
                                    <?= $status === 'active' ? 'selected' : '' ?>
                                >
                                    Active
                                </option>

                                <option
                                    value="inactive"
                                    <?= $status === 'inactive' ? 'selected' : '' ?>
                                >
                                    Inactive
                                </option>

                            </select>

                        </div>


                        <div class="col-md-1 mb-2 d-flex align-items-end">

                            <button
                                type="submit"
                                class="btn btn-primary btn-block"
                            >

                                <i class="fas fa-search"></i>

                            </button>

                        </div>

                    </div>

                </form>

            </div>

        </div>


        <!-- Teachers table -->

        <div class="card">

            <div class="card-header">

                <div class="d-flex justify-content-between align-items-center">

                    <span>
                        Teacher List
                    </span>

                    <span class="badge badge-primary">

                        <?= $result->num_rows ?>

                        Teacher<?= $result->num_rows == 1 ? '' : 's' ?>

                    </span>

                </div>

            </div>

            <div class="card-body p-0">

                <div class="table-responsive">

                    <table class="table table-hover mb-0">

                        <thead class="thead-light">

                            <tr>

                                <th>
                                    #
                                </th>

                                <th>
                                    Teacher
                                </th>

                                <th>
                                    Teacher No.
                                </th>

                                <th>
                                    Gender
                                </th>

                                <th>
                                    Phone
                                </th>

                                <th>
                                    Department
                                </th>

                                <th>
                                    Specialization
                                </th>

                                <th>
                                    Status
                                </th>

                                <th>
                                    Actions
                                </th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php if ($result->num_rows > 0): ?>

                            <?php
                            $counter = 1;
                            ?>

                            <?php while ($teacher = $result->fetch_assoc()): ?>

                                <?php

                                $fullName = trim(
                                    $teacher['first_name'] . ' ' .
                                    ($teacher['other_names'] ?? '') . ' ' .
                                    $teacher['last_name']
                                );

                                ?>

                                <tr>

                                    <!-- Number -->

                                    <td>
                                        <?= $counter++ ?>
                                    </td>


                                    <!-- Teacher -->

                                    <td>

                                        <div class="d-flex align-items-center">

                                            <?php if (!empty($teacher['photo'])): ?>

                                                <img
                                                    src="/uploads/teachers/<?= e($teacher['photo']) ?>"
                                                    alt="<?= e($fullName) ?>"
                                                    class="teacher-photo mr-2"
                                                >

                                            <?php else: ?>

                                                <div class="teacher-photo-placeholder mr-2">

                                                    <i class="fas fa-user"></i>

                                                </div>

                                            <?php endif; ?>


                                            <div>

                                                <strong>
                                                    <?= e($fullName) ?>
                                                </strong>

                                                <?php if (!empty($teacher['email'])): ?>

                                                    <small class="d-block text-muted">

                                                        <?= e($teacher['email']) ?>

                                                    </small>

                                                <?php endif; ?>

                                            </div>

                                        </div>

                                    </td>


                                    <!-- Teacher number -->

                                    <td>

                                        <span class="badge badge-secondary">

                                            <?= e($teacher['teacher_no']) ?>

                                        </span>

                                    </td>


                                    <!-- Gender -->

                                    <td>
                                        <?= e($teacher['gender']) ?>
                                    </td>


                                    <!-- Phone -->

                                    <td>

                                        <?= !empty($teacher['phone'])
                                            ? e($teacher['phone'])
                                            : '<span class="text-muted">—</span>'
                                        ?>

                                    </td>


                                    <!-- Department -->

                                    <td>

                                        <?= !empty($teacher['department'])
                                            ? e($teacher['department'])
                                            : '<span class="text-muted">—</span>'
                                        ?>

                                    </td>


                                    <!-- Specialization -->

                                    <td>

                                        <?= !empty($teacher['specialization'])
                                            ? e($teacher['specialization'])
                                            : '<span class="text-muted">—</span>'
                                        ?>

                                    </td>


                                    <!-- Status -->

                                    <td>

                                        <?php if ($teacher['status'] === 'active'): ?>

                                            <span class="badge badge-success">
                                                Active
                                            </span>

                                        <?php else: ?>

                                            <span class="badge badge-secondary">
                                                Inactive
                                            </span>

                                        <?php endif; ?>

                                    </td>


                                    <!-- Actions -->

                                    <td>

                                        <div class="btn-group">

                                            <a
                                                href="view.php?id=<?= (int)$teacher['id'] ?>"
                                                class="btn btn-sm btn-info"
                                                title="View"
                                            >

                                                <i class="fas fa-eye"></i>

                                            </a>

                                            <a
                                                href="edit.php?id=<?= (int)$teacher['id'] ?>"
                                                class="btn btn-sm btn-warning"
                                                title="Edit"
                                            >

                                                <i class="fas fa-edit"></i>

                                            </a>

                                            <a
                                                href="delete.php?id=<?= (int)$teacher['id'] ?>"
                                                class="btn btn-sm btn-danger"
                                                title="Delete"
                                                onclick="return confirm('Are you sure you want to delete this teacher?');"
                                            >

                                                <i class="fas fa-trash"></i>

                                            </a>

                                        </div>

                                    </td>

                                </tr>

                            <?php endwhile; ?>

                        <?php else: ?>

                            <tr>

                                <td
                                    colspan="9"
                                    class="text-center py-5"
                                >

                                    <div class="text-muted">

                                        <i
                                            class="fas fa-chalkboard-teacher fa-3x mb-3"
                                        ></i>

                                        <h5>
                                            No teachers found
                                        </h5>

                                        <?php if ($search !== '' || $status !== ''): ?>

                                            <p>
                                                Try changing your search or filter.
                                            </p>

                                            <a
                                                href="index.php"
                                                class="btn btn-outline-secondary"
                                            >
                                                Clear Filters
                                            </a>

                                        <?php else: ?>

                                            <p>
                                                No teachers have been registered yet.
                                            </p>

                                            <a
                                                href="add.php"
                                                class="btn btn-primary"
                                            >

                                                <i class="fas fa-plus"></i>

                                                Register First Teacher

                                            </a>

                                        <?php endif; ?>

                                    </div>

                                </td>

                            </tr>

                        <?php endif; ?>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    </div>

</div>


<!-- =========================================================
     JAVASCRIPT
========================================================= -->

<script>

    const sidebar = document.getElementById('sidebar');

    const mainContent =
        document.getElementById('mainContent');

    const sidebarToggle =
        document.getElementById('sidebarToggle');

    const mobileMenuButton =
        document.getElementById('mobileMenuButton');

    const sidebarOverlay =
        document.getElementById('sidebarOverlay');


    /*
    |--------------------------------------------------------------------------
    | Desktop sidebar collapse
    |--------------------------------------------------------------------------
    */

    if (sidebarToggle) {

        sidebarToggle.addEventListener(
            'click',
            function () {

                if (window.innerWidth > 767) {

                    sidebar.classList.toggle('collapsed');

                    mainContent.classList.toggle('expanded');

                }

            }
        );

    }


    /*
    |--------------------------------------------------------------------------
    | Mobile sidebar open
    |--------------------------------------------------------------------------
    */

    if (mobileMenuButton) {

        mobileMenuButton.addEventListener(
            'click',
            function () {

                sidebar.classList.add('mobile-open');

                sidebarOverlay.classList.add('active');

            }
        );

    }


    /*
    |--------------------------------------------------------------------------
    | Close mobile sidebar
    |--------------------------------------------------------------------------
    */

    function closeMobileSidebar()
    {
        sidebar.classList.remove('mobile-open');

        sidebarOverlay.classList.remove('active');
    }


    if (sidebarOverlay) {

        sidebarOverlay.addEventListener(
            'click',
            closeMobileSidebar
        );

    }


    /*
    |--------------------------------------------------------------------------
    | Close sidebar when clicking a link on mobile
    |--------------------------------------------------------------------------
    */

    const sidebarLinks =
        sidebar.querySelectorAll('a');

    sidebarLinks.forEach(
        function (link) {

            link.addEventListener(
                'click',
                function () {

                    if (window.innerWidth <= 767) {

                        closeMobileSidebar();

                    }

                }
            );

        }
    );


    /*
    |--------------------------------------------------------------------------
    | Escape key
    |--------------------------------------------------------------------------
    */

    document.addEventListener(
        'keydown',
        function (event) {

            if (event.key === 'Escape') {

                closeMobileSidebar();

            }

        }
    );

</script>

</body>

</html>