<?php

require_once "../../config/database.php";
require_once "../../includes/auth.php";

requireRole([
    'administrator',
    'assistant_administrator'
]);

/*
|--------------------------------------------------------------------------
| Helper
|--------------------------------------------------------------------------
*/

function e($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| CSRF Token
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(
        random_bytes(32)
    );
}

$csrf_token = $_SESSION['csrf_token'];

/*
|--------------------------------------------------------------------------
| Current logged-in user
|--------------------------------------------------------------------------
*/

$userId = (int)($_SESSION['user_id'] ?? 0);

if ($userId <= 0) {
    exit("Invalid user session.");
}

/*
|--------------------------------------------------------------------------
| Form variables
|--------------------------------------------------------------------------
*/

$teacher_no = '';
$first_name = '';
$last_name = '';
$other_names = '';
$gender = '';
$date_of_birth = '';

$phone = '';
$email = '';
$nin_no = '';
$address = '';

$department = '';
$specialization = '';
$employment_date = '';

$salary = '';
$status = 'active';

$error = '';
$success = '';

/*
|--------------------------------------------------------------------------
| Process form
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /*
    |--------------------------------------------------------------------------
    | CSRF validation
    |--------------------------------------------------------------------------
    */

    if (
        !isset($_POST['csrf_token']) ||
        !hash_equals(
            $_SESSION['csrf_token'],
            $_POST['csrf_token']
        )
    ) {

        $error = "Invalid security token. Please refresh the page and try again.";

    } else {

        /*
        |--------------------------------------------------------------------------
        | Get form values
        |--------------------------------------------------------------------------
        */

        $teacher_no = trim(
            $_POST['teacher_no'] ?? ''
        );

        $first_name = trim(
            $_POST['first_name'] ?? ''
        );

        $last_name = trim(
            $_POST['last_name'] ?? ''
        );

        $other_names = trim(
            $_POST['other_names'] ?? ''
        );

        $gender = trim(
            $_POST['gender'] ?? ''
        );

        $date_of_birth = trim(
            $_POST['date_of_birth'] ?? ''
        );

        $phone = trim(
            $_POST['phone'] ?? ''
        );

        $email = trim(
            $_POST['email'] ?? ''
        );

        $nin_no = trim(
            $_POST['nin_no'] ?? ''
        );

        $address = trim(
            $_POST['address'] ?? ''
        );

        $department = trim(
            $_POST['department'] ?? ''
        );

        $specialization = trim(
            $_POST['specialization'] ?? ''
        );

        $employment_date = trim(
            $_POST['employment_date'] ?? ''
        );

        $salary = trim(
            $_POST['salary'] ?? ''
        );

        $status = trim(
            $_POST['status'] ?? 'active'
        );

        /*
        |--------------------------------------------------------------------------
        | Validation
        |--------------------------------------------------------------------------
        */

        if ($teacher_no === '') {

            $error = "Teacher number is required.";

        } elseif (
            !preg_match(
                '/^[A-Za-z0-9\/_-]{2,50}$/',
                $teacher_no
            )
        ) {

            $error = "Invalid teacher number. Use letters, numbers, /, - or _ only.";

        } elseif ($first_name === '') {

            $error = "First name is required.";

        } elseif ($last_name === '') {

            $error = "Last name is required.";

        } elseif (
            !in_array(
                $gender,
                ['Male', 'Female', 'Other'],
                true
            )
        ) {

            $error = "Please select a valid gender.";

        } elseif (
            !in_array(
                $status,
                ['active', 'inactive'],
                true
            )
        ) {

            $error = "Invalid teacher status.";

        } elseif (
            $email !== '' &&
            !filter_var(
                $email,
                FILTER_VALIDATE_EMAIL
            )
        ) {

            $error = "Please enter a valid email address.";

        } elseif (
            $salary !== '' &&
            (!is_numeric($salary) || (float)$salary < 0)
        ) {

            $error = "Salary must be a valid positive number.";

        }

        /*
        |--------------------------------------------------------------------------
        | Duplicate teacher number
        |--------------------------------------------------------------------------
        */

        if ($error === '') {

            $check = $conn->prepare("
                SELECT id
                FROM teachers
                WHERE teacher_no = ?
                LIMIT 1
            ");

            if (!$check) {

                $error =
                    "Failed to check teacher number: " .
                    $conn->error;

            } else {

                $check->bind_param(
                    "s",
                    $teacher_no
                );

                $check->execute();

                $checkResult =
                    $check->get_result();

                if ($checkResult->num_rows > 0) {

                    $error =
                        "Teacher number already exists.";

                }

                $check->close();
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Photo upload
        |--------------------------------------------------------------------------
        */

        $photoName = null;

        if (
            $error === '' &&
            isset($_FILES['photo']) &&
            $_FILES['photo']['error'] !== UPLOAD_ERR_NO_FILE
        ) {

            if (
                $_FILES['photo']['error'] !==
                UPLOAD_ERR_OK
            ) {

                $error =
                    "There was a problem uploading the teacher photo.";

            } else {

                $originalName =
                    $_FILES['photo']['name'];

                $tmpName =
                    $_FILES['photo']['tmp_name'];

                $fileSize =
                    (int)$_FILES['photo']['size'];

                /*
                |--------------------------------------------------------------------------
                | Maximum photo size: 5 MB
                |--------------------------------------------------------------------------
                */

                if ($fileSize > 5 * 1024 * 1024) {

                    $error =
                        "Teacher photo must not exceed 5 MB.";

                } else {

                    $extension = strtolower(
                        pathinfo(
                            $originalName,
                            PATHINFO_EXTENSION
                        )
                    );

                    $allowedExtensions = [
                        'jpg',
                        'jpeg',
                        'png',
                        'gif',
                        'webp'
                    ];

                    if (
                        !in_array(
                            $extension,
                            $allowedExtensions,
                            true
                        )
                    ) {

                        $error =
                            "Invalid photo format. " .
                            "Use JPG, JPEG, PNG, GIF or WEBP.";

                    } else {

                        /*
                        |--------------------------------------------------------------------------
                        | Verify actual image
                        |--------------------------------------------------------------------------
                        */

                        $imageInfo =
                            @getimagesize($tmpName);

                        if ($imageInfo === false) {

                            $error =
                                "The uploaded file is not a valid image.";

                        } else {

                            /*
                            |--------------------------------------------------------------------------
                            | Upload directory
                            |--------------------------------------------------------------------------
                            */

                            $uploadDir =
                                "../../uploads/teachers/";

                            if (!is_dir($uploadDir)) {

                                if (
                                    !mkdir(
                                        $uploadDir,
                                        0755,
                                        true
                                    )
                                ) {

                                    $error =
                                        "Failed to create teacher photo directory.";
                                }
                            }

                            /*
                            |--------------------------------------------------------------------------
                            | Generate filename
                            |--------------------------------------------------------------------------
                            */

                            if ($error === '') {

                                $photoName =
                                    uniqid(
                                        'teacher_',
                                        true
                                    ) .
                                    '.' .
                                    $extension;

                                $photoPath =
                                    $uploadDir .
                                    $photoName;

                                if (
                                    !move_uploaded_file(
                                        $tmpName,
                                        $photoPath
                                    )
                                ) {

                                    $error =
                                        "Failed to save teacher photo.";

                                    $photoName = null;
                                }
                            }
                        }
                    }
                }
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Insert teacher
        |--------------------------------------------------------------------------
        */

        if ($error === '') {

            $salaryValue =
                ($salary === '')
                ? 0.00
                : (float)$salary;

            $stmt = $conn->prepare("
                INSERT INTO teachers
                (
                    teacher_no,
                    first_name,
                    last_name,
                    other_names,
                    gender,
                    date_of_birth,
                    phone,
                    email,
                    nin_no,
                    address,
                    department,
                    specialization,
                    employment_date,
                    salary,
                    photo,
                    status,
                    created_by
                )
                VALUES
                (
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    NULLIF(?, ''),
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    NULLIF(?, ''),
                    ?,
                    ?,
                    ?,
                    ?
                )
            ");

            if (!$stmt) {

                $error =
                    "Failed to prepare teacher registration: " .
                    $conn->error;

            } else {

                /*
                |--------------------------------------------------------------------------
                | 17 parameters
                |--------------------------------------------------------------------------
                |
                | s s s s s s s s s s s s s d s s i
                |
                */

                $stmt->bind_param(
                    "sssssssssssssdssi",
                    $teacher_no,
                    $first_name,
                    $last_name,
                    $other_names,
                    $gender,
                    $date_of_birth,
                    $phone,
                    $email,
                    $nin_no,
                    $address,
                    $department,
                    $specialization,
                    $employment_date,
                    $salaryValue,
                    $photoName,
                    $status,
                    $userId
                );

                if ($stmt->execute()) {

                    $teacherId =
                        $stmt->insert_id;

                    $stmt->close();

                    /*
                    |--------------------------------------------------------------------------
                    | Redirect after successful registration
                    |--------------------------------------------------------------------------
                    */

                    header(
                        "Location: view.php?id=" .
                        $teacherId .
                        "&success=Teacher registered successfully."
                    );

                    exit;

                } else {

                    /*
                    |--------------------------------------------------------------------------
                    | Delete uploaded photo if database insert failed
                    |--------------------------------------------------------------------------
                    */

                    if (
                        $photoName !== null
                    ) {

                        $uploadedFile =
                            "../../uploads/teachers/" .
                            $photoName;

                        if (
                            file_exists(
                                $uploadedFile
                            )
                        ) {

                            unlink(
                                $uploadedFile
                            );
                        }
                    }

                    if (
                        $stmt->errno === 1062
                    ) {

                        $error =
                            "Teacher number already exists.";

                    } else {

                        $error =
                            "Failed to register teacher: " .
                            $stmt->error;
                    }

                    $stmt->close();
                }
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Add Teacher - School Management System
    </title>

    <!-- Bootstrap -->
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
    >

    <!-- Font Awesome -->
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
    >

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: #f4f6f9;
            font-family: Arial, sans-serif;
        }

        /*
        |--------------------------------------------------------------------------
        | Sidebar
        |--------------------------------------------------------------------------
        */

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;

            width: 250px;
            height: 100vh;

            background: #343a40;
            color: white;

            transition: all 0.3s ease;

            z-index: 1050;

            overflow-y: auto;
        }

        .sidebar-header {
            height: 65px;

            display: flex;
            align-items: center;

            padding: 0 20px;

            background: #212529;

            font-size: 18px;
            font-weight: bold;
        }

        .sidebar-header i {
            margin-right: 10px;
        }

        .sidebar-menu {
            list-style: none;

            padding: 15px 0;
            margin: 0;
        }

        .sidebar-menu li {
            margin: 2px 10px;
        }

        .sidebar-menu a {
            display: flex;

            align-items: center;

            padding: 12px 15px;

            color: #ced4da;

            text-decoration: none;

            border-radius: 5px;

            transition: 0.2s;
        }

        .sidebar-menu a:hover {
            background: #495057;
            color: white;
        }

        .sidebar-menu a.active {
            background: #007bff;
            color: white;
        }

        .sidebar-menu i {
            width: 25px;

            margin-right: 10px;

            text-align: center;
        }

        /*
        |--------------------------------------------------------------------------
        | Main content
        |--------------------------------------------------------------------------
        */

        .main-content {
            margin-left: 250px;

            min-height: 100vh;

            transition: all 0.3s ease;
        }

        /*
        |--------------------------------------------------------------------------
        | Topbar
        |--------------------------------------------------------------------------
        */

        .topbar {
            height: 65px;

            background: white;

            border-bottom: 1px solid #dee2e6;

            display: flex;

            align-items: center;

            padding: 0 25px;
        }

        .sidebar-toggle {
            border: none;

            background: none;

            font-size: 22px;

            cursor: pointer;

            margin-right: 15px;

            color: #343a40;
        }

        .page-title {
            margin: 0;

            font-size: 22px;

            font-weight: 600;
        }

        /*
        |--------------------------------------------------------------------------
        | Content
        |--------------------------------------------------------------------------
        */

        .content {
            padding: 25px;
        }

        /*
        |--------------------------------------------------------------------------
        | Cards
        |--------------------------------------------------------------------------
        */

        .card {
            border: none;

            border-radius: 10px;

            box-shadow:
                0 2px 8px rgba(0, 0, 0, 0.06);
        }

        .card-header {
            background: white;

            border-bottom: 1px solid #eee;

            padding: 18px 20px;

            font-weight: 600;
        }

        /*
        |--------------------------------------------------------------------------
        | Form
        |--------------------------------------------------------------------------
        */

        .form-section-title {
            font-size: 16px;

            font-weight: 600;

            color: #343a40;

            margin-bottom: 18px;

            padding-bottom: 10px;

            border-bottom: 1px solid #e9ecef;
        }

        .form-section-title i {
            color: #007bff;

            margin-right: 8px;
        }

        label {
            font-weight: 500;
        }

        .required {
            color: #dc3545;
        }

        /*
        |--------------------------------------------------------------------------
        | Photo preview
        |--------------------------------------------------------------------------
        */

        .photo-preview {
            width: 150px;
            height: 150px;

            object-fit: cover;

            border-radius: 10px;

            border: 2px solid #dee2e6;

            display: none;

            margin-top: 10px;
        }

        /*
        |--------------------------------------------------------------------------
        | Mobile
        |--------------------------------------------------------------------------
        */

        .mobile-topbar {
            display: none;
        }

        .sidebar-overlay {
            display: none;

            position: fixed;

            top: 0;
            left: 0;

            width: 100%;
            height: 100%;

            background: rgba(0, 0, 0, 0.5);

            z-index: 1040;
        }

        /*
        |--------------------------------------------------------------------------
        | Collapsed sidebar
        |--------------------------------------------------------------------------
        */

        .sidebar.collapsed {
            width: 75px;
        }

        .sidebar.collapsed .sidebar-header span,
        .sidebar.collapsed .sidebar-menu span {
            display: none;
        }

        .sidebar.collapsed .sidebar-header {
            justify-content: center;

            padding: 0;
        }

        .sidebar.collapsed .sidebar-header i {
            margin: 0;
        }

        .sidebar.collapsed .sidebar-menu a {
            justify-content: center;

            padding: 12px 0;
        }

        .sidebar.collapsed .sidebar-menu i {
            margin: 0;
        }

        .main-content.expanded {
            margin-left: 75px;
        }

        /*
        |--------------------------------------------------------------------------
        | Responsive
        |--------------------------------------------------------------------------
        */

        @media (max-width: 767px) {

            .sidebar {
                left: -250px;

                width: 250px;
            }

            .sidebar.mobile-open {
                left: 0;
            }

            .main-content {
                margin-left: 0;
            }

            .mobile-topbar {
                display: flex;

                height: 60px;

                background: #343a40;

                color: white;

                align-items: center;

                padding: 0 15px;
            }

            .mobile-menu-button {
                border: none;

                background: none;

                color: white;

                font-size: 22px;

                margin-right: 15px;
            }

            .content {
                padding: 15px;
            }

            .topbar {
                display: none;
            }

            .sidebar-overlay.active {
                display: block;
            }

            .page-actions {
                margin-top: 15px;
            }
        }

    </style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>

<body>

<!-- =========================================================
     SIDEBAR
========================================================= -->

<div
    class="sidebar"
    id="sidebar"
>

    <div class="sidebar-header">

        <i class="fas fa-school"></i>

        <span>School System</span>

    </div>


    <ul class="sidebar-menu">

        <li>
            <a href="/admin/dashboard.php">

                <i class="fas fa-tachometer-alt"></i>

                <span>Dashboard</span>

            </a>
        </li>


        <li>
            <a href="/admin/classes/index.php">

                <i class="fas fa-chalkboard"></i>

                <span>Classes</span>

            </a>
        </li>


        <li>
            <a href="/admin/students/list.php">

                <i class="fas fa-user-graduate"></i>

                <span>Students</span>

            </a>
        </li>


        <li>
            <a
                href="/admin/teachers/index.php"
                class="active"
            >

                <i class="fas fa-chalkboard-teacher"></i>

                <span>Teachers</span>

            </a>
        </li>


        <li>
            <a href="/admin/bursar/index.php">

                <i class="fas fa-money-bill-wave"></i>

                <span>Bursar</span>

            </a>
        </li>


        <li>
            <a href="/admin/assets/index.php">

                <i class="fas fa-boxes"></i>

                <span>Assets</span>

            </a>
        </li>


        <li>
            <a href="/admin/staff/index.php">

                <i class="fas fa-users"></i>

                <span>Other Staff</span>

            </a>
        </li>


        <li>
            <a href="/admin/projects/index.php">

                <i class="fas fa-project-diagram"></i>

                <span>School Projects</span>

            </a>
        </li>


        <li>
            <a href="/admin/users/index.php">

                <i class="fas fa-user-cog"></i>

                <span>Users</span>

            </a>
        </li>


        <li>
            <a href="/logout.php">

                <i class="fas fa-sign-out-alt"></i>

                <span>Logout</span>

            </a>
        </li>

    </ul>

</div>


<div
    class="sidebar-overlay"
    id="sidebarOverlay"
></div>


<!-- =========================================================
     MAIN CONTENT
========================================================= -->

<div
    class="main-content"
    id="mainContent"
>

    <!-- Desktop topbar -->

    <div class="topbar">

        <button
            class="sidebar-toggle"
            id="sidebarToggle"
            type="button"
        >

            <i class="fas fa-bars"></i>

        </button>


        <h1 class="page-title">
            Add Teacher
        </h1>

    </div>


    <!-- Mobile topbar -->

    <div class="mobile-topbar">

        <button
            class="mobile-menu-button"
            id="mobileMenuButton"
            type="button"
        >

            <i class="fas fa-bars"></i>

        </button>

        <strong>
            Add Teacher
        </strong>

    </div>


    <!-- Content -->

    <div class="content">

        <!-- Page heading -->

        <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

            <div>

                <h2 class="mb-1">
                    Register Teacher
                </h2>

                <p class="text-muted mb-0">
                    Add a new teacher to the school system.
                </p>

            </div>


            <div class="page-actions">

                <a
                    href="index.php"
                    class="btn btn-secondary"
                >

                    <i class="fas fa-arrow-left"></i>

                    Back to Teachers

                </a>

            </div>

        </div>


        <!-- Error -->

        <?php if ($error !== ''): ?>

            <div
                class="alert alert-danger alert-dismissible fade show"
            >

                <i class="fas fa-exclamation-circle"></i>

                <?= e($error) ?>

                <button
                    type="button"
                    class="close"
                    data-dismiss="alert"
                >

                    <span>&times;</span>

                </button>

            </div>

        <?php endif; ?>


        <!-- Form -->

        <form
            method="POST"
            action="add.php"
            enctype="multipart/form-data"
        >

            <input
                type="hidden"
                name="csrf_token"
                value="<?= e($csrf_token) ?>"
            >


            <!-- =====================================================
                 PERSONAL INFORMATION
            ====================================================== -->

            <div class="card mb-4">

                <div class="card-header">

                    <div class="form-section-title mb-0">

                        <i class="fas fa-user"></i>

                        Personal Information

                    </div>

                </div>


                <div class="card-body">

                    <div class="form-row">

                        <!-- Teacher Number -->

                        <div class="form-group col-md-4">

                            <label>
                                Teacher Number
                                <span class="required">*</span>
                            </label>

                            <input
                                type="text"
                                name="teacher_no"
                                class="form-control"
                                placeholder="e.g. TCH-0001"
                                value="<?= e($teacher_no) ?>"
                                maxlength="50"
                                required
                            >

                            <small class="form-text text-muted">
                                This number must be unique.
                            </small>

                        </div>


                        <!-- First Name -->

                        <div class="form-group col-md-4">

                            <label>
                                First Name
                                <span class="required">*</span>
                            </label>

                            <input
                                type="text"
                                name="first_name"
                                class="form-control"
                                value="<?= e($first_name) ?>"
                                maxlength="100"
                                required
                            >

                        </div>


                        <!-- Last Name -->

                        <div class="form-group col-md-4">

                            <label>
                                Last Name
                                <span class="required">*</span>
                            </label>

                            <input
                                type="text"
                                name="last_name"
                                class="form-control"
                                value="<?= e($last_name) ?>"
                                maxlength="100"
                                required
                            >

                        </div>


                        <!-- Other Names -->

                        <div class="form-group col-md-4">

                            <label>
                                Other Names
                            </label>

                            <input
                                type="text"
                                name="other_names"
                                class="form-control"
                                value="<?= e($other_names) ?>"
                                maxlength="100"
                            >

                        </div>


                        <!-- Gender -->

                        <div class="form-group col-md-4">

                            <label>
                                Gender
                                <span class="required">*</span>
                            </label>

                            <select
                                name="gender"
                                class="form-control"
                                required
                            >

                                <option value="">
                                    Select Gender
                                </option>

                                <option
                                    value="Male"
                                    <?= $gender === 'Male' ? 'selected' : '' ?>
                                >
                                    Male
                                </option>

                                <option
                                    value="Female"
                                    <?= $gender === 'Female' ? 'selected' : '' ?>
                                >
                                    Female
                                </option>

                                <option
                                    value="Other"
                                    <?= $gender === 'Other' ? 'selected' : '' ?>
                                >
                                    Other
                                </option>

                            </select>

                        </div>


                        <!-- Date of Birth -->

                        <div class="form-group col-md-4">

                            <label>
                                Date of Birth
                            </label>

                            <input
                                type="date"
                                name="date_of_birth"
                                class="form-control"
                                value="<?= e($date_of_birth) ?>"
                            >

                        </div>

                    </div>

                </div>

            </div>


            <!-- =====================================================
                 CONTACT INFORMATION
            ====================================================== -->

            <div class="card mb-4">

                <div class="card-header">

                    <div class="form-section-title mb-0">

                        <i class="fas fa-address-book"></i>

                        Contact Information

                    </div>

                </div>


                <div class="card-body">

                    <div class="form-row">

                        <!-- Phone -->

                        <div class="form-group col-md-4">

                            <label>
                                Phone Number
                            </label>

                            <input
                                type="text"
                                name="phone"
                                class="form-control"
                                placeholder="e.g. 0700000000"
                                value="<?= e($phone) ?>"
                                maxlength="30"
                            >

                        </div>


                        <!-- Email -->

                        <div class="form-group col-md-4">

                            <label>
                                Email Address
                            </label>

                            <input
                                type="email"
                                name="email"
                                class="form-control"
                                placeholder="teacher@example.com"
                                value="<?= e($email) ?>"
                                maxlength="150"
                            >

                        </div>


                        <!-- NIN -->

                        <div class="form-group col-md-4">

                            <label>
                                National ID / NIN
                            </label>

                            <input
                                type="text"
                                name="nin_no"
                                class="form-control"
                                placeholder="NIN Number"
                                value="<?= e($nin_no) ?>"
                                maxlength="50"
                            >

                        </div>


                        <!-- Address -->

                        <div class="form-group col-md-12">

                            <label>
                                Address
                            </label>

                            <textarea
                                name="address"
                                class="form-control"
                                rows="3"
                                placeholder="Teacher's residential address"
                            ><?= e($address) ?></textarea>

                        </div>

                    </div>

                </div>

            </div>


            <!-- =====================================================
                 EMPLOYMENT INFORMATION
            ====================================================== -->

            <div class="card mb-4">

                <div class="card-header">

                    <div class="form-section-title mb-0">

                        <i class="fas fa-briefcase"></i>

                        Employment Information

                    </div>

                </div>


                <div class="card-body">

                    <div class="form-row">

                        <!-- Department -->

                        <div class="form-group col-md-4">

                            <label>
                                Department
                            </label>

                            <input
                                type="text"
                                name="department"
                                class="form-control"
                                placeholder="e.g. Science"
                                value="<?= e($department) ?>"
                                maxlength="100"
                            >

                        </div>


                        <!-- Specialization -->

                        <div class="form-group col-md-4">

                            <label>
                                Specialization / Subject
                            </label>

                            <input
                                type="text"
                                name="specialization"
                                class="form-control"
                                placeholder="e.g. Mathematics"
                                value="<?= e($specialization) ?>"
                                maxlength="150"
                            >

                        </div>


                        <!-- Employment Date -->

                        <div class="form-group col-md-4">

                            <label>
                                Employment Date
                            </label>

                            <input
                                type="date"
                                name="employment_date"
                                class="form-control"
                                value="<?= e($employment_date) ?>"
                            >

                        </div>


                        <!-- Salary -->

                        <div class="form-group col-md-4">

                            <label>
                                Monthly Salary
                            </label>

                            <div class="input-group">

                                <div class="input-group-prepend">

                                    <span class="input-group-text">
                                        UGX
                                    </span>

                                </div>

                                <input
                                    type="number"
                                    name="salary"
                                    class="form-control"
                                    placeholder="0"
                                    value="<?= e($salary) ?>"
                                    min="0"
                                    step="0.01"
                                >

                            </div>

                        </div>


                        <!-- Status -->

                        <div class="form-group col-md-4">

                            <label>
                                Status
                            </label>

                            <select
                                name="status"
                                class="form-control"
                            >

                                <option
                                    value="active"
                                    <?= $status === 'active' ? 'selected' : '' ?>
                                >
                                    Active
                                </option>

                                <option
                                    value="inactive"
                                    <?= $status === 'inactive' ? 'selected' : '' ?>
                                >
                                    Inactive
                                </option>

                            </select>

                        </div>

                    </div>

                </div>

            </div>


            <!-- =====================================================
                 PHOTO
            ====================================================== -->

            <div class="card mb-4">

                <div class="card-header">

                    <div class="form-section-title mb-0">

                        <i class="fas fa-camera"></i>

                        Teacher Photo

                    </div>

                </div>


                <div class="card-body">

                    <div class="form-group mb-0">

                        <label>
                            Upload Photo
                        </label>

                        <input
                            type="file"
                            name="photo"
                            id="photo"
                            class="form-control-file"
                            accept=".jpg,.jpeg,.png,.gif,.webp,image/*"
                        >

                        <small class="form-text text-muted">

                            Accepted formats:
                            JPG, JPEG, PNG, GIF and WEBP.
                            Maximum size: 5 MB.

                        </small>


                        <img
                            id="photoPreview"
                            class="photo-preview"
                            alt="Teacher photo preview"
                        >

                    </div>

                </div>

            </div>


            <!-- =====================================================
                 SUBMIT
            ====================================================== -->

            <div class="card mb-4">

                <div class="card-body">

                    <div class="d-flex justify-content-end">

                        <a
                            href="index.php"
                            class="btn btn-secondary mr-2"
                        >

                            <i class="fas fa-times"></i>

                            Cancel

                        </a>


                        <button
                            type="submit"
                            class="btn btn-primary"
                        >

                            <i class="fas fa-save"></i>

                            Register Teacher

                        </button>

                    </div>

                </div>

            </div>

        </form>

    </div>

</div>


<!-- =========================================================
     JAVASCRIPT
========================================================= -->

<script>

    const sidebar =
        document.getElementById('sidebar');

    const mainContent =
        document.getElementById('mainContent');

    const sidebarToggle =
        document.getElementById('sidebarToggle');

    const mobileMenuButton =
        document.getElementById('mobileMenuButton');

    const sidebarOverlay =
        document.getElementById('sidebarOverlay');


    /*
    |--------------------------------------------------------------------------
    | Desktop sidebar collapse
    |--------------------------------------------------------------------------
    */

    if (sidebarToggle) {

        sidebarToggle.addEventListener(
            'click',
            function () {

                if (window.innerWidth > 767) {

                    sidebar.classList.toggle(
                        'collapsed'
                    );

                    mainContent.classList.toggle(
                        'expanded'
                    );

                }

            }
        );

    }


    /*
    |--------------------------------------------------------------------------
    | Mobile sidebar
    |--------------------------------------------------------------------------
    */

    if (mobileMenuButton) {

        mobileMenuButton.addEventListener(
            'click',
            function () {

                sidebar.classList.add(
                    'mobile-open'
                );

                sidebarOverlay.classList.add(
                    'active'
                );

            }
        );

    }


    /*
    |--------------------------------------------------------------------------
    | Close mobile sidebar
    |--------------------------------------------------------------------------
    */

    function closeMobileSidebar()
    {
        sidebar.classList.remove(
            'mobile-open'
        );

        sidebarOverlay.classList.remove(
            'active'
        );
    }


    if (sidebarOverlay) {

        sidebarOverlay.addEventListener(
            'click',
            closeMobileSidebar
        );

    }


    /*
    |--------------------------------------------------------------------------
    | Close sidebar after clicking a link
    |--------------------------------------------------------------------------
    */

    const sidebarLinks =
        sidebar.querySelectorAll('a');

    sidebarLinks.forEach(
        function (link) {

            link.addEventListener(
                'click',
                function () {

                    if (window.innerWidth <= 767) {

                        closeMobileSidebar();

                    }

                }
            );

        }
    );


    /*
    |--------------------------------------------------------------------------
    | Escape key
    |--------------------------------------------------------------------------
    */

    document.addEventListener(
        'keydown',
        function (event) {

            if (event.key === 'Escape') {

                closeMobileSidebar();

            }

        }
    );


    /*
    |--------------------------------------------------------------------------
    | Photo preview
    |--------------------------------------------------------------------------
    */

    const photoInput =
        document.getElementById('photo');

    const photoPreview =
        document.getElementById('photoPreview');


    if (photoInput) {

        photoInput.addEventListener(
            'change',
            function (event) {

                const file =
                    event.target.files[0];

                if (!file) {

                    photoPreview.style.display =
                        'none';

                    photoPreview.src = '';

                    return;
                }


                /*
                |--------------------------------------------------------------------------
                | Check file type
                |--------------------------------------------------------------------------
                */

                if (!file.type.startsWith('image/')) {

                    alert(
                        'Please select a valid image file.'
                    );

                    photoInput.value = '';

                    photoPreview.style.display =
                        'none';

                    return;
                }


                /*
                |--------------------------------------------------------------------------
                | Preview
                |--------------------------------------------------------------------------
                */

                const reader =
                    new FileReader();

                reader.onload =
                    function (e) {

                        photoPreview.src =
                            e.target.result;

                        photoPreview.style.display =
                            'block';

                    };

                reader.readAsDataURL(file);

            }
        );

    }

</script>


<!-- Bootstrap JS -->

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>