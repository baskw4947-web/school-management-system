<?php
/**
 * School Management System - Bursar Dashboard
 * Install as: /bursar/dashboard.php
 * Finance modules are linked to their current /admin/bursar/ locations.
 */

date_default_timezone_set('Africa/Kampala');

require_once __DIR__ . '/../includes/auth.php';
requireRole(['administrator', 'assistant_administrator', 'bursar']);

$db = null;
$dbWarning = false;
$warnings = [];

try {
    require_once __DIR__ . '/../config/database.php';
    $db = $conn ?? ($mysqli ?? ($connection ?? null));
    if (!$db instanceof mysqli) {
        $dbWarning = true;
        $warnings[] = 'The database connection was not found. Check config/database.php.';
        error_log('Bursar dashboard: database connection not found.');
    } else {
        $db->set_charset('utf8mb4');
    }
} catch (Throwable $e) {
    $dbWarning = true;
    $warnings[] = 'The database could not be loaded. Check your hosting PHP error log.';
    error_log('Bursar dashboard database setup error: ' . $e->getMessage());
}

function bursarDashE($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function bursarDashIdent(string $identifier): string
{
    return '`' . str_replace('`', '``', $identifier) . '`';
}

function bursarDashTableMap(mysqli $db): array
{
    $map = [];
    $result = $db->query('SHOW TABLES');
    while ($row = $result->fetch_row()) {
        $name = (string)$row[0];
        $map[strtolower($name)] = $name;
    }
    $result->free();
    return $map;
}

function bursarDashColumns(mysqli $db, string $table): array
{
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $table)) {
        return [];
    }
    $columns = [];
    $result = $db->query('SHOW COLUMNS FROM ' . bursarDashIdent($table));
    while ($row = $result->fetch_assoc()) {
        $columns[strtolower((string)$row['Field'])] = (string)$row['Field'];
    }
    $result->free();
    return $columns;
}

function bursarDashFirstColumn(array $columns, array $candidates): ?string
{
    foreach ($candidates as $candidate) {
        $key = strtolower((string)$candidate);
        if (isset($columns[$key])) return $columns[$key];
    }
    return null;
}

function bursarDashCount(mysqli $db, array $tables, string $table, ?string $distinctColumn = null): ?int
{
    try {
        $realTable = $tables[strtolower($table)] ?? null;
        if (!$realTable) return null;
        if ($distinctColumn !== null) {
            $columns = bursarDashColumns($db, $realTable);
            $realColumn = bursarDashFirstColumn($columns, [$distinctColumn]);
            if (!$realColumn) return null;
            $sql = 'SELECT COUNT(DISTINCT ' . bursarDashIdent($realColumn) . ') AS total FROM ' . bursarDashIdent($realTable);
        } else {
            $sql = 'SELECT COUNT(*) AS total FROM ' . bursarDashIdent($realTable);
        }
        $row = $db->query($sql)->fetch_assoc();
        return (int)($row['total'] ?? 0);
    } catch (Throwable $e) {
        error_log('Bursar dashboard count error (' . $table . '): ' . $e->getMessage());
        return null;
    }
}

/** Sum a known financial table, optionally restricted to the current month or today. */
function bursarDashSum(mysqli $db, array $tables, string $table, array $amountCandidates, array $dateCandidates = [], string $period = 'all', array $statusCandidates = ['status', 'payment_status']): ?float
{
    try {
        $realTable = $tables[strtolower($table)] ?? null;
        if (!$realTable) return null;
        $columns = bursarDashColumns($db, $realTable);
        $amountColumn = bursarDashFirstColumn($columns, $amountCandidates);
        if (!$amountColumn) return null;

        $dateColumn = $dateCandidates ? bursarDashFirstColumn($columns, $dateCandidates) : null;
        $statusColumn = bursarDashFirstColumn($columns, $statusCandidates);
        $where = [];
        if ($statusColumn) {
            $where[] = "LOWER(COALESCE(" . bursarDashIdent($statusColumn) . ", 'completed')) IN ('completed','complete','paid','success','successful','confirmed','approved','posted','received','settled','processed','done','1')";
        }
        if ($period === 'today' && $dateColumn) {
            $where[] = 'DATE(' . bursarDashIdent($dateColumn) . ') = CURDATE()';
        } elseif ($period === 'month' && $dateColumn) {
            $where[] = bursarDashIdent($dateColumn) . ' >= DATE_FORMAT(CURDATE(), \'%Y-%m-01\')';
            $where[] = bursarDashIdent($dateColumn) . ' < DATE_ADD(LAST_DAY(CURDATE()), INTERVAL 1 DAY)';
        } elseif ($period !== 'all' && !$dateColumn) {
            return null;
        }
        $sql = 'SELECT COALESCE(SUM(' . bursarDashIdent($amountColumn) . '), 0) AS total FROM ' . bursarDashIdent($realTable);
        if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
        $row = $db->query($sql)->fetch_assoc();
        return (float)($row['total'] ?? 0);
    } catch (Throwable $e) {
        error_log('Bursar dashboard sum error (' . $table . '): ' . $e->getMessage());
        return null;
    }
}

function bursarDashFeeAccountTotals(mysqli $db, array $tables): array
{
    $out = ['expected' => null, 'paid' => null, 'balance' => null, 'accounts' => null, 'students' => null, 'outstanding_accounts' => null];
    $table = $tables['student_fee_accounts'] ?? null;
    if (!$table) return $out;
    try {
        $columns = bursarDashColumns($db, $table);
        $expectedCol = bursarDashFirstColumn($columns, ['total_amount', 'expected_amount', 'fee_amount', 'total_fee', 'amount_due']);
        $paidCol = bursarDashFirstColumn($columns, ['total_paid', 'amount_paid', 'paid_amount', 'amount_received']);
        $balanceCol = bursarDashFirstColumn($columns, ['balance', 'outstanding_balance', 'amount_balance']);
        $studentCol = bursarDashFirstColumn($columns, ['student_id']);
        $idCol = bursarDashFirstColumn($columns, ['id', 'account_id']);

        if ($expectedCol) {
            $row = $db->query('SELECT COALESCE(SUM(' . bursarDashIdent($expectedCol) . '),0) AS total FROM ' . bursarDashIdent($table))->fetch_assoc();
            $out['expected'] = (float)($row['total'] ?? 0);
        }
        if ($paidCol) {
            $row = $db->query('SELECT COALESCE(SUM(' . bursarDashIdent($paidCol) . '),0) AS total FROM ' . bursarDashIdent($table))->fetch_assoc();
            $out['paid'] = (float)($row['total'] ?? 0);
        }
        if ($balanceCol) {
            $row = $db->query('SELECT COALESCE(SUM(' . bursarDashIdent($balanceCol) . '),0) AS total FROM ' . bursarDashIdent($table))->fetch_assoc();
            $out['balance'] = (float)($row['total'] ?? 0);
            $outstandingWhere = bursarDashIdent($balanceCol) . ' > 0';
        } elseif ($expectedCol && $paidCol) {
            $out['balance'] = max(0, (float)$out['expected'] - (float)$out['paid']);
            $outstandingWhere = '(' . bursarDashIdent($expectedCol) . ' - ' . bursarDashIdent($paidCol) . ') > 0';
        } else {
            $outstandingWhere = null;
        }
        if ($idCol) {
            $row = $db->query('SELECT COUNT(*) AS total FROM ' . bursarDashIdent($table))->fetch_assoc();
            $out['accounts'] = (int)($row['total'] ?? 0);
        }
        if ($studentCol) {
            $row = $db->query('SELECT COUNT(DISTINCT ' . bursarDashIdent($studentCol) . ') AS total FROM ' . bursarDashIdent($table))->fetch_assoc();
            $out['students'] = (int)($row['total'] ?? 0);
        }
        if ($outstandingWhere !== null) {
            $row = $db->query('SELECT COUNT(*) AS total FROM ' . bursarDashIdent($table) . ' WHERE ' . $outstandingWhere)->fetch_assoc();
            $out['outstanding_accounts'] = (int)($row['total'] ?? 0);
        }
    } catch (Throwable $e) {
        error_log('Bursar dashboard fee account error: ' . $e->getMessage());
    }
    return $out;
}

function bursarDashRecentPayments(mysqli $db, array $tables): array
{
    $table = $tables['fee_payments'] ?? null;
    if (!$table) return [];
    try {
        $cols = bursarDashColumns($db, $table);
        $id = bursarDashFirstColumn($cols, ['id', 'payment_id']);
        $receipt = bursarDashFirstColumn($cols, ['receipt_no', 'receipt_number', 'payment_no', 'transaction_no']);
        $amount = bursarDashFirstColumn($cols, ['amount', 'paid_amount', 'payment_amount', 'total_amount']);
        $date = bursarDashFirstColumn($cols, ['payment_date', 'paid_date', 'transaction_date', 'created_at']);
        $status = bursarDashFirstColumn($cols, ['status', 'payment_status']);
        $studentName = bursarDashFirstColumn($cols, ['student_name', 'payer_name', 'received_from']);
        $studentId = bursarDashFirstColumn($cols, ['student_id']);
        $reference = bursarDashFirstColumn($cols, ['reference_no', 'reference_number', 'transaction_reference']);
        if (!$amount || !$date) return [];

        $select = [];
        $select[] = ($id ? bursarDashIdent($id) : 'NULL') . ' AS row_id';
        $select[] = ($receipt ? bursarDashIdent($receipt) : 'NULL') . ' AS receipt';
        $select[] = bursarDashIdent($amount) . ' AS amount';
        $select[] = bursarDashIdent($date) . ' AS paid_on';
        $select[] = ($status ? bursarDashIdent($status) : "'Recorded'") . ' AS payment_status';
        $select[] = ($studentName ? bursarDashIdent($studentName) : 'NULL') . ' AS student_name';
        $select[] = ($studentId ? bursarDashIdent($studentId) : 'NULL') . ' AS student_id';
        $select[] = ($reference ? bursarDashIdent($reference) : 'NULL') . ' AS reference_no';
        $sql = 'SELECT ' . implode(', ', $select) . ' FROM ' . bursarDashIdent($table);
        if ($status) $sql .= " WHERE LOWER(COALESCE(" . bursarDashIdent($status) . ", 'completed')) IN ('completed','complete','paid','success','successful','confirmed','approved','posted','received','settled','processed','done','1')";
        $sql .= ' ORDER BY ' . bursarDashIdent($date) . ' DESC';
        if ($id) $sql .= ', ' . bursarDashIdent($id) . ' DESC';
        $sql .= ' LIMIT 8';
        $result = $db->query($sql);
        $rows = [];
        while ($row = $result->fetch_assoc()) $rows[] = $row;
        $result->free();

        // Attach current LIN No., Student Payment Code and Day/Boarding value.
        $studentsTable = $tables['students'] ?? null;
        if ($studentsTable && $studentId) {
            try {
                $studentCols = bursarDashColumns($db, $studentsTable);
                $studentPk = bursarDashFirstColumn($studentCols, ['id','student_id']);
                $linCol = bursarDashFirstColumn($studentCols, ['lin_no']);
                $paymentCodeCol = bursarDashFirstColumn($studentCols, ['student_payment_code']);
                $sectionCol = bursarDashFirstColumn($studentCols, ['student_section']);
                if ($studentPk) {
                    $selectStudent = [bursarDashIdent($studentPk) . ' AS sid'];
                    $selectStudent[] = $linCol ? bursarDashIdent($linCol) . ' AS lin_no' : "'' AS lin_no";
                    $selectStudent[] = $paymentCodeCol ? bursarDashIdent($paymentCodeCol) . ' AS student_payment_code' : "'' AS student_payment_code";
                    $selectStudent[] = $sectionCol ? bursarDashIdent($sectionCol) . ' AS student_section' : "'Day' AS student_section";
                    $studentResult = $db->query('SELECT ' . implode(', ', $selectStudent) . ' FROM ' . bursarDashIdent($studentsTable));
                    $identifiers = [];
                    while ($student = $studentResult->fetch_assoc()) $identifiers[(string)$student['sid']] = $student;
                    $studentResult->free();
                    foreach ($rows as &$paymentRow) {
                        $studentKey = (string)($paymentRow['student_id'] ?? '');
                        $student = $identifiers[$studentKey] ?? [];
                        $paymentRow['lin_no'] = $student['lin_no'] ?? '';
                        $paymentRow['student_payment_code'] = $student['student_payment_code'] ?? '';
                        $paymentRow['student_section'] = $student['student_section'] ?? 'Day';
                    }
                    unset($paymentRow);
                }
            } catch (Throwable $e) { error_log('Bursar dashboard student identifier lookup: ' . $e->getMessage()); }
        }
        return $rows;
    } catch (Throwable $e) {
        error_log('Bursar dashboard recent payments error: ' . $e->getMessage());
        return [];
    }
}

function bursarDashMoney($value, bool $available = true): string
{
    return $available && $value !== null ? 'UGX ' . number_format((float)$value, 0) : '—';
}

$tables = [];
$stats = [
    'students' => null,
    'accounts' => null,
    'expected' => null,
    'paid' => null,
    'balance' => null,
    'outstanding_accounts' => null,
    'today_collected' => null,
    'month_collected' => null,
    'month_income' => null,
    'month_expenses' => null,
    'month_salary' => null,
    'payment_count' => null,
    'suppliers' => null,
];
$recentPayments = [];

if ($db instanceof mysqli) {
    try {
        $tables = bursarDashTableMap($db);
        $feeTotals = bursarDashFeeAccountTotals($db, $tables);
        $stats['students'] = $feeTotals['students'];
        $stats['accounts'] = $feeTotals['accounts'];
        $stats['expected'] = $feeTotals['expected'];
        $stats['paid'] = $feeTotals['paid'];
        $stats['balance'] = $feeTotals['balance'];
        $stats['outstanding_accounts'] = $feeTotals['outstanding_accounts'];
        $stats['today_collected'] = bursarDashSum($db, $tables, 'fee_payments', ['amount', 'paid_amount', 'payment_amount', 'total_amount'], ['payment_date', 'paid_date', 'transaction_date', 'created_at'], 'today');
        $stats['month_collected'] = bursarDashSum($db, $tables, 'fee_payments', ['amount', 'paid_amount', 'payment_amount', 'total_amount'], ['payment_date', 'paid_date', 'transaction_date', 'created_at'], 'month');
        $stats['month_income'] = bursarDashSum($db, $tables, 'income_transactions', ['amount', 'income_amount', 'total_amount'], ['income_date', 'transaction_date', 'date', 'created_at'], 'month');
        $stats['month_expenses'] = bursarDashSum($db, $tables, 'expense_transactions', ['amount', 'expense_amount', 'total_amount'], ['expense_date', 'transaction_date', 'date', 'created_at'], 'month');
        $stats['month_salary'] = bursarDashSum($db, $tables, 'salary_payments', ['net_salary', 'amount', 'paid_amount', 'payment_amount', 'net_amount'], ['payment_date', 'paid_date', 'transaction_date', 'created_at'], 'month');
        $stats['payment_count'] = bursarDashCount($db, $tables, 'fee_payments');
        $stats['suppliers'] = bursarDashCount($db, $tables, 'suppliers');
        $recentPayments = bursarDashRecentPayments($db, $tables);
    } catch (Throwable $e) {
        $dbWarning = true;
        $warnings[] = 'Some financial totals could not be loaded. Check the database tables and PHP error log.';
        error_log('Bursar dashboard statistics error: ' . $e->getMessage());
    }
}

if (!$tables || !isset($tables['student_fee_accounts'])) {
    $dbWarning = true;
    $warnings[] = 'The student_fee_accounts table was not found. Student fee totals cannot be displayed.';
}
if (!$tables || !isset($tables['fee_payments'])) {
    $dbWarning = true;
    $warnings[] = 'The fee_payments table was not found. Payment collections cannot be displayed.';
}

$fullName = (string)($_SESSION['full_name'] ?? $_SESSION['name'] ?? 'Bursar');
$currentRole = (string)($_SESSION['role'] ?? $_SESSION['user_role'] ?? 'bursar');
$roleLabel = ucwords(str_replace('_', ' ', strtolower(trim($currentRole))));
$todayLabel = date('l, d F Y');

// Existing finance pages are maintained under /admin/bursar/.
$financeBase = '/admin/bursar/';
$links = [
    'dashboard' => '/bursar/dashboard.php',
    'accounts' => $financeBase . 'students_fee_accounts.php',
    'fees' => $financeBase . 'fee_structure.php',
    'payments' => $financeBase . 'payments.php',
    'outstanding' => $financeBase . 'outstanding_fees.php',
    'income' => $financeBase . 'income.php',
    'expenses' => $financeBase . 'expenses.php',
    'suppliers' => $financeBase . 'suppliers.php',
    'supplier_payments' => $financeBase . 'supplier_payments.php',
    'salaries' => $financeBase . 'salaries.php',
    'salary_payments' => $financeBase . 'salary_payments.php',
    'budgets' => $financeBase . 'budgets.php',
    'cashbook' => $financeBase . 'cashbook.php',
    'reports' => $financeBase . 'reports.php',
    'income_report' => $financeBase . 'income_report.php',
    'expense_report' => $financeBase . 'expense_report.php',
    'fees_report' => $financeBase . 'fees_report.php',
    'profit_loss' => $financeBase . 'profit_loss.php',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bursar Dashboard | School Management System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root { --sidebar:#212529; --sidebar2:#343a40; --accent:#dc3545; --page:#f4f6f9; --ink:#253044; --muted:#6c757d; }
        * { box-sizing: border-box; }
        body { margin:0; background:var(--page); color:var(--ink); font-family:Arial,Helvetica,sans-serif; }
        .sidebar { position:fixed; left:0; top:0; bottom:0; width:250px; background:var(--sidebar); color:#fff; z-index:1050; overflow-y:auto; transition:left .25s ease; }
        .sidebar-header { padding:22px 18px 18px; background:#171a1d; text-align:center; font-size:19px; font-weight:700; }
        .sidebar-header small { display:block; color:#adb5bd; font-size:12px; font-weight:400; margin-top:5px; }
        .sidebar-section { padding:17px 18px 7px; color:#929ba4; font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.8px; }
        .sidebar-menu { padding:8px 10px 20px; }
        .sidebar-menu a { display:flex; align-items:center; gap:10px; color:#ced4da; text-decoration:none; padding:11px 13px; margin:2px 0; border-radius:6px; font-size:14px; transition:background .15s,color .15s; }
        .sidebar-menu a i { width:20px; text-align:center; }
        .sidebar-menu a:hover, .sidebar-menu a.active { background:var(--accent); color:#fff; }
        .main-content { margin-left:250px; min-height:100vh; }
        .topbar { min-height:70px; background:#fff; border-bottom:1px solid #e7eaf0; display:flex; align-items:center; justify-content:space-between; gap:15px; padding:12px 25px; }
        .topbar-title { margin:0; font-size:21px; font-weight:700; color:#253044; }
        .topbar-meta { display:flex; align-items:center; gap:15px; }
        .user-avatar { width:38px; height:38px; display:inline-flex; align-items:center; justify-content:center; border-radius:50%; color:#fff; background:#dc3545; margin-right:8px; }
        .menu-btn { display:none; border:0; background:transparent; color:#343a40; font-size:22px; padding:4px 8px; }
        .page-content { padding:25px; }
        .page-heading { display:flex; justify-content:space-between; align-items:flex-start; gap:15px; margin-bottom:20px; }
        .page-heading h2 { margin:0 0 5px; font-size:25px; font-weight:700; }
        .page-heading p { margin:0; color:var(--muted); }
        .date-pill { padding:8px 12px; background:#fff; border:1px solid #e8ebf1; border-radius:7px; color:#5f6b7a; font-size:13px; white-space:nowrap; }
        .welcome-box { background:linear-gradient(135deg,#007bff,#0056b3); color:#fff; border-radius:10px; padding:24px 26px; margin-bottom:22px; box-shadow:0 4px 14px rgba(0,70,160,.12); }
        .welcome-box h3 { margin:0 0 8px; font-weight:700; font-size:23px; }
        .welcome-box p { margin:0; opacity:.95; }
        .stat-card { height:100%; background:#fff; border:0; border-radius:10px; box-shadow:0 2px 10px rgba(26,39,60,.06); margin-bottom:20px; transition:transform .2s,box-shadow .2s; }
        .stat-card:hover { transform:translateY(-3px); box-shadow:0 6px 16px rgba(26,39,60,.10); }
        .stat-card .card-body { padding:18px; }
        .stat-label { color:#718096; font-size:13px; margin-bottom:6px; }
        .stat-value { font-size:clamp(19px,2vw,25px); font-weight:700; line-height:1.25; color:#263449; overflow-wrap:anywhere; }
        .stat-note { color:#98a2b3; font-size:11px; margin-top:5px; }
        .stat-icon { flex:0 0 52px; width:52px; height:52px; border-radius:11px; display:flex; align-items:center; justify-content:center; color:#fff; font-size:21px; }
        .blue { background:#007bff; } .green { background:#28a745; } .orange { background:#fd7e14; } .red { background:#dc3545; } .purple { background:#6f42c1; } .teal { background:#17a2b8; }
        .section-heading { display:flex; align-items:center; justify-content:space-between; gap:10px; margin:7px 0 14px; }
        .section-heading h4 { margin:0; font-size:19px; font-weight:700; }
        .module-card { height:100%; background:#fff; border-radius:10px; padding:20px; border:1px solid #edf0f5; box-shadow:0 2px 9px rgba(26,39,60,.045); transition:transform .2s,box-shadow .2s; }
        .module-card:hover { transform:translateY(-3px); box-shadow:0 7px 18px rgba(26,39,60,.09); }
        .module-icon { width:48px; height:48px; display:flex; align-items:center; justify-content:center; border-radius:11px; color:#007bff; background:#eaf3ff; font-size:20px; margin-bottom:13px; }
        .module-card h5 { margin:0 0 7px; font-size:16px; font-weight:700; }
        .module-card p { min-height:39px; margin:0 0 14px; font-size:13px; color:#788394; }
        .module-card .btn { border-radius:6px; font-size:13px; }
        .content-card { border:0; border-radius:10px; box-shadow:0 2px 10px rgba(26,39,60,.055); overflow:hidden; margin-bottom:20px; }
        .content-card .card-header { background:#fff; border-bottom:1px solid #edf0f4; padding:15px 18px; font-weight:700; }
        .table th { border-top:0; background:#f8f9fb; color:#6d7786; font-size:12px; white-space:nowrap; }
        .table td { vertical-align:middle; font-size:13px; }
        .small-muted { color:#98a2b3; font-size:11px; }
        .alert { border-radius:8px; }
        .overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.48); z-index:1040; }
        .overlay.show { display:block; }
        .footer { text-align:center; color:#98a2b3; font-size:12px; padding:17px 0 5px; }
        @media(max-width:991px) { .sidebar { left:-255px; } .sidebar.show { left:0; } .main-content { margin-left:0; } .menu-btn { display:inline-block; } .topbar { padding:11px 15px; } .page-content { padding:16px; } .topbar-title { font-size:18px; } }
        @media(max-width:575px) { .page-heading { display:block; } .date-pill { display:inline-block; margin-top:12px; } .topbar .user-name { display:none; } .welcome-box { padding:20px; } .welcome-box h3 { font-size:20px; } }
        @media print { .sidebar,.topbar,.overlay,.no-print { display:none!important; } .main-content { margin:0; } body { background:#fff; } .page-content { padding:0; } .stat-card,.module-card,.content-card { box-shadow:none; border:1px solid #ddd; } }
    </style>
    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>
<body>
<div class="overlay" id="sidebarOverlay"></div>
<aside class="sidebar" id="sidebar">
    <div class="sidebar-header"><i class="fas fa-university mr-2"></i>Bursar Panel<small>School Management System</small></div>
    <nav class="sidebar-menu">
        <div class="sidebar-section">Main</div>
        <a href="/bursar/dashboard.php" class="active"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
        <div class="sidebar-section">Student Fees</div>
        <a href="<?= bursarDashE($links['accounts']) ?>"><i class="fas fa-user-graduate"></i>Student Fee Accounts</a>
        <a href="<?= bursarDashE($links['fees']) ?>"><i class="fas fa-layer-group"></i>Fee Structure</a>
        <a href="<?= bursarDashE($links['payments']) ?>"><i class="fas fa-cash-register"></i>Receive Student Payment</a>
        <a href="<?= bursarDashE($links['outstanding']) ?>"><i class="fas fa-exclamation-circle"></i>Outstanding Fees</a>
        <div class="sidebar-section">Finance</div>
        <a href="<?= bursarDashE($links['income']) ?>"><i class="fas fa-arrow-down"></i>Other Income</a>
        <a href="<?= bursarDashE($links['expenses']) ?>"><i class="fas fa-arrow-up"></i>Expenses</a>
        <a href="<?= bursarDashE($links['suppliers']) ?>"><i class="fas fa-truck"></i>Suppliers</a>
        <a href="<?= bursarDashE($links['supplier_payments']) ?>"><i class="fas fa-file-invoice-dollar"></i>Supplier Payments</a>
        <div class="sidebar-section">Payroll & Budget</div>
        <a href="<?= bursarDashE($links['salaries']) ?>"><i class="fas fa-users"></i>Staff Salaries</a>
        <a href="<?= bursarDashE($links['salary_payments']) ?>"><i class="fas fa-money-check-alt"></i>Salary Payments</a>
        <a href="<?= bursarDashE($links['budgets']) ?>"><i class="fas fa-wallet"></i>Budgets</a>
        <a href="<?= bursarDashE($links['cashbook']) ?>"><i class="fas fa-book"></i>Cashbook</a>
        <div class="sidebar-section">Reports</div>
        <a href="<?= bursarDashE($links['reports']) ?>"><i class="fas fa-chart-bar"></i>Financial Reports</a>
        <a href="<?= bursarDashE($links['income_report']) ?>"><i class="fas fa-file-invoice-dollar"></i>Income Report</a>
        <a href="<?= bursarDashE($links['expense_report']) ?>"><i class="fas fa-file-alt"></i>Expense Report</a>
        <a href="<?= bursarDashE($links['fees_report']) ?>"><i class="fas fa-receipt"></i>Fees Report</a>
        <a href="<?= bursarDashE($links['profit_loss']) ?>"><i class="fas fa-balance-scale"></i>Profit &amp; Loss</a>
        <div class="sidebar-section">Account</div>
        <a href="/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
    </nav>
</aside>

<div class="main-content">
    <header class="topbar">
        <div class="d-flex align-items-center">
            <button type="button" class="menu-btn mr-2" id="mobileMenuBtn" aria-label="Open navigation"><i class="fas fa-bars"></i></button>
            <h1 class="topbar-title">Bursar Dashboard</h1>
        </div>
        <div class="topbar-meta">
            <div class="text-right user-name"><strong><?= bursarDashE($fullName) ?></strong><br><small class="text-muted"><?= bursarDashE($roleLabel) ?></small></div>
            <span class="user-avatar"><i class="fas fa-user"></i></span>
            <a href="/logout.php" class="btn btn-outline-danger btn-sm no-print"><i class="fas fa-sign-out-alt mr-1"></i>Logout</a>
        </div>
    </header>

    <main class="page-content">
        <div class="page-heading">
            <div><h2>Financial Overview</h2><p>Monitor student fees, collections, income, expenses and payroll.</p></div>
            <div class="date-pill"><i class="far fa-calendar-alt mr-1"></i><?= bursarDashE($todayLabel) ?></div>
        </div>

        <?php if ($dbWarning): ?>
            <div class="alert alert-warning" role="status"><strong>Some dashboard figures may be unavailable.</strong><ul class="mb-0 mt-2"><?php foreach (array_unique($warnings) as $warning): ?><li><?= bursarDashE($warning) ?></li><?php endforeach; ?></ul><small>Unavailable figures are shown as a dash. See the PHP error log for technical details.</small></div>
        <?php endif; ?>

        <section class="welcome-box">
            <h3>Welcome, <?= bursarDashE($fullName) ?></h3>
            <p>Use your finance workspace to record student payments, track outstanding balances and manage the school's daily financial operations.</p>
        </section>

        <div class="section-heading"><h4>Fee Accounts &amp; Collections</h4><a class="btn btn-sm btn-outline-primary no-print" href="<?= bursarDashE($links['payments']) ?>"><i class="fas fa-plus mr-1"></i>Record Payment</a></div>
        <div class="row">
            <div class="col-xl-3 col-md-6 mb-3"><div class="stat-card"><div class="card-body d-flex justify-content-between align-items-center"><div><div class="stat-label">Total Fees Expected</div><div class="stat-value"><?= bursarDashMoney($stats['expected']) ?></div><div class="stat-note">From student fee accounts</div></div><div class="stat-icon blue"><i class="fas fa-file-invoice-dollar"></i></div></div></div></div>
            <div class="col-xl-3 col-md-6 mb-3"><div class="stat-card"><div class="card-body d-flex justify-content-between align-items-center"><div><div class="stat-label">Total Fees Collected</div><div class="stat-value text-success"><?= bursarDashMoney($stats['paid']) ?></div><div class="stat-note">Cumulative account payments</div></div><div class="stat-icon green"><i class="fas fa-money-bill-wave"></i></div></div></div></div>
            <div class="col-xl-3 col-md-6 mb-3"><div class="stat-card"><div class="card-body d-flex justify-content-between align-items-center"><div><div class="stat-label">Outstanding Fees</div><div class="stat-value text-danger"><?= bursarDashMoney($stats['balance']) ?></div><div class="stat-note">Expected less collected / account balance</div></div><div class="stat-icon red"><i class="fas fa-exclamation-triangle"></i></div></div></div></div>
            <div class="col-xl-3 col-md-6 mb-3"><div class="stat-card"><div class="card-body d-flex justify-content-between align-items-center"><div><div class="stat-label">Today's Collections</div><div class="stat-value"><?= bursarDashMoney($stats['today_collected']) ?></div><div class="stat-note">Completed student payments today</div></div><div class="stat-icon orange"><i class="fas fa-cash-register"></i></div></div></div></div>
        </div>

        <div class="section-heading mt-2"><h4>Finance Summary</h4></div>
        <div class="row">
            <div class="col-xl-3 col-md-6 mb-3"><div class="stat-card"><div class="card-body d-flex justify-content-between align-items-center"><div><div class="stat-label">Student Accounts</div><div class="stat-value"><?= $stats['accounts'] === null ? '—' : number_format($stats['accounts']) ?></div><div class="stat-note">Fee accounts recorded</div></div><div class="stat-icon purple"><i class="fas fa-folder-open"></i></div></div></div></div>
            <div class="col-xl-3 col-md-6 mb-3"><div class="stat-card"><div class="card-body d-flex justify-content-between align-items-center"><div><div class="stat-label">Students With Accounts</div><div class="stat-value"><?= $stats['students'] === null ? '—' : number_format($stats['students']) ?></div><div class="stat-note">Distinct students</div></div><div class="stat-icon blue"><i class="fas fa-user-graduate"></i></div></div></div></div>
            <div class="col-xl-3 col-md-6 mb-3"><div class="stat-card"><div class="card-body d-flex justify-content-between align-items-center"><div><div class="stat-label">Other Income This Month</div><div class="stat-value text-success"><?= bursarDashMoney($stats['month_income']) ?></div><div class="stat-note">Income transactions</div></div><div class="stat-icon teal"><i class="fas fa-arrow-down"></i></div></div></div></div>
            <div class="col-xl-3 col-md-6 mb-3"><div class="stat-card"><div class="card-body d-flex justify-content-between align-items-center"><div><div class="stat-label">Expenses This Month</div><div class="stat-value text-danger"><?= bursarDashMoney($stats['month_expenses']) ?></div><div class="stat-note">Expense transactions</div></div><div class="stat-icon red"><i class="fas fa-arrow-up"></i></div></div></div></div>
            <div class="col-xl-3 col-md-6 mb-3"><div class="stat-card"><div class="card-body d-flex justify-content-between align-items-center"><div><div class="stat-label">Salary Payments This Month</div><div class="stat-value"><?= bursarDashMoney($stats['month_salary']) ?></div><div class="stat-note">Recorded payroll disbursements</div></div><div class="stat-icon orange"><i class="fas fa-users"></i></div></div></div></div>
            <div class="col-xl-3 col-md-6 mb-3"><div class="stat-card"><div class="card-body d-flex justify-content-between align-items-center"><div><div class="stat-label">Outstanding Accounts</div><div class="stat-value"><?= $stats['outstanding_accounts'] === null ? '—' : number_format($stats['outstanding_accounts']) ?></div><div class="stat-note">Accounts with a balance due</div></div><div class="stat-icon red"><i class="fas fa-clock"></i></div></div></div></div>
            <div class="col-xl-3 col-md-6 mb-3"><div class="stat-card"><div class="card-body d-flex justify-content-between align-items-center"><div><div class="stat-label">Payment Records</div><div class="stat-value"><?= $stats['payment_count'] === null ? '—' : number_format($stats['payment_count']) ?></div><div class="stat-note">Records in the payment ledger</div></div><div class="stat-icon green"><i class="fas fa-receipt"></i></div></div></div></div>
            <div class="col-xl-3 col-md-6 mb-3"><div class="stat-card"><div class="card-body d-flex justify-content-between align-items-center"><div><div class="stat-label">Suppliers</div><div class="stat-value"><?= $stats['suppliers'] === null ? '—' : number_format($stats['suppliers']) ?></div><div class="stat-note">Registered suppliers</div></div><div class="stat-icon purple"><i class="fas fa-truck"></i></div></div></div></div>
        </div>

        <div class="section-heading mt-3"><h4>Finance Modules</h4></div>
        <div class="row">
            <?php
            $modules = [
                ['Student Fee Accounts','View student balances, fee allocations and payment history.','fa-user-graduate','blue','accounts','Open Accounts'],
                ['Fee Structure','Set class fees, terms and academic-year charges.','fa-layer-group','purple','fees','Manage Fees'],
                ['Receive Student Payment','Record payments and issue student receipts.','fa-cash-register','green','payments','Record Payment'],
                ['Outstanding Fees','Review unpaid balances and follow up arrears.','fa-exclamation-circle','red','outstanding','View Balances'],
                ['Other Income','Record and track non-fee school income.','fa-arrow-down','teal','income','Manage Income'],
                ['Expenses','Record operating costs and school expenditures.','fa-arrow-up','orange','expenses','Manage Expenses'],
                ['Suppliers','Maintain supplier details and balances.','fa-truck','blue','suppliers','Manage Suppliers'],
                ['Supplier Payments','Record payments made to suppliers.','fa-file-invoice-dollar','green','supplier_payments','Pay Suppliers'],
                ['Staff Salaries','Maintain staff salary records.','fa-users','purple','salaries','Manage Salaries'],
                ['Salary Payments','Record and review staff salary disbursements.','fa-money-check-alt','orange','salary_payments','Pay Salaries'],
                ['Budgets','Plan and monitor school budgets.','fa-wallet','teal','budgets','Manage Budgets'],
                ['Cashbook','Review money received and money paid.','fa-book','blue','cashbook','Open Cashbook'],
                ['Financial Reports','Review income, expenditure and finance summaries.','fa-chart-bar','purple','reports','View Reports'],
                ['Fees Report','Review student fee collections and balances.','fa-receipt','green','fees_report','View Fees Report'],
                ['Profit & Loss','Compare recorded income and expenses.','fa-balance-scale','orange','profit_loss','View Profit & Loss'],
            ];
            foreach ($modules as $module):
            ?>
            <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                <div class="module-card">
                    <div class="module-icon"><i class="fas <?= bursarDashE($module[2]) ?>"></i></div>
                    <h5><?= bursarDashE($module[0]) ?></h5>
                    <p><?= bursarDashE($module[1]) ?></p>
                    <a class="btn btn-outline-primary btn-block" href="<?= bursarDashE($links[$module[4]]) ?>"><?= bursarDashE($module[5]) ?> <i class="fas fa-arrow-right ml-1"></i></a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <section class="content-card mt-1">
            <div class="card-header d-flex justify-content-between align-items-center"><span><i class="fas fa-history text-primary mr-2"></i>Recent Student Payments</span><a href="<?= bursarDashE($links['payments']) ?>" class="btn btn-sm btn-outline-primary">View All Payments</a></div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead><tr><th>Receipt / Payment</th><th>Student</th><th>Reference</th><th>Date</th><th class="text-right">Amount (UGX)</th><th>Status</th></tr></thead>
                    <tbody>
                    <?php if (!$recentPayments): ?>
                        <tr><td colspan="6" class="text-center text-muted py-4">No recent payment records were found, or the payment table does not contain the expected date and amount columns.</td></tr>
                    <?php else: foreach ($recentPayments as $payment):
                        $receiptLabel = trim((string)($payment['receipt'] ?? ''));
                        if ($receiptLabel === '') $receiptLabel = !empty($payment['row_id']) ? 'Payment #' . (int)$payment['row_id'] : 'Payment';
                        $studentLabel = trim((string)($payment['student_name'] ?? ''));
                        if ($studentLabel === '' && !empty($payment['student_id'])) $studentLabel = 'Student #' . (string)$payment['student_id'];
                        if ($studentLabel === '') $studentLabel = 'Student fee payment';
                        $paidOn = trim((string)($payment['paid_on'] ?? ''));
                        $paidOnLabel = $paidOn !== '' && strtotime($paidOn) ? date('d M Y, H:i', strtotime($paidOn)) : '—';
                        $statusLabel = trim((string)($payment['payment_status'] ?? 'Recorded')) ?: 'Recorded';
                    ?>
                        <tr>
                            <td><strong><?= bursarDashE($receiptLabel) ?></strong></td>
                            <td><?= bursarDashE($studentLabel) ?><div class="small text-muted">LIN: <?= bursarDashE($payment['lin_no'] ?? '—') ?> | Payment Code: <?= bursarDashE($payment['student_payment_code'] ?? '—') ?> | <?= bursarDashE($payment['student_section'] ?? 'Day') ?></div></td>
                            <td><?= bursarDashE($payment['reference_no'] ?? '—') ?></td>
                            <td><?= bursarDashE($paidOnLabel) ?></td>
                            <td class="text-right font-weight-bold"> <?= number_format((float)($payment['amount'] ?? 0), 0) ?></td>
                            <td><span class="badge badge-success"><?= bursarDashE(ucwords(str_replace('_', ' ', $statusLabel))) ?></span></td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <div class="footer">School Management System &copy; <?= date('Y') ?> &mdash; Bursar Finance Workspace</div>
    </main>
</div>

<script>
(function () {
    var sidebar = document.getElementById('sidebar');
    var overlay = document.getElementById('sidebarOverlay');
    var button = document.getElementById('mobileMenuBtn');
    function closeMenu() {
        if (sidebar) sidebar.classList.remove('show');
        if (overlay) overlay.classList.remove('show');
    }
    if (button && sidebar) {
        button.addEventListener('click', function () {
            sidebar.classList.toggle('show');
            if (overlay) overlay.classList.toggle('show', sidebar.classList.contains('show'));
        });
    }
    if (overlay) overlay.addEventListener('click', closeMenu);
    document.addEventListener('keydown', function (event) { if (event.key === 'Escape') closeMenu(); });
    window.addEventListener('resize', function () { if (window.innerWidth > 991) closeMenu(); });
})();
</script>
</body>
</html>
