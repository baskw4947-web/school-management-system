<?php
/**
 * School Management System - Administrator Dashboard
 * Statistics are read live from the configured MySQL database.
 */

// Load authentication before producing any HTML so redirects and sessions work.
require_once __DIR__ . '../includes/auth.php';
requireRole([
    'administrator',
    'assistant_administrator',
    'bursar'
]);

// The database configuration used by the other school-management modules.
$dashboardDb = null;
$dashboardDbWarning = false;
try {
    require_once __DIR__ . '../config/database.php';
    $dashboardDb = $conn ?? ($mysqli ?? ($connection ?? null));
    if (!$dashboardDb instanceof mysqli) {
        $dashboardDbWarning = true;
        error_log('Administrator dashboard: database configuration did not provide a MySQLi connection.');
    } else {
        $dashboardDb->set_charset('utf8mb4');
    }
} catch (Throwable $exception) {
    $dashboardDbWarning = true;
    error_log('Administrator dashboard database error: ' . $exception->getMessage());
}

/** Check for a table in the currently selected database. */
function dashboardTableExists(mysqli $db, string $table): bool
{
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $table)) {
        return false;
    }
    $stmt = $db->prepare('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1');
    $stmt->bind_param('s', $table);
    $stmt->execute();
    $exists = $stmt->get_result()->num_rows > 0;
    $stmt->close();
    return $exists;
}

/** Return a lowercase-keyed list of a table's real column names. */
function dashboardColumns(mysqli $db, string $table): array
{
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $table) || !dashboardTableExists($db, $table)) {
        return [];
    }
    $result = $db->query('SHOW COLUMNS FROM `' . $table . '`');
    $columns = [];
    while ($row = $result->fetch_assoc()) {
        $columns[strtolower($row['Field'])] = $row['Field'];
    }
    return $columns;
}

/** Return a row count, or null when the table is not available. */
function dashboardCount(mysqli $db, string $table): ?int
{
    try {
        if (!dashboardTableExists($db, $table)) {
            return null;
        }
        $result = $db->query('SELECT COUNT(*) AS total FROM `' . $table . '`');
        $row = $result->fetch_assoc();
        return (int)($row['total'] ?? 0);
    } catch (Throwable $exception) {
        error_log('Administrator dashboard count error for ' . $table . ': ' . $exception->getMessage());
        return null;
    }
}

/**
 * Total recorded student fees collected. Prefer the individual payment ledger;
 * use the cumulative amount-paid field on fee accounts only if no usable ledger exists.
 */
function dashboardFeesCollected(mysqli $db): ?float
{
    try {
        $paymentColumns = dashboardColumns($db, 'fee_payments');
        $amountColumn = null;
        foreach (['amount', 'paid_amount', 'payment_amount', 'total_amount', 'received_amount'] as $candidate) {
            if (isset($paymentColumns[$candidate])) {
                $amountColumn = $paymentColumns[$candidate];
                break;
            }
        }

        if ($amountColumn !== null) {
            $sql = 'SELECT COALESCE(SUM(`' . $amountColumn . '`), 0) AS total FROM `fee_payments`';
            $statusColumn = null;
            foreach (['status', 'payment_status'] as $candidate) {
                if (isset($paymentColumns[$candidate])) {
                    $statusColumn = $paymentColumns[$candidate];
                    break;
                }
            }
            if ($statusColumn !== null) {
                $sql .= " WHERE LOWER(COALESCE(`" . $statusColumn . "`, '')) NOT IN ('cancelled','canceled','reversed','void','failed','deleted')";
            }
            $result = $db->query($sql);
            $row = $result->fetch_assoc();
            return (float)($row['total'] ?? 0);
        }

        $accountColumns = dashboardColumns($db, 'student_fee_accounts');
        $paidColumn = null;
        foreach (['amount_paid', 'total_paid', 'paid_amount', 'amount_received'] as $candidate) {
            if (isset($accountColumns[$candidate])) {
                $paidColumn = $accountColumns[$candidate];
                break;
            }
        }
        if ($paidColumn !== null) {
            $result = $db->query('SELECT COALESCE(SUM(`' . $paidColumn . '`), 0) AS total FROM `student_fee_accounts`');
            $row = $result->fetch_assoc();
            return (float)($row['total'] ?? 0);
        }
        return null;
    } catch (Throwable $exception) {
        error_log('Administrator dashboard fees total error: ' . $exception->getMessage());
        return null;
    }
}

$dashboardStats = [
    'students' => null,
    'classes' => null,
    'teachers' => null,
    'fees' => null,
];

if ($dashboardDb instanceof mysqli) {
    $dashboardStats['students'] = dashboardCount($dashboardDb, 'students');
    $dashboardStats['classes'] = dashboardCount($dashboardDb, 'classes');
    $dashboardStats['teachers'] = dashboardCount($dashboardDb, 'teachers');
    $dashboardStats['fees'] = dashboardFeesCollected($dashboardDb);
}

if (in_array(null, $dashboardStats, true)) {
    $dashboardDbWarning = true;
}

$adminName = (string)($_SESSION['full_name'] ?? $_SESSION['name'] ?? 'Administrator');
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Administrator Dashboard</title>

    <link rel="stylesheet"
          href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>

        body {
            background: #f4f6f9;
            font-family: Arial, sans-serif;
        }

        /* Sidebar */

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            width: 250px;
            background: #172b4d;
            color: white;
            overflow-y: auto;
            z-index: 1000;
        }

        .sidebar-brand {
            padding: 25px 20px;
            font-size: 21px;
            font-weight: bold;
            background: #10213d;
            text-align: center;
        }

        .sidebar-menu {
            padding: 15px 10px;
        }

        .sidebar-menu a {
            display: block;
            color: #d8e0eb;
            padding: 13px 15px;
            margin-bottom: 5px;
            border-radius: 6px;
            text-decoration: none;
            transition: 0.2s;
        }

        .sidebar-menu a:hover {
            background: #007bff;
            color: white;
        }

        .sidebar-menu a.active {
            background: #007bff;
            color: white;
        }

        .sidebar-menu i {
            width: 25px;
        }

        .menu-title {
            color: #8998ad;
            font-size: 12px;
            text-transform: uppercase;
            padding: 15px;
            margin-top: 10px;
        }

        /* Main */

        .main-content {
            margin-left: 250px;
            min-height: 100vh;
        }

        .topbar {
            background: white;
            padding: 15px 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .topbar h4 {
            margin: 0;
            font-weight: 600;
        }

        .welcome-box {
            background: linear-gradient(135deg, #007bff, #0056b3);
            color: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 25px;
        }

        .welcome-box h3 {
            font-weight: bold;
        }

        /* Statistics */

        .stat-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
            transition: 0.2s;
        }

        .stat-card:hover {
            transform: translateY(-3px);
        }

        .stat-icon {
            width: 55px;
            height: 55px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 23px;
            color: white;
        }

        .blue {
            background: #007bff;
        }

        .green {
            background: #28a745;
        }

        .orange {
            background: #fd7e14;
        }

        .purple {
            background: #6f42c1;
        }

        .fees-total {
            font-size: 1.15rem;
            overflow-wrap: anywhere;
        }

        .dashboard-db-warning {
            border-radius: 8px;
            margin-bottom: 20px;
        }

        /* Module cards */

        .module-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            height: 100%;
            border: none;
            box-shadow: 0 3px 12px rgba(0,0,0,0.07);
            transition: 0.2s;
        }

        .module-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 7px 20px rgba(0,0,0,0.12);
        }

        .module-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 26px;
            color: white;
            margin-bottom: 15px;
        }

        .module-card h5 {
            font-weight: bold;
            margin-bottom: 8px;
        }

        .module-card p {
            color: #777;
            font-size: 14px;
            min-height: 40px;
        }

        .module-card .btn {
            border-radius: 5px;
        }

        /* Mobile */

        @media (max-width: 768px) {

            .sidebar {
                position: relative;
                width: 100%;
                min-height: auto;
            }

            .main-content {
                margin-left: 0;
            }

            .sidebar-menu {
                padding-bottom: 10px;
            }

        }

    </style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>

<body>
<button type="button" id="unifiedSidebarToggle" class="unified-sidebar-toggle" aria-label="Open navigation" aria-controls="sidebar" aria-expanded="false"><i class="fas fa-bars"></i></button>
<div id="unifiedSidebarOverlay" class="sidebar-overlay"></div>



<!-- ================= SIDEBAR ================= -->

<div class="sidebar">

    <div class="sidebar-brand">

        <i class="fas fa-school"></i>

        School Management

    </div>


    <div class="sidebar-menu">

        <div class="menu-title">
            Main
        </div>

        <a href="/admin/dashboard.php" class="active">
            <i class="fas fa-tachometer-alt"></i>
            Dashboard
        </a>


        <div class="menu-title">
            Academic
        </div>

        <a href="/admin/classes/index.php">
            <i class="fas fa-chalkboard"></i>
            Classes
        </a>

        <a href="/admin/students/list.php">
            <i class="fas fa-user-graduate"></i>
            Students
        </a>

        <a href="/admin/teachers/index.php">
            <i class="fas fa-chalkboard-teacher"></i>
            Teachers
        </a>


        <div class="menu-title">
            Finance
        </div>

        <a href="/bursar/dashboard.php">
            <i class="fas fa-money-bill-wave"></i>
            Bursar
        </a>


        <div class="menu-title">
            School Management
        </div>

        <a href="/admin/assets/index.php">
            <i class="fas fa-boxes"></i>
            Assets
        </a>

        <a href="/admin/staff/index.php">
            <i class="fas fa-users"></i>
            Other Staff Members
        </a>

        <a href="/admin/projects/index.php">
            <i class="fas fa-project-diagram"></i>
            School Projects
        </a>


        <div class="menu-title">
            Administration
        </div>

        <a href="/admin/users/index.php">
            <i class="fas fa-users-cog"></i>
            Users
        </a>

        <a href="/logout.php">
            <i class="fas fa-sign-out-alt"></i>
            Logout
        </a>

    </div>

</div>


<!-- ================= MAIN CONTENT ================= -->

<div class="main-content">


    <!-- TOP BAR -->

    <div class="topbar">

        <div>

            <h4>
                Administrator Dashboard
            </h4>

        </div>


        <div>

            <span class="mr-3">

                <i class="fas fa-user-circle"></i>

                <?php
                echo htmlspecialchars($adminName, ENT_QUOTES, 'UTF-8');
                ?>

            </span>

            <a href="../logout.php"
               class="btn btn-outline-danger btn-sm">

                <i class="fas fa-sign-out-alt"></i>

                Logout

            </a>

        </div>

    </div>


    <!-- PAGE CONTENT -->

    <div class="container-fluid p-4">


        <?php if ($dashboardDbWarning): ?>
            <div class="alert alert-warning dashboard-db-warning" role="status">
                <strong>Some dashboard totals could not be loaded.</strong>
                Check that the database connection and the expected tables are available. A dash (—) means that a matching table or amount column was not found; details are written to the PHP error log.
            </div>
        <?php endif; ?>

        <!-- WELCOME -->

        <div class="welcome-box">

            <h3>

                Welcome,
                <?php
                echo htmlspecialchars($adminName, ENT_QUOTES, 'UTF-8');
                ?>

            </h3>

            <p class="mb-0">

                Manage your school's students, classes,
                teachers, staff, finances, assets and projects
                from one place.

            </p>

        </div>


        <!-- ================= STATISTICS ================= -->

        <div class="row">


            <div class="col-md-3 mb-4">

                <div class="card stat-card">

                    <div class="card-body">

                        <div class="d-flex align-items-center">

                            <div class="stat-icon blue mr-3">

                                <i class="fas fa-user-graduate"></i>

                            </div>

                            <div>

                                <small class="text-muted">
                                    Students
                                </small>

                                <h4 class="mb-0"><?= $dashboardStats['students'] === null ? '—' : number_format($dashboardStats['students']) ?></h4>

                            </div>

                        </div>

                    </div>

                </div>

            </div>


            <div class="col-md-3 mb-4">

                <div class="card stat-card">

                    <div class="card-body">

                        <div class="d-flex align-items-center">

                            <div class="stat-icon green mr-3">

                                <i class="fas fa-chalkboard"></i>

                            </div>

                            <div>

                                <small class="text-muted">
                                    Classes
                                </small>

                                <h4 class="mb-0"><?= $dashboardStats['classes'] === null ? '—' : number_format($dashboardStats['classes']) ?></h4>

                            </div>

                        </div>

                    </div>

                </div>

            </div>


            <div class="col-md-3 mb-4">

                <div class="card stat-card">

                    <div class="card-body">

                        <div class="d-flex align-items-center">

                            <div class="stat-icon orange mr-3">

                                <i class="fas fa-chalkboard-teacher"></i>

                            </div>

                            <div>

                                <small class="text-muted">
                                    Teachers
                                </small>

                                <h4 class="mb-0"><?= $dashboardStats['teachers'] === null ? '—' : number_format($dashboardStats['teachers']) ?></h4>

                            </div>

                        </div>

                    </div>

                </div>

            </div>


            <div class="col-md-3 mb-4">

                <div class="card stat-card">

                    <div class="card-body">

                        <div class="d-flex align-items-center">

                            <div class="stat-icon purple mr-3">

                                <i class="fas fa-money-bill-wave"></i>

                            </div>

                            <div>

                                <small class="text-muted">
                                    Fees Collected
                                </small>

                                <h4 class="mb-0 fees-total"><?= $dashboardStats['fees'] === null ? 'UGX —' : 'UGX ' . number_format($dashboardStats['fees'], 0) ?></h4>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- ================= MODULES ================= -->

        <div class="d-flex justify-content-between align-items-center mb-3">

            <h4>
                School Management
            </h4>

        </div>


        <div class="row">


            <!-- CLASSES -->

            <div class="col-lg-3 col-md-6 mb-4">

                <div class="module-card">

                    <div class="module-icon blue">

                        <i class="fas fa-chalkboard"></i>

                    </div>

                    <h5>
                        Classes
                    </h5>

                    <p>
                        Create and manage school classes,
                        sections and academic years.
                    </p>

                    <a href="classes/index.php"
                       class="btn btn-primary btn-block">

                        Manage Classes

                    </a>

                </div>

            </div>


            <!-- STUDENTS -->

            <div class="col-lg-3 col-md-6 mb-4">

                <div class="module-card">

                    <div class="module-icon green">

                        <i class="fas fa-user-graduate"></i>

                    </div>

                    <h5>
                        Students
                    </h5>

                    <p>
                        Register students, manage profiles,
                        guardians and student records.
                    </p>

                    <a href="students/list.php"
                       class="btn btn-success btn-block">

                        Manage Students

                    </a>

                </div>

            </div>


            <!-- ASSETS -->

            <div class="col-lg-3 col-md-6 mb-4">

                <div class="module-card">

                    <div class="module-icon orange">

                        <i class="fas fa-boxes"></i>

                    </div>

                    <h5>
                        Assets
                    </h5>

                    <p>
                        Manage school property,
                        equipment and other assets.
                    </p>

                    <a href="assets/index.php"
                       class="btn btn-warning btn-block">

                        Manage Assets

                    </a>

                </div>

            </div>


            <!-- BURSAR -->

            <div class="col-lg-3 col-md-6 mb-4">

                <div class="module-card">

                    <div class="module-icon purple">

                        <i class="fas fa-money-bill-wave"></i>

                    </div>

                    <h5>
                        Bursar
                    </h5>

                    <p>
                        Manage school fees, payments,
                        balances and financial records.
                    </p>

                    <a href="bursar/index.php"
                       class="btn btn-primary btn-block">

                        Open Bursar

                    </a>

                </div>

            </div>


            <!-- TEACHERS -->

            <div class="col-lg-3 col-md-6 mb-4">

                <div class="module-card">

                    <div class="module-icon blue">

                        <i class="fas fa-chalkboard-teacher"></i>

                    </div>

                    <h5>
                        Teachers
                    </h5>

                    <p>
                        Manage teachers, subjects,
                        assignments and teacher records.
                    </p>

                    <a href="teachers/index.php"
                       class="btn btn-info btn-block">

                        Manage Teachers

                    </a>

                </div>

            </div>


            <!-- OTHER STAFF -->

            <div class="col-lg-3 col-md-6 mb-4">

                <div class="module-card">

                    <div class="module-icon green">

                        <i class="fas fa-users"></i>

                    </div>

                    <h5>
                        Other Staff Members
                    </h5>

                    <p>
                        Manage non-teaching staff
                        and employee information.
                    </p>

                    <a href="staff/index.php"
                       class="btn btn-success btn-block">

                        Manage Staff

                    </a>

                </div>

            </div>


            <!-- SCHOOL PROJECTS -->

            <div class="col-lg-3 col-md-6 mb-4">

                <div class="module-card">

                    <div class="module-icon orange">

                        <i class="fas fa-project-diagram"></i>

                    </div>

                    <h5>
                        School Projects
                    </h5>

                    <p>
                        Manage school development
                        projects and project expenses.
                    </p>

                    <a href="projects/index.php"
                       class="btn btn-warning btn-block">

                        Manage Projects

                    </a>

                </div>

            </div>


            <!-- USERS -->

            <div class="col-lg-3 col-md-6 mb-4">

                <div class="module-card">

                    <div class="module-icon purple">

                        <i class="fas fa-users-cog"></i>

                    </div>

                    <h5>
                        System Users
                    </h5>

                    <p>
                        Manage administrators, assistants,
                        bursars and teachers.
                    </p>

                    <a href="users/index.php"
                       class="btn btn-dark btn-block">

                        Manage Users

                    </a>

                </div>

            </div>


        </div>


        <!-- FOOTER -->

        <div class="text-center text-muted mt-4 mb-3">

            <small>

                School Management System &copy;
                <?php echo date('Y'); ?>

            </small>

        </div>


    </div>

</div>



<script src="/assets/js/sidebar-unified.js?v=20261106"></script>
</body>

</html>