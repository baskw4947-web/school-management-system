<?php
/**
 * School Management System - Assistant Administrator Dashboard
 * Statistics are read live from the configured MySQL database.
 */

// Load authentication before producing any HTML so redirects and sessions work.
require_once __DIR__ . '/../includes/auth.php';
requireRole(['assistant_administrator', 'administrator']);

// The database configuration used by the other school-management modules.
$assistantDashboardDb = null;
$assistantDashboardDbWarning = false;
try {
    require_once __DIR__ . '/../config/database.php';
    $assistantDashboardDb = $conn ?? ($mysqli ?? ($connection ?? null));
    if (!$assistantDashboardDb instanceof mysqli) {
        $assistantDashboardDbWarning = true;
        error_log('Assistant administrator dashboard: database configuration did not provide a MySQLi connection.');
    } else {
        $assistantDashboardDb->set_charset('utf8mb4');
    }
} catch (Throwable $exception) {
    $assistantDashboardDbWarning = true;
    error_log('Assistant administrator dashboard database error: ' . $exception->getMessage());
}

/** Check for a table in the currently selected database. */
function assistantDashboardTableExists(mysqli $db, string $table): bool
{
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $table)) {
        return false;
    }
    $stmt = $db->prepare('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1');
    $stmt->bind_param('s', $table);
    $stmt->execute();
    $exists = $stmt->get_result()->num_rows > 0;
    $stmt->close();
    return $exists;
}

/** Return a lowercase-keyed list of a table's real column names. */
function assistantDashboardColumns(mysqli $db, string $table): array
{
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $table) || !assistantDashboardTableExists($db, $table)) {
        return [];
    }
    $result = $db->query('SHOW COLUMNS FROM `' . $table . '`');
    $columns = [];
    while ($row = $result->fetch_assoc()) {
        $columns[strtolower($row['Field'])] = $row['Field'];
    }
    return $columns;
}

/** Return a row count, or null when the table is not available. */
function assistantDashboardCount(mysqli $db, string $table): ?int
{
    try {
        if (!assistantDashboardTableExists($db, $table)) {
            return null;
        }
        $result = $db->query('SELECT COUNT(*) AS total FROM `' . $table . '`');
        $row = $result->fetch_assoc();
        return (int)($row['total'] ?? 0);
    } catch (Throwable $exception) {
        error_log('Assistant administrator dashboard count error for ' . $table . ': ' . $exception->getMessage());
        return null;
    }
}

/**
 * Total recorded student fees collected. Prefer the individual payment ledger;
 * use the cumulative amount-paid field on fee accounts only if no usable ledger exists.
 */
function assistantDashboardFeesCollected(mysqli $db): ?float
{
    try {
        $paymentColumns = assistantDashboardColumns($db, 'fee_payments');
        $amountColumn = null;
        foreach (['amount', 'paid_amount', 'payment_amount', 'total_amount', 'received_amount'] as $candidate) {
            if (isset($paymentColumns[$candidate])) {
                $amountColumn = $paymentColumns[$candidate];
                break;
            }
        }

        if ($amountColumn !== null) {
            $sql = 'SELECT COALESCE(SUM(`' . $amountColumn . '`), 0) AS total FROM `fee_payments`';
            $statusColumn = null;
            foreach (['status', 'payment_status'] as $candidate) {
                if (isset($paymentColumns[$candidate])) {
                    $statusColumn = $paymentColumns[$candidate];
                    break;
                }
            }
            if ($statusColumn !== null) {
                $sql .= " WHERE LOWER(COALESCE(`" . $statusColumn . "`, '')) NOT IN ('cancelled','canceled','reversed','void','failed','deleted')";
            }
            $result = $db->query($sql);
            $row = $result->fetch_assoc();
            return (float)($row['total'] ?? 0);
        }

        $accountColumns = assistantDashboardColumns($db, 'student_fee_accounts');
        $paidColumn = null;
        foreach (['amount_paid', 'total_paid', 'paid_amount', 'amount_received'] as $candidate) {
            if (isset($accountColumns[$candidate])) {
                $paidColumn = $accountColumns[$candidate];
                break;
            }
        }
        if ($paidColumn !== null) {
            $result = $db->query('SELECT COALESCE(SUM(`' . $paidColumn . '`), 0) AS total FROM `student_fee_accounts`');
            $row = $result->fetch_assoc();
            return (float)($row['total'] ?? 0);
        }
        return null;
    } catch (Throwable $exception) {
        error_log('Assistant administrator dashboard fees total error: ' . $exception->getMessage());
        return null;
    }
}

$assistantDashboardStats = [
    'students' => null,
    'classes' => null,
    'teachers' => null,
    'fees' => null,
];

if ($assistantDashboardDb instanceof mysqli) {
    $assistantDashboardStats['students'] = assistantDashboardCount($assistantDashboardDb, 'students');
    $assistantDashboardStats['classes'] = assistantDashboardCount($assistantDashboardDb, 'classes');
    $assistantDashboardStats['teachers'] = assistantDashboardCount($assistantDashboardDb, 'teachers');
    $assistantDashboardStats['fees'] = assistantDashboardFeesCollected($assistantDashboardDb);
}

if (in_array(null, $assistantDashboardStats, true)) {
    $assistantDashboardDbWarning = true;
}

$assistantName = (string)($_SESSION['full_name'] ?? $_SESSION['name'] ?? 'Assistant Administrator');
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Assistant Assistant Administrator Dashboard</title>

    <link rel="stylesheet"
          href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>

        body {
            background: #f4f6f9;
            font-family: Arial, sans-serif;
        }

        /* Sidebar */

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            width: 250px;
            background: #172b4d;
            color: white;
            overflow-y: auto;
            z-index: 1000;
        }

        .sidebar-brand {
            padding: 25px 20px;
            font-size: 21px;
            font-weight: bold;
            background: #10213d;
            text-align: center;
        }

        .sidebar-menu {
            padding: 15px 10px;
        }

        .sidebar-menu a {
            display: block;
            color: #d8e0eb;
            padding: 13px 15px;
            margin-bottom: 5px;
            border-radius: 6px;
            text-decoration: none;
            transition: 0.2s;
        }

        .sidebar-menu a:hover {
            background: #007bff;
            color: white;
        }

        .sidebar-menu a.active {
            background: #007bff;
            color: white;
        }

        .sidebar-menu i {
            width: 25px;
        }

        .menu-title {
            color: #8998ad;
            font-size: 12px;
            text-transform: uppercase;
            padding: 15px;
            margin-top: 10px;
        }

        /* Main */

        .main-content {
            margin-left: 250px;
            min-height: 100vh;
        }

        .topbar {
            background: white;
            padding: 15px 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .topbar h4 {
            margin: 0;
            font-weight: 600;
        }

        .welcome-box {
            background: linear-gradient(135deg, #007bff, #0056b3);
            color: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 25px;
        }

        .welcome-box h3 {
            font-weight: bold;
        }

        /* Statistics */

        .stat-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
            transition: 0.2s;
        }

        .stat-card:hover {
            transform: translateY(-3px);
        }

        .stat-icon {
            width: 55px;
            height: 55px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 23px;
            color: white;
        }

        .blue {
            background: #007bff;
        }

        .green {
            background: #28a745;
        }

        .orange {
            background: #fd7e14;
        }

        .purple {
            background: #6f42c1;
        }

        .fees-total {
            font-size: 1.15rem;
            overflow-wrap: anywhere;
        }

        .dashboard-db-warning {
            border-radius: 8px;
            margin-bottom: 20px;
        }

        /* Module cards */

        .module-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            height: 100%;
            border: none;
            box-shadow: 0 3px 12px rgba(0,0,0,0.07);
            transition: 0.2s;
        }

        .module-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 7px 20px rgba(0,0,0,0.12);
        }

        .module-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 26px;
            color: white;
            margin-bottom: 15px;
        }

        .module-card h5 {
            font-weight: bold;
            margin-bottom: 8px;
        }

        .module-card p {
            color: #777;
            font-size: 14px;
            min-height: 40px;
        }

        .module-card .btn {
            border-radius: 5px;
        }

        /* Mobile */

        @media (max-width: 768px) {

            .sidebar {
                position: relative;
                width: 100%;
                min-height: auto;
            }

            .main-content {
                margin-left: 0;
            }

            .sidebar-menu {
                padding-bottom: 10px;
            }

        }

    </style>

    <link rel="stylesheet" href="/assets/css/sidebar-unified.css?v=20261106">
</head>

<body>
<button type="button" id="unifiedSidebarToggle" class="unified-sidebar-toggle" aria-label="Open navigation" aria-controls="sidebar" aria-expanded="false"><i class="fas fa-bars"></i></button>
<div id="unifiedSidebarOverlay" class="sidebar-overlay"></div>



<!-- ================= SIDEBAR ================= -->

<div class="sidebar">

    <div class="sidebar-brand">

        <i class="fas fa-school"></i>

        School Management

    </div>


    <div class="sidebar-menu">

        <div class="menu-title">Main</div>
        <a href="/assistant_admin/dashboard.php" class="active">
            <i class="fas fa-tachometer-alt"></i>
            Dashboard
        </a>

        <div class="menu-title">Academic Management</div>
        <a href="/admin/classes/index.php">
            <i class="fas fa-chalkboard"></i>
            Classes
        </a>
        <a href="/admin/students/list.php">
            <i class="fas fa-user-graduate"></i>
            Students
        </a>
        <a href="/admin/teachers/index.php">
            <i class="fas fa-chalkboard-teacher"></i>
            Teachers
        </a>

        <div class="menu-title">Finance</div>
        <a href="/bursar/dashboard.php">
            <i class="fas fa-money-bill-wave"></i>
            Bursar Dashboard
        </a>

        <div class="menu-title">School Management</div>
        <a href="/admin/assets/index.php">
            <i class="fas fa-boxes"></i>
            Assets
        </a>
        <a href="/admin/staff/index.php">
            <i class="fas fa-users"></i>
            Other Staff Members
        </a>
        <a href="/admin/projects/index.php">
            <i class="fas fa-project-diagram"></i>
            School Projects
        </a>

        <div class="menu-title">Account</div>
        <a href="/logout.php">
            <i class="fas fa-sign-out-alt"></i>
            Logout
        </a>

    </div>

</div>


<!-- ================= MAIN CONTENT ================= -->

<div class="main-content">


    <!-- TOP BAR -->

    <div class="topbar">

        <div>

            <h4>
                Assistant Administrator Dashboard
            </h4>

        </div>


        <div>

            <span class="mr-3">

                <i class="fas fa-user-circle"></i>

                <?php
                echo htmlspecialchars($assistantName, ENT_QUOTES, 'UTF-8');
                ?>

            </span>

            <a href="../logout.php"
               class="btn btn-outline-danger btn-sm">

                <i class="fas fa-sign-out-alt"></i>

                Logout

            </a>

        </div>

    </div>


    <!-- PAGE CONTENT -->

    <div class="container-fluid p-4">


        <?php if ($assistantDashboardDbWarning): ?>
            <div class="alert alert-warning dashboard-db-warning" role="status">
                <strong>Some dashboard totals could not be loaded.</strong>
                Check that the database connection and the expected tables are available. A dash (—) means that a matching table or amount column was not found; details are written to the PHP error log.
            </div>
        <?php endif; ?>

        <!-- WELCOME -->

        <div class="welcome-box">

            <h3>

                Welcome,
                <?php
                echo htmlspecialchars($assistantName, ENT_QUOTES, 'UTF-8');
                ?>

            </h3>

            <p class="mb-0">

                Support your school's daily academic and administrative operations.
                Manage student records, classes, teachers and school resources
                from one place.

            </p>

        </div>


        <!-- ================= STATISTICS ================= -->

        <div class="row">


            <div class="col-md-3 mb-4">

                <div class="card stat-card">

                    <div class="card-body">

                        <div class="d-flex align-items-center">

                            <div class="stat-icon blue mr-3">

                                <i class="fas fa-user-graduate"></i>

                            </div>

                            <div>

                                <small class="text-muted">
                                    Students
                                </small>

                                <h4 class="mb-0"><?= $assistantDashboardStats['students'] === null ? '—' : number_format($assistantDashboardStats['students']) ?></h4>

                            </div>

                        </div>

                    </div>

                </div>

            </div>


            <div class="col-md-3 mb-4">

                <div class="card stat-card">

                    <div class="card-body">

                        <div class="d-flex align-items-center">

                            <div class="stat-icon green mr-3">

                                <i class="fas fa-chalkboard"></i>

                            </div>

                            <div>

                                <small class="text-muted">
                                    Classes
                                </small>

                                <h4 class="mb-0"><?= $assistantDashboardStats['classes'] === null ? '—' : number_format($assistantDashboardStats['classes']) ?></h4>

                            </div>

                        </div>

                    </div>

                </div>

            </div>


            <div class="col-md-3 mb-4">

                <div class="card stat-card">

                    <div class="card-body">

                        <div class="d-flex align-items-center">

                            <div class="stat-icon orange mr-3">

                                <i class="fas fa-chalkboard-teacher"></i>

                            </div>

                            <div>

                                <small class="text-muted">
                                    Teachers
                                </small>

                                <h4 class="mb-0"><?= $assistantDashboardStats['teachers'] === null ? '—' : number_format($assistantDashboardStats['teachers']) ?></h4>

                            </div>

                        </div>

                    </div>

                </div>

            </div>


            <div class="col-md-3 mb-4">

                <div class="card stat-card">

                    <div class="card-body">

                        <div class="d-flex align-items-center">

                            <div class="stat-icon purple mr-3">

                                <i class="fas fa-money-bill-wave"></i>

                            </div>

                            <div>

                                <small class="text-muted">
                                    Fees Collected
                                </small>

                                <h4 class="mb-0 fees-total"><?= $assistantDashboardStats['fees'] === null ? 'UGX —' : 'UGX ' . number_format($assistantDashboardStats['fees'], 0) ?></h4>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- ================= MODULES ================= -->

        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4>School Management</h4>
        </div>

        <div class="row">

            <div class="col-lg-3 col-md-6 mb-4">
                <div class="module-card">
                    <div class="module-icon blue"><i class="fas fa-chalkboard"></i></div>
                    <h5>Classes</h5>
                    <p>View and manage school classes, sections and academic years.</p>
                    <a href="../admin/classes/index.php" class="btn btn-primary btn-block">Open Classes</a>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4">
                <div class="module-card">
                    <div class="module-icon green"><i class="fas fa-user-graduate"></i></div>
                    <h5>Students</h5>
                    <p>Register students and maintain profiles, guardians and student records.</p>
                    <a href="../admin/students/list.php" class="btn btn-success btn-block">Open Students</a>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4">
                <div class="module-card">
                    <div class="module-icon orange"><i class="fas fa-chalkboard-teacher"></i></div>
                    <h5>Teachers</h5>
                    <p>View teacher records and manage teaching staff information.</p>
                    <a href="../admin/teachers/index.php" class="btn btn-info btn-block">Open Teachers</a>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4">
                <div class="module-card">
                    <div class="module-icon purple"><i class="fas fa-money-bill-wave"></i></div>
                    <h5>Bursar</h5>
                    <p>Review school fees, payments, outstanding balances and financial records.</p>
                    <a href="../bursar/dashboard.php" class="btn btn-primary btn-block">Open Bursar</a>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4">
                <div class="module-card">
                    <div class="module-icon orange"><i class="fas fa-boxes"></i></div>
                    <h5>Assets</h5>
                    <p>View and manage school property, equipment and other assets.</p>
                    <a href="../admin/assets/index.php" class="btn btn-warning btn-block">Open Assets</a>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4">
                <div class="module-card">
                    <div class="module-icon green"><i class="fas fa-users"></i></div>
                    <h5>Other Staff Members</h5>
                    <p>Maintain information about non-teaching staff and employees.</p>
                    <a href="../admin/staff/index.php" class="btn btn-success btn-block">Open Staff</a>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4">
                <div class="module-card">
                    <div class="module-icon blue"><i class="fas fa-project-diagram"></i></div>
                    <h5>School Projects</h5>
                    <p>Review school development projects and project activities.</p>
                    <a href="../admin/projects/index.php" class="btn btn-info btn-block">Open Projects</a>
                </div>
            </div>

        </div>


        <!-- FOOTER -->

        <div class="text-center text-muted mt-4 mb-3">

            <small>

                School Management System &copy;
                <?php echo date('Y'); ?>

            </small>

        </div>


    </div>

</div>



<script src="/assets/js/sidebar-unified.js?v=20261106"></script>
</body>

</html>
