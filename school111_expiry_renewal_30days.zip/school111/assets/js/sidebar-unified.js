(function () {
    'use strict';
    var sidebar = document.getElementById('sidebar') || document.querySelector('.sidebar');
    var button = document.getElementById('unifiedSidebarToggle');
    var overlay = document.getElementById('unifiedSidebarOverlay');
    if (!sidebar || !button || !overlay) return;

    function openMenu() {
        sidebar.classList.add('show');
        overlay.classList.add('show');
        button.setAttribute('aria-expanded', 'true');
    }
    function closeMenu() {
        sidebar.classList.remove('show');
        overlay.classList.remove('show');
        button.setAttribute('aria-expanded', 'false');
    }
    button.addEventListener('click', function () {
        if (sidebar.classList.contains('show')) closeMenu();
        else openMenu();
    });
    overlay.addEventListener('click', closeMenu);
    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') closeMenu();
    });
    sidebar.addEventListener('click', function (event) {
        if (event.target.closest('a')) closeMenu();
    });
    window.addEventListener('resize', function () {
        if (window.innerWidth > 991) closeMenu();
    });
})();
