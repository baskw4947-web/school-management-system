-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 24, 2026 at 05:04 PM
-- Server version: 5.7.23-23
-- PHP Version: 8.1.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sserumed_school_mgt`
--

-- --------------------------------------------------------

--
-- Table structure for table `budgets`
--

CREATE TABLE `budgets` (
  `id` int(11) NOT NULL,
  `budget_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `academic_year` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `total_budget` decimal(14,2) NOT NULL DEFAULT '0.00',
  `status` enum('draft','active','closed','cancelled') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'draft',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `budget_categories`
--

CREATE TABLE `budget_categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `status` enum('active','inactive') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `budget_items`
--

CREATE TABLE `budget_items` (
  `id` int(11) NOT NULL,
  `budget_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `budgeted_amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `id` int(11) NOT NULL,
  `class_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `section` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `academic_year` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`id`, `class_name`, `section`, `academic_year`, `status`, `created_at`) VALUES
(1, 'S.1', 'East', '2026', 'active', '2026-11-08 04:55:31'),
(2, 'S.1', 'WEST', '2026', 'active', '2026-11-08 04:55:48');

-- --------------------------------------------------------

--
-- Table structure for table `class_timetables`
--

CREATE TABLE `class_timetables` (
  `id` int(11) NOT NULL,
  `timetable_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stream` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teacher_name` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `room` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `day_of_week` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `academic_year` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `term` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Term 1',
  `lesson_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Lesson',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `status` enum('active','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `class_timetables`
--

INSERT INTO `class_timetables` (`id`, `timetable_code`, `class_name`, `stream`, `subject_name`, `teacher_name`, `room`, `day_of_week`, `start_time`, `end_time`, `academic_year`, `term`, `lesson_type`, `notes`, `status`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'TT-20261109-A4EC8A', 'S.1', 'west', 'math', 'Sseru Mark', 'Room 4', 'Monday', '08:00:00', '09:00:00', '2026', 'Term 1', 'Lesson', NULL, 'active', 1, '2026-11-09 22:52:48', '2026-11-09 22:52:48');

-- --------------------------------------------------------

--
-- Table structure for table `development_projects`
--

CREATE TABLE `development_projects` (
  `id` int(10) UNSIGNED NOT NULL,
  `project_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `project_name` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `contractor` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `project_manager` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `funding_source` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `budget_amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `status` enum('planned','ongoing','on_hold','completed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'planned',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `development_project_expenses`
--

CREATE TABLE `development_project_expenses` (
  `id` int(10) UNSIGNED NOT NULL,
  `expense_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `expense_date` date NOT NULL,
  `description` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_no` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(14,2) NOT NULL,
  `status` enum('paid','pending','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'paid',
  `recorded_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expense_categories`
--

CREATE TABLE `expense_categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `status` enum('active','inactive') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `expense_categories`
--

INSERT INTO `expense_categories` (`id`, `category_name`, `description`, `status`, `created_at`) VALUES
(1, 'Salaries and Wages', NULL, 'active', '2026-11-06 08:12:19'),
(2, 'Utilities', NULL, 'active', '2026-11-06 08:12:19'),
(3, 'Teaching Materials', NULL, 'active', '2026-11-06 08:12:19'),
(4, 'School Supplies', NULL, 'active', '2026-11-06 08:12:19'),
(5, 'Repairs and Maintenance', NULL, 'active', '2026-11-06 08:12:19'),
(6, 'Transport', NULL, 'active', '2026-11-06 08:12:19'),
(7, 'Supplier Payments', NULL, 'active', '2026-11-06 08:12:19'),
(8, 'Cleaning', NULL, 'active', '2026-11-06 08:12:19'),
(9, 'ICT and Equipment', NULL, 'active', '2026-11-06 08:12:19'),
(10, 'School Projects', NULL, 'active', '2026-11-06 08:12:19'),
(11, 'Administration', NULL, 'active', '2026-11-06 08:12:19'),
(12, 'Bank Charges', NULL, 'active', '2026-11-06 08:12:19'),
(13, 'Other', NULL, 'active', '2026-11-06 08:12:19');

-- --------------------------------------------------------

--
-- Table structure for table `expense_transactions`
--

CREATE TABLE `expense_transactions` (
  `id` int(11) NOT NULL,
  `transaction_no` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `expense_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `payment_method_id` int(11) DEFAULT NULL,
  `reference_no` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `supplier_id` int(11) DEFAULT NULL,
  `requested_by` int(11) DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'completed',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `payee_name` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fee_payments`
--

CREATE TABLE `fee_payments` (
  `id` int(11) NOT NULL,
  `receipt_no` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `student_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `payment_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reference_no` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `received_by` int(11) NOT NULL,
  `status` enum('completed','cancelled','reversed') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'completed',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fee_structures`
--

CREATE TABLE `fee_structures` (
  `id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `academic_year` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `term` enum('Term 1','Term 2','Term 3') COLLATE utf8_unicode_ci NOT NULL,
  `fee_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `due_date` date DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `financial_accounts`
--

CREATE TABLE `financial_accounts` (
  `id` int(11) NOT NULL,
  `account_code` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `account_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `account_type` enum('asset','liability','income','expense','equity') COLLATE utf8_unicode_ci NOT NULL,
  `opening_balance` decimal(14,2) NOT NULL DEFAULT '0.00',
  `status` enum('active','inactive') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `financial_transactions`
--

CREATE TABLE `financial_transactions` (
  `id` bigint(20) NOT NULL,
  `transaction_no` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `transaction_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `transaction_type` enum('income','expense','fee_payment','salary','supplier_payment','transfer','adjustment') COLLATE utf8_unicode_ci NOT NULL,
  `reference_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reference_id` bigint(20) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `debit` decimal(14,2) NOT NULL DEFAULT '0.00',
  `credit` decimal(14,2) NOT NULL DEFAULT '0.00',
  `payment_method_id` int(11) DEFAULT NULL,
  `reference_no` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `status` enum('completed','cancelled','reversed') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'completed',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `guardians`
--

CREATE TABLE `guardians` (
  `id` int(11) NOT NULL,
  `full_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `relationship` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `nin_no` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `income_categories`
--

CREATE TABLE `income_categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `status` enum('active','inactive') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `income_categories`
--

INSERT INTO `income_categories` (`id`, `category_name`, `description`, `status`, `created_at`) VALUES
(1, 'School Fees', NULL, 'active', '2026-11-06 08:06:33'),
(2, 'Donations', NULL, 'active', '2026-11-06 08:06:33'),
(3, 'Grants', NULL, 'active', '2026-11-06 08:06:33'),
(4, 'Fundraising', NULL, 'active', '2026-11-06 08:06:33'),
(5, 'Sale of Items', NULL, 'active', '2026-11-06 08:06:33'),
(6, 'Other Income', NULL, 'active', '2026-11-06 08:06:33');

-- --------------------------------------------------------

--
-- Table structure for table `income_transactions`
--

CREATE TABLE `income_transactions` (
  `id` int(11) NOT NULL,
  `transaction_no` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `income_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `payment_method_id` int(11) DEFAULT NULL,
  `reference_no` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `received_by` int(11) NOT NULL,
  `status` enum('completed','cancelled','reversed') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'completed',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `library_books`
--

CREATE TABLE `library_books` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `isbn` varchar(50) DEFAULT NULL,
  `book_title` varchar(255) NOT NULL,
  `author` varchar(180) DEFAULT NULL,
  `publisher` varchar(180) DEFAULT NULL,
  `publication_year` year(4) DEFAULT NULL,
  `edition` varchar(100) DEFAULT NULL,
  `language` varchar(80) DEFAULT 'English',
  `description` text,
  `shelf_location` varchar(100) DEFAULT NULL,
  `cover_image` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `library_book_copies`
--

CREATE TABLE `library_book_copies` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `accession_number` varchar(100) NOT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_price` decimal(12,2) DEFAULT '0.00',
  `condition_status` enum('new','good','fair','damaged','lost') DEFAULT 'good',
  `availability_status` enum('available','borrowed','reserved','lost','damaged') DEFAULT 'available',
  `notes` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `library_categories`
--

CREATE TABLE `library_categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(150) NOT NULL,
  `description` text,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `library_fines`
--

CREATE TABLE `library_fines` (
  `id` int(11) NOT NULL,
  `loan_id` int(11) NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `amount_paid` decimal(12,2) NOT NULL DEFAULT '0.00',
  `reason` varchar(255) NOT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_method` varchar(100) DEFAULT NULL,
  `recorded_by` int(11) DEFAULT NULL,
  `notes` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `library_loans`
--

CREATE TABLE `library_loans` (
  `id` int(11) NOT NULL,
  `copy_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `issue_date` date NOT NULL,
  `due_date` date NOT NULL,
  `return_date` date DEFAULT NULL,
  `loan_status` enum('borrowed','returned','overdue','lost') DEFAULT 'borrowed',
  `fine_amount` decimal(12,2) DEFAULT '0.00',
  `fine_paid` decimal(12,2) DEFAULT '0.00',
  `issued_by` int(11) DEFAULT NULL,
  `received_by` int(11) DEFAULT NULL,
  `issue_notes` text,
  `return_notes` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `library_members`
--

CREATE TABLE `library_members` (
  `id` int(11) NOT NULL,
  `member_type` enum('student','teacher','staff') NOT NULL,
  `member_id` int(11) NOT NULL,
  `membership_number` varchar(100) NOT NULL,
  `registration_date` date DEFAULT NULL,
  `status` enum('active','inactive','suspended') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `other_staff`
--

CREATE TABLE `other_staff` (
  `id` int(11) NOT NULL,
  `staff_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `other_names` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `department` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_title` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employment_type` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qualification` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_joined` date DEFAULT NULL,
  `salary` decimal(12,2) NOT NULL DEFAULT '0.00',
  `next_of_kin` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `next_of_kin_phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive','on_leave','terminated') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL,
  `method_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `method_name`, `status`, `created_at`, `description`) VALUES
(1, 'Cash', 'active', '2026-11-06 08:06:33', NULL),
(2, 'Mobile Money', 'active', '2026-11-06 08:06:33', NULL),
(3, 'Bank', 'active', '2026-11-06 08:06:33', NULL),
(4, 'Cheque', 'active', '2026-11-06 08:06:33', NULL),
(9, 'Other', 'active', '2026-11-06 08:12:19', 'Other payment method');

-- --------------------------------------------------------

--
-- Table structure for table `salaries`
--

CREATE TABLE `salaries` (
  `id` int(11) NOT NULL,
  `salary_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `person_source` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `person_id` int(11) DEFAULT NULL,
  `person_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `person_role` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `basic_salary` decimal(12,2) NOT NULL DEFAULT '0.00',
  `allowances` decimal(12,2) NOT NULL DEFAULT '0.00',
  `deductions` decimal(12,2) NOT NULL DEFAULT '0.00',
  `net_salary` decimal(12,2) NOT NULL DEFAULT '0.00',
  `pay_frequency` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'monthly',
  `effective_date` date DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `salary_payments`
--

CREATE TABLE `salary_payments` (
  `id` int(11) NOT NULL,
  `payment_no` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `payroll_month` date NOT NULL,
  `basic_salary` decimal(12,2) NOT NULL DEFAULT '0.00',
  `allowances` decimal(12,2) NOT NULL DEFAULT '0.00',
  `deductions` decimal(12,2) NOT NULL DEFAULT '0.00',
  `net_salary` decimal(12,2) NOT NULL DEFAULT '0.00',
  `payment_method_id` int(11) DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `reference_no` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paid_by` int(11) NOT NULL,
  `status` enum('pending','paid','cancelled','reversed') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'pending',
  `notes` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `school_assets`
--

CREATE TABLE `school_assets` (
  `id` int(10) UNSIGNED NOT NULL,
  `asset_code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `asset_name` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `serial_number` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `purchase_date` date DEFAULT NULL,
  `purchase_cost` decimal(14,2) NOT NULL DEFAULT '0.00',
  `supplier_name` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custodian` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `condition_status` enum('new','good','fair','poor','damaged') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'good',
  `asset_status` enum('active','in_repair','disposed','lost','retired') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `warranty_expiry` date DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `school_exams`
--

CREATE TABLE `school_exams` (
  `id` int(10) UNSIGNED NOT NULL,
  `exam_code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exam_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'End of Term',
  `class_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `term` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `academic_year` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exam_date` date DEFAULT NULL,
  `duration_minutes` int(10) UNSIGNED DEFAULT NULL,
  `max_marks` decimal(7,2) NOT NULL DEFAULT '100.00',
  `instructions` text COLLATE utf8mb4_unicode_ci,
  `status` enum('scheduled','open','closed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `school_exam_results`
--

CREATE TABLE `school_exam_results` (
  `id` int(10) UNSIGNED NOT NULL,
  `exam_id` int(10) UNSIGNED NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `student_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admission_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marks_obtained` decimal(7,2) NOT NULL DEFAULT '0.00',
  `percentage` decimal(6,2) NOT NULL DEFAULT '0.00',
  `grade` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entered_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `admission_no` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `lin_no` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `student_payment_code` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `other_names` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` enum('Male','Female','Other') COLLATE utf8_unicode_ci NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `class_id` int(11) NOT NULL,
  `student_section` enum('Day','Boarding') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Day',
  `guardian_id` int(11) NOT NULL,
  `photo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `registered_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_fee_accounts`
--

CREATE TABLE `student_fee_accounts` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `academic_year` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `term` enum('Term 1','Term 2','Term 3') COLLATE utf8_unicode_ci NOT NULL,
  `total_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total_paid` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discount_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `amount_paid` decimal(12,2) NOT NULL DEFAULT '0.00',
  `balance` decimal(12,2) NOT NULL DEFAULT '0.00',
  `status` enum('pending','partial','paid','overdue') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Stand-in structure for view `student_fee_balances`
-- (See below for the actual view)
--
CREATE TABLE `student_fee_balances` (
`student_id` int(11)
,`admission_no` varchar(50)
,`lin_no` varchar(50)
,`student_payment_code` varchar(50)
,`student_section` enum('Day','Boarding')
,`first_name` varchar(100)
,`last_name` varchar(100)
,`class_name` varchar(100)
,`section` varchar(50)
,`academic_year` varchar(20)
,`term` enum('Term 1','Term 2','Term 3')
,`total_amount` decimal(12,2)
,`discount_amount` decimal(12,2)
,`amount_paid` decimal(12,2)
,`balance` decimal(12,2)
,`status` enum('pending','partial','paid','overdue')
);

-- --------------------------------------------------------

--
-- Table structure for table `student_fee_items`
--

CREATE TABLE `student_fee_items` (
  `id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `fee_structure_id` int(11) DEFAULT NULL,
  `fee_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `amount_paid` decimal(12,2) NOT NULL DEFAULT '0.00',
  `balance` decimal(12,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_projects`
--

CREATE TABLE `student_projects` (
  `id` int(10) UNSIGNED NOT NULL,
  `project_code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `academic_year` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `term` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `instructions` longtext COLLATE utf8mb4_unicode_ci,
  `due_date` date DEFAULT NULL,
  `max_marks` decimal(8,2) NOT NULL DEFAULT '100.00',
  `resource_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resource_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resource_mime` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resource_size` bigint(20) UNSIGNED DEFAULT NULL,
  `status` enum('draft','published','closed','archived') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_project_submissions`
--

CREATE TABLE `student_project_submissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `student_name` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admission_no` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submission_text` longtext COLLATE utf8mb4_unicode_ci,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_mime` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` bigint(20) UNSIGNED DEFAULT NULL,
  `status` enum('submitted','late','reviewed','returned','missing') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'submitted',
  `marks` decimal(8,2) DEFAULT NULL,
  `feedback` text COLLATE utf8mb4_unicode_ci,
  `submitted_at` datetime DEFAULT NULL,
  `reviewed_by` int(11) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_term_reports`
--

CREATE TABLE `student_term_reports` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `report_level` enum('O_LEVEL','A_LEVEL') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'O_LEVEL',
  `student_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admission_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `student_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `class_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `term` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `academic_year` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_title` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class_teacher_comment` text COLLATE utf8mb4_unicode_ci,
  `headteacher_comment` text COLLATE utf8mb4_unicode_ci,
  `next_term_begins` date DEFAULT NULL,
  `term_closes` date DEFAULT NULL,
  `fees_balance` decimal(12,2) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_term_report_subjects`
--

CREATE TABLE `student_term_report_subjects` (
  `id` int(10) UNSIGNED NOT NULL,
  `report_id` int(10) UNSIGNED NOT NULL,
  `subject_code` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aoi2` decimal(5,2) DEFAULT NULL,
  `aoi1` decimal(5,2) DEFAULT NULL,
  `total_scores` decimal(6,2) DEFAULT NULL,
  `avg_score` decimal(6,2) DEFAULT NULL,
  `out20` decimal(5,2) DEFAULT NULL,
  `identifier_value` tinyint(4) DEFAULT NULL,
  `out80` decimal(5,2) DEFAULT NULL,
  `final_mark` decimal(5,2) DEFAULT NULL,
  `grade` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `points` decimal(6,2) DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `initials` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subject_notes`
--

CREATE TABLE `subject_notes` (
  `id` int(10) UNSIGNED NOT NULL,
  `note_code` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_year` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `term` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `note_content` longtext COLLATE utf8mb4_unicode_ci,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_mime` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` bigint(20) UNSIGNED DEFAULT NULL,
  `status` enum('draft','published','archived') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'published',
  `uploaded_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subject_notes`
--

INSERT INTO `subject_notes` (`id`, `note_code`, `title`, `subject_name`, `class_name`, `academic_year`, `term`, `topic`, `description`, `note_content`, `file_name`, `file_path`, `file_mime`, `file_size`, `status`, `uploaded_by`, `created_at`, `updated_at`) VALUES
(1, 'NOTE-20261109-4D10BA', 'introduction to linear equation', 'math', 'S.1 west', '2026', 'Term I', 'linear equation', 'alot', 'many', NULL, NULL, NULL, NULL, 'published', 1, '2026-11-09 22:49:02', '2026-11-09 22:49:02');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `supplier_no` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `supplier_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `contact_person` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8_unicode_ci,
  `tax_number` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bank_name` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bank_account` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `notes` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `supplier_payments`
--

CREATE TABLE `supplier_payments` (
  `id` int(11) NOT NULL,
  `payment_no` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `payment_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `payment_method_id` int(11) DEFAULT NULL,
  `reference_no` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `paid_by` int(11) NOT NULL,
  `status` enum('completed','cancelled','reversed') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'completed',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` int(11) NOT NULL,
  `teacher_no` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `other_names` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` enum('Male','Female','Other') COLLATE utf8_unicode_ci NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `phone` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nin_no` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8_unicode_ci,
  `department` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `specialization` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employment_date` date DEFAULT NULL,
  `salary` decimal(12,2) DEFAULT '0.00',
  `photo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `teacher_no`, `first_name`, `last_name`, `other_names`, `gender`, `date_of_birth`, `phone`, `email`, `nin_no`, `address`, `department`, `specialization`, `employment_date`, `salary`, `photo`, `status`, `created_by`, `created_at`) VALUES
(1, 'TCH23342266', 'Sseru', 'Mark', '', 'Male', '1984-11-24', '0774253625', 'sseru@gmail.com', '1122887653', '123456 kampala', 'Science', 'Math', '2024-06-03', 2000000.00, NULL, 'active', 1, '2026-11-09 22:41:01');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_student_attendance`
--

CREATE TABLE `teacher_student_attendance` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `student_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `attendance_date` date NOT NULL,
  `attendance_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Present',
  `remarks` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marked_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `full_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `role` enum('administrator','assistant_administrator','bursar','teacher') COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `full_name`, `role`, `status`, `created_at`) VALUES
(1, 'admin', '$2y$10$b80m2QDGnNiiaBw512Hh4uz5432l1BTNB2ndVd0vgEWMkZglPE2va', 'System Administrator', 'administrator', 'active', '2026-09-22 18:55:55'),
(6, 'Try', '$2y$10$sfYInvF.ycDG4EUUZ7FD1OQL1xsPwTIDmK..RzqOALmXZh./iRRf.', 'Try It now', 'administrator', 'active', '2026-11-24 11:21:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `budgets`
--
ALTER TABLE `budgets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_budget_user` (`created_by`),
  ADD KEY `idx_budget_year` (`academic_year`),
  ADD KEY `idx_budget_status` (`status`);

--
-- Indexes for table `budget_categories`
--
ALTER TABLE `budget_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `category_name` (`category_name`);

--
-- Indexes for table `budget_items`
--
ALTER TABLE `budget_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_budget_item_category` (`category_id`),
  ADD KEY `idx_budget_item_budget` (`budget_id`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_class` (`class_name`,`section`,`academic_year`);

--
-- Indexes for table `class_timetables`
--
ALTER TABLE `class_timetables`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_class_timetables_code` (`timetable_code`),
  ADD KEY `idx_timetable_class_day` (`class_name`,`day_of_week`),
  ADD KEY `idx_timetable_teacher_day` (`teacher_name`,`day_of_week`),
  ADD KEY `idx_timetable_year_term` (`academic_year`,`term`),
  ADD KEY `idx_timetable_status` (`status`);

--
-- Indexes for table `development_projects`
--
ALTER TABLE `development_projects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_development_project_no` (`project_no`),
  ADD KEY `idx_development_project_status` (`status`),
  ADD KEY `idx_development_project_dates` (`start_date`,`end_date`);

--
-- Indexes for table `development_project_expenses`
--
ALTER TABLE `development_project_expenses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_development_project_expense_no` (`expense_no`),
  ADD KEY `idx_project_expense_project` (`project_id`),
  ADD KEY `idx_project_expense_date` (`expense_date`),
  ADD KEY `idx_project_expense_status` (`status`);

--
-- Indexes for table `expense_categories`
--
ALTER TABLE `expense_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `category_name` (`category_name`);

--
-- Indexes for table `expense_transactions`
--
ALTER TABLE `expense_transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transaction_no` (`transaction_no`),
  ADD KEY `fk_expense_payment_method` (`payment_method_id`),
  ADD KEY `fk_expense_requested_by` (`requested_by`),
  ADD KEY `fk_expense_approved_by` (`approved_by`),
  ADD KEY `idx_expense_date` (`expense_date`),
  ADD KEY `idx_expense_category` (`category_id`),
  ADD KEY `idx_expense_status` (`status`),
  ADD KEY `idx_expense_supplier` (`supplier_id`);

--
-- Indexes for table `fee_payments`
--
ALTER TABLE `fee_payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `receipt_no` (`receipt_no`),
  ADD KEY `fk_fee_payment_method` (`payment_method_id`),
  ADD KEY `fk_fee_payment_user` (`received_by`),
  ADD KEY `idx_fee_payment_student` (`student_id`),
  ADD KEY `idx_fee_payment_account` (`account_id`),
  ADD KEY `idx_fee_payment_date` (`payment_date`),
  ADD KEY `idx_fee_payment_status` (`status`);

--
-- Indexes for table `fee_structures`
--
ALTER TABLE `fee_structures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_fee_structure_user` (`created_by`),
  ADD KEY `idx_fee_class` (`class_id`),
  ADD KEY `idx_fee_year_term` (`academic_year`,`term`),
  ADD KEY `idx_fee_status` (`status`);

--
-- Indexes for table `financial_accounts`
--
ALTER TABLE `financial_accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `account_code` (`account_code`);

--
-- Indexes for table `financial_transactions`
--
ALTER TABLE `financial_transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transaction_no` (`transaction_no`),
  ADD KEY `fk_financial_payment_method` (`payment_method_id`),
  ADD KEY `fk_financial_user` (`created_by`),
  ADD KEY `idx_financial_date` (`transaction_date`),
  ADD KEY `idx_financial_type` (`transaction_type`),
  ADD KEY `idx_financial_reference` (`reference_type`,`reference_id`),
  ADD KEY `idx_financial_status` (`status`);

--
-- Indexes for table `guardians`
--
ALTER TABLE `guardians`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `income_categories`
--
ALTER TABLE `income_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `category_name` (`category_name`);

--
-- Indexes for table `income_transactions`
--
ALTER TABLE `income_transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transaction_no` (`transaction_no`),
  ADD KEY `fk_income_payment_method` (`payment_method_id`),
  ADD KEY `fk_income_user` (`received_by`),
  ADD KEY `idx_income_date` (`income_date`),
  ADD KEY `idx_income_category` (`category_id`),
  ADD KEY `idx_income_status` (`status`);

--
-- Indexes for table `library_books`
--
ALTER TABLE `library_books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `isbn` (`isbn`),
  ADD KEY `idx_book_title` (`book_title`),
  ADD KEY `idx_book_category` (`category_id`);

--
-- Indexes for table `library_book_copies`
--
ALTER TABLE `library_book_copies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `accession_number` (`accession_number`),
  ADD KEY `idx_copy_book` (`book_id`),
  ADD KEY `idx_copy_status` (`availability_status`);

--
-- Indexes for table `library_categories`
--
ALTER TABLE `library_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `category_name` (`category_name`);

--
-- Indexes for table `library_fines`
--
ALTER TABLE `library_fines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_fine_loan` (`loan_id`);

--
-- Indexes for table `library_loans`
--
ALTER TABLE `library_loans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_loan_copy` (`copy_id`),
  ADD KEY `idx_loan_member` (`member_id`),
  ADD KEY `idx_loan_status` (`loan_status`),
  ADD KEY `idx_loan_due_date` (`due_date`);

--
-- Indexes for table `library_members`
--
ALTER TABLE `library_members`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `membership_number` (`membership_number`),
  ADD UNIQUE KEY `unique_library_member` (`member_type`,`member_id`),
  ADD KEY `idx_membership_type` (`member_type`);

--
-- Indexes for table `other_staff`
--
ALTER TABLE `other_staff`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_other_staff_no` (`staff_no`),
  ADD KEY `idx_other_staff_name` (`last_name`,`first_name`),
  ADD KEY `idx_other_staff_status` (`status`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `method_name` (`method_name`);

--
-- Indexes for table `salaries`
--
ALTER TABLE `salaries`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_salaries_salary_no` (`salary_no`),
  ADD KEY `idx_salaries_person` (`person_source`,`person_id`),
  ADD KEY `idx_salaries_status` (`status`);

--
-- Indexes for table `salary_payments`
--
ALTER TABLE `salary_payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `payment_no` (`payment_no`),
  ADD KEY `fk_salary_payment_method` (`payment_method_id`),
  ADD KEY `fk_salary_user` (`paid_by`),
  ADD KEY `idx_salary_teacher` (`teacher_id`),
  ADD KEY `idx_salary_month` (`payroll_month`),
  ADD KEY `idx_salary_status` (`status`);

--
-- Indexes for table `school_assets`
--
ALTER TABLE `school_assets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_school_assets_code` (`asset_code`),
  ADD KEY `idx_school_assets_category` (`category`),
  ADD KEY `idx_school_assets_status` (`asset_status`),
  ADD KEY `idx_school_assets_location` (`location`);

--
-- Indexes for table `school_exams`
--
ALTER TABLE `school_exams`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_school_exam_code` (`exam_code`),
  ADD KEY `idx_school_exam_class_year` (`class_name`,`academic_year`),
  ADD KEY `idx_school_exam_subject` (`subject_name`),
  ADD KEY `idx_school_exam_date` (`exam_date`),
  ADD KEY `idx_school_exam_status` (`status`);

--
-- Indexes for table `school_exam_results`
--
ALTER TABLE `school_exam_results`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_school_exam_result_exam` (`exam_id`),
  ADD KEY `idx_school_exam_result_student` (`student_id`),
  ADD KEY `idx_school_exam_result_grade` (`grade`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admission_no` (`admission_no`),
  ADD KEY `fk_student_guardian` (`guardian_id`),
  ADD KEY `fk_student_user` (`registered_by`),
  ADD KEY `idx_student_name` (`last_name`,`first_name`),
  ADD KEY `idx_student_class` (`class_id`),
  ADD KEY `idx_students_lin_no` (`lin_no`),
  ADD KEY `idx_students_payment_code` (`student_payment_code`);

--
-- Indexes for table `student_fee_accounts`
--
ALTER TABLE `student_fee_accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_student_term` (`student_id`,`academic_year`,`term`),
  ADD KEY `idx_student_fee_student` (`student_id`),
  ADD KEY `idx_student_fee_status` (`status`),
  ADD KEY `idx_student_fee_year_term` (`academic_year`,`term`);

--
-- Indexes for table `student_fee_items`
--
ALTER TABLE `student_fee_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_student_fee_item_structure` (`fee_structure_id`),
  ADD KEY `idx_fee_item_account` (`account_id`);

--
-- Indexes for table `student_projects`
--
ALTER TABLE `student_projects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_student_projects_code` (`project_code`),
  ADD KEY `idx_student_projects_class` (`class_name`),
  ADD KEY `idx_student_projects_subject` (`subject_name`),
  ADD KEY `idx_student_projects_status_due` (`status`,`due_date`),
  ADD KEY `idx_student_projects_year_term` (`academic_year`,`term`);

--
-- Indexes for table `student_project_submissions`
--
ALTER TABLE `student_project_submissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_project_student` (`project_id`,`student_id`),
  ADD KEY `idx_project_submissions_project` (`project_id`),
  ADD KEY `idx_project_submissions_student` (`student_id`),
  ADD KEY `idx_project_submissions_status` (`status`);

--
-- Indexes for table `student_term_reports`
--
ALTER TABLE `student_term_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_term_report_student` (`student_id`),
  ADD KEY `idx_term_report_class_term` (`class_name`,`term`,`academic_year`);

--
-- Indexes for table `student_term_report_subjects`
--
ALTER TABLE `student_term_report_subjects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_term_report_subject_report` (`report_id`);

--
-- Indexes for table `subject_notes`
--
ALTER TABLE `subject_notes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_subject_notes_code` (`note_code`),
  ADD KEY `idx_subject_notes_subject` (`subject_name`),
  ADD KEY `idx_subject_notes_class` (`class_name`),
  ADD KEY `idx_subject_notes_status` (`status`),
  ADD KEY `idx_subject_notes_year_term` (`academic_year`,`term`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `supplier_no` (`supplier_no`),
  ADD KEY `fk_supplier_user` (`created_by`),
  ADD KEY `idx_supplier_name` (`supplier_name`),
  ADD KEY `idx_supplier_status` (`status`);

--
-- Indexes for table `supplier_payments`
--
ALTER TABLE `supplier_payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `payment_no` (`payment_no`),
  ADD KEY `fk_supplier_payment_method` (`payment_method_id`),
  ADD KEY `fk_supplier_payment_user` (`paid_by`),
  ADD KEY `idx_supplier_payment_supplier` (`supplier_id`),
  ADD KEY `idx_supplier_payment_date` (`payment_date`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `teacher_no` (`teacher_no`),
  ADD KEY `fk_teacher_created_by` (`created_by`),
  ADD KEY `idx_teacher_name` (`last_name`,`first_name`),
  ADD KEY `idx_teacher_department` (`department`),
  ADD KEY `idx_teacher_status` (`status`);

--
-- Indexes for table `teacher_student_attendance`
--
ALTER TABLE `teacher_student_attendance`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_student_attendance` (`student_id`,`attendance_date`),
  ADD KEY `idx_class_date` (`class_id`,`attendance_date`),
  ADD KEY `idx_attendance_date` (`attendance_date`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `budgets`
--
ALTER TABLE `budgets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `budget_categories`
--
ALTER TABLE `budget_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `budget_items`
--
ALTER TABLE `budget_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `class_timetables`
--
ALTER TABLE `class_timetables`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `development_projects`
--
ALTER TABLE `development_projects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `development_project_expenses`
--
ALTER TABLE `development_project_expenses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `expense_categories`
--
ALTER TABLE `expense_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `expense_transactions`
--
ALTER TABLE `expense_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fee_payments`
--
ALTER TABLE `fee_payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fee_structures`
--
ALTER TABLE `fee_structures`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `financial_accounts`
--
ALTER TABLE `financial_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `financial_transactions`
--
ALTER TABLE `financial_transactions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `guardians`
--
ALTER TABLE `guardians`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `income_categories`
--
ALTER TABLE `income_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `income_transactions`
--
ALTER TABLE `income_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `library_books`
--
ALTER TABLE `library_books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `library_book_copies`
--
ALTER TABLE `library_book_copies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `library_categories`
--
ALTER TABLE `library_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `library_fines`
--
ALTER TABLE `library_fines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `library_loans`
--
ALTER TABLE `library_loans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `library_members`
--
ALTER TABLE `library_members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `other_staff`
--
ALTER TABLE `other_staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `salaries`
--
ALTER TABLE `salaries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `salary_payments`
--
ALTER TABLE `salary_payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `school_assets`
--
ALTER TABLE `school_assets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `school_exams`
--
ALTER TABLE `school_exams`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `school_exam_results`
--
ALTER TABLE `school_exam_results`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_fee_accounts`
--
ALTER TABLE `student_fee_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_fee_items`
--
ALTER TABLE `student_fee_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_projects`
--
ALTER TABLE `student_projects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_project_submissions`
--
ALTER TABLE `student_project_submissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_term_reports`
--
ALTER TABLE `student_term_reports`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_term_report_subjects`
--
ALTER TABLE `student_term_report_subjects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subject_notes`
--
ALTER TABLE `subject_notes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supplier_payments`
--
ALTER TABLE `supplier_payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `teacher_student_attendance`
--
ALTER TABLE `teacher_student_attendance`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

-- --------------------------------------------------------

--
-- Structure for view `student_fee_balances`
--
DROP TABLE IF EXISTS `student_fee_balances`;

CREATE ALGORITHM=UNDEFINED DEFINER=`sserumedia`@`localhost` SQL SECURITY INVOKER VIEW `student_fee_balances`  AS SELECT `s`.`id` AS `student_id`, `s`.`admission_no` AS `admission_no`, `s`.`lin_no` AS `lin_no`, `s`.`student_payment_code` AS `student_payment_code`, `s`.`student_section` AS `student_section`, `s`.`first_name` AS `first_name`, `s`.`last_name` AS `last_name`, `c`.`class_name` AS `class_name`, `c`.`section` AS `section`, `a`.`academic_year` AS `academic_year`, `a`.`term` AS `term`, `a`.`total_amount` AS `total_amount`, `a`.`discount_amount` AS `discount_amount`, `a`.`amount_paid` AS `amount_paid`, `a`.`balance` AS `balance`, `a`.`status` AS `status` FROM ((`student_fee_accounts` `a` join `students` `s` on((`s`.`id` = `a`.`student_id`))) join `classes` `c` on((`c`.`id` = `s`.`class_id`))) ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `budgets`
--
ALTER TABLE `budgets`
  ADD CONSTRAINT `fk_budget_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `budget_items`
--
ALTER TABLE `budget_items`
  ADD CONSTRAINT `fk_budget_item_budget` FOREIGN KEY (`budget_id`) REFERENCES `budgets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_budget_item_category` FOREIGN KEY (`category_id`) REFERENCES `budget_categories` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `expense_transactions`
--
ALTER TABLE `expense_transactions`
  ADD CONSTRAINT `fk_expense_approved_by` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_expense_category` FOREIGN KEY (`category_id`) REFERENCES `expense_categories` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_expense_payment_method` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_expense_requested_by` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_expense_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `fee_payments`
--
ALTER TABLE `fee_payments`
  ADD CONSTRAINT `fk_fee_payment_account` FOREIGN KEY (`account_id`) REFERENCES `student_fee_accounts` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_fee_payment_method` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_fee_payment_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_fee_payment_user` FOREIGN KEY (`received_by`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `fee_structures`
--
ALTER TABLE `fee_structures`
  ADD CONSTRAINT `fk_fee_structure_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_fee_structure_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `financial_transactions`
--
ALTER TABLE `financial_transactions`
  ADD CONSTRAINT `fk_financial_payment_method` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_financial_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `income_transactions`
--
ALTER TABLE `income_transactions`
  ADD CONSTRAINT `fk_income_category` FOREIGN KEY (`category_id`) REFERENCES `income_categories` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_income_payment_method` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_income_user` FOREIGN KEY (`received_by`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `library_books`
--
ALTER TABLE `library_books`
  ADD CONSTRAINT `fk_library_book_category` FOREIGN KEY (`category_id`) REFERENCES `library_categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `library_book_copies`
--
ALTER TABLE `library_book_copies`
  ADD CONSTRAINT `fk_library_copy_book` FOREIGN KEY (`book_id`) REFERENCES `library_books` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `library_fines`
--
ALTER TABLE `library_fines`
  ADD CONSTRAINT `fk_library_fine_loan` FOREIGN KEY (`loan_id`) REFERENCES `library_loans` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `library_loans`
--
ALTER TABLE `library_loans`
  ADD CONSTRAINT `fk_library_loan_copy` FOREIGN KEY (`copy_id`) REFERENCES `library_book_copies` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_library_loan_member` FOREIGN KEY (`member_id`) REFERENCES `library_members` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `salary_payments`
--
ALTER TABLE `salary_payments`
  ADD CONSTRAINT `fk_salary_payment_method` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_salary_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_salary_user` FOREIGN KEY (`paid_by`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `fk_student_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`),
  ADD CONSTRAINT `fk_student_guardian` FOREIGN KEY (`guardian_id`) REFERENCES `guardians` (`id`),
  ADD CONSTRAINT `fk_student_user` FOREIGN KEY (`registered_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `student_fee_accounts`
--
ALTER TABLE `student_fee_accounts`
  ADD CONSTRAINT `fk_student_fee_account_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `student_fee_items`
--
ALTER TABLE `student_fee_items`
  ADD CONSTRAINT `fk_student_fee_item_account` FOREIGN KEY (`account_id`) REFERENCES `student_fee_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_student_fee_item_structure` FOREIGN KEY (`fee_structure_id`) REFERENCES `fee_structures` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `student_term_report_subjects`
--
ALTER TABLE `student_term_report_subjects`
  ADD CONSTRAINT `fk_term_report_subject_report` FOREIGN KEY (`report_id`) REFERENCES `student_term_reports` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD CONSTRAINT `fk_supplier_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `supplier_payments`
--
ALTER TABLE `supplier_payments`
  ADD CONSTRAINT `fk_supplier_payment_method` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_supplier_payment_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_supplier_payment_user` FOREIGN KEY (`paid_by`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `teachers`
--
ALTER TABLE `teachers`
  ADD CONSTRAINT `fk_teacher_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
